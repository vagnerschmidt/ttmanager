# Guia de Implantação e Publicação na HostGator 🌐

Este guia fornece o passo a passo completo para você publicar o **TT Manager Pro** na sua hospedagem paga da **HostGator** (Compartilhada, VPS ou Dedicada) utilizando o painel cPanel ou acesso FTP.

---

## 🚀 Resumo do Processo

Como o TT Manager Pro é um aplicativo React construído com **Vite**, toda a sua lógica de visualização e roteamento roda diretamente no navegador do usuário (Client-Side). Para publicá-lo na HostGator, você só precisa gerar a pasta compilada (`dist`) e enviar os arquivos estáticos para o servidor.

Nós já pré-configuramos um arquivo `.htaccess` na pasta `public/` do seu projeto. Quando você gerar a versão de produção, ele será copiado automaticamente para a pasta de destino para garantir que o roteamento de links diretos (como `/atletas` ou `/resultados`) funcione 100% sem erros 404!

---

## 📦 Passo 1: Gerar a Versão de Produção localmente

1. No seu terminal (no seu computador local), instale as dependências se ainda não o fez:
   ```bash
   npm install
   ```
2. Execute o comando de compilação de produção:
   ```bash
   npm run build
   ```
3. Este comando criará uma pasta chamada `dist` na raiz do seu projeto. Esta pasta contém todos os arquivos otimizados (HTML, CSS, JavaScript, imagens e o arquivo `.htaccess`).

---

## 📁 Passo 2: Enviar os arquivos para a HostGator

Você pode enviar os arquivos da pasta `dist` para a HostGator de duas maneiras principais:

### Opção A: Pelo Gerenciador de Arquivos do cPanel (Recomendado para iniciantes)

1. Faça login no seu painel de controle **cPanel** da HostGator.
2. Procure pela ferramenta **Gerenciador de Arquivos** (File Manager).
3. No menu lateral, navegue até a pasta **`public_html`** (esta é a pasta pública principal do seu domínio). 
   * *Nota:* Se for um subdomínio (ex: `torneios.seudominio.com`), navegue até a pasta correspondente configurada para ele.
4. No seu computador, compacte todo o conteúdo de dentro da pasta `dist` em um arquivo **`.zip`** (selecione os arquivos de dentro de `dist` e crie o ZIP, não compacte a pasta `dist` em si).
5. No Gerenciador de Arquivos do cPanel, clique em **Carregar** (Upload) e envie o arquivo `.zip`.
6. Após concluir o envio, selecione o arquivo `.zip` no cPanel e clique em **Extrair** (Extract).
7. Certifique-se de que o arquivo `.htaccess` e o arquivo `index.html` ficaram diretamente na raiz da sua pasta `public_html`.

### Opção B: Por FTP (Recomendado para desenvolvedores)

1. Use um cliente de FTP de sua preferência (como o **FileZilla**).
2. Conecte-se ao seu servidor HostGator usando os dados de FTP fornecidos no e-mail de boas-vindas da HostGator ou criados no cPanel.
   * **Host:** `ftp.seudominio.com.br` ou o IP do servidor.
   * **Usuário:** Seu usuário do cPanel.
   * **Senha:** Sua senha do cPanel.
   * **Porta:** `21`
3. No painel esquerdo (seu computador), acesse a pasta `dist` do projeto.
4. No painel direito (servidor), navegue até a pasta `public_html`.
5. Arraste e solte todos os arquivos e pastas de dentro de `dist` para dentro da pasta `public_html`.

---

## 🛠️ Detalhes Importantes para Funcionamento 100%

### 1. Suporte a Rotas do React Router (Amigáveis)
Em servidores Apache (padrão HostGator), recarregar a página em um endereço amigável como `http://seudominio.com/atletas` pode causar um erro `404 Not Found`.
Para evitar isso, incluímos o arquivo `.htaccess` com a seguinte regra automática:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]
  RewriteRule ^ index.html [L]
</IfModule>
```
*Isto garante que qualquer rota digitada redirecione para o aplicativo React decidir qual página exibir!*

### 2. HTTPS e Certificado SSL Grátis
A HostGator oferece **SSL Grátis** para todos os domínios. Recomendamos ativar para que as conexões com o banco de dados Firebase e recursos de sincronização funcionem perfeitamente.
No cPanel:
1. Procure por **Let's Encrypt SSL** ou **SSL/TLS Status**.
2. Selecione seu domínio e clique em **Run AutoSSL** para ativar o certificado de segurança (HTTPS).

### 3. Conexão com Firebase Firestore
Seu aplicativo utiliza o Firebase como banco de dados em nuvem. Ao publicar na HostGator, os dados continuarão salvos e sincronizados perfeitamente na sua conta do Firebase, pois o aplicativo faz chamadas diretas de API em nuvem a partir do navegador do cliente. Certifique-se de que suas regras de segurança do Firebase estão devidamente configuradas!
