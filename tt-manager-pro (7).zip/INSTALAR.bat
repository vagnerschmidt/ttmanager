@echo off
chcp 65001 >nul
title TT Manager Pro - Instalador
color 0B

echo ============================================================
echo             TT MANAGER PRO - INSTALACAO COMPLETA
echo ============================================================
echo.

:: -----------------------------------------------------------------
:: 1) Verificar se o Node.js esta instalado
:: -----------------------------------------------------------------
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] O Node.js nao foi encontrado neste computador.
    echo.
    echo O TT Manager Pro precisa do Node.js para funcionar.
    echo Vou abrir a pagina de download oficial para voce instalar.
    echo.
    echo Depois de instalar o Node.js, feche esta janela e
    echo execute o INSTALAR.bat novamente.
    echo.
    start https://nodejs.org/pt-br
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node -v') do set NODE_VERSION=%%v
echo [OK] Node.js encontrado: %NODE_VERSION%
echo.

:: -----------------------------------------------------------------
:: 2) Instalar dependencias do projeto
:: -----------------------------------------------------------------
echo ------------------------------------------------------------
echo Instalando dependencias do sistema (pode levar alguns minutos)...
echo ------------------------------------------------------------
call npm install
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Falha ao instalar as dependencias.
    echo Verifique sua conexao com a internet e tente novamente.
    pause
    exit /b 1
)
echo.
echo [OK] Dependencias instaladas com sucesso!
echo.

:: -----------------------------------------------------------------
:: 3) Gerar build de producao
:: -----------------------------------------------------------------
echo ------------------------------------------------------------
echo Gerando versao de producao do sistema...
echo ------------------------------------------------------------
call npm run build
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Falha ao gerar o build do sistema.
    pause
    exit /b 1
)
echo.
echo [OK] Build gerado com sucesso!
echo.

:: -----------------------------------------------------------------
:: 4) Criar o atalho INICIAR.bat para uso no dia a dia
:: -----------------------------------------------------------------
call :criarIniciar

:: -----------------------------------------------------------------
:: 5) Descobrir o IP local da rede (para acesso via Android/tablet)
:: -----------------------------------------------------------------
set LOCAL_IP=
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    if not defined LOCAL_IP (
        set LOCAL_IP=%%a
    )
)
set LOCAL_IP=%LOCAL_IP: =%

echo ============================================================
echo         INSTALACAO CONCLUIDA COM SUCESSO!
echo ============================================================
echo.
echo O sistema vai abrir automaticamente neste computador.
echo.
echo Para usar no CELULAR / TABLET ANDROID (mesmo Wi-Fi deste PC):
echo   1. Conecte o celular na MESMA rede Wi-Fi deste computador.
echo   2. Abra o navegador (Chrome) no celular.
echo   3. Digite o endereco abaixo:
echo.
echo        http://%LOCAL_IP%:4173
echo.
echo   4. Toque no menu do Chrome (tres pontinhos) e escolha
echo      "Adicionar a tela inicial" para instalar como um app.
echo.
echo Da proxima vez que quiser usar o TT Manager Pro no PC, basta
echo clicar duas vezes no arquivo INICIAR.bat criado nesta pasta.
echo ============================================================
echo.

start http://localhost:4173
call npm run preview -- --port 4173

pause
exit /b 0

:criarIniciar
(
echo @echo off
echo chcp 65001 ^>nul
echo title TT Manager Pro
echo color 0B
echo.
echo set LOCAL_IP=
echo for /f "tokens=2 delims=:" %%%%a in ^('ipconfig ^^^| findstr /c:"IPv4"'^) do ^(
echo     if not defined LOCAL_IP set LOCAL_IP=%%%%a
echo ^)
echo set LOCAL_IP=%%LOCAL_IP: =%%
echo.
echo echo ============================================================
echo echo   TT MANAGER PRO
echo echo ============================================================
echo echo Neste computador:   http://localhost:4173
echo echo No celular/tablet Android ^(mesma rede Wi-Fi^): 
echo echo   http://%%LOCAL_IP%%:4173
echo echo ============================================================
echo echo.
echo start http://localhost:4173
echo call npm run preview -- --port 4173
) > INICIAR.bat
exit /b 0
