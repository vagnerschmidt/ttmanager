import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const PUBLIC_DIR = path.join(process.cwd(), 'public');
const DIST_DIR = path.join(process.cwd(), 'dist');

async function processDirectory(directory) {
  if (!fs.existsSync(directory)) return;

  const entries = fs.readdirSync(directory, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(directory, entry.name);

    if (entry.isDirectory()) {
      await processDirectory(fullPath);
    } else if (/\.(png|jpe?g|webp)$/i.test(entry.name) && !entry.name.includes('.min.')) {
      try {
        const ext = path.extname(entry.name).toLowerCase();
        const baseName = path.basename(entry.name, ext);
        const webpPath = path.join(directory, `${baseName}.webp`);

        // Convert to optimized WebP if WebP does not exist or if file is PNG/JPG
        if (!fs.existsSync(webpPath) || ext !== '.webp') {
          console.log(`[Image Optimizer] Compressing: ${entry.name}`);
          await sharp(fullPath)
            .resize({ width: 1920, withoutEnlargement: true }) // Limit max width to 1920px
            .webp({ quality: 80, effort: 6 })
            .toFile(webpPath + '.tmp');

          fs.renameSync(webpPath + '.tmp', webpPath);
          console.log(`[Image Optimizer] Saved optimized WebP: ${path.basename(webpPath)}`);
        }
      } catch (err) {
        console.warn(`[Image Optimizer] Skipped ${entry.name}:`, err.message);
      }
    }
  }
}

async function main() {
  console.log('🚀 Iniciando script de otimização e minificação de imagens para Vercel...');
  await processDirectory(PUBLIC_DIR);
  await processDirectory(DIST_DIR);
  console.log('✅ Otimização de imagens concluída com sucesso!');
}

main();
