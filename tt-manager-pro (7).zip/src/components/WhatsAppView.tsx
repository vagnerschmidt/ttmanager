import React, { useState, useEffect } from 'react';
import { Atleta, Arbitro } from '../types';
import { Share2, Phone, Volume2, Info, MessageSquare } from 'lucide-react';
import { normalizePhoneToBrazil } from '../utils/phone';

interface WhatsAppViewProps {
  atletas: Atleta[];
  arbitros: Arbitro[];
}

export default function WhatsAppView({ atletas, arbitros }: WhatsAppViewProps) {
  const [activeTab, setActiveTab] = useState<'convocacao' | 'resultado' | 'ranking' | 'livre'>('convocacao');
  const [destinationType, setDestinationType] = useState('Todos os Atletas');
  const [customPhone, setCustomPhone] = useState('');
  const [message, setMessage] = useState('');

  // Built-in presets
  const convocacaoPreset = `🏓 *TT Manager Pro*\n\nOlá, atleta!\n\nVocê está convocado(a) para participar do próximo torneio oficial.\n\n📅 Data: ${new Date().toLocaleDateString('pt-BR')}\n📍 Local: Ginásio Poliesportivo Municipal\n\nPor favor, responda confirmando sua presença e categoria desejada!\n\n_A Direção Esportiva_`;
  
  const resultadoPreset = `🏓 *Resultado das Finais*\n\nConfronto Oficial:\n*Carlos Mendes* 🆚 *Pedro Alves*\nSets: 3 x 1 (Grande Final)\n\nParabéns aos atletas pelo excelente desempenho! 🏆\n\n_Associação Copa TT_`;

  // Dynamic ranking string builder
  const getRankingPreset = () => {
    const top5 = [...atletas].sort((x, y) => y.rating - x.rating).slice(0, 5);
    const rankingLines = top5.map((a, i) => `${i + 1}. *${a.nome}* — ${a.rating} pts (${a.clube || 'Livre'})`).join('\n');
    return `🏓 *TOP 5 ATLETAS ATUAL*\n\nClassificação por Rating:\n${rankingLines || 'Nenhum atleta registrado.'}\n\nEvolua o seu jogo e suba na classificação geral!\n\n_TT Manager Pro_`;
  };

  // Switch tab callback
  useEffect(() => {
    if (activeTab === 'convocacao') {
      setMessage(convocacaoPreset);
    } else if (activeTab === 'resultado') {
      setMessage(resultadoPreset);
    } else if (activeTab === 'ranking') {
      setMessage(getRankingPreset());
    } else {
      setMessage('');
    }
  }, [activeTab]);

  // WhatsApp bold rendering replacement utility
  const formatWhatsappPreview = (text: string) => {
    if (!text) return 'Escreva uma mensagem para pré-visualizar...';
    // Match *text* for bolding
    let formatted = text.replace(/\*(.*?)\*/g, '<strong class="font-extrabold text-yellow-400">$1</strong>');
    // Match _text_ for italics
    formatted = formatted.replace(/_(.*?)_/g, '<em class="italic text-slate-350">$1</em>');
    // Match custom breaks
    return formatted.split('\n').map((line, idx) => (
      <React.Fragment key={idx}>
        <span dangerouslySetInnerHTML={{ __html: formatted }} />
        {idx < text.split('\n').length - 1 && <br />}
      </React.Fragment>
    ));
  };

  const handleSend = () => {
    if (!message.trim()) {
      alert("Escreva uma mensagem!");
      return;
    }
    const normalized = normalizePhoneToBrazil(customPhone);
    let cleanPhone = normalized.replace(/\D/g, '');
    const encodedText = encodeURIComponent(message);
    const openUrl = cleanPhone 
      ? `https://wa.me/${cleanPhone}?text=${encodedText}` 
      : `https://wa.me/?text=${encodedText}`;
    
    window.open(openUrl, '_blank');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Parameters Controls */}
      <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-sm">
        <h3 className="font-bold text-slate-100 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-yellow-400" />
          Configurar Envio
        </h3>

        {/* Preset Tabs selection */}
        <div className="flex bg-slate-950 p-1 border border-slate-850 rounded-lg select-none">
          {['convocacao', 'resultado', 'ranking', 'livre'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`flex-1 py-1.5 px-1 text-2xs font-extrabold uppercase rounded-lg tracking-wider transition ${
                activeTab === tab ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab === 'convocacao' ? 'Convocação' : tab === 'resultado' ? 'Resultado' : tab === 'ranking' ? 'Ranking' : 'Livre'}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Grupo Destino</label>
            <select
              value={destinationType}
              onChange={(e) => setDestinationType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-250 rounded-lg px-3 py-2 text-sm outline-none"
            >
              <option>Todos os Atletas</option>
              <option>Árbitros</option>
              <option>Número Específico</option>
            </select>
          </div>

          {destinationType === 'Número Específico' && (
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Número do Celular (+55...)</label>
              <input
                type="text"
                placeholder="+5511999990000"
                value={customPhone}
                onChange={(e) => setCustomPhone(e.target.value)}
                onBlur={() => setCustomPhone(prev => normalizePhoneToBrazil(prev))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Corpo da Mensagem</label>
            <textarea
              rows={8}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Digite aqui sua mensagem. Use asteriscos para negrito: *sua mensagem*..."
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs outline-none transition font-sans leading-relaxed"
            />
          </div>

          <button
            onClick={handleSend}
            className="w-full bg-green-500 hover:bg-green-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
          >
            <Share2 className="w-4 h-4" />
            Abrir no WhatsApp
          </button>
        </div>
      </div>

      {/* Screen Preview */}
      <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-6 rounded-xl flex flex-col justify-between shadow-sm">
        <h3 className="font-bold text-slate-200 mb-4 text-xs uppercase tracking-wider text-slate-400 flex items-center gap-2">
          Pré-visualização da Notificação
        </h3>

        {/* Beautiful mock chat box screen overlay */}
        <div className="flex-1 bg-[#0b141a]/95 border border-emerald-950 rounded-xl p-5 mb-5 relative min-h-[300px]">
          <div className="absolute top-2 right-4 text-emerald-500/20 text-4xl select-none select-none pointer-events-none">
            WhatsApp
          </div>

          <div className="border-l-4 border-emerald-500 bg-[#111b21] p-4.5 rounded-r-lg rounded-bl-lg max-w-[90%] text-[13px] leading-relaxed text-[#e9edef] font-sans shadow-md">
            
            {/* Display message using whatsapp formatting mock elements styled cleanly */}
            <div className="text-[#e9edef] leading-relaxed">
              {message ? (
                message.split('\n').map((line, lineIdx) => {
                  // Match bold elements
                  const segments = line.split(/(\*.*?\*)/g);
                  return (
                    <div key={lineIdx} className="min-h-[1rem]">
                      {segments.map((seg, segIdx) => {
                        if (seg.startsWith('*') && seg.endsWith('*')) {
                          return (
                            <strong key={segIdx} className="font-black text-emerald-400">
                              {seg.slice(1, -1)}
                            </strong>
                          );
                        }
                        // Match italic elements
                        const italicSegs = seg.split(/(_.*?_)/g);
                        return italicSegs.map((ital, italIdx) => {
                          if (ital.startsWith('_') && ital.endsWith('_')) {
                            return (
                              <em key={italIdx} className="italic text-slate-300">
                                {ital.slice(1, -1)}
                              </em>
                            );
                          }
                          return ital;
                        });
                      })}
                    </div>
                  );
                })
              ) : (
                <span className="text-slate-500 italic">Escreva uma mensagem para visualizar o resultado...</span>
              )}
            </div>

            <div className="text-right text-[10px] text-slate-500 mt-2 font-mono">
              {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} ✓✓
            </div>
          </div>
        </div>

        <div className="p-3.5 bg-slate-950/20 border border-slate-800 rounded-lg flex items-start gap-2.5 text-xs text-slate-400 leading-relaxed">
          <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
          <p>
            Esta ferramenta gera uma mensagem formatada especificamente para o aplicativo WhatsApp. Ao clicar em enviar, se houver um número de telefone informado, ela abrirá a janela de conversa direta, caso contrário, abrirá e permitirá que você escolha o contato ou grupo manualmente.
          </p>
        </div>
      </div>

    </div>
  );
}
