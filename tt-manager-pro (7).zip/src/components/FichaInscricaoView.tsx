import React, { useState } from 'react';
import { Atleta, Torneio, Arbitro, Funcionario, Treinador, Inscricao, SystemConfig } from '../types';
import { 
  Printer, 
  FileText, 
  Info, 
  IdCard, 
  Users, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  Search, 
  QrCode, 
  Sparkles, 
  DollarSign, 
  Award, 
  CheckSquare, 
  UserPlus, 
  ChevronRight,
  Edit,
  Save,
  Copy,
  Check
} from 'lucide-react';
import { triggerToast } from '../utils/toast';
import { generatePixPayload, getPixQRCodeUrl, generateAthleteId, generatePaymentId, generateUUID } from '../utils/pix';
import { normalizePhoneToBrazil } from '../utils/phone';

interface FichaInscricaoViewProps {
  atletas: Atleta[];
  torneios: Torneio[];
  arbitros: Arbitro[];
  funcionarios: Funcionario[];
  treinadores: Treinador[];
  inscricoes: Inscricao[];
  config?: SystemConfig;
  onSaveTreinadores: (treinadores: Treinador[]) => void;
  onSaveInscricoes: (inscricoes: Inscricao[]) => void;
  userRole?: string;
}

type SubSection = 'ficha' | 'inscricoes' | 'treinadores' | 'crachas';

export default function FichaInscricaoView({
  atletas,
  torneios,
  arbitros,
  funcionarios,
  treinadores,
  inscricoes,
  config,
  onSaveTreinadores,
  onSaveInscricoes
}: FichaInscricaoViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<SubSection>('crachas');

  // --- TAB 1: ORIGINAL FICHA FÍSICA STATES ---
  const [selectedAtletaId, setSelectedAtletaId] = useState('');
  const [selectedTorneioId, setSelectedTorneioId] = useState('');
  const [selectedCategoria, setSelectedCategoria] = useState('Simples Masculino');
  const [inscricaoNumero, setInscricaoNumero] = useState('001');
  const [observacoes, setObservacoes] = useState('');

  const selectedAtleta = atletas.find(a => a.id === selectedAtletaId);
  const selectedTorneio = torneios.find(t => t.id === selectedTorneioId);

  // --- TAB 2: GESTÃO DE INSCRIÇÕES STATES ---
  const [insAtletaId, setInsAtletaId] = useState('');
  const [insTorneioId, setInsTorneioId] = useState('');
  const [insCategoria, setInsCategoria] = useState('');
  const [insValorTaxa, setInsValorTaxa] = useState('80.00');
  const [insStatusPagamento, setInsStatusPagamento] = useState<'Pendente' | 'Pago' | 'Isento'>('Pendente');
  const [insTreinadorId, setInsTreinadorId] = useState('');
  const [insSearchText, setInsSearchText] = useState('');

  // --- TAB 3: GESTÃO DE TREINADORES STATES ---
  const [trNome, setTrNome] = useState('');
  const [trClube, setTrClube] = useState('');
  const [trCref, setTrCref] = useState('');
  const [trWa, setTrWa] = useState('');
  const [trEmail, setTrEmail] = useState('');
  const [trSearchText, setTrSearchText] = useState('');
  const [editingCoachId, setEditingCoachId] = useState<string | null>(null);

  // --- TAB 4: CRACHÁ ONLINE STATES ---
  const [crachaRole, setCrachaRole] = useState<'Atleta' | 'Treinador' | 'Arbitro' | 'Funcionario'>('Atleta');
  const [selectedPersonId, setSelectedPersonId] = useState('');

  // --- PIX MODAL STATES FOR REGISTERED ATHLETES ---
  const [selectedPixInscription, setSelectedPixInscription] = useState<Inscricao | null>(null);
  const [isPixModalOpen, setIsPixModalOpen] = useState(false);
  const [overridePixKey, setOverridePixKey] = useState('');
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedPayload, setCopiedPayload] = useState(false);

  const modalPixPayload = selectedPixInscription ? (
    overridePixKey 
      ? generatePixPayload({
          key: overridePixKey,
          amount: parseFloat(selectedPixInscription.valorTaxa || '0'),
          recipientName: torneios.find(t => t.id === selectedPixInscription.torneioId)?.org || config?.org || 'Campeonato Tenis de Mesa',
          recipientCity: torneios.find(t => t.id === selectedPixInscription.torneioId)?.cidade || 'Sao Paulo',
          txid: selectedPixInscription.pixTransactionUuid || selectedPixInscription.identificadorPagamento || generatePaymentId(selectedPixInscription.id)
        })
      : (selectedPixInscription.pixPayloadString || generatePixPayload({
          key: torneios.find(t => t.id === selectedPixInscription.torneioId)?.pixKey || config?.pixKey || 'pix.campeonato@associacaott.org',
          amount: parseFloat(selectedPixInscription.valorTaxa || '0'),
          recipientName: torneios.find(t => t.id === selectedPixInscription.torneioId)?.org || config?.org || 'Campeonato Tenis de Mesa',
          recipientCity: torneios.find(t => t.id === selectedPixInscription.torneioId)?.cidade || 'Sao Paulo',
          txid: selectedPixInscription.pixTransactionUuid || selectedPixInscription.identificadorPagamento || generatePaymentId(selectedPixInscription.id)
        }))
  ) : '';

  const modalPixQrCodeUrl = selectedPixInscription ? (
    overridePixKey 
      ? getPixQRCodeUrl(modalPixPayload, 300)
      : (selectedPixInscription.pixQrCodeUrl || getPixQRCodeUrl(modalPixPayload, 300))
  ) : '';

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key)
      .then(() => {
        setCopiedKey(true);
        triggerToast("Chave Pix copiada com sucesso!", "success");
        setTimeout(() => setCopiedKey(false), 2000);
      })
      .catch(() => triggerToast("Erro ao copiar! Copie manualmente.", "error"));
  };

  const handleCopyPayload = (payload: string) => {
    navigator.clipboard.writeText(payload)
      .then(() => {
        setCopiedPayload(true);
        triggerToast("Código Pix Copia e Cola copiado!", "success");
        setTimeout(() => setCopiedPayload(false), 2000);
      })
      .catch(() => triggerToast("Erro ao copiar!", "error"));
  };

  // Handlers
  const handlePrint = () => {
    window.print();
  };

  // Auto set fee and category based on tournament choice
  const handleTournamentSelectForInscription = (id: string) => {
    setInsTorneioId(id);
    const torn = torneios.find(t => t.id === id);
    if (torn) {
      setInsValorTaxa(torn.taxa || '80.00');
    }
  };

  // Add athlete tournament enrollment (Inscrição)
  const handleAddInscription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!insAtletaId || !insTorneioId || !insCategoria) {
      triggerToast('Preencha o atleta, torneio e categoria de entrada!', 'error');
      return;
    }

    // Check duplicate
    const exists = inscricoes.find(
      i => i.atletaId === insAtletaId && i.torneioId === insTorneioId && i.categoria === insCategoria
    );
    if (exists) {
      triggerToast('Inscrição já existente para este atleta, torneio e categoria!', 'error');
      return;
    }

    const nextConfirmada = insStatusPagamento === 'Pago' || insStatusPagamento === 'Isento';
    const targetAtl = atletas.find(a => a.id === insAtletaId);
    const targetTorn = torneios.find(t => t.id === insTorneioId);
    
    // Generate distinct identifiers for the athlete and payment
    const athleteCode = targetAtl ? generateAthleteId(targetAtl.id, targetAtl.cpf) : `ATL-2026-GEN-${Math.floor(100 + Math.random()*900)}`;
    const paymentId = 'TX-PIX-' + Date.now().toString().slice(-6);
    const transactionUuid = generateUUID();

    // Pre-calculate Pix details to be stored directly inside the enrollment object
    const finalAmountString = insStatusPagamento === 'Isento' ? '0.00' : insValorTaxa;
    let computedPixPayload = '';
    let computedQrCodeUrl = '';
    
    if (parseFloat(finalAmountString) > 0) {
      computedPixPayload = generatePixPayload({
        key: targetTorn?.pixKey || config?.pixKey || 'pix.campeonato@associacaott.org',
        amount: parseFloat(finalAmountString),
        recipientName: targetTorn?.org || config?.org || 'Campeonato Tenis de Mesa',
        recipientCity: targetTorn?.cidade || 'Sao Paulo',
        txid: transactionUuid
      });
      computedQrCodeUrl = getPixQRCodeUrl(computedPixPayload, 300);
    }

    const newInscricao: Inscricao = {
      id: 'ins-' + Date.now(),
      atletaId: insAtletaId,
      torneioId: insTorneioId,
      categoria: insCategoria,
      valorTaxa: finalAmountString,
      statusPagamento: insStatusPagamento,
      confirmada: nextConfirmada,
      treinadorId: insTreinadorId || undefined,
      identificadorAtleta: athleteCode,
      identificadorPagamento: paymentId,
      pixPayloadString: computedPixPayload || undefined,
      pixQrCodeUrl: computedQrCodeUrl || undefined,
      pixTransactionUuid: transactionUuid
    };

    const updated = [newInscricao, ...inscricoes];
    onSaveInscricoes(updated);
    
    // Clear form
    setInsAtletaId('');
    setInsCategoria('');
    setInsTreinadorId('');
    
    if (!nextConfirmada) {
      // Auto open PIX generation modal for athletic payment checkout
      setSelectedPixInscription(newInscricao);
      setIsPixModalOpen(true);
      setOverridePixKey('');
      triggerToast('Inscrição registrada! Finalize seu pagamento no Pix ao lado.', 'info');
    } else {
      triggerToast('Inscrição realizada e confirmada com sucesso!', 'success');
    }
  };

  // Delete subscription
  const handleDeleteInscription = (id: string) => {
    const updated = inscricoes.filter(i => i.id !== id);
    onSaveInscricoes(updated);
    triggerToast('Inscrição removida!', 'info');
  };

  // Confirm payment in-place
  const handleTogglePaymentStatus = (id: string, nextStatus: 'Pendente' | 'Pago' | 'Isento') => {
    const updated = inscricoes.map(i => {
      if (i.id === id) {
        const nextConfirm = nextStatus === 'Pago' || nextStatus === 'Isento';
        return {
          ...i,
          statusPagamento: nextStatus,
          confirmada: nextConfirm,
          valorTaxa: nextStatus === 'Isento' ? '0.00' : i.valorTaxa === '0.00' ? '80.00' : i.valorTaxa
        };
      }
      return i;
    });
    onSaveInscricoes(updated);
    triggerToast(`Status de pagamento alterado para ${nextStatus}!`, 'success');
  };

  // Add / Edit customized Coach (Treinador)
  const handleAddCoach = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trNome || !trCref) {
      triggerToast('Nome do treinador e registro CREF são obrigatórios!', 'error');
      return;
    }

    if (editingCoachId) {
      // Edit mode
      const updated = treinadores.map(t => {
        if (t.id === editingCoachId) {
          return {
            ...t,
            nome: trNome.toUpperCase(),
            clube: trClube.toUpperCase() || 'INDIVIDUAL',
            cref: trCref.toUpperCase(),
            wa: normalizePhoneToBrazil(trWa),
            email: trEmail
          };
        }
        return t;
      });
      onSaveTreinadores(updated);
      setEditingCoachId(null);
      triggerToast('Cadastro de treinador atualizado com sucesso!', 'success');
    } else {
      // Create mode
      const nCoach: Treinador = {
        id: 'tr-' + Date.now(),
        nome: trNome.toUpperCase(),
        clube: trClube.toUpperCase() || 'INDIVIDUAL',
        cref: trCref.toUpperCase(),
        wa: normalizePhoneToBrazil(trWa),
        email: trEmail,
        status: 'Ativo'
      };
      onSaveTreinadores([...treinadores, nCoach]);
      triggerToast('Treinador cadastrado com sucesso!', 'success');
    }
    
    // reset
    setTrNome('');
    setTrClube('');
    setTrCref('');
    setTrWa('');
    setTrEmail('');
  };

  const handleStartEditCoach = (tr: Treinador) => {
    setEditingCoachId(tr.id);
    setTrNome(tr.nome);
    setTrClube(tr.clube === 'INDIVIDUAL' ? '' : tr.clube);
    setTrCref(tr.cref);
    setTrWa(tr.wa || '');
    setTrEmail(tr.email || '');
    triggerToast(`Editando dados de ${tr.nome}`, 'info');
  };

  const handleCancelEditCoach = () => {
    setEditingCoachId(null);
    setTrNome('');
    setTrClube('');
    setTrCref('');
    setTrWa('');
    setTrEmail('');
  };

  // Delete Coach
  const handleDeleteCoach = (id: string) => {
    if (editingCoachId === id) {
      handleCancelEditCoach();
    }
    const updated = treinadores.filter(t => t.id !== id);
    onSaveTreinadores(updated);
    triggerToast('Treinador removido!', 'info');
  };

  // Get active person for badge generation
  const getBadgePersonDetails = () => {
    if (crachaRole === 'Atleta') {
      const atl = atletas.find(a => a.id === selectedPersonId) || atletas[0];
      if (!atl) return null;
      // Find tournament inscriptions
      const ins = inscricoes.filter(i => i.atletaId === atl.id);
      const isConfirmed = ins.length > 0 ? ins.every(i => i.confirmada) : false;
      const associatedTournaments = ins.map(i => {
        const t = torneios.find(torn => torn.id === i.torneioId);
        return {
          torneioNome: t?.nome || 'Torneio',
          status: i.statusPagamento,
          confirmada: i.confirmada,
          categoria: i.categoria
        };
      });

      return {
        id: atl.id,
        nome: atl.nome,
        sub: atl.clube || 'Nenhum Clube',
        detailTitle: 'Inscrições no Evento',
        rating: atl.rating,
        foto: atl.foto,
        badgeType: 'ATLETA',
        metaName: 'Rating CBTT',
        metaValue: `${atl.rating} pts`,
        colorTheme: 'from-blue-600 to-cyan-500',
        textColor: 'text-cyan-400',
        athleteInscriptions: associatedTournaments,
        isConfirmed: ins.length > 0 && isConfirmed,
        hasInscriptions: ins.length > 0
      };
    }

    if (crachaRole === 'Treinador') {
      const tr = treinadores.find(t => t.id === selectedPersonId) || treinadores[0];
      if (!tr) return null;
      return {
        id: tr.id,
        nome: tr.nome,
        sub: tr.clube || 'Livre',
        detailTitle: 'Inscrição Profissional',
        rating: 0,
        foto: tr.foto || '',
        badgeType: 'TREINADOR',
        metaName: 'Registro Regulado',
        metaValue: tr.cref,
        colorTheme: 'from-emerald-600 to-teal-500',
        textColor: 'text-emerald-400',
        isConfirmed: true,
        hasInscriptions: true
      };
    }

    if (crachaRole === 'Arbitro') {
      const arb = arbitros.find(a => a.id === selectedPersonId) || arbitros[0];
      if (!arb) return null;
      return {
        id: arb.id,
        nome: arb.nome,
        sub: `Federado - ${arb.nivel}`,
        detailTitle: 'Registro Arbitragem',
        rating: 0,
        foto: arb.foto || '',
        badgeType: 'ÁRBITRO',
        metaName: 'Credencial CBTT',
        metaValue: arb.cbtt || 'Arbitragem Geral',
        colorTheme: 'from-amber-500 to-yellow-500',
        textColor: 'text-yellow-400',
        isConfirmed: true,
        hasInscriptions: true
      };
    }

    if (crachaRole === 'Funcionario') {
      const func = funcionarios.find(f => f.id === selectedPersonId) || funcionarios[0];
      if (!func) return null;
      return {
        id: func.id,
        nome: func.nome,
        sub: `${func.cargo} — ${func.depto}`,
        detailTitle: 'Alocação Organizacional',
        rating: 0,
        foto: func.foto || '',
        badgeType: 'ORGANIZAÇÃO',
        metaName: 'ID Funcional',
        metaValue: func.cpf ? `CPF: ***.${func.cpf.slice(-6)}` : 'STAFF MEMBER',
        colorTheme: 'from-purple-600 to-pink-500',
        textColor: 'text-pink-400',
        isConfirmed: true,
        hasInscriptions: true
      };
    }

    return null;
  };

  const activeBadge = getBadgePersonDetails();

  // Search filter implementations
  const filteredInscriptions = inscricoes.filter(ins => {
    const atl = atletas.find(a => a.id === ins.atletaId);
    const torn = torneios.find(t => t.id === ins.torneioId);
    
    // Fallback ID generation for older records or on-the-fly matches
    const aId = ins.identificadorAtleta || (atl ? generateAthleteId(atl.id, atl.cpf) : '');
    const pId = ins.identificadorPagamento || generatePaymentId(ins.id);
    
    const searchString = `${atl?.nome || ''} ${torn?.nome || ''} ${ins.categoria} ${aId} ${pId}`.toLowerCase();
    return searchString.includes(insSearchText.toLowerCase());
  });

  const filteredTreinadores = treinadores.filter(tr => {
    const searchString = `${tr.nome} ${tr.clube} ${tr.cref}`.toLowerCase();
    return searchString.includes(trSearchText.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Tab Navigation header */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2">
            <IdCard className="w-6 h-6 text-yellow-400" />
            Inscrições, Pagamentos & Credenciamento Online
          </h2>
          <p className="text-xs text-slate-400 font-medium">
            Gerencie taxas oficiais de inscrição, atletas, treinadores regulados e emita crachás eletrônicos oficiais.
          </p>
        </div>

        {/* Tab triggers */}
        <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex gap-1">
          <button
            onClick={() => setActiveSubTab('crachas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'crachas' 
                ? 'bg-yellow-400 text-slate-950' 
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Crachás Online
          </button>
          
          <button
            onClick={() => setActiveSubTab('inscricoes')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'inscricoes' 
                ? 'bg-yellow-400 text-slate-950' 
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            Inscrições / Mensalidade
          </button>

          <button
            onClick={() => setActiveSubTab('treinadores')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'treinadores' 
                ? 'bg-yellow-400 text-slate-950' 
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Treinadores
          </button>

          <button
            onClick={() => setActiveSubTab('ficha')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeSubTab === 'ficha' 
                ? 'bg-yellow-400 text-slate-950' 
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Ficha de Inscrição Física
          </button>
        </div>
      </div>

      {/* --- RENDER SUB-TABS --- */}

      {/* 1. CRACHÁS ONLINE VIEW */}
      {activeSubTab === 'crachas' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 leading-relaxed">
          {/* Badge Selection & Selector Panel */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-sm self-start">
            <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wider">
              <IdCard className="w-4 h-4 text-yellow-400" />
              Configurar Credencial Online
            </h3>

            {/* Role filter */}
            <div className="space-y-1.5">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-black block">Tipo de Credencial</label>
              <div className="grid grid-cols-2 gap-2">
                {(['Atleta', 'Treinador', 'Arbitro', 'Funcionario'] as const).map(role => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => {
                      setCrachaRole(role);
                      setSelectedPersonId('');
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-bold border transition text-center cursor-pointer ${
                      crachaRole === role
                        ? 'bg-yellow-400/10 border-yellow-400 text-yellow-400'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {role === 'Atleta' && 'Atleta'}
                    {role === 'Treinador' && 'Treinador'}
                    {role === 'Arbitro' && 'Árbitro'}
                    {role === 'Funcionario' && 'Organização'}
                  </button>
                ))}
              </div>
            </div>

            {/* Person choices depending on role */}
            <div className="space-y-1.5">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-black block">
                Selecionar {crachaRole === 'Atleta' ? 'Atleta Inscrito' : crachaRole === 'Treinador' ? 'Treinador Regulado' : crachaRole === 'Arbitro' ? 'Árbitro Convocado' : 'Funcionário'}
              </label>
              <select
                value={selectedPersonId}
                onChange={(e) => setSelectedPersonId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition"
              >
                <option value="">Selecione um profissional/atleta...</option>
                {crachaRole === 'Atleta' && atletas.map(a => {
                  const insCount = inscricoes.filter(i => i.atletaId === a.id).length;
                  const paidCount = inscricoes.filter(i => i.atletaId === a.id && i.confirmada).length;
                  return (
                    <option key={a.id} value={a.id}>
                      {a.nome} ({a.clube || 'Sem Clube'}){insCount > 0 ? ` [${paidCount}/${insCount} Inscrições pagas/isentas]` : ' [Sem torneio linkado]'}
                    </option>
                  );
                })}
                {crachaRole === 'Treinador' && treinadores.map(t => (
                  <option key={t.id} value={t.id}>{t.nome} — {t.clube} ({t.cref})</option>
                ))}
                {crachaRole === 'Arbitro' && arbitros.map(a => (
                  <option key={a.id} value={a.id}>{a.nome} — {a.nivel}</option>
                ))}
                {crachaRole === 'Funcionario' && funcionarios.map(f => (
                  <option key={f.id} value={f.id}>{f.nome} — {f.cargo}</option>
                ))}
              </select>
            </div>

            {/* Print Instruction & Tips */}
            <div className="p-3 bg-slate-950 rounded-lg space-y-2 border border-slate-850">
              <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Printer className="w-3.5 h-3.5 text-blue-400" />
                Dica para Credencial de Treinadores
              </div>
              <p className="text-2xs text-slate-400 leading-relaxed">
                Você pode cadastrar e vincular novos Treinadores na aba "Treinadores", eles receberão um Crachá Online personalizado com seu CREF.
              </p>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg space-y-2 border border-slate-850">
              <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Segurança & Validação
              </div>
              <p className="text-2xs text-slate-400 leading-relaxed">
                Atletas inscritos possuem indicador visual em tempo real de pagamento. Somente inscrições cujo status seja <strong>Pago</strong> ou <strong>Isento</strong> exibem a credencial como <strong>"✓ INSCRIÇÃO CONFIRMADA"</strong>. Caso contrário, alerta <strong>"⚠ PAGAMENTO PENDENTE"</strong>.
              </p>
            </div>

            <button
              onClick={() => {
                if (!activeBadge) {
                  triggerToast('Nenhum crachá configurado para impressão!', 'error');
                  return;
                }
                handlePrint();
              }}
              className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-extrabold py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
            >
              <Printer className="w-4 h-4" />
              Imprimir Credencial Ativa
            </button>
          </div>

          {/* Interactive Credential Portrait Card Preview */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-6 rounded-xl flex flex-col items-center justify-center shadow-sm relative min-h-[500px]">
            {activeBadge ? (
              <div className="space-y-6 flex flex-col items-center w-full">
                
                {/* Rule Validation Warning */}
                {crachaRole === 'Atleta' && !activeBadge.isConfirmed && (
                  <div className="w-full max-w-sm p-3.5 bg-red-500/10 border border-red-500/20 text-red-400 rounded-lg flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-red-400" />
                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider">Inscrição Bloqueada / Pendente</h5>
                      <p className="text-2xs text-red-300/80 leading-relaxed mt-0.5">
                        Este atleta não possui inscrições confirmadas ou tem alguma pendente de taxa. Conclua o pagamento na aba <strong>Inscrições / Mensalidade</strong> para liberar.
                      </p>
                    </div>
                  </div>
                )}

                {crachaRole === 'Atleta' && activeBadge.isConfirmed && (
                  <div className="w-full max-w-sm p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg flex items-start gap-2.5">
                    <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
                    <div>
                      <h5 className="text-xs font-bold uppercase tracking-wider">Credenciamento Homologado</h5>
                      <p className="text-2xs text-emerald-300/80 leading-relaxed mt-0.5">
                        Tudo certo! Taxa de inscrição confirmada {activeBadge.athleteInscriptions?.some(i => i.status === 'Isento') && '(Isenção Concedida)'}. Credencial de acesso liberada!
                      </p>
                    </div>
                  </div>
                )}

                {/* THE PORTRAIT LANYARD BADGE (DESIGNED PROPORTIONALLY IN PORTUGUESE) */}
                <div 
                  id="ficha-inscricao-print" 
                  className="w-[320px] h-[480px] bg-slate-950 border-2 border-slate-800 rounded-2xl relative overflow-hidden flex flex-col justify-between shadow-2xl p-5"
                >
                  {/* Hologram Gradient Strip on the edge */}
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-gradient-to-b from-yellow-400 via-pink-500 to-cyan-500 opacity-80" />
                  
                  {/* Outer glowing ambient background accents */}
                  <div className="absolute -top-16 -left-16 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
                  <div className="absolute -bottom-16 -right-16 w-36 h-36 bg-yellow-500/10 rounded-full blur-2xl pointer-events-none" />

                  {/* HEADER AREA */}
                  <div className="flex items-center justify-between border-b border-slate-900 pb-3 h-[45px]">
                    <div className="flex items-center gap-1.5">
                      <span className="text-base">🏓</span>
                      <div>
                        <h4 className="text-2xs font-extrabold text-slate-200 tracking-wider uppercase font-sans">TT Manager Pro</h4>
                        <p className="text-[7px] text-slate-500 font-bold uppercase tracking-widest leading-none">Tournaments</p>
                      </div>
                    </div>
                    <div>
                      <span className={`text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 ${activeBadge.textColor}`}>
                        {activeBadge.badgeType}
                      </span>
                    </div>
                  </div>

                  {/* AVATAR PHOTO */}
                  <div className="flex flex-col items-center justify-center my-4">
                    <div className="relative">
                      <div className={`p-0.5 rounded-full bg-gradient-to-tr ${activeBadge.colorTheme} shadow-xl`}>
                        {activeBadge.foto ? (
                          <img 
                            src={activeBadge.foto} 
                            alt={activeBadge.nome}
                            referrerPolicy="no-referrer"
                            className="w-20 h-20 rounded-full object-cover bg-slate-900"
                          />
                        ) : (
                          <div className="w-20 h-20 rounded-full bg-slate-900 flex items-center justify-center text-slate-400 font-extrabold text-2xl font-mono uppercase border border-slate-800 select-none">
                            {activeBadge.nome.slice(0, 2)}
                          </div>
                        )}
                      </div>
                      
                      {/* Active Confirmation stamp badge */}
                      {crachaRole === 'Atleta' && (
                        <div className="absolute -bottom-1.5 -right-1.5">
                          {activeBadge.isConfirmed ? (
                            <span className="bg-emerald-500 text-slate-950 p-1 rounded-full block shadow-md border-2 border-slate-950" title="Inscrição Confirmada">
                              <CheckCircle2 className="w-3.5 h-3.5 font-bold" />
                            </span>
                          ) : (
                            <span className="bg-red-500 text-slate-950 p-1 rounded-full block shadow-md border-2 border-slate-950 animate-pulse" title="Inscrição Pendente">
                              <AlertTriangle className="w-3.5 h-3.5 font-bold" />
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    <h3 className="text-base font-black text-slate-100 uppercase tracking-tight text-center mt-3 max-w-[240px] truncate leading-tight">
                      {activeBadge.nome}
                    </h3>
                    <p className="text-[10px] text-slate-400 font-medium tracking-wide text-center mt-0.5 truncate max-w-[220px]">
                      {activeBadge.sub}
                    </p>
                  </div>

                  {/* INNER CONTENT GRID */}
                  <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-900 grid grid-cols-2 gap-2 text-left h-[100px] overflow-hidden">
                    <div className="min-w-0">
                      <span className="text-[7px] text-slate-500 uppercase tracking-wider font-extrabold block">Categoria</span>
                      <span className="text-[10px] font-bold text-slate-300 truncate block leading-tight">
                        {crachaRole === 'Atleta' 
                          ? (activeBadge.athleteInscriptions?.[0]?.categoria || 'Sem categoria') 
                          : activeBadge.detailTitle}
                      </span>
                    </div>

                    <div className="min-w-0">
                      <span className="text-[7px] text-slate-500 uppercase tracking-wider font-extrabold block">{activeBadge.metaName}</span>
                      <span className="text-[10px] font-mono font-bold text-yellow-500 truncate block leading-tight">
                        {activeBadge.metaValue}
                      </span>
                    </div>

                    <div className="col-span-2 border-t border-slate-850 pt-2 min-w-0">
                      <span className="text-[7px] text-slate-500 uppercase tracking-wider font-extrabold block">Status Homologado</span>
                      {crachaRole === 'Atleta' ? (
                        activeBadge.hasInscriptions ? (
                          activeBadge.isConfirmed ? (
                            <span className="text-[8px] font-black text-emerald-400 block uppercase tracking-wider">
                              ✓ INSCRIÇÃO ATIVA & PAGA
                            </span>
                          ) : (
                            <span className="text-[8px] font-black text-red-400 block uppercase tracking-wider animate-pulse">
                              ⚠ FINANCEIRO EM ABERTO
                            </span>
                          )
                        ) : (
                          <span className="text-[8px] font-black text-amber-500 block uppercase tracking-wider">
                            Pendente de Matrícula
                          </span>
                        )
                      ) : (
                        <span className="text-[8px] font-black text-emerald-400 block uppercase tracking-wider">
                          ✓ CREDENCIAMENTO ATIVO
                        </span>
                      )}
                    </div>
                  </div>

                  {/* QR CODE & INSTRUCTIONS AT THE BOTTOM */}
                  <div className="flex items-center justify-between border-t border-slate-900 pt-3 h-[75px]">
                    <div className="text-left space-y-1">
                      <span className="text-[6px] text-slate-500 tracking-widest uppercase font-black font-mono block">Autenticação Digital</span>
                      <p className="text-[8px] text-slate-400 leading-normal font-sans max-w-[170px]">
                        Escaneie ou apresente este crachá na mesa coletora oficial para confirmar sua chamada.
                      </p>
                    </div>

                    {/* QR Code Graphic using pure inline SVG representation */}
                    <div className="bg-white p-1 rounded-lg shrink-0 shadow-lg border border-slate-800">
                      <svg width="45" height="45" viewBox="0 0 29 29" className="text-slate-950 fill-current">
                        <path d="M0 0h9v9H0zm1 1h7v7H1zm1 1h5v5H2zM12 0h5v1h-5zm6 0h2v1h-2zm3 0h3v1h-3zm5 0h1v4h-1zm-9 2h2v1h-2zm3 0h1v2h-1zm3 0h1v1h-1zm2 0h1v2h-1zm-9 2h1v1h-1zm2 0h1v1h-1zm4 0h1v1h-1zm1 0h1v2h-1zm-10 1h2v1h-2zm4 0h1v1h-1zm-10 2h1v1H0zm2 0h1v1H2zm4 0h1v1H6zm14 0h3v1h-3zm-10 1h2v1h-2zm12 0h2v1h-2zm-22 1h9v9H0zm1 1h7v7H1zm1 1h5v5H2zm10 0h2v1h-2zm4 0h1v3h-1zm3 0h1v1h-1zm2 0h1v2h-1zm-10 2h1v1h-1zm6 0h1v1h-1zm2 0h1v2h-1zm5 0h1v2h-1zm1 0h1v1h-1zm-15 1h2v1h-2zm12 0h1v2h-1zm1 0h2v1h-2zm-12 2h1v1h-1zm2 0h2v1h-2zm3 0h1v1h-1zm6 0h2v1h-2zm1 0h1v2h-1zm2 0h1v1h-1zm-15 1h2v1h-2zm5 0h1v1h-1zm3 0h1v1h-1zm2 0h2v1h-2zm4 0h1v1h-1zm1 0h1v1h-1z" />
                      </svg>
                    </div>
                  </div>
                </div>

              </div>
            ) : (
              <div className="text-center space-y-2 max-w-sm text-slate-400">
                <IdCard className="w-8 h-8 sm:w-10 sm:h-10 text-slate-650 mx-auto" />
                <p className="text-sm font-bold">Nenhum crachá selecionado</p>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Por favor, escolha um tipo de credencial e selecione uma pessoa na barra lateral para gerar e visualizar o crachá esportivo digital.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. GESTÃO DE INSCRIÇÕES & PAGAMENTOS */}
      {activeSubTab === 'inscricoes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 leading-relaxed">
          {/* New subscription registration Form */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-sm h-fit">
            <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wide">
              <Plus className="w-4 h-4 text-yellow-400" />
              Inscrever Atleta
            </h3>

            <form onSubmit={handleAddInscription} className="space-y-4 text-xs">
              
              {/* Torneio select */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">1. Torneio Esportivo</label>
                <select
                  value={insTorneioId}
                  onChange={(e) => handleTournamentSelectForInscription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition"
                  required
                >
                  <option value="">Selecione o torneio...</option>
                  {torneios.map(t => (
                    <option key={t.id} value={t.id}>{t.nome} (Taxa: R$ {t.taxa})</option>
                  ))}
                </select>
              </div>

              {/* Atleta select */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">2. Atleta Regulado</label>
                <select
                  value={insAtletaId}
                  onChange={(e) => setInsAtletaId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition"
                  required
                >
                  <option value="">Selecione o atleta...</option>
                  {atletas.map(a => (
                    <option key={a.id} value={a.id}>{a.nome} ({a.clube || 'Nenhum Clube'})</option>
                  ))}
                </select>
              </div>

              {/* Categoria de entrada */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">3. Categoria Pretendida</label>
                <input
                  type="text"
                  placeholder="Ex: Simples Adulto, Sub-19, etc."
                  value={insCategoria}
                  onChange={(e) => setInsCategoria(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition uppercase"
                  required
                />
              </div>

              {/* Opcional Treinador / Coach Link */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">4. Treinador Responsável</label>
                  <span className="text-3xs text-yellow-500 font-black uppercase tracking-wider block">Opcional</span>
                </div>
                <select
                  value={insTreinadorId}
                  onChange={(e) => setInsTreinadorId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition"
                >
                  <option value="">Sem Treinador Vinculado</option>
                  {treinadores.map(t => (
                    <option key={t.id} value={t.id}>{t.nome} ({t.cref})</option>
                  ))}
                </select>
              </div>

              {/* Valor da Taxa e status de isenção */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Valor da Taxa (R$)</label>
                  <input
                    type="text"
                    disabled={insStatusPagamento === 'Isento'}
                    value={insStatusPagamento === 'Isento' ? '0.00' : insValorTaxa}
                    onChange={(e) => setInsValorTaxa(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-1.5 text-xs outline-none transition font-mono disabled:opacity-50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Status Pagamento</label>
                  <select
                    value={insStatusPagamento}
                    onChange={(e) => setInsStatusPagamento(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-1.5 text-xs outline-none transition font-semibold"
                  >
                    <option value="Pendente">🔴 Pendente</option>
                    <option value="Pago">🟢 Pago</option>
                    <option value="Isento">⚪ Isento (Grátis)</option>
                  </select>
                </div>
              </div>

              <div className="p-2.5 bg-slate-950 border border-slate-850 rounded-lg">
                <p className="text-3xs text-slate-400 leading-normal">
                  Inscrições marcadas como <strong>Pago</strong> ou <strong>Isento</strong> confirmam o atleta automaticamente, habilitando seu crachá.
                </p>
              </div>

              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
              >
                <Plus className="w-4 h-4" />
                Registrar Matrícula
              </button>
            </form>
          </div>

          {/* List of current Inscriptions and payment confirmations */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-sm self-stretch">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
              <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wide">
                <CheckSquare className="w-4 h-4 text-yellow-400" />
                Controle de Pagamentos de Inscrições
              </h3>

              {/* Search bar */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Filtrar inscrições..."
                  value={insSearchText}
                  onChange={(e) => setInsSearchText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-3 py-1.5 rounded-lg text-xs outline-none focus:border-yellow-400 transition"
                />
              </div>
            </div>

            <div className="overflow-x-auto text-[11px]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-450 uppercase text-3xs font-black tracking-wider">
                    <th className="py-2.5 px-2">Atleta</th>
                    <th className="py-2.5 px-2">Torneio</th>
                    <th className="py-2.5 px-2">Categoria</th>
                    <th className="py-2.5 px-2">Treinador</th>
                    <th className="py-2.5 px-2">Taxa (R$)</th>
                    <th className="py-2.5 px-2 text-center">Status Pagamento</th>
                    <th className="py-2.5 px-2 text-center">Validação</th>
                    <th className="py-2.5 px-2 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {filteredInscriptions.length > 0 ? (
                    filteredInscriptions.map(ins => {
                      const atl = atletas.find(a => a.id === ins.atletaId);
                      const torn = torneios.find(t => t.id === ins.torneioId);
                      const trainer = treinadores.find(t => t.id === ins.treinadorId);

                      return (
                        <tr key={ins.id} className="hover:bg-slate-950/20 transition-colors">
                          <td className="py-2 px-2 text-slate-100 font-extrabold font-sans">
                            {atl?.nome || 'Atleta Indefinido'}
                            <span className="block text-[9px] text-slate-400 font-medium lowercase font-mono">
                              {atl?.clube || 'Sem clube'}
                            </span>
                            <span className="inline-block text-[8px] font-mono text-cyan-400 font-extrabold bg-cyan-950/30 border border-cyan-500/20 px-1 py-0.5 rounded w-fit uppercase mt-1">
                              ID: {ins.identificadorAtleta || (atl ? generateAthleteId(atl.id, atl.cpf) : 'ATL-PENDENTE')}
                            </span>
                          </td>
                          <td className="py-2 px-2 text-slate-300">
                            <div>{torn?.nome || '—'}</div>
                            <span className="inline-block text-[8px] font-mono text-purple-400 font-extrabold bg-purple-950/30 border border-purple-500/20 px-1 py-0.5 rounded w-fit uppercase mt-1">
                              PAG: {ins.identificadorPagamento || generatePaymentId(ins.id)}
                            </span>
                          </td>
                          <td className="py-2 px-2 text-slate-400">
                            <span className="bg-slate-950 border border-slate-850 px-1.5 py-0.5 rounded font-bold uppercase text-[9px]">
                              {ins.categoria}
                            </span>
                          </td>
                          <td className="py-2 px-2 text-slate-300">
                            {trainer ? (
                              <span className="text-emerald-400 font-bold uppercase tracking-tight font-mono text-[10px]">
                                {trainer.nome}
                              </span>
                            ) : (
                              <span className="text-slate-500 italic text-[10px]">Sem Treinador</span>
                            )}
                          </td>
                          <td className="py-2 px-2 font-mono text-amber-400 font-bold">
                            R$ {parseFloat(ins.valorTaxa || '0').toFixed(2)}
                          </td>
                          <td className="py-2 px-2 text-center whitespace-nowrap">
                            <div className="flex justify-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleTogglePaymentStatus(ins.id, 'Pendente')}
                                className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider transition ${
                                  ins.statusPagamento === 'Pendente'
                                    ? 'bg-red-500 text-white'
                                    : 'bg-slate-950 text-slate-500 hover:text-red-400 border border-slate-800'
                                }`}
                              >
                                Pendente
                              </button>
                              <button
                                type="button"
                                onClick={() => handleTogglePaymentStatus(ins.id, 'Pago')}
                                className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider transition ${
                                  ins.statusPagamento === 'Pago'
                                    ? 'bg-emerald-500 text-slate-950'
                                    : 'bg-slate-950 text-slate-500 hover:text-emerald-400 border border-slate-800'
                                }`}
                              >
                                Pago
                              </button>
                              <button
                                type="button"
                                onClick={() => handleTogglePaymentStatus(ins.id, 'Isento')}
                                className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider transition ${
                                  ins.statusPagamento === 'Isento'
                                    ? 'bg-blue-500 text-white'
                                    : 'bg-slate-950 text-slate-500 hover:text-blue-400 border border-slate-800'
                                }`}
                              >
                                Isento
                              </button>
                            </div>
                          </td>
                          <td className="py-2 px-2 text-center">
                            {ins.confirmada ? (
                              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-black font-mono">
                                CONFIRMADA
                              </span>
                            ) : (
                              <span className="text-[9px] bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded font-black font-mono animate-pulse">
                                AGUARDANDO
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-2 text-right">
                            <div className="flex justify-end items-center gap-1.5">
                              {ins.statusPagamento === 'Pendente' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedPixInscription(ins);
                                    setIsPixModalOpen(true);
                                    setOverridePixKey('');
                                  }}
                                  className="text-emerald-400 hover:text-emerald-300 p-1 rounded-md transition hover:bg-emerald-950/40"
                                  title="Pagar com Pix / Ver QR Code"
                                >
                                  <QrCode className="w-4 h-4 animate-pulse" />
                                </button>
                              )}
                              {ins.statusPagamento === 'Pago' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedPixInscription(ins);
                                    setIsPixModalOpen(true);
                                    setOverridePixKey('');
                                  }}
                                  className="text-slate-400 hover:text-emerald-400 p-1 rounded-md transition hover:bg-slate-950/40"
                                  title="Ver Detalhes do Pix"
                                >
                                  <QrCode className="w-4 h-4" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => handleDeleteInscription(ins.id)}
                                className="text-slate-500 hover:text-red-400 p-1 rounded-md transition hover:bg-red-950/40"
                                title="Remover Inscrição"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={8} className="text-center py-6 text-slate-500">
                        Nenhuma inscrição registrada correspondente com o filtro inserido.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. GESTÃO DE TREINADORES */}
      {activeSubTab === 'treinadores' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 leading-relaxed">
          {/* New Coach Form */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-sm self-start">
            <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wide">
              <UserPlus className="w-4 h-4 text-yellow-400" />
              {editingCoachId ? 'Editar Cadastro de Treinador' : 'Cadastrar Novo Treinador'}
            </h3>

            <form onSubmit={handleAddCoach} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nome do Treinador</label>
                <input
                  type="text"
                  placeholder="NOME COMPLETO"
                  value={trNome}
                  onChange={(e) => setTrNome(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition uppercase"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Clube / Associação Vinculada</label>
                <input
                  type="text"
                  placeholder="EX: SPFC, AD SANTO ANDRÉ, ETC."
                  value={trClube}
                  onChange={(e) => setTrClube(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition uppercase"
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Registro CREF (Conselho Federal)</label>
                <input
                  type="text"
                  placeholder="EX: CREF 12345-G/SP"
                  value={trCref}
                  onChange={(e) => setTrCref(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition uppercase font-mono"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">WhatsApp de Contato</label>
                <input
                  type="text"
                  inputMode="numeric"
                  placeholder="+55 (11) 99999-9999"
                  value={trWa}
                  onChange={(e) => setTrWa(e.target.value.toUpperCase())}
                  onBlur={() => setTrWa(prev => normalizePhoneToBrazil(prev))}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition font-mono uppercase"
                />
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Email Oficial</label>
                <input
                  type="email"
                  placeholder="TREINADOR@EXEMPLO.COM"
                  value={trEmail}
                  onChange={(e) => setTrEmail(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition uppercase"
                />
              </div>

              <div className="flex gap-2">
                {editingCoachId && (
                  <button
                    type="button"
                    onClick={handleCancelEditCoach}
                    className="flex-1 bg-slate-850 hover:bg-slate-800 text-slate-300 font-bold py-2.5 rounded-lg text-xs uppercase cursor-pointer transition duration-150 border border-slate-800"
                  >
                    Cancelar
                  </button>
                )}
                <button
                  type="submit"
                  className="flex-1 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
                >
                  {editingCoachId ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editingCoachId ? 'Salvar' : 'Cadastrar'}
                </button>
              </div>
            </form>
          </div>

          {/* List of Coaches */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4 shadow-sm self-stretch">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
              <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wide">
                <Award className="w-4 h-4 text-emerald-400" />
                Treinadores Regulamentados Registrados
              </h3>

              {/* Search bar */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Pesquisar treinador..."
                  value={trSearchText}
                  onChange={(e) => setTrSearchText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 pl-8 pr-3 py-1.5 rounded-lg text-xs outline-none focus:border-yellow-400 transition"
                />
              </div>
            </div>

            <div className="overflow-x-auto text-[11px]">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-450 uppercase text-3xs font-black tracking-wider">
                    <th className="py-2.5 px-2">Treinador</th>
                    <th className="py-2.5 px-2">CREF</th>
                    <th className="py-2.5 px-2">Clube de Afiliação</th>
                    <th className="py-2.5 px-2">Contato WhatsApp</th>
                    <th className="py-2.5 px-2 font-mono text-center">Inscritos Vinculados</th>
                    <th className="py-2.5 px-2 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {filteredTreinadores.length > 0 ? (
                    filteredTreinadores.map(tr => {
                      const linkedAtletasCount = inscricoes.filter(i => i.treinadorId === tr.id).length;
                      return (
                        <tr key={tr.id} className="hover:bg-slate-950/20 transition-colors">
                          <td className="py-3 px-2 text-slate-100 font-extrabold font-sans flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center font-bold text-xs uppercase">
                              {tr.nome.slice(0, 2)}
                            </div>
                            <div>
                              <span>{tr.nome}</span>
                              <span className="block text-[9px] text-slate-400 font-medium font-sans">
                                {tr.email || 'Sem email cadastrado'}
                              </span>
                            </div>
                          </td>
                          <td className="py-3 px-2 text-slate-300 font-mono font-bold">
                            {tr.cref}
                          </td>
                          <td className="py-3 px-2 text-slate-400">
                            <span className="bg-slate-950 border border-slate-850 px-1.5 py-0.5 rounded font-bold uppercase text-[9px]">
                              {tr.clube}
                            </span>
                          </td>
                          <td className="py-3 px-2 text-slate-300 font-mono">
                            {tr.wa || '—'}
                          </td>
                          <td className="py-3 px-2 text-center text-emerald-400 font-bold font-mono">
                            {linkedAtletasCount} atletas
                          </td>
                          <td className="py-3 px-2 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleStartEditCoach(tr)}
                                className="text-slate-500 hover:text-yellow-400 p-1 rounded-md transition"
                                title="Editar Treinador"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteCoach(tr.id)}
                                className="text-slate-500 hover:text-red-400 p-1 rounded-md transition"
                                title="Remover Treinador"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={6} className="text-center py-6 text-slate-500">
                        Nenhum treinador correspondente aos filtros.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. PHYSICAL ENROLLMENT SHEET (ORIGINAL FICHA DE INSCRIÇÃO FÍSICA) */}
      {activeSubTab === 'ficha' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 leading-relaxed">
          {/* Parameters Panel */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-sm">
            <h3 className="font-bold text-slate-100 flex items-center gap-2">
              <FileText className="w-5 h-5 text-yellow-400" />
              Dados da Ficha Esportiva
            </h3>

            <div className="space-y-4">
              {/* Athlete Choice */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Selecione Atleta</label>
                <select
                  value={selectedAtletaId}
                  onChange={(e) => setSelectedAtletaId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
                >
                  <option value="">Selecione um atleta...</option>
                  {atletas.map(a => (
                    <option key={a.id} value={a.id}>{a.nome}</option>
                  ))}
                </select>
              </div>

              {/* Tournament Choice */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Selecione o Torneio</label>
                <select
                  value={selectedTorneioId}
                  onChange={(e) => setSelectedTorneioId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
                >
                  <option value="">Selecione o torneio...</option>
                  {torneios.map(t => (
                    <option key={t.id} value={t.id}>{t.nome}</option>
                  ))}
                </select>
              </div>

              {/* Categoria Input */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Categoria de Entrada</label>
                <select
                  value={selectedCategoria}
                  onChange={(e) => setSelectedCategoria(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
                >
                  <option>Simples Masculino</option>
                  <option>Simples Feminino</option>
                  <option>Duplas Masculino</option>
                  <option>Duplas Feminino</option>
                  <option>Duplas Misto</option>
                </select>
              </div>

              {/* Card Number Designation */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Inscrição Nº</label>
                <input
                  type="text"
                  value={inscricaoNumero}
                  onChange={(e) => setInscricaoNumero(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition font-mono"
                />
              </div>

              {/* Observation parameters */}
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Observações Gerais</label>
                <textarea
                  rows={3}
                  placeholder="Ex: Pagamento pendente, atestado médico entregue..."
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition resize-none"
                />
              </div>

              <button
                onClick={handlePrint}
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-extrabold px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
              >
                <Printer className="w-4 h-4" />
                Imprimir Ficha
              </button>
            </div>
          </div>

          {/* Interactive Sheet Preview */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-6 rounded-xl flex flex-col justify-between shadow-sm">
            <h3 className="font-bold text-slate-200 mb-4 text-xs uppercase tracking-wider text-slate-400 flex items-center gap-2">
              Pré-visualização Ficha de Inscrição Física
            </h3>

            {/* Dynamic official physical receipt card matching original custom colors */}
            <div id="ficha-inscricao-print" className="bg-slate-950 border-2 border-yellow-400 rounded-xl p-6 sm:p-8 text-slate-100 flex flex-col justify-between min-h-[380px] relative overflow-hidden shadow-2xl">
              {/* Subtle logo watermark */}
              <div className="absolute right-[-10px] bottom-[-10px] opacity-[0.03] rotate-12 select-none pointer-events-none">
                <FileText className="w-64 h-64" />
              </div>

              {/* Header Row */}
              <div className="flex items-center gap-4 border-b-2 border-yellow-400 pb-5 mb-5 relative z-10">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-yellow-400 text-slate-950 rounded-xl flex items-center justify-center font-black shadow-lg shrink-0">
                  <span className="text-lg sm:text-xl">🏓</span>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-yellow-400 tracking-tight">TT Manager Pro</h2>
                  <p className="text-xs text-slate-400 font-semibold tracking-wider uppercase">Ficha de Inscrição Esportiva Oficial</p>
                </div>
                <div className="ml-auto text-right">
                  <span className="text-slate-500 font-mono text-2xs block uppercase tracking-wider">Inscrição</span>
                  <span className="text-yellow-400 font-mono text-xl font-black">Nº {inscricaoNumero || '000'}</span>
                </div>
              </div>

              {/* Content Field Values Grid */}
              <div className="grid grid-cols-2 gap-y-4 gap-x-6 text-sm relative z-10 mb-8">
                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Atleta</span>
                  <span className="text-base font-bold text-slate-100">{selectedAtleta?.nome || '—'}</span>
                </div>
                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Torneio</span>
                  <span className="text-base font-bold text-slate-100">{selectedTorneio?.nome || '—'}</span>
                </div>

                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Clube / Associação</span>
                  <span className="text-sm font-semibold text-slate-200">{selectedAtleta?.clube || '—'}</span>
                </div>
                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Categoria de Entrada</span>
                  <span className="text-sm font-semibold text-slate-200">{selectedCategoria}</span>
                </div>

                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Data Nascimento</span>
                  <span className="text-sm font-semibold text-slate-200">
                    {selectedAtleta?.nasc ? new Date(selectedAtleta.nasc + 'T12:00').toLocaleDateString('pt-BR') : '—'}
                  </span>
                </div>
                <div className="border-b border-slate-800 pb-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Rating CBTT</span>
                  <span className="text-sm font-bold text-yellow-400 font-mono">{selectedAtleta?.rating || '0'} pts</span>
                </div>

                <div className="border-b border-slate-800 pb-1 col-span-2">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Observações</span>
                  <span className="text-xs text-slate-400 italic block min-h-[1.5rem] mt-0.5">{observacoes || 'Sem observações adicionais.'}</span>
                </div>
              </div>

              {/* Signature lines panel */}
              <div className="grid grid-cols-2 gap-8 border-t border-slate-800 pt-6 mt-2 relative z-10">
                <div className="text-center">
                  <div className="h-0.5 w-full bg-slate-700/60 mb-2"></div>
                  <span className="text-xs text-slate-400 text-center block">Assinatura do Atleta</span>
                </div>
                <div className="text-center">
                  <div className="h-0.5 w-full bg-slate-700/60 mb-2"></div>
                  <span className="text-xs text-slate-400 text-center block font-semibold text-slate-300">Carimbo / Supervisor de Mesa</span>
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-slate-950/20 border border-slate-800 rounded-lg flex items-start gap-2.5">
              <Info className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
              <p className="text-xs text-slate-400 leading-relaxed">
                Dica: Para imprimir apenas a ficha física, clique em <strong>Imprimir Ficha</strong>. O layout de impressão do sistema foi otimizado para ocultar menus e barras laterais no papel.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Dynamic Pix Payment Modal overlay */}
      {isPixModalOpen && selectedPixInscription && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in text-left">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="bg-gradient-to-r from-emerald-950 to-slate-905 px-6 py-4 border-b border-emerald-900/40 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 bg-emerald-500 text-slate-950 rounded-xl flex items-center justify-center font-black shadow-lg">
                  <QrCode className="w-5 h-5 text-slate-950" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-slate-100 uppercase tracking-wide">Pagamento Pix</h3>
                  <p className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider font-mono">
                    TT Manager Checkout
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsPixModalOpen(false);
                  setSelectedPixInscription(null);
                  setOverridePixKey('');
                }}
                className="text-slate-400 hover:text-slate-100 font-semibold p-1.5 hover:bg-slate-800 rounded-lg text-sm transition"
              >
                ✕
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="p-6 space-y-4 overflow-y-auto">
              {/* Dynamic Info Rows */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950/40 border border-slate-850 p-4 rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Atleta Beneficiário</span>
                  <p className="font-extrabold text-slate-200 mt-0.5">
                    {atletas.find(a => a.id === selectedPixInscription.atletaId)?.nome || 'Não definido'}
                  </p>
                  <span className="text-[9px] font-mono font-bold text-cyan-400 bg-cyan-950/40 border border-cyan-800/30 px-1 py-0.5 rounded uppercase inline-block mt-1">
                    ID: {selectedPixInscription.identificadorAtleta || (atletas.find(a => a.id === selectedPixInscription.atletaId) ? generateAthleteId(selectedPixInscription.atletaId, atletas.find(a => a.id === selectedPixInscription.atletaId)?.cpf) : 'ATL-PENDENTE')}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Campeonato / Torneio</span>
                  <p className="font-bold text-slate-200 truncate mt-0.5">
                    {torneios.find(t => t.id === selectedPixInscription.torneioId)?.nome || '—'}
                  </p>
                  <span className="text-[9px] font-mono font-bold text-purple-400 bg-purple-950/40 border border-purple-800/30 px-1 py-0.5 rounded uppercase inline-block mt-1">
                    PAG: {selectedPixInscription.identificadorPagamento || generatePaymentId(selectedPixInscription.id)}
                  </span>
                </div>
                <div className="border-t border-slate-800/60 pt-2.5">
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Categoria</span>
                  <p className="font-bold text-slate-350 mt-0.5">{selectedPixInscription.categoria}</p>
                </div>
                <div className="border-t border-slate-800/60 pt-2.5">
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Taxa de Inscrição</span>
                  <p className="font-extrabold text-amber-400 text-sm mt-0.5">
                    R$ {parseFloat(selectedPixInscription.valorTaxa || '0').toFixed(2)}
                  </p>
                </div>
                <div className="col-span-2 border-t border-slate-800/60 pt-2.5">
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Identificador Único de Transação (UUID)</span>
                  <p className="font-mono text-[10px] text-blue-400 font-extrabold mt-1 select-all overflow-hidden text-ellipsis bg-slate-950 px-2.5 py-2 rounded-lg border border-slate-850 flex items-center justify-between gap-2.5">
                    <span className="truncate">{selectedPixInscription.pixTransactionUuid || 'uuid-' + Math.random().toString(36).substring(2, 10)}</span>
                    <button 
                      type="button"
                      onClick={() => {
                        const val = selectedPixInscription.pixTransactionUuid || '';
                        navigator.clipboard.writeText(val);
                        triggerToast('UUID de transação copiado!', 'success');
                      }}
                      className="text-slate-400 hover:text-white text-[9px] font-black uppercase bg-slate-900 border border-slate-800 px-2 py-1 rounded transition shrink-0"
                    >
                      Copiar UUID
                    </button>
                  </p>
                </div>
              </div>

              {/* Destination Pix Key Setup */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">
                  Chave Pix do Recebedor (Championship Register Key)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={overridePixKey || torneios.find(t => t.id === selectedPixInscription.torneioId)?.pixKey || ''}
                    placeholder="Sem chave do torneio..."
                    onChange={(e) => setOverridePixKey(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 outline-none font-bold"
                  />
                  {(!overridePixKey && !torneios.find(t => t.id === selectedPixInscription.torneioId)?.pixKey) ? (
                    <button
                      type="button"
                      onClick={() => setOverridePixKey('pix.campeonato@associacaott.org')}
                      className="px-3 py-1.5 bg-yellow-400/20 border border-yellow-500/30 hover:bg-yellow-400/30 text-yellow-400 text-[10px] font-extrabold rounded-lg transition"
                    >
                      Usar Demo
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleCopyKey(overridePixKey || torneios.find(t => t.id === selectedPixInscription.torneioId)?.pixKey || '')}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 text-xs font-bold rounded-lg transition flex items-center gap-1 shrink-0"
                    >
                      {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      Copiar
                    </button>
                  )}
                </div>
                {(!overridePixKey && !torneios.find(t => t.id === selectedPixInscription.torneioId)?.pixKey) && (
                  <p className="text-[10px] text-red-400 font-semibold leading-tight pt-1">
                    ⚠️ Atenção: Nenhuma chave Pix foi configurada para este torneio! Digite uma chave acima ou clique em "Usar Demo" para carregar a chave padrão e liberar o QR Code.
                  </p>
                )}
              </div>

              {/* QR CODE AND PAYLOAD SECTION */}
              {parseFloat(selectedPixInscription.valorTaxa || '0') > 0 ? (
                <div className="flex flex-col items-center bg-slate-950 rounded-2xl p-5 border border-slate-850/65 shadow-inner">
                  {/* Dynamic QR Code */}
                  <div className="w-44 h-44 bg-white p-2 rounded-xl flex items-center justify-center shadow-lg mb-3">
                    <img
                      src={modalPixQrCodeUrl}
                      alt="Pix QR Code"
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="text-[9px] text-slate-500 uppercase font-black tracking-widest block text-center mb-4">
                    Abra o app do seu banco e aponte a câmera para pagar
                  </span>

                  {/* PIX COPIA E COLA PAYLOAD ACCORDION */}
                  <div className="w-full space-y-1">
                    <span className="text-[10px] text-slate-400 font-bold block pl-0.5 text-left">
                      Ou pague utilizando o Pix Copia e Cola:
                    </span>
                    <div className="flex gap-1.5 w-full">
                      <input
                        type="text"
                        readOnly
                        value={modalPixPayload}
                        className="flex-1 bg-slate-900 border border-slate-800 text-[10px] rounded-lg px-2.5 py-1.5 text-slate-400 font-mono select-all focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => handleCopyPayload(modalPixPayload)}
                        className="px-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-lg transition shrink-0 flex items-center gap-1"
                      >
                        {copiedPayload ? <Check className="w-3.5 h-3.5 text-slate-950" /> : <Copy className="w-3.5 h-3.5 text-slate-950" />}
                        Copiar Código
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6 border border-blue-900/30 bg-blue-950/20 rounded-xl space-y-1.5 text-slate-300">
                  <span className="text-lg">💰</span>
                  <p className="font-bold text-xs text-blue-400 font-sans">Esta inscrição é isenta de taxa!</p>
                  <p className="text-[11px] leading-relaxed text-slate-420">
                    Nenhum pagamento Pix ou QR Code precisa ser emitido para este participante porque a taxa correspondente foi definida como isenta (ou gratuita).
                  </p>
                </div>
              )}

              {/* Inline Payment Status Quick Update */}
              <div className="border-t border-slate-800/60 pt-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase font-black block">Status Atual</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    {selectedPixInscription.statusPagamento === 'Pago' ? (
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                    ) : selectedPixInscription.statusPagamento === 'Isento' ? (
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
                    ) : (
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block animate-pulse"></span>
                    )}
                    <span className="text-xs font-extrabold uppercase tracking-wide text-slate-300">
                      {selectedPixInscription.statusPagamento}
                    </span>
                  </div>
                </div>
                <div className="flex gap-1.5 bg-slate-950/40 p-1.5 border border-slate-850 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      handleTogglePaymentStatus(selectedPixInscription.id, 'Pago');
                      setSelectedPixInscription(prev => prev ? { ...prev, statusPagamento: 'Pago' } : null);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-2xs font-extrabold uppercase tracking-wider transition ${
                      selectedPixInscription.statusPagamento === 'Pago'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-slate-900 text-slate-400 hover:text-emerald-400'
                    }`}
                  >
                    Confirmar Pago
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleTogglePaymentStatus(selectedPixInscription.id, 'Pendente');
                      setSelectedPixInscription(prev => prev ? { ...prev, statusPagamento: 'Pendente' } : null);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-2xs font-extrabold uppercase tracking-wider transition ${
                      selectedPixInscription.statusPagamento === 'Pendente'
                        ? 'bg-red-500 text-white'
                        : 'bg-slate-900 text-slate-400 hover:text-red-400'
                    }`}
                  >
                    Marcar Pendente
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => {
                  setIsPixModalOpen(false);
                  setSelectedPixInscription(null);
                  setOverridePixKey('');
                }}
                className="px-5 py-2 bg-slate-850 hover:bg-slate-800 border border-slate-750 text-slate-300 hover:text-white font-bold text-xs rounded-xl transition"
              >
                Fechar Painel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
