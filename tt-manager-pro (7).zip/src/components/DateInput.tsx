import React, { useState, useRef, useEffect } from 'react';
import { Calendar as CalendarIcon, Keyboard, ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface DateInputProps {
  value: string; // ISO format: YYYY-MM-DD
  onChange: (value: string) => void;
  label?: string;
  placeholder?: string;
  className?: string;
  required?: boolean;
  disabled?: boolean;
  min?: string;
  max?: string;
  id?: string;
}

// Helper: Convert YYYY-MM-DD -> DD/MM/YYYY
export function isoToBrDate(iso: string): string {
  if (!iso || typeof iso !== 'string' || !iso.includes('-')) return '';
  const parts = iso.split('-');
  if (parts.length !== 3) return '';
  const [y, m, d] = parts;
  if (!y || !m || !d) return '';
  return `${d.padStart(2, '0')}/${m.padStart(2, '0')}/${y}`;
}

// Helper: Convert DD/MM/YYYY or digits -> YYYY-MM-DD
export function brToIsoDate(br: string): string {
  if (!br) return '';
  const digits = br.replace(/\D/g, '');
  if (digits.length === 8) {
    const d = digits.substring(0, 2);
    const m = digits.substring(2, 4);
    const y = digits.substring(4, 8);
    const dayNum = parseInt(d, 10);
    const monthNum = parseInt(m, 10);
    const yearNum = parseInt(y, 10);
    if (monthNum >= 1 && monthNum <= 12 && dayNum >= 1 && dayNum <= 31 && yearNum >= 1900 && yearNum <= 2100) {
      return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
    }
  }
  return '';
}

export default function DateInput({
  value,
  onChange,
  label,
  placeholder = "DD/MM/AAAA",
  className = "",
  required = false,
  disabled = false,
  min,
  max,
  id
}: DateInputProps) {
  const [mode, setMode] = useState<'text' | 'native'>('text'); // 'text' for numeric keyboard, 'native' for browser datepicker
  const [textVal, setTextVal] = useState(isoToBrDate(value));
  const [showPopover, setShowPopover] = useState(false);
  
  const nativeRef = useRef<HTMLInputElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  // Sync textVal when external value changes
  useEffect(() => {
    setTextVal(isoToBrDate(value));
  }, [value]);

  // Calendar State for custom popover picker
  const initialDate = value ? new Date(value + 'T00:00:00') : new Date();
  const [viewYear, setViewYear] = useState(isNaN(initialDate.getFullYear()) ? new Date().getFullYear() : initialDate.getFullYear());
  const [viewMonth, setViewMonth] = useState(isNaN(initialDate.getMonth()) ? new Date().getMonth() : initialDate.getMonth());

  // Close popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setShowPopover(false);
      }
    };
    if (showPopover) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPopover]);

  // Handle direct numeric input
  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let raw = e.target.value.replace(/\D/g, '');
    if (raw.length > 8) raw = raw.substring(0, 8);

    let formatted = '';
    if (raw.length > 0) {
      formatted = raw.substring(0, 2);
      if (raw.length >= 3) {
        formatted += '/' + raw.substring(2, 4);
      }
      if (raw.length >= 5) {
        formatted += '/' + raw.substring(4, 8);
      }
    }

    setTextVal(formatted);

    if (raw.length === 8) {
      const iso = brToIsoDate(raw);
      if (iso) {
        onChange(iso);
        // Sync popover view date
        const [y, m] = iso.split('-').map(Number);
        setViewYear(y);
        setViewMonth(m - 1);
      }
    } else if (raw.length === 0) {
      onChange('');
    }
  };

  // Trigger browser native calendar picker or popover
  const handleOpenCalendar = () => {
    if (disabled) return;
    
    // Attempt native showPicker if available
    if (nativeRef.current && typeof nativeRef.current.showPicker === 'function') {
      try {
        nativeRef.current.showPicker();
        return;
      } catch (err) {
        console.warn("showPicker error, fallback to custom calendar popover", err);
      }
    }
    
    // Fallback: toggle custom popover
    setShowPopover(!showPopover);
  };

  const handleSelectDay = (day: number) => {
    const mStr = String(viewMonth + 1).padStart(2, '0');
    const dStr = String(day).padStart(2, '0');
    const iso = `${viewYear}-${mStr}-${dStr}`;
    onChange(iso);
    setTextVal(`${dStr}/${mStr}/${viewYear}`);
    setShowPopover(false);
  };

  const monthNames = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfWeek = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDayOfWeek = getFirstDayOfWeek(viewYear, viewMonth);

  // Years array from 1920 to current + 10
  const currentYr = new Date().getFullYear();
  const years = Array.from({ length: 115 }, (_, i) => currentYr + 5 - i);

  return (
    <div className={`space-y-1 relative ${className}`}>
      {label && (
        <div className="flex items-center justify-between">
          <label htmlFor={id} className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
            {label} {required && <span className="text-yellow-400">*</span>}
          </label>
          <span className="text-[10px] text-slate-500 font-medium">
            {mode === 'text' ? 'Teclado numérico' : 'Calendário'}
          </span>
        </div>
      )}

      <div className="relative flex items-center">
        {/* Hidden Native Input for native picker fallback */}
        <input
          ref={nativeRef}
          type="date"
          value={value || ''}
          min={min}
          max={max}
          onChange={(e) => {
            onChange(e.target.value);
            setTextVal(isoToBrDate(e.target.value));
          }}
          className="sr-only"
          tabIndex={-1}
        />

        {/* Text / Numeric Input with Mask */}
        <input
          id={id}
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={textVal}
          onChange={handleTextChange}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-3 pr-24 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono placeholder:text-slate-600 transition"
        />

        {/* Control Action Buttons (Calendar Icon & Mode Switcher) */}
        <div className="absolute right-1.5 flex items-center gap-1">
          <button
            type="button"
            onClick={handleOpenCalendar}
            disabled={disabled}
            className="p-1.5 bg-slate-900 hover:bg-slate-800 text-yellow-400 border border-slate-750 hover:border-yellow-400/50 rounded-md text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-sm"
            title="Abrir Calendário para escolher data"
          >
            <CalendarIcon className="w-3.5 h-3.5 text-yellow-400" />
            <span className="text-[10px] hidden sm:inline">Calendário</span>
          </button>
        </div>
      </div>

      {/* Interactive Custom Calendar Popover */}
      {showPopover && (
        <div
          ref={popoverRef}
          className="absolute z-50 top-full mt-2 right-0 sm:left-0 bg-slate-900 border border-slate-700 rounded-xl p-4 shadow-2xl space-y-3 w-72 text-slate-100"
        >
          {/* Header Controls */}
          <div className="flex items-center justify-between gap-1 border-b border-slate-800 pb-2">
            <button
              type="button"
              onClick={() => {
                if (viewMonth === 0) {
                  setViewMonth(11);
                  setViewYear(viewYear - 1);
                } else {
                  setViewMonth(viewMonth - 1);
                }
              }}
              className="p-1 hover:bg-slate-800 text-slate-300 rounded transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1">
              <select
                value={viewMonth}
                onChange={(e) => setViewMonth(Number(e.target.value))}
                className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-1.5 py-1 text-xs outline-none font-bold"
              >
                {monthNames.map((m, idx) => (
                  <option key={m} value={idx}>{m}</option>
                ))}
              </select>

              <select
                value={viewYear}
                onChange={(e) => setViewYear(Number(e.target.value))}
                className="bg-slate-950 border border-slate-800 text-slate-200 rounded px-1.5 py-1 text-xs outline-none font-bold font-mono"
              >
                {years.map(y => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={() => {
                if (viewMonth === 11) {
                  setViewMonth(0);
                  setViewYear(viewYear + 1);
                } else {
                  setViewMonth(viewMonth + 1);
                }
              }}
              className="p-1 hover:bg-slate-800 text-slate-300 rounded transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 text-center text-[10px] font-black uppercase text-slate-400">
            <span>Dom</span>
            <span>Seg</span>
            <span>Ter</span>
            <span>Qua</span>
            <span>Qui</span>
            <span>Sex</span>
            <span>Sáb</span>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1 text-center font-mono text-xs">
            {/* Empty slots before first day */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}

            {/* Month days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const mStr = String(viewMonth + 1).padStart(2, '0');
              const dStr = String(day).padStart(2, '0');
              const thisIso = `${viewYear}-${mStr}-${dStr}`;
              const isSelected = value === thisIso;

              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleSelectDay(day)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    isSelected
                      ? 'bg-yellow-400 text-slate-950 font-black shadow-md'
                      : 'hover:bg-slate-800 text-slate-200 hover:text-yellow-400'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>

          {/* Quick Action Footer */}
          <div className="flex items-center justify-between border-t border-slate-800 pt-2 text-2xs">
            <button
              type="button"
              onClick={() => {
                const today = new Date();
                const y = today.getFullYear();
                const m = String(today.getMonth() + 1).padStart(2, '0');
                const d = String(today.getDate()).padStart(2, '0');
                const iso = `${y}-${m}-${d}`;
                onChange(iso);
                setTextVal(`${d}/${m}/${y}`);
                setShowPopover(false);
              }}
              className="text-yellow-400 hover:underline font-bold"
            >
              Hoje
            </button>
            <button
              type="button"
              onClick={() => setShowPopover(false)}
              className="text-slate-400 hover:text-slate-200"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
