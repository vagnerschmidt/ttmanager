import React, { useState } from 'react';
import { Atleta, Resultado } from '../types';
import { Award, ArrowRightLeft, FileSpreadsheet, Medal } from 'lucide-react';

interface ClassificacaoViewProps {
  atletas: Atleta[];
  resultados: Resultado[];
}

export default function ClassificacaoView({ atletas, resultados }: ClassificacaoViewProps) {
  const [selectedCat, setSelectedCat] = useState('');

  // Auto-categorize category options available
  const categoriesList = Array.from(
    new Set(atletas.flatMap(a => a.cat ? a.cat.split(',').map(c => c.trim()) : []))
  ).filter(Boolean).sort();

  // Filter listed athletes
  const filteredAtletas = atletas.filter(a => !selectedCat || (a.cat && a.cat.split(',').map(c => c.trim()).includes(selectedCat)));

  // Generate leaderboard data with live matches calculations
  const leaderboardData = filteredAtletas.map(a => {
    // Total matches played
    const matchesPlay = resultados.filter(r => r.nomeA === a.nome || r.nomeB === a.nome);
    const totalPlay = matchesPlay.length;

    // Total wins
    const wins = matchesPlay.filter(r => {
      if (r.nomeA === a.nome && r.ponA > r.ponB) return true;
      if (r.nomeB === a.nome && r.ponB > r.ponA) return true;
      return false;
    }).length;

    const losses = totalPlay - wins;
    const wrRate = totalPlay > 0 ? Math.round((wins / totalPlay) * 100) : 0;

    return {
      athlete: a,
      games: totalPlay,
      wins,
      losses,
      winRate: wrRate
    };
  }).sort((x, y) => {
    // Primary sort: rating points desc
    if (y.athlete.rating !== x.athlete.rating) {
      return y.athlete.rating - x.athlete.rating;
    }
    // Secondary sort: win rate desc
    return y.winRate - x.winRate;
  });

  const handleExportCSV = () => {
    const csvHeader = "Posicao,Atleta,Clube,Categoria,Rating,Jogos,Vitorias,Derrotas,WinRate%\n";
    const csvRows = leaderboardData.map((item, index) => {
      const a = item.athlete;
      return `${index + 1},"${a.nome}","${a.clube || ''}","${a.cat}",${a.rating},${item.games},${item.wins},${item.losses},${item.winRate}`;
    }).join("\n");

    const fullCsv = csvHeader + csvRows;
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), fullCsv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `classificacao_rating_${selectedCat || 'geral'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Filtering and download headers */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="space-y-1 w-full sm:w-auto">
          <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block mb-1">Filtrar Categoria</label>
          <select
            value={selectedCat}
            onChange={(e) => setSelectedCat(e.target.value)}
            className="w-full sm:w-60 bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Leaderboard Geral</option>
            {categoriesList.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <button
          onClick={handleExportCSV}
          className="w-full sm:w-auto bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-100 font-bold px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-sm"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          Exportar Ranking CSV
        </button>
      </div>

      {/* Standings List matches the HTML mockup aesthetics */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-950/20 flex items-center justify-between">
          <h3 className="font-bold text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wider">
            <Award className="w-5 h-5 text-yellow-400" />
            Classificação por Rating CBTT
          </h3>
          <span className="text-3xs bg-slate-850 px-2 py-0.5 rounded text-slate-400 font-semibold uppercase tracking-wider font-mono">
            Real-time
          </span>
        </div>

        <div className="p-4 divide-y divide-slate-850">
          {leaderboardData.length > 0 ? (
            leaderboardData.map((item, index) => {
              const a = item.athlete;
              const hasMedal = index < 3;
              
              return (
                <div key={a.id} className="flex items-center gap-4 py-3 first:pt-1 last:pb-1 group hover:bg-slate-950/15 p-2 rounded-lg transition-colors">
                  
                  {/* Position number or gold/silver/bronze icons */}
                  <div className="w-10 flex items-center justify-center font-black text-slate-500 text-lg">
                    {index === 0 ? (
                      <span className="text-yellow-400" title="1º Lugar">❶</span>
                    ) : index === 1 ? (
                      <span className="text-slate-350" title="2º Lugar">❷</span>
                    ) : index === 2 ? (
                      <span className="text-amber-600" title="3º Lugar">❸</span>
                    ) : (
                      index + 1
                    )}
                  </div>

                  {/* Profile avatar thumbnail */}
                  {a.foto ? (
                    <img src={a.foto} className="w-10 h-10 rounded-full object-cover border border-slate-700 shrink-0" alt={a.nome} />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-extrabold text-slate-300 shrink-0 text-sm">
                      {a.nome[0].toUpperCase()}
                    </div>
                  )}

                  {/* Full details info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-black text-slate-200 text-sm truncate flex items-center gap-1.5Packed">
                      {a.nome}
                      {hasMedal && <Medal className={`w-3.5 h-3.5 ${
                        index === 0 ? 'text-yellow-400' : index === 1 ? 'text-slate-300' : 'text-amber-600'
                      }`} />}
                    </h4>
                    <p className="text-slate-400 text-2xs truncate mt-0.5 flex flex-wrap gap-1 items-center">
                      <span>{a.clube || 'Sem clube'}</span>
                      <span className="text-slate-600">·</span>
                      {a.cat ? a.cat.split(',').map(c => (
                        <span key={c.trim()} className="bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase">
                          {c.trim()}
                        </span>
                      )) : null}
                    </p>
                  </div>

                  {/* Rating / Win details stats columns */}
                  <div className="text-right whitespace-nowrap">
                    <div className="text-base font-black text-yellow-400 font-mono tracking-tight">{a.rating} <span className="text-3xs uppercase text-slate-500 font-bold">pts</span></div>
                    <div className="text-3xs text-slate-500 font-semibold font-mono tracking-wider mt-0.5">
                      {item.wins}V – {item.losses}D · <strong className="text-slate-400">{item.winRate}% WR</strong> ({item.games} jogos)
                    </div>
                  </div>

                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-slate-500">
              Nenhum atleta cadastrado para obter classificação.
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
