import React, { useState } from 'react';
import { Torneio, Categoria, Atleta, Arbitro, Resultado } from '../types';
import { Search, Save, Trash2, Trophy, Clock, HelpCircle, Activity } from 'lucide-react';

interface ResultadosViewProps {
  torneios: Torneio[];
  categorias: Categoria[];
  atletas: Atleta[];
  arbitros: Arbitro[];
  resultados: Resultado[];
  onSave: (result: Resultado) => void;
  onDelete: (id: string) => void;
  userRole?: string;
}

export default function ResultadosView({
  torneios,
  categorias,
  atletas,
  arbitros,
  resultados,
  onSave,
  onDelete
}: ResultadosViewProps) {
  
  // Scoring Panel State
  const [selectedTorneio, setSelectedTorneio] = useState('');
  const [selectedCat, setSelectedCat] = useState('');
  const [athleteA, setAthleteA] = useState('');
  const [athleteB, setAthleteB] = useState('');
  const [scoreA, setScoreA] = useState(0); // Live points Player A
  const [scoreB, setScoreB] = useState(0); // Live points Player B
  const [setsA, setSetsA] = useState(0); // Final sets count Player A
  const [setsB, setSetsB] = useState(0); // Final sets count Player B
  const [tableNum, setTableNum] = useState(1);
  const [selectedArb, setSelectedArb] = useState('');
  const [dateTime, setDateTime] = useState(() => {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  });

  // Walkover status and penalty cards states
  const [woForfeit, setWoForfeit] = useState<'none' | 'A' | 'B'>('none');
  const [obsNotes, setObsNotes] = useState('');
  const [manualYellowA, setManualYellowA] = useState(0);
  const [manualYellowB, setManualYellowB] = useState(0);
  const [manualRedA, setManualRedA] = useState(0);
  const [manualRedB, setManualRedB] = useState(0);

  // History Search filter
  const [searchHistoryQuery, setSearchHistoryQuery] = useState('');

  // Auto-fill scores when Walkover is selected
  React.useEffect(() => {
    if (woForfeit === 'A') {
      setSetsA(0);
      setSetsB(3);
      setScoreA(0);
      setScoreB(11);
      setObsNotes('Vitória por W.O. (Não comparecimento de Atleta A)');
    } else if (woForfeit === 'B') {
      setSetsB(0);
      setSetsA(3);
      setScoreB(0);
      setScoreA(11);
      setObsNotes('Vitória por W.O. (Não comparecimento de Atleta B)');
    } else if (woForfeit === 'none') {
      setObsNotes('');
    }
  }, [woForfeit]);

  // Get active names for live rendering
  const activeAtletaA = atletas.find(a => a.id === athleteA);
  const activeAtletaB = atletas.find(b => b.id === athleteB);

  const handleSaveResult = () => {
    if (!athleteA || !athleteB || athleteA === athleteB) {
      alert("Selecione dois atletas diferentes para registrar o resultado!");
      return;
    }

    const tRef = torneios.find(t => t.id === selectedTorneio);
    const cRef = categorias.find(c => c.id === selectedCat);

    const match: Resultado = {
      id: 'res_' + Date.now().toString(36),
      torId: selectedTorneio,
      catId: selectedCat,
      nomeA: activeAtletaA?.nome || athleteA,
      nomeB: activeAtletaB?.nome || athleteB,
      ponA: scoreA,
      ponB: scoreB,
      setsA: Number(setsA) || 0,
      setsB: Number(setsB) || 0,
      arb: selectedArb || 'Indefinido',
      mesa: Number(tableNum) || 1,
      dt: dateTime,
      wo: woForfeit !== 'none' ? woForfeit : undefined,
      obs: obsNotes || undefined,
      cartoesA: (manualYellowA > 0 || manualRedA > 0) ? { amarelo: manualYellowA, vermelho: manualRedA } : undefined,
      cartoesB: (manualYellowB > 0 || manualRedB > 0) ? { amarelo: manualYellowB, vermelho: manualRedB } : undefined
    };

    onSave(match);

    // Reset Live Points states (keep selection to ease entry)
    setScoreA(0);
    setScoreB(0);
    setSetsA(0);
    setSetsB(0);
    setWoForfeit('none');
    setObsNotes('');
    setManualYellowA(0);
    setManualYellowB(0);
    setManualRedA(0);
    setManualRedB(0);
  };

  const filteredHistory = [...resultados].reverse().filter(r => {
    const q = searchHistoryQuery.toLowerCase();
    return !q || r.nomeA.toLowerCase().includes(q) || r.nomeB.toLowerCase().includes(q);
  });

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
      
      {/* SCORES LAUNCH PANEL */}
      <div className="xl:col-span-6 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-sm">
        <h3 className="font-bold text-slate-100 flex items-center gap-2">
          <Activity className="w-5 h-5 text-yellow-400" />
          Lançar Resultado
        </h3>

        <div className="grid grid-cols-2 gap-4">
          {/* Tournament */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Torneio</label>
            <select
              value={selectedTorneio}
              onChange={(e) => setSelectedTorneio(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition focus:border-yellow-400"
            >
              <option value="">Selecionar torneio...</option>
              {torneios.map(t => (
                <option key={t.id} value={t.id}>{t.nome}</option>
              ))}
            </select>
          </div>

          {/* Categoria */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Categoria</label>
            <select
              value={selectedCat}
              onChange={(e) => setSelectedCat(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition focus:border-yellow-400"
            >
              <option value="">Selecionar categoria...</option>
              {categorias.map(c => (
                <option key={c.id} value={c.id}>{c.nome}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Scoreboard Console */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 select-none">
          <div className="grid grid-cols-11 items-center gap-3">
            
            {/* Athlete A Stats Panel */}
            <div className="col-span-5 text-center flex flex-col items-center">
              <div className="w-full space-y-2 mb-3">
                <label className="text-3xs uppercase tracking-widest text-slate-500 font-extrabold block">Atleta A</label>
                <select
                  value={athleteA}
                  onChange={(e) => setAthleteA(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-850 text-slate-250 text-xs font-bold text-center rounded px-2.0 py-1.5 outline-none transition"
                >
                  <option value="">Selecione...</option>
                  {atletas.map(a => (
                    <option key={a.id} value={a.id}>{a.nome}</option>
                  ))}
                </select>
              </div>

              {/* Big live score number block */}
              <div className="text-5xl font-black text-yellow-400 font-mono tracking-tight leading-none min-h-[48px] py-1 bg-slate-900 border border-slate-800/60 rounded-xl w-24">
                {scoreA}
              </div>

              {/* Controls */}
              <div className="flex gap-2.5 mt-3 justify-center">
                <button
                  type="button"
                  onClick={() => setScoreA(p => Math.max(0, p - 1))}
                  className="w-8 h-8 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 duration-150 rounded border border-slate-750"
                  title="Diminuir"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setScoreA(p => p + 1)}
                  className="w-8 h-8 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 duration-150 rounded border border-slate-750"
                  title="Aumentar"
                >
                  +
                </button>
              </div>
            </div>

            {/* Separator VS */}
            <div className="col-span-1 text-center font-bold text-slate-500 text-base">
              VS
            </div>

            {/* Athlete B Stats Panel */}
            <div className="col-span-5 text-center flex flex-col items-center">
              <div className="w-full space-y-2 mb-3">
                <label className="text-3xs uppercase tracking-widest text-slate-500 font-extrabold block">Atleta B</label>
                <select
                  value={athleteB}
                  onChange={(e) => setAthleteB(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-850 text-slate-250 text-xs font-bold text-center rounded px-2.0 py-1.5 outline-none transition"
                >
                  <option value="">Selecione...</option>
                  {atletas.map(a => (
                    <option key={a.id} value={a.id}>{a.nome}</option>
                  ))}
                </select>
              </div>

              {/* Big live score number block */}
              <div className="text-5xl font-black text-yellow-400 font-mono tracking-tight leading-none min-h-[48px] py-1 bg-slate-900 border border-slate-800/60 rounded-xl w-24">
                {scoreB}
              </div>

              {/* Controls */}
              <div className="flex gap-2.5 mt-3 justify-center">
                <button
                  type="button"
                  onClick={() => setScoreB(p => Math.max(0, p - 1))}
                  className="w-8 h-8 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 duration-150 rounded border border-slate-750"
                  title="Diminuir"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setScoreB(p => p + 1)}
                  className="w-8 h-8 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-slate-100 hover:bg-slate-700 duration-150 rounded border border-slate-750"
                  title="Aumentar"
                >
                  +
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Sets Count Parameters Input grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Sets Conquistados (A)</label>
            <input
              type="number"
              min={0}
              max={4}
              value={setsA}
              onChange={(e) => setSetsA(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
            />
          </div>
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Sets Conquistados (B)</label>
            <input
              type="number"
              min={0}
              max={4}
              value={setsB}
              onChange={(e) => setSetsB(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
            />
          </div>
        </div>

        {/* Referee, table, and date values */}
        <div className="grid grid-cols-3 gap-3 text-sm">
          <div className="space-y-1 col-span-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nº Mesa</label>
            <input
              type="number"
              min={1}
              value={tableNum}
              onChange={(e) => setTableNum(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm font-mono outline-none"
            />
          </div>
          <div className="space-y-1 col-span-2">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Árbitro Oficial</label>
            <select
              value={selectedArb}
              onChange={(e) => setSelectedArb(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none"
            >
              <option value="">Selecionar árbitro...</option>
              {arbitros.map(arb => (
                <option key={arb.id} value={arb.nome}>{arb.nome} ({arb.nivel})</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Data / Hora do Evento</label>
          <input
            type="datetime-local"
            value={dateTime}
            onChange={(e) => setDateTime(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm font-mono outline-none"
          />
        </div>

        {/* W.O. Status & Cards Forfeit HUD */}
        <div className="grid grid-cols-2 gap-4 border-t border-slate-800/60 pt-4">
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-450 font-extrabold block">Status de W.O.</label>
            <select
              value={woForfeit}
              onChange={(e) => setWoForfeit(e.target.value as 'none' | 'A' | 'B')}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400"
            >
              <option value="none">Nenhum W.O. (Jogo Normal)</option>
              <option value="A">Atleta A Faltou (Vitória W.O. do Atleta B)</option>
              <option value="B">Atleta B Faltou (Vitória W.O. do Atleta A)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-450 font-extrabold block">Observações / Súmula</label>
            <input
              type="text"
              placeholder="Ex: Falta ao jogo, má conduta..."
              value={obsNotes}
              onChange={(e) => setObsNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs outline-none"
            />
          </div>
        </div>

        {/* Penalty Cards manually registered */}
        <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-850/75 space-y-2">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Cartões de Punição</span>
          <div className="grid grid-cols-2 gap-4">
            {/* Player A cards */}
            <div className="space-y-1">
              <span className="text-[10px] text-yellow-500 font-bold block">Jogador A</span>
              <div className="flex gap-2">
                <div className="flex-1 flex items-center bg-slate-900 rounded border border-slate-800 p-1 px-2 gap-2" title="Amarelos Jogador A">
                  <span className="w-2 h-3.5 bg-yellow-400 rounded-sm" />
                  <input
                    type="number"
                    min={0}
                    value={manualYellowA}
                    onChange={(e) => setManualYellowA(Number(e.target.value))}
                    className="w-full bg-transparent font-bold text-xs text-slate-100 outline-none font-mono"
                  />
                </div>
                <div className="flex-1 flex items-center bg-slate-900 rounded border border-slate-800 p-1 px-2 gap-2" title="Vermelhos Jogador A">
                  <span className="w-2 h-3.5 bg-red-600 rounded-sm" />
                  <input
                    type="number"
                    min={0}
                    value={manualRedA}
                    onChange={(e) => setManualRedA(Number(e.target.value))}
                    className="w-full bg-transparent font-bold text-xs text-slate-100 outline-none font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Player B cards */}
            <div className="space-y-1">
              <span className="text-[10px] text-yellow-500 font-bold block">Jogador B</span>
              <div className="flex gap-2">
                <div className="flex-1 flex items-center bg-slate-900 rounded border border-slate-800 p-1 px-2 gap-2" title="Amarelos Jogador B">
                  <span className="w-2 h-3.5 bg-yellow-400 rounded-sm" />
                  <input
                    type="number"
                    min={0}
                    value={manualYellowB}
                    onChange={(e) => setManualYellowB(Number(e.target.value))}
                    className="w-full bg-transparent font-bold text-xs text-slate-100 outline-none font-mono"
                  />
                </div>
                <div className="flex-1 flex items-center bg-slate-900 rounded border border-slate-800 p-1 px-2 gap-2" title="Vermelhos Jogador B">
                  <span className="w-2 h-3.5 bg-red-600 rounded-sm" />
                  <input
                    type="number"
                    min={0}
                    value={manualRedB}
                    onChange={(e) => setManualRedB(Number(e.target.value))}
                    className="w-full bg-transparent font-bold text-xs text-slate-100 outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={handleSaveResult}
          className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
        >
          <Save className="w-4 h-4" />
          Salvar Resultado
        </button>
      </div>

      {/* RESULTS LIST HISTORY */}
      <div className="xl:col-span-6 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm flex flex-col justify-between">
        
        {/* Header containing result text search input */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/20 flex flex-col sm:flex-row items-center justify-between gap-3">
          <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider flex items-center gap-2 shrink-0">
            <Trophy className="w-4 h-4 text-yellow-400" />
            Histórico de Resultados
          </h4>
          <div className="relative w-full sm:w-48 text-sm">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar Atleta..."
              value={searchHistoryQuery}
              onChange={(e) => setSearchHistoryQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none transition"
            />
          </div>
        </div>

        {/* Results entries list */}
        <div className="overflow-x-auto flex-1 max-h-[500px]">
          <table className="w-full text-left text-sm text-slate-350">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/10 text-slate-400 text-3xs uppercase tracking-wider font-semibold">
                <th className="py-2.5 px-4">Atleta A</th>
                <th className="py-2.5 text-center w-16">Sets</th>
                <th className="py-2.5 pl-3">Atleta B</th>
                <th className="py-2.5 px-4 text-right hidden sm:table-cell">Horário</th>
                <th className="py-2.5 text-center w-12">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-805">
              {filteredHistory.length > 0 ? (
                filteredHistory.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-950/15 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-200">
                      <div className="flex flex-col">
                        <span className="truncate max-w-[150px]">{r.nomeA}</span>
                        {r.wo === 'A' && (
                          <span className="text-[9px] text-[#f87171] bg-red-950/40 border border-red-500/20 px-1 hover:border-red-500/50 rounded font-extrabold w-fit mt-1 leading-none">W.O. Faltou</span>
                        )}
                        {r.cartoesA && (
                          <div className="flex gap-1 items-center mt-1">
                            {Array.from({ length: r.cartoesA.amarelo || 0 }).map((_, i) => (
                              <span key={`ca-y-${i}`} className="w-2 h-3 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0" title="Cartão Amarelo" />
                            ))}
                            {Array.from({ length: r.cartoesA.vermelho || 0 }).map((_, i) => (
                              <span key={`ca-r-${i}`} className="w-2 h-3 bg-red-600 rounded-sm border border-red-750 block shrink-0" title="Cartão Vermelho" />
                            ))}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 text-center">
                      <span className="inline-block bg-yellow-400/10 text-yellow-400 font-extrabold px-2 py-0.5 rounded text-xs select-none shadow-sm">
                        {r.setsA}×{r.setsB}
                      </span>
                    </td>
                    <td className="py-3 pl-3 font-bold text-slate-200">
                      <div className="flex flex-col">
                        <span className="truncate max-w-[150px]">{r.nomeB}</span>
                        {r.wo === 'B' && (
                          <span className="text-[9px] text-[#f87171] bg-red-950/40 border border-red-500/20 px-1 hover:border-red-500/50 rounded font-extrabold w-fit mt-1 leading-none">W.O. Faltou</span>
                        )}
                        {r.cartoesB && (
                          <div className="flex gap-1 items-center mt-1">
                            {Array.from({ length: r.cartoesB.amarelo || 0 }).map((_, i) => (
                              <span key={`cb-y-${i}`} className="w-2 h-3 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0" title="Cartão Amarelo" />
                            ))}
                            {Array.from({ length: r.cartoesB.vermelho || 0 }).map((_, i) => (
                              <span key={`cb-r-${i}`} className="w-2 h-3 bg-red-600 rounded-sm border border-red-755 block shrink-0" title="Cartão Vermelho" />
                            ))}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right text-xs font-mono text-slate-400 hidden sm:table-cell">
                      <div className="flex flex-col items-end gap-0.5 leading-none">
                        <span>{new Date(r.dt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</span>
                        {r.obs && (
                          <span className="text-[10px] text-yellow-400/80 italic font-sans truncate max-w-[180px] mt-0.5" title={r.obs}>
                            {r.obs}
                          </span>
                        )}
                        <span className="text-[9px] text-slate-500 font-sans mt-0.5">
                          Mesa {r.mesa} • Por {r.arb || 'Juiz'}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 text-center">
                      <button
                        onClick={() => {
                          if (confirm(`Remover resultado registrado de "${r.nomeA} x ${r.nomeB}"?`)) {
                            onDelete(r.id);
                          }
                        }}
                        className="text-slate-450 hover:text-red-400 p-1.5 hover:bg-slate-800 rounded transition"
                        title="Remover"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500">
                    Nenhum resultado registrado no sistema.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
