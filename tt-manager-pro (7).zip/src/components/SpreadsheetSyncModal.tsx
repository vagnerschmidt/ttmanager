import React, { useState, useRef, useEffect } from 'react';
import { 
  FileSpreadsheet, Upload, Download, CheckCircle2, AlertCircle, 
  ArrowRight, RefreshCw, Zap, ShieldCheck, X, Layers, Users, Trophy, UserCheck, Briefcase, Tag,
  Globe, ExternalLink, Plus, Cloud, Check
} from 'lucide-react';
import { 
  CurrentSystemState, 
  generateSpreadsheetTemplate, 
  parseSpreadsheetFile, 
  executeSmartSystemSync, 
  applySyncToState, 
  exportSynchronizedSpreadsheet,
  SyncDiffReport 
} from '../utils/spreadsheetSync';
import { triggerToast } from '../utils/toast';
import { 
  getGoogleSheetsSettings, 
  saveGoogleSheetsSettings, 
  requestGoogleSheetsAccessToken, 
  createGoogleSpreadsheet, 
  syncDataToGoogleSheet, 
  fetchGoogleSheetData, 
  extractSpreadsheetId, 
  GoogleSheetsSettings 
} from '../utils/googleSheets';

interface SpreadsheetSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: CurrentSystemState;
  onApplySync: (newState: CurrentSystemState) => void;
}

export default function SpreadsheetSyncModal({
  isOpen,
  onClose,
  currentState,
  onApplySync
}: SpreadsheetSyncModalProps) {
  const [syncSource, setSyncSource] = useState<'local' | 'gsheets'>('local');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [diffReport, setDiffReport] = useState<SyncDiffReport | null>(null);
  const [activeTab, setActiveTab] = useState<'atletas' | 'arbitros' | 'treinadores' | 'funcionarios' | 'torneios' | 'categorias'>('atletas');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Google Sheets state
  const [gsSettings, setGsSettings] = useState<GoogleSheetsSettings>(getGoogleSheetsSettings);
  const [gsInputUrl, setGsInputUrl] = useState('');
  const [isSyncingGs, setIsSyncingGs] = useState(false);
  const [showConfirmCreateModal, setShowConfirmCreateModal] = useState(false);

  // Sync settings on modal load
  useEffect(() => {
    if (isOpen) {
      const settings = getGoogleSheetsSettings();
      setGsSettings(settings);
      if (settings.linkedSpreadsheetUrl) {
        setGsInputUrl(settings.linkedSpreadsheetUrl);
      }
    }
  }, [isOpen]);

  // Escape key handler to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  // Handle template download
  const handleDownloadTemplate = () => {
    try {
      const blob = generateSpreadsheetTemplate();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'Modelo_Sincronizacao_Sistema_TTManager.xlsx');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      triggerToast('Modelo de planilha baixado com sucesso!', 'success');
    } catch (err) {
      console.error(err);
      triggerToast('Erro ao gerar modelo de planilha', 'error');
    }
  };

  // Handle file selection & instant comparison
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    await processFile(selected);
  };

  const processFile = async (selectedFile: File) => {
    setFile(selectedFile);
    setLoading(true);
    try {
      const parsedData = await parseSpreadsheetFile(selectedFile);
      const report = executeSmartSystemSync(currentState, parsedData);
      setDiffReport(report);
      triggerToast(`Planilha comparada em ${report.summary.executionTimeMs}ms!`, 'info');
    } catch (err) {
      console.error(err);
      triggerToast('Erro ao processar e comparar campos da planilha', 'error');
      setDiffReport(null);
    } finally {
      setLoading(false);
    }
  };

  // Dropzone drag handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  // Google Sheets: Connect / Authorize
  const handleConnectGoogleSheets = async () => {
    try {
      triggerToast('Solicitando autorização segura do Google Sheets...', 'info');
      const token = await requestGoogleSheetsAccessToken();
      setGsSettings(getGoogleSheetsSettings());
      triggerToast('Conta do Google Sheets conectada com sucesso!', 'success');
      return token;
    } catch (err: any) {
      console.error(err);
      triggerToast(`Falha na conexão com Google Sheets: ${err.message || 'Ação cancelada'}`, 'error');
      return null;
    }
  };

  // Google Sheets: Create New Spreadsheet (after confirmation)
  const handleConfirmCreateSpreadsheet = async () => {
    setShowConfirmCreateModal(false);
    setIsSyncingGs(true);
    try {
      let token = gsSettings.accessToken;
      const now = Date.now();
      if (!token || !gsSettings.tokenExpiresAt || gsSettings.tokenExpiresAt < now + 60000) {
        token = await requestGoogleSheetsAccessToken();
      }

      if (!token) return;

      const res = await createGoogleSpreadsheet(currentState, token);
      setGsSettings(getGoogleSheetsSettings());
      setGsInputUrl(res.spreadsheetUrl);
      triggerToast(`Nova Planilha criada com sucesso no Google Sheets!`, 'success');
    } catch (err: any) {
      console.error(err);
      triggerToast(`Erro ao criar planilha no Google Sheets: ${err.message}`, 'error');
    } finally {
      setIsSyncingGs(false);
    }
  };

  // Google Sheets: Fetch & Compare live data from Google Sheets API
  const handleFetchFromGoogleSheets = async () => {
    const sheetId = extractSpreadsheetId(gsInputUrl);
    if (!sheetId) {
      triggerToast('Por favor, informe uma URL ou ID válido de Planilha do Google Sheets.', 'warning');
      return;
    }

    setIsSyncingGs(true);
    setLoading(true);
    try {
      let token = gsSettings.accessToken;
      const now = Date.now();
      if (!token || !gsSettings.tokenExpiresAt || gsSettings.tokenExpiresAt < now + 60000) {
        token = await requestGoogleSheetsAccessToken();
      }

      if (!token) return;

      const parsedData = await fetchGoogleSheetData(sheetId, token);
      const totalRecordCount = 
        (parsedData.atletas?.length || 0) +
        (parsedData.arbitros?.length || 0) +
        (parsedData.treinadores?.length || 0) +
        (parsedData.funcionarios?.length || 0) +
        (parsedData.torneios?.length || 0) +
        (parsedData.categorias?.length || 0);

      const report = executeSmartSystemSync(currentState, parsedData);
      setDiffReport(report);

      saveGoogleSheetsSettings({
        linkedSpreadsheetId: sheetId,
        linkedSpreadsheetUrl: gsInputUrl.startsWith('http') ? gsInputUrl : `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
        lastSyncTime: now,
        lastSyncStatus: 'Sucesso',
        totalRecordCount,
      });
      setGsSettings(getGoogleSheetsSettings());

      triggerToast(`Dados do Google Sheets lidos e comparados em ${report.summary.executionTimeMs}ms!`, 'success');
    } catch (err: any) {
      console.error(err);
      triggerToast(`Erro ao ler dados do Google Sheets: ${err.message}`, 'error');
    } finally {
      setIsSyncingGs(false);
      setLoading(false);
    }
  };

  // Google Sheets: Push current system state directly into Google Sheets API
  const handlePushToGoogleSheets = async () => {
    const sheetId = extractSpreadsheetId(gsInputUrl) || gsSettings.linkedSpreadsheetId;
    if (!sheetId) {
      triggerToast('Nenhuma planilha do Google Sheets vinculada. Crie uma nova ou cole a URL.', 'warning');
      return;
    }

    const confirmed = window.confirm(
      `Deseja atualizar a planilha no Google Sheets com os ${currentState.atletas.length} atletas e dados do sistema?`
    );
    if (!confirmed) return;

    setIsSyncingGs(true);
    try {
      let token = gsSettings.accessToken;
      const now = Date.now();
      if (!token || !gsSettings.tokenExpiresAt || gsSettings.tokenExpiresAt < now + 60000) {
        token = await requestGoogleSheetsAccessToken();
      }

      if (!token) return;

      const activeState = diffReport ? applySyncToState(currentState, diffReport) : currentState;
      await syncDataToGoogleSheet(sheetId, activeState, token);

      const totalRecordCount = 
        activeState.atletas.length +
        activeState.arbitros.length +
        activeState.treinadores.length +
        activeState.funcionarios.length +
        activeState.torneios.length +
        activeState.categorias.length;

      saveGoogleSheetsSettings({
        linkedSpreadsheetId: sheetId,
        lastSyncTime: Date.now(),
        lastSyncStatus: 'Sucesso',
        totalRecordCount,
      });
      setGsSettings(getGoogleSheetsSettings());

      triggerToast('Dados sincronizados e gravados com sucesso no Google Sheets!', 'success');
    } catch (err: any) {
      console.error(err);
      triggerToast(`Erro ao enviar dados para o Google Sheets: ${err.message}`, 'error');
    } finally {
      setIsSyncingGs(false);
    }
  };

  // Handle downloading the unified, fully synchronized official spreadsheet (.xlsx)
  const handleExportSynchronizedFile = () => {
    try {
      const activeState = diffReport ? applySyncToState(currentState, diffReport) : currentState;
      const blob = exportSynchronizedSpreadsheet(activeState);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Planilha_Oficial_Sincronizada_${new Date().toISOString().slice(0,10)}.xlsx`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      triggerToast('Planilha Oficial Sincronizada (.xlsx) gerada e baixada com sucesso!', 'success');
    } catch (err) {
      console.error(err);
      triggerToast('Erro ao exportar planilha oficial sincronizada', 'error');
    }
  };

  // Single-Click Sync Execution
  const handleConfirmSync = () => {
    if (!diffReport) return;
    const newState = applySyncToState(currentState, diffReport);
    onApplySync(newState);
    triggerToast(
      `Sincronização concluída! Sistema e Planilha alinhados com +${diffReport.summary.totalAdded} novos e ${diffReport.summary.totalUpdated} atualizados`,
      'success'
    );
    onClose();
  };

  const renderDiffSection = (sectionName: keyof Omit<SyncDiffReport, 'summary'>, title: string, icon: React.ReactNode) => {
    if (!diffReport) return null;
    const section = diffReport[sectionName];

    return (
      <div className="space-y-4">
        {/* Section Header Metrics */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-950/60 rounded-lg border border-slate-800">
          <div className="flex items-center gap-2">
            {icon}
            <span className="font-semibold text-slate-100 text-sm">{title}</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              +{section.added.length} novos
            </span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
              {section.updated.length} alterados
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              {section.unchangedCount} inalterados (ignorados)
            </span>
          </div>
        </div>

        {/* List of Differences */}
        {section.diffs.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm italic">
            Nenhuma alteração identificada nesta categoria.
          </div>
        ) : (
          <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
            {section.diffs.map((diff) => {
              if (diff.status === 'UNCHANGED') return null; // Skip rendering unchanged rows for high performance

              return (
                <div 
                  key={diff.id} 
                  className={`p-3 rounded-lg border text-sm transition ${
                    diff.status === 'ADDED' 
                      ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200' 
                      : 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold mb-1">
                    <span className="flex items-center gap-2">
                      {diff.status === 'ADDED' ? (
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-amber-400" />
                      )}
                      {diff.name}
                      <span className="text-xs font-mono text-slate-400 font-normal">({diff.id})</span>
                    </span>
                    <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-slate-900 border border-slate-700">
                      {diff.status === 'ADDED' ? 'NOVO REGISTRO' : 'CAMPO(S) ALTERADO(S)'}
                    </span>
                  </div>

                  {diff.status === 'ADDED' && (
                    <p className="text-xs text-slate-400 mt-1">
                      Será adicionado ao sistema com todos os dados preenchidos da planilha.
                    </p>
                  )}

                  {diff.status === 'UPDATED' && (
                    <div className="mt-2 space-y-1">
                      {diff.changes.map((c, i) => (
                        <div key={i} className="flex flex-wrap items-center gap-2 text-xs font-mono bg-slate-950/80 p-1.5 rounded border border-slate-800">
                          <span className="text-slate-400 font-sans font-semibold">{c.label}:</span>
                          <span className="line-through text-red-400">{String(c.oldVal)}</span>
                          <ArrowRight className="w-3 h-3 text-amber-400" />
                          <span className="text-emerald-400 font-bold">{String(c.newVal)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn"
    >
      <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Zap className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                Sincronização Inteligente de Planilha
                <span className="text-[10px] sm:text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                  1 Clique
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Alimenta todo o sistema comparando campos individualmente e ignorando dados inalterados para alta performance.
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition shrink-0"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Source Selector Tabs */}
          <div className="flex border-b border-slate-800 gap-2">
            <button
              type="button"
              onClick={() => setSyncSource('local')}
              className={`pb-2 px-4 text-xs font-bold transition flex items-center gap-2 border-b-2 ${
                syncSource === 'local'
                  ? 'border-emerald-400 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4" />
              Arquivo Local (.xlsx / .csv)
            </button>
            <button
              type="button"
              onClick={() => setSyncSource('gsheets')}
              className={`pb-2 px-4 text-xs font-bold transition flex items-center gap-2 border-b-2 ${
                syncSource === 'gsheets'
                  ? 'border-emerald-400 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Globe className="w-4 h-4 text-emerald-400" />
              Google Sheets (API em Nuvem) 📊
            </button>
          </div>

          {/* Local File Sync Option */}
          {syncSource === 'local' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Action 1: Download Official Template */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 transition flex flex-col justify-between space-y-3">
                <div className="flex items-start gap-3">
                  <FileSpreadsheet className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-semibold text-slate-100">Modelo Oficial de Planilha</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Baixe o arquivo Excel (.xlsx) contendo todas as abas e cabeçalhos preformatados.
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleDownloadTemplate}
                  className="w-full py-2 px-3 bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                  Baixar Modelo Oficial (.xlsx)
                </button>
              </div>

              {/* Action 2: Upload / Drag Drop */}
              <div 
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className="p-4 rounded-xl bg-slate-950 border border-dashed border-emerald-500/40 hover:border-emerald-400 transition cursor-pointer flex flex-col items-center justify-center text-center space-y-2 group"
              >
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileSelect} 
                  accept=".xlsx, .xls, .csv, .json" 
                  className="hidden" 
                />
                <Upload className="w-7 h-7 text-emerald-400 group-hover:scale-110 transition duration-200" />
                <div>
                  <p className="text-xs font-semibold text-slate-200">
                    {file ? file.name : 'Clique ou arraste a planilha aqui'}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Suporta arquivos .xlsx, .xls, .csv ou backup .json
                  </p>
                </div>
              </div>

            </div>
          )}

          {/* Google Sheets Live API Sync Option */}
          {syncSource === 'gsheets' && (
            <div className="bg-slate-950 border border-emerald-500/30 rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                      Integração com Google Sheets API
                      <span className="text-3xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">
                        Nuvem
                      </span>
                    </h4>
                    <p className="text-xs text-slate-400">
                      Leia, importe e atualize diretamente suas planilhas no Google Sheets sem precisar baixar arquivos manuais.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleConnectGoogleSheets}
                  className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold rounded-lg transition flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  {gsSettings.accessToken ? '✓ Conta Google Conectada' : 'Conectar Google Sheets'}
                </button>
              </div>

              {/* URL or ID Input and Action Controls */}
              <div className="space-y-3">
                <label className="text-xs font-semibold text-slate-300 block">
                  URL ou ID da Planilha do Google Sheets:
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    placeholder="https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit"
                    value={gsInputUrl}
                    onChange={(e) => setGsInputUrl(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 focus:border-emerald-400 text-slate-100 text-xs rounded-lg px-3 py-2.5 outline-none font-mono"
                  />
                  
                  <button
                    type="button"
                    onClick={handleFetchFromGoogleSheets}
                    disabled={isSyncingGs || !gsInputUrl}
                    className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-lg transition flex items-center justify-center gap-2 cursor-pointer shrink-0"
                  >
                    {isSyncingGs ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Zap className="w-4 h-4 fill-current" />
                    )}
                    <span>Sincronizar do Google Sheets</span>
                  </button>
                </div>

                {/* Additional Google Sheets Actions */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-850">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowConfirmCreateModal(true)}
                      disabled={isSyncingGs}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4 text-emerald-400" />
                      <span>Criar Nova Planilha no Google Sheets</span>
                    </button>

                    <button
                      type="button"
                      onClick={handlePushToGoogleSheets}
                      disabled={isSyncingGs || (!gsInputUrl && !gsSettings.linkedSpreadsheetId)}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <Upload className="w-4 h-4 text-emerald-400" />
                      <span>Exportar Dados Atuais p/ Google Sheets</span>
                    </button>
                  </div>

                  {gsSettings.linkedSpreadsheetUrl && (
                    <a
                      href={gsSettings.linkedSpreadsheetUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                    >
                      Abrir no Google Sheets <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>

              {gsSettings.lastSyncTime && (
                <div className="text-3xs text-slate-400 font-mono flex items-center gap-1.5 pt-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    Última sincronização do Google Sheets: {new Date(gsSettings.lastSyncTime).toLocaleString('pt-BR')} ({gsSettings.lastSyncStatus || 'Sucesso'})
                  </span>
                </div>
              )}
            </div>
          )}

          {/* User Confirmation Modal for Creating New Google Spreadsheet */}
          {showConfirmCreateModal && (
            <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 max-w-md w-full space-y-4 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-100">Criar Nova Planilha no Google Sheets?</h4>
                    <p className="text-xs text-slate-400">Google Sheets API</p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Isso irá criar um novo documento de planilha na sua conta do Google Drive e preenchê-lo com as abas de <strong>Atletas</strong>, <strong>Árbitros</strong>, <strong>Treinadores</strong>, <strong>Funcionários</strong>, <strong>Torneios</strong> e <strong>Categorias</strong> do TT Manager Pro.
                </p>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowConfirmCreateModal(false)}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmCreateSpreadsheet}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    Confirmar e Criar
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="p-8 text-center bg-slate-950/40 rounded-xl border border-slate-800 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
              <p className="text-sm text-slate-300 font-medium">Analisando e comparando campos da planilha...</p>
            </div>
          )}

          {/* Comparison Preview Dashboard */}
          {diffReport && !loading && (
            <div className="space-y-4">
              
              {/* Summary Stats Banner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center">
                  <span className="text-xs text-slate-400 block font-sans">Novos Registros</span>
                  <span className="text-xl font-bold text-emerald-400 font-mono">+{diffReport.summary.totalAdded}</span>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center">
                  <span className="text-xs text-slate-400 block font-sans">Atualizados (Diff)</span>
                  <span className="text-xl font-bold text-amber-400 font-mono">{diffReport.summary.totalUpdated}</span>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center">
                  <span className="text-xs text-slate-400 block font-sans">Sem Alteração (Ignorados)</span>
                  <span className="text-xl font-bold text-slate-400 font-mono">{diffReport.summary.totalUnchanged}</span>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg border border-slate-800 text-center">
                  <span className="text-xs text-slate-400 block font-sans">Tempo de Análise</span>
                  <span className="text-xl font-bold text-emerald-400 font-mono">{diffReport.summary.executionTimeMs} ms</span>
                </div>
              </div>

              {/* Entity Navigation Tabs */}
              <div className="flex border-b border-slate-800 overflow-x-auto gap-1">
                <button
                  onClick={() => setActiveTab('atletas')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'atletas' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  Atletas ({diffReport.atletas.added.length + diffReport.atletas.updated.length})
                </button>

                <button
                  onClick={() => setActiveTab('arbitros')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'arbitros' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  Árbitros ({diffReport.arbitros.added.length + diffReport.arbitros.updated.length})
                </button>

                <button
                  onClick={() => setActiveTab('treinadores')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'treinadores' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  Treinadores ({diffReport.treinadores.added.length + diffReport.treinadores.updated.length})
                </button>

                <button
                  onClick={() => setActiveTab('funcionarios')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'funcionarios' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  Funcionários ({diffReport.funcionarios.added.length + diffReport.funcionarios.updated.length})
                </button>

                <button
                  onClick={() => setActiveTab('torneios')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'torneios' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Trophy className="w-3.5 h-3.5" />
                  Torneios ({diffReport.torneios.added.length + diffReport.torneios.updated.length})
                </button>

                <button
                  onClick={() => setActiveTab('categorias')}
                  className={`px-4 py-2 text-xs font-semibold rounded-t-lg transition flex items-center gap-2 border-b-2 whitespace-nowrap ${
                    activeTab === 'categorias' 
                      ? 'border-emerald-400 text-emerald-400 bg-slate-850' 
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Tag className="w-3.5 h-3.5" />
                  Categorias ({diffReport.categorias.added.length + diffReport.categorias.updated.length})
                </button>
              </div>

              {/* Tab Content Display */}
              <div className="bg-slate-950 p-4 rounded-b-xl border border-slate-800">
                {activeTab === 'atletas' && renderDiffSection('atletas', 'Atletas', <Users className="w-4 h-4 text-emerald-400" />)}
                {activeTab === 'arbitros' && renderDiffSection('arbitros', 'Árbitros', <UserCheck className="w-4 h-4 text-emerald-400" />)}
                {activeTab === 'treinadores' && renderDiffSection('treinadores', 'Treinadores', <Users className="w-4 h-4 text-emerald-400" />)}
                {activeTab === 'funcionarios' && renderDiffSection('funcionarios', 'Funcionários', <Briefcase className="w-4 h-4 text-emerald-400" />)}
                {activeTab === 'torneios' && renderDiffSection('torneios', 'Torneios', <Trophy className="w-4 h-4 text-emerald-400" />)}
                {activeTab === 'categorias' && renderDiffSection('categorias', 'Categorias', <Tag className="w-4 h-4 text-emerald-400" />)}
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Harmonização bidirecional: a planilha e o sistema ficam 100% idênticos.</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition"
            >
              Cancelar
            </button>

            <button
              onClick={handleExportSynchronizedFile}
              className="px-3.5 py-2 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer shadow-sm"
              title="Baixar planilha unificada e formatada com os dados sincronizados"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Baixar Planilha Oficial Sincronizada (.xlsx)</span>
            </button>

            <button
              disabled={!diffReport || (diffReport.summary.totalAdded === 0 && diffReport.summary.totalUpdated === 0)}
              onClick={handleConfirmSync}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer ${
                diffReport && (diffReport.summary.totalAdded > 0 || diffReport.summary.totalUpdated > 0)
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-lg shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>Sincronizar Sistema em 1 Clique</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
