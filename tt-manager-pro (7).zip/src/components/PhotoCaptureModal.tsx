import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, Check, X } from 'lucide-react';

interface PhotoCaptureModalProps {
  onCapture: (dataUrl: string) => void;
  onClose: () => void;
}

export default function PhotoCaptureModal({ onCapture, onClose }: PhotoCaptureModalProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [previewData, setPreviewData] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Start camera stream on mount
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
      .then((mediaStream) => {
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      })
      .catch((err) => {
        console.error("Camera error:", err);
        setError("Não foi possível acessar a câmera. Verifique as permissões do navegador.");
      });

    return () => {
      // Clean up stream on unmount
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setPreviewData(dataUrl);
      }
    }
  };

  const handleConfirm = () => {
    if (previewData) {
      onCapture(previewData);
      onClose();
    }
  };

  const handleRetry = () => {
    setPreviewData(null);
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-[999] flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          <h3 className="font-bold text-slate-100 flex items-center gap-2">
            <Camera className="w-5 h-5 text-yellow-400" />
            Tirar Foto
          </h3>
          <button 
            type="button" 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 flex flex-col items-center">
          {error ? (
            <div className="text-center py-6">
              <p className="text-red-400 text-sm mb-4 font-medium">{error}</p>
              <button 
                type="button" 
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 text-slate-200 border border-slate-700 rounded-lg hover:bg-slate-700 text-xs font-semibold"
              >
                Fechar e Usar Upload
              </button>
            </div>
          ) : (
            <div className="w-full">
              <div className="relative aspect-3/4 max-h-[320px] w-full bg-black rounded-lg overflow-hidden border border-slate-700 flex items-center justify-center">
                {/* Real-time Video Stream */}
                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  muted
                  className={`w-full h-full object-cover transform -scale-x-100 ${previewData ? 'hidden' : 'block'}`}
                />
                
                {/* Taken snapshot image */}
                {previewData && (
                  <img 
                    src={previewData} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                  />
                )}

                {/* Hidden processing canvas */}
                <canvas ref={canvasRef} className="hidden" />
              </div>

              <div className="mt-6 flex justify-center gap-4">
                {!previewData ? (
                  <button
                    type="button"
                    onClick={handleCapture}
                    className="w-16 h-16 rounded-full bg-yellow-400 hover:bg-yellow-300 border-4 border-white shadow-lg cursor-pointer transition active:scale-95 flex items-center justify-center text-slate-900"
                    title="Capturar Foto"
                  >
                    <Camera className="w-8 h-8" />
                  </button>
                ) : (
                  <div className="flex gap-4 w-full">
                    <button
                      type="button"
                      onClick={handleRetry}
                      className="flex-1 py-2 px-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg font-semibold text-sm transition flex items-center justify-center gap-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Refazer
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirm}
                      className="flex-1 py-2 px-4 bg-yellow-400 hover:bg-yellow-300 text-slate-950 rounded-lg font-semibold text-sm transition flex items-center justify-center gap-2"
                    >
                      <Check className="w-4 h-4" />
                      Confirmar
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
