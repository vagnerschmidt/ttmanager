import React, { useState } from 'react';
import { Atleta, Categoria, Torneio, Inscricao } from '../types';
import { Search, Plus, Eye, Edit, Trash2, Camera, Upload, X, Save, ShieldAlert, BookOpen, Printer, Send, Copy, Share2, Trophy, Sparkles, CheckCircle2 } from 'lucide-react';
import PhotoCaptureModal from './PhotoCaptureModal';
import DateInput from './DateInput';
import { triggerToast } from '../utils/toast';
import { exportAtletasToPDF } from '../utils/pdfExport';
import { normalizePhoneToBrazil } from '../utils/phone';
import { isValidCPF, formatCPF } from '../utils/cpf';
import { generateAutoBracketForCategory } from '../utils/bracketGenerator';

interface AtletasViewProps {
  atletas: Atleta[];
  categorias: Categoria[];
  torneios?: Torneio[];
  inscricoes?: Inscricao[];
  onSave: (atleta: Atleta) => void;
  onDelete: (id: string) => void;
  onSaveInscricoes?: (inscricoes: Inscricao[]) => void;
  onNavigateToSection?: (sectionId: string) => void;
  userRole?: 'comum' | 'admin' | 'master';
}

export default function AtletasView({ 
  atletas, 
  categorias, 
  torneios = [],
  inscricoes = [],
  onSave, 
  onDelete, 
  onSaveInscricoes,
  onNavigateToSection,
  userRole = 'comum' 
}: AtletasViewProps) {
  // Filters & Pagination State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterPresenca, setFilterPresenca] = useState('');
  const [filterPagamento, setFilterPagamento] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const pageSize = 10;

  // Selected athlete for viewing
  const [inspectAthlete, setInspectAthlete] = useState<Atleta | null>(null);

  // Modal Athlete Form States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'pessoal' | 'esportivo' | 'inscricao' | 'contato'>('pessoal');
  const [formId, setFormId] = useState('');
  const [formFoto, setFormFoto] = useState('');
  const [isCamOpen, setIsCamOpen] = useState(false);

  // Tournament Auto-Enrollment Form States
  const [formAutoEnroll, setFormAutoEnroll] = useState(true);
  const [formTorneioId, setFormTorneioId] = useState('');
  const [formInscricaoCat, setFormInscricaoCat] = useState('');
  const [formStatusPagamentoInscricao, setFormStatusPagamentoInscricao] = useState<'Pendente' | 'Pago' | 'Isento'>('Pendente');
  const [formValorTaxa, setFormValorTaxa] = useState('80.00');
  const [formAutoGenerateBracket, setFormAutoGenerateBracket] = useState(true);

  // Form Individual Inputs
  const [formNome, setFormNome] = useState('');
  const [formNasc, setFormNasc] = useState('');
  const [formCpf, setFormCpf] = useState('');
  const [formGenero, setFormGenero] = useState('Masculino');
  const [formNatural, setFormNatural] = useState('');
  
  // Custom address sub-fields
  const [formCep, setFormCep] = useState('');
  const [formLogradouro, setFormLogradouro] = useState('');
  const [formNumero, setFormNumero] = useState('');
  const [formComplemento, setFormComplemento] = useState('');
  const [formBairro, setFormBairro] = useState('');
  const [formCidade, setFormCidade] = useState('');
  const [formUf, setFormUf] = useState('');

  // Multi-Category selection
  const [formCats, setFormCats] = useState<string[]>(['Adulto']);

  const [formClube, setFormClube] = useState('');
  const [formRating, setFormRating] = useState(0);
  const [formCbtt, setFormCbtt] = useState('');
  const [formNivel, setFormNivel] = useState('Iniciante');
  const [formMao, setFormMao] = useState('Direita');
  const [formEmp, setFormEmp] = useState('Shakehand');
  const [formStatus, setFormStatus] = useState('Ativo');
  const [formObs, setFormObs] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formWa, setFormWa] = useState('');
  const [formTel, setFormTel] = useState('');
  const [formEmerg, setFormEmerg] = useState('');
  const [formResp, setFormResp] = useState('');
  const [formRespCpf, setFormRespCpf] = useState('');
  const [formPresenca, setFormPresenca] = useState('CONFIRMADA');
  const [formPagamento, setFormPagamento] = useState('PAGO');

  // Auto-categorize categories based on athletes present
  const availableCategories = Array.from(
    new Set(atletas.flatMap(a => a.cat ? a.cat.split(',').map(s => s.trim()) : []))
  ).filter(Boolean).sort();

  // Confirm presence at organizer table for an individual athlete
  const handleConfirmPresenceAtMesa = (a: Atleta) => {
    const isCurrentlyConfirmed = (a.presenca || 'CONFIRMADA') === 'CONFIRMADA';
    const nextPresenca = isCurrentlyConfirmed ? 'PENDENTE' : 'CONFIRMADA';
    const updatedAtleta: Atleta = {
      ...a,
      presenca: nextPresenca
    };
    onSave(updatedAtleta);

    // Also update confirmada on inscriptions if callback exists
    if (onSaveInscricoes && inscricoes && inscricoes.length > 0) {
      const updatedInscs = inscricoes.map(i => {
        if (i.atletaId === a.id) {
          return { ...i, confirmada: nextPresenca === 'CONFIRMADA' };
        }
        return i;
      });
      onSaveInscricoes(updatedInscs);
    }

    if (nextPresenca === 'CONFIRMADA') {
      triggerToast(`✓ Presença de ${a.nome} CONFIRMADA na Mesa Organizadora!`, 'success');
    } else {
      triggerToast(`Presença de ${a.nome} alterada para PENDENTE.`, 'info');
    }
  };

  // Confirm presence for all currently filtered athletes at Mesa Organizadora
  const handleConfirmAllPresence = () => {
    if (filteredData.length === 0) {
      triggerToast('Nenhum atleta encontrado no filtro atual.', 'warning');
      return;
    }
    let count = 0;
    filteredData.forEach(a => {
      if (a.presenca !== 'CONFIRMADA') {
        onSave({ ...a, presenca: 'CONFIRMADA' });
        count++;
      }
    });

    if (onSaveInscricoes && inscricoes) {
      const filteredIds = new Set(filteredData.map(a => a.id));
      const updatedInscs = inscricoes.map(i => {
        if (filteredIds.has(i.atletaId)) {
          return { ...i, confirmada: true };
        }
        return i;
      });
      onSaveInscricoes(updatedInscs);
    }

    triggerToast(`⚡ Presença na Mesa Organizadora confirmada para ${count > 0 ? count + ' atleta(s)' : 'todos os atletas'}!`, 'success');
  };

  // Helper to trigger ViaCEP search on Cep change
  const handleCepChange = (val: string) => {
    const cleanCep = val.replace(/\D/g, '').slice(0, 8);
    let formatted = cleanCep;
    if (cleanCep.length > 5) {
      formatted = `${cleanCep.slice(0, 5)}-${cleanCep.slice(5)}`;
    }
    setFormCep(formatted);

    if (cleanCep.length === 8) {
      fetch(`https://viacep.com.br/ws/${cleanCep}/json/`)
        .then(res => res.json())
        .then(data => {
          if (!data.erro) {
            setFormLogradouro(data.logradouro || '');
            setFormBairro(data.bairro || '');
            setFormCidade(data.localidade || '');
            setFormUf(data.uf || '');
            if (data.complemento) {
              setFormComplemento(data.complemento);
            }
          }
        })
        .catch(err => console.error("Erro ao buscar CEP:", err));
    }
  };

  // Handle Photo input file
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        if (uploadEvent.target?.result) {
          setFormFoto(uploadEvent.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Open form for Creating or Editing
  const handleOpenForm = (a?: Atleta) => {
    const defaultTornId = torneios && torneios.length > 0 ? torneios[0].id : '';
    const defaultCatName = categorias && categorias.length > 0 ? categorias[0].nome : 'Adulto';

    if (a) {
      // Edit mode
      setFormId(a.id);
      setFormNome(a.nome);
      setFormNasc(a.nasc);
      setFormCpf(a.cpf);
      setFormGenero(a.genero);
      setFormNatural(a.natural);

      // Parse structured address if present
      let cep = '';
      let logradouro = '';
      let numero = '';
      let complemento = '';
      let bairro = '';
      let cidade = '';
      let uf = '';

      if (a.end) {
        if (a.end.includes(' | ')) {
          const parts = a.end.split(' | ');
          if (parts.length >= 4) {
            cep = parts[0].replace('CEP: ', '');
            const streetPart = parts[1];
            const commaIndex = streetPart.indexOf(', ');
            if (commaIndex !== -1) {
              logradouro = streetPart.substring(0, commaIndex);
              const rest = streetPart.substring(commaIndex + 2);
              const dashIndex = rest.indexOf(' - ');
              if (dashIndex !== -1) {
                numero = rest.substring(0, dashIndex);
                complemento = rest.substring(dashIndex + 3);
              } else {
                numero = rest;
              }
            } else {
              logradouro = streetPart;
            }
            bairro = parts[2];
            const cityState = parts[3].split(' - ');
            cidade = cityState[0];
            uf = cityState[1] || '';
          } else {
            logradouro = a.end;
          }
        } else {
          logradouro = a.end;
        }
      }

      setFormCep(cep);
      setFormLogradouro(logradouro);
      setFormNumero(numero);
      setFormComplemento(complemento);
      setFormBairro(bairro);
      setFormCidade(cidade);
      setFormUf(uf);

      const parsedCats = a.cat ? a.cat.split(',').map(s => s.trim()).filter(Boolean) : ['Adulto'];
      setFormCats(parsedCats);

      setFormClube(a.clube);
      setFormRating(a.rating);
      setFormCbtt(a.cbtt);
      setFormNivel(a.nivel);
      setFormMao(a.mao);
      setFormEmp(a.emp);
      setFormStatus(a.status);
      setFormObs(a.obs);
      setFormEmail(a.email);
      setFormWa(a.wa);
      setFormTel(a.tel);
      setFormEmerg(a.emerg);
      setFormResp(a.resp);
      setFormRespCpf(a.respCpf);
      setFormPresenca(a.presenca || 'CONFIRMADA');
      setFormPagamento(a.pagamento || 'PAGO');
      setFormFoto(a.foto);

      // Check existing inscription
      const existingIns = (inscricoes || []).find(i => i.atletaId === a.id);
      if (existingIns) {
        setFormAutoEnroll(true);
        setFormTorneioId(existingIns.torneioId);
        setFormInscricaoCat(existingIns.categoria);
        setFormStatusPagamentoInscricao(existingIns.statusPagamento || 'Pendente');
        setFormValorTaxa(existingIns.valorTaxa || '80.00');
      } else {
        setFormAutoEnroll(Boolean(defaultTornId));
        setFormTorneioId(defaultTornId);
        setFormInscricaoCat(parsedCats[0] || defaultCatName);
        setFormStatusPagamentoInscricao('Pendente');
        setFormValorTaxa('80.00');
      }
    } else {
      // Create mode
      setFormId('');
      setFormNome('');
      setFormNasc('');
      setFormCpf('');
      setFormGenero('Masculino');
      setFormNatural('');
      setFormCep('');
      setFormLogradouro('');
      setFormNumero('');
      setFormComplemento('');
      setFormBairro('');
      setFormCidade('');
      setFormUf('');
      setFormCats(['Adulto']);
      setFormClube('');
      setFormRating(1000);
      setFormCbtt('');
      setFormNivel('Iniciante');
      setFormMao('Direita');
      setFormEmp('Shakehand');
      setFormStatus('Ativo');
      setFormPresenca('CONFIRMADA');
      setFormPagamento('PAGO');
      setFormObs('');
      setFormEmail('');
      setFormWa('');
      setFormTel('');
      setFormEmerg('');
      setFormResp('');
      setFormRespCpf('');
      setFormFoto('');

      setFormAutoEnroll(Boolean(defaultTornId));
      setFormTorneioId(defaultTornId);
      setFormInscricaoCat(defaultCatName);
      setFormStatusPagamentoInscricao('Pendente');
      setFormValorTaxa('80.00');
      setFormAutoGenerateBracket(true);
    }
    setActiveTab('pessoal');
    setIsFormOpen(true);
  };

  const handleSave = (andNavigateToBracket = false) => {
    if (!formNome.trim()) {
      triggerToast("Nome completo é obrigatório!", "warning");
      return;
    }
    if (formCpf.trim() && !isValidCPF(formCpf)) {
      triggerToast(`O CPF do atleta (${formCpf}) é inválido! Verifique os dígitos digitados.`, "error");
      return;
    }
    if (formRespCpf.trim() && !isValidCPF(formRespCpf)) {
      triggerToast(`O CPF do responsável (${formRespCpf}) é inválido! Verifique os dígitos digitados.`, "error");
      return;
    }
    if (formCats.length === 0) {
      triggerToast("Selecione pelo menos uma categoria de atividade!", "warning");
      return;
    }
    const finalId = formId || 'atl_' + Date.now().toString(36);
    const compiledEnd = formCep
      ? `CEP: ${formCep} | ${formLogradouro}, ${formNumero}${formComplemento ? ' - ' + formComplemento : ''} | ${formBairro} | ${formCidade} - ${formUf}`
      : formLogradouro || '';

    const athleteData: Atleta = {
      id: finalId,
      nome: formNome,
      nasc: formNasc,
      cpf: formCpf,
      rg: '', // RG removed, keeping it as type conform empty
      genero: formGenero,
      natural: formNatural,
      end: compiledEnd,
      cat: formCats.join(', '),
      clube: formClube,
      rating: Number(formRating) || 0,
      cbtt: formCbtt,
      nivel: formNivel,
      mao: formMao,
      emp: formEmp,
      status: formStatus,
      presenca: formPresenca,
      pagamento: formPagamento,
      obs: formObs,
      email: formEmail,
      wa: normalizePhoneToBrazil(formWa),
      tel: normalizePhoneToBrazil(formTel),
      emerg: formEmerg,
      resp: formResp,
      respCpf: formRespCpf,
      foto: formFoto
    };

    onSave(athleteData);

    // Process Direct Championship Enrollment
    let nextInscricoes = [...(inscricoes || [])];
    if (formAutoEnroll && formTorneioId) {
      const targetCat = formInscricaoCat || formCats[0] || 'Adulto';
      const existingIns = (inscricoes || []).find(
        i => i.atletaId === finalId && i.torneioId === formTorneioId
      );

      const newInscricao: Inscricao = {
        id: existingIns?.id || 'ins-' + Date.now(),
        atletaId: finalId,
        torneioId: formTorneioId,
        categoria: targetCat,
        valorTaxa: formStatusPagamentoInscricao === 'Isento' ? '0.00' : (formValorTaxa || '80.00'),
        statusPagamento: formStatusPagamentoInscricao,
        confirmada: formStatusPagamentoInscricao === 'Pago' || formStatusPagamentoInscricao === 'Isento',
        identificadorAtleta: existingIns?.identificadorAtleta || `ATL-${finalId.slice(-6).toUpperCase()}`,
        identificadorPagamento: existingIns?.identificadorPagamento || 'TX-PIX-' + Date.now().toString().slice(-6),
        pixTransactionUuid: existingIns?.pixTransactionUuid || Math.random().toString(36).substring(2, 10)
      };

      if (existingIns) {
        nextInscricoes = nextInscricoes.map(i => i.id === existingIns.id ? newInscricao : i);
      } else {
        nextInscricoes = [newInscricao, ...nextInscricoes];
      }

      if (onSaveInscricoes) {
        onSaveInscricoes(nextInscricoes);
      }

      // Automatic Bracket Generation
      if (formAutoGenerateBracket) {
        const updatedAtletasList = atletas.some(a => a.id === finalId)
          ? atletas.map(a => a.id === finalId ? athleteData : a)
          : [...atletas, athleteData];

        const bRes = generateAutoBracketForCategory(
          formTorneioId,
          targetCat,
          updatedAtletasList,
          nextInscricoes,
          categorias,
          'rating'
        );

        if (bRes.success) {
          triggerToast(`⚡ ${bRes.message}`, 'success');
        } else {
          triggerToast(`Inscrição gravada! ${bRes.message}`, 'info');
        }
      } else {
        triggerToast(`Atleta inscrito no campeonato (${formStatusPagamentoInscricao})!`, 'success');
      }
    }

    setIsFormOpen(false);

    if (andNavigateToBracket && onNavigateToSection) {
      onNavigateToSection('chaveamento');
    }
  };

  // CPF Mask Helper
  const maskCpf = (val: string) => {
    return formatCPF(val);
  };

  // Helper to calculate age
  const calculateAge = (born: string) => {
    if (!born) return '—';
    const birthDate = new Date(born);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age + ' anos';
  };

  // Filter athletes list according to filters
  const filteredData = atletas.filter(a => {
    const query = searchQuery.toLowerCase();
    const matchesSearch = !query || 
      a.nome.toLowerCase().includes(query) || 
      (a.clube && a.clube.toLowerCase().includes(query)) ||
      (a.cpf && a.cpf.includes(query)) ||
      (a.email && a.email.toLowerCase().includes(query));
      
    const matchesCategory = !filterCategory || (a.cat && a.cat.split(',').map(s => s.trim()).includes(filterCategory));
    const matchesStatus = !filterStatus || a.status === filterStatus;
    
    const itemPresenca = a.presenca || 'CONFIRMADA';
    const itemPagamento = a.pagamento || 'PAGO';
    const matchesPresenca = !filterPresenca || itemPresenca === filterPresenca;
    const matchesPagamento = !filterPagamento || itemPagamento === filterPagamento;

    return matchesSearch && matchesCategory && matchesStatus && matchesPresenca && matchesPagamento;
  });

  const handleExportPDF = () => {
    const descParts: string[] = [];
    if (searchQuery) descParts.push(`Busca: "${searchQuery}"`);
    if (filterCategory) descParts.push(`Cat: ${filterCategory}`);
    if (filterStatus) descParts.push(`Status: ${filterStatus}`);
    
    const finalDesc = descParts.length > 0 ? descParts.join(' | ') : 'Todos os Atletas Registrados';
    exportAtletasToPDF(filteredData, { filterDescription: finalDesc });
  };

  // Pagination calculation
  const totalRecords = filteredData.length;
  const totalPages = Math.ceil(totalRecords / pageSize) || 1;
  const currentPageSafe = Math.min(currentPage, totalPages - 1);
  const paginatedData = filteredData.slice(
    currentPageSafe * pageSize, 
    (currentPageSafe + 1) * pageSize
  );

  return (
    <div className="space-y-6">
      {/* CARD: INSCRIÇÃO AUTOMÁTICA POR CATEGORIA & CONFIRMAÇÃO DE PRESENÇA NA MESA */}
      <div className="bg-gradient-to-r from-blue-950/80 via-slate-900 to-slate-900 border border-blue-800/60 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl relative overflow-hidden">
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="p-3 bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 rounded-xl shrink-0 shadow-inner">
            <CheckCircle2 className="w-6 h-6 text-yellow-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-wide">
                Inscrição Automática no Campeonato por Categoria Habilitada
              </h3>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-3xs font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Inscritos por Categoria
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mt-1 max-w-2xl font-medium">
              Todos os atletas estão <strong>inscritos automaticamente no campeonato de acordo com a sua categoria</strong>. No local do jogo, na <strong>mesa organizadora</strong>, basta apenas confirmar a presença física do atleta abaixo.
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto shrink-0">
          <button
            type="button"
            onClick={handleConfirmAllPresence}
            className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-lg active:scale-95"
            title="Confirmar presença física na mesa organizadora para todos os atletas visíveis"
          >
            <CheckCircle2 className="w-4 h-4 text-slate-950" />
            <span>CONFIRMAR PRESENÇA DE TODOS NA MESA</span>
          </button>
        </div>
      </div>

      {/* CARD: ENVIAR CONVITE AUTO-REGISTRO */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row gap-5 items-center justify-between shadow-lg relative overflow-hidden select-none">
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/5 rounded-full blur-2xl -z-10 pointer-events-none" />
        <div className="flex items-center gap-4 text-left">
          <div className="w-9 h-9 sm:w-10 sm:h-10 bg-yellow-400/10 text-yellow-400 rounded-xl flex items-center justify-center font-black text-lg sm:text-xl border border-yellow-500/20 shrink-0">
            ✉️
          </div>
          <div className="space-y-1 ml-0.5">
            <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-tight">Convide Atletas para Auto-Cadastro</h3>
            <p className="text-2xs text-slate-400 leading-relaxed max-w-md font-medium">
              Envie o link oficial para que os próprios atletas preencham seus dados de cadastro no sistema. Eles entrarão automaticamente, pendentes apenas de presenças físicas e comprovações de taxas.
            </p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto">
          <button
            type="button"
            onClick={() => {
              const url = `${window.location.origin}${window.location.pathname}?autoReg=true`;
              navigator.clipboard.writeText(url)
                .then(() => triggerToast('Link de cadastro de atletas copiado!', 'success'))
                .catch(() => triggerToast('Falha ao copiar link!', 'error'));
            }}
            className="flex items-center justify-center gap-1.5 bg-slate-950 border border-slate-850 hover:bg-slate-850 text-slate-300 hover:text-white rounded-lg px-4 py-2 text-xs font-bold transition cursor-pointer"
            title="Copiar Link de Formulário de Atletas"
          >
            <Copy className="w-3.5 h-3.5 text-yellow-400" />
            <span>COPIAR LINK</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const url = `${window.location.origin}${window.location.pathname}?autoReg=true`;
              const msg = `Olá! 🏓 Faça agora mesmo o seu Auto-Cadastro oficial de Atleta no sistema para ingressar as chaves do nosso campeonato!

Acesse o link abaixo para preencher os seus dados:
🔗 ${url}

*IMPORTANTE:* Após enviar o formulário, o cadastro ficará como *PENDENTE* no painel central da comissão, liberado imediatamente após a sua *CONFIRMAÇÃO DE PRESENÇA* física no dia de jogos e a *COMPROVAÇÃO DE PAGAMENTO DA TAXA DE INSCRIÇÃO* junto à secretaria do torneio.`;
              window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
            }}
            className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-lg px-4 py-2 text-xs transition cursor-pointer tracking-wider"
            title="Enviar convite para atletas no WhatsApp"
          >
            <Send className="w-3.5 h-3.5 text-white" />
            <span>ENVIAR NO WHATSAPP</span>
          </button>
        </div>
      </div>

      {/* Search Header Bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="flex flex-col sm:flex-row gap-3 w-full md:flex-1">
          {/* Query search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Buscar atleta por nome, clube, CPF..." 
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(0); }}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition"
            />
          </div>

          {/* Category filter */}
          <select
            value={filterCategory}
            onChange={(e) => { setFilterCategory(e.target.value); setCurrentPage(0); }}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todas categorias</option>
            {availableCategories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Status filter */}
          <select
            value={filterStatus}
            onChange={(e) => { setFilterStatus(e.target.value); setCurrentPage(0); }}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todos status</option>
            <option value="Ativo">Ativo</option>
            <option value="Inativo">Inativo</option>
            <option value="Suspenso">Suspenso</option>
          </select>

          {/* Presença filter */}
          <select
            value={filterPresenca}
            onChange={(e) => { setFilterPresenca(e.target.value); setCurrentPage(0); }}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todas Presenças</option>
            <option value="CONFIRMADA">✓ Confirmada</option>
            <option value="PENDENTE">⚠ Pendente</option>
            <option value="AUSENTE">✗ Ausente</option>
          </select>

          {/* Pagamento filter */}
          <select
            value={filterPagamento}
            onChange={(e) => { setFilterPagamento(e.target.value); setCurrentPage(0); }}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todos Pagamentos</option>
            <option value="PAGO">✓ Pago</option>
            <option value="PENDENTE">⚠ Pendente</option>
            <option value="ISENTO">✦ Isento</option>
          </select>
        </div>

        {/* Action Buttons: Export PDF and Create Atleta */}
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <button
            onClick={handleExportPDF}
            className="w-full md:w-auto bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold px-4 py-2 border border-slate-700 hover:border-slate-600 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-md"
            title="Exportar lista filtrada de atletas para PDF"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            Exportar PDF
          </button>
          {userRole !== 'comum' && (
            <button
              onClick={() => handleOpenForm()}
              className="w-full md:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
            >
              <Plus className="w-4 h-4" />
              Novo Atleta
            </button>
          )}
        </div>
      </div>

      {/* Main List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm text-slate-200">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/20 text-slate-400 text-2xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Atleta</th>
                <th className="py-3 px-4 hidden sm:table-cell">Idade (Nasc.)</th>
                <th className="py-3 px-4">Categoria</th>
                <th className="py-3 px-4 hidden md:table-cell">Clube</th>
                <th className="py-3 px-4">Rating</th>
                <th className="py-3 px-4 hidden lg:table-cell">WhatsApp</th>
                <th className="py-3 px-4 text-center">Validação (Presença / Taxa)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center w-28">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {paginatedData.length > 0 ? (
                paginatedData.map((a, i) => (
                  <tr key={a.id} className="hover:bg-slate-950/20 transition-colors">
                    <td className="py-3.5 px-4 text-center text-slate-500 font-mono text-xs">
                      {currentPageSafe * pageSize + i + 1}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        {a.foto ? (
                          <img src={a.foto} className="w-10 h-10 rounded-full object-cover border border-slate-700" alt={a.nome} />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-slate-300">
                            {a.nome[0].toUpperCase()}
                          </div>
                        )}
                        <div>
                          <div className="font-bold text-slate-100">{a.nome}</div>
                          <div className="text-slate-400 text-xs truncate max-w-[170px]">{a.email || 'sem e-mail'}</div>
                          {/* Automatic Category Inscription Badge */}
                          <div className="flex flex-wrap items-center gap-1 mt-1">
                            <span 
                              className="text-[9px] bg-blue-500/15 text-blue-300 border border-blue-500/30 px-1.5 py-0.5 rounded font-bold flex items-center gap-1 shrink-0"
                              title="Inscrição automática garantida por categoria"
                            >
                              🏆 Inscrito: {a.cat || 'Todas Categorias'}
                            </span>
                            {/* Active Championship Inscriptions */}
                            {inscricoes && inscricoes.some(i => i.atletaId === a.id) && (
                              inscricoes.filter(i => i.atletaId === a.id).map(ins => {
                                const tObj = torneios?.find(t => t.id === ins.torneioId);
                                return (
                                  <span 
                                    key={ins.id} 
                                    className="text-[9px] bg-yellow-400/15 text-yellow-300 border border-yellow-500/30 px-1.5 py-0.5 rounded font-mono font-extrabold flex items-center gap-1 shrink-0"
                                    title={`Inscrito no campeonato: ${tObj?.nome || 'Torneio'} (${ins.statusPagamento})`}
                                  >
                                    {ins.categoria}
                                  </span>
                                );
                              })
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 hidden sm:table-cell whitespace-nowrap">
                      <span>{calculateAge(a.nasc)}</span>
                      {a.nasc && <span className="block text-2xs text-slate-400">{new Date(a.nasc + 'T12:00').toLocaleDateString('pt-BR')}</span>}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1 max-w-[170px]">
                        {a.cat ? a.cat.split(',').map(c => (
                          <span key={c.trim()} className="text-[10px] bg-slate-800 text-blue-400 border border-slate-700 rounded px-1.5 py-0.5 font-bold uppercase shrink-0">
                            {c.trim()}
                          </span>
                        )) : '—'}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 hidden md:table-cell font-medium text-slate-300">
                      {a.clube || '—'}
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-yellow-400">
                      {a.rating}
                    </td>
                    <td className="py-3.5 px-4 hidden lg:table-cell text-xs font-mono text-slate-400">
                      {a.wa || '—'}
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="flex flex-col items-center gap-1 select-none">
                        {/* Interactive Mesa Organizadora Presence Check-in Button */}
                        <button
                          type="button"
                          onClick={() => handleConfirmPresenceAtMesa(a)}
                          className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-md flex items-center gap-1.5 transition cursor-pointer border shadow-xs active:scale-95 ${
                            (a.presenca || 'CONFIRMADA') === 'CONFIRMADA'
                              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
                              : (a.presenca || 'CONFIRMADA') === 'AUSENTE'
                              ? 'bg-red-500/15 text-red-400 border-red-500/40 hover:bg-red-500/25'
                              : 'bg-yellow-400 text-slate-950 font-black border-yellow-400 hover:bg-yellow-300 shadow-md animate-pulse'
                          }`}
                          title="Mesa Organizadora: Clique para alterar ou confirmar presença física do atleta no campeonato"
                        >
                          {(a.presenca || 'CONFIRMADA') === 'CONFIRMADA' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>✓ PRESENÇA CONFIRMADA</span>
                            </>
                          ) : (a.presenca || 'CONFIRMADA') === 'AUSENTE' ? (
                            <>
                              <X className="w-3.5 h-3.5 text-red-400" />
                              <span>✗ AUSENTE</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                              <span>⚡ CONFIRMAR PRESENÇA NA MESA</span>
                            </>
                          )}
                        </button>
                        
                        {/* Payment badge */}
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md flex items-center gap-1 ${
                          (a.pagamento || 'PAGO') === 'PAGO'
                            ? 'bg-green-500/10 text-green-300 border border-green-500/20'
                            : (a.pagamento || 'PAGO') === 'ISENTO'
                            ? 'bg-indigo-505/10 text-indigo-400 border border-indigo-500/20'
                            : 'bg-red-500/15 text-red-400 border border-red-500/20 animate-pulse'
                        }`}>
                          {(a.pagamento || 'PAGO') === 'PAGO' ? '✓ TAXA PAGA' : (a.pagamento || 'PAGO') === 'ISENTO' ? '✦ ISENTO' : '⚠ TAXA PENDENTE'}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className={`text-2xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                        a.status === 'Ativo' 
                          ? 'bg-emerald-400/10 text-emerald-400' 
                          : a.status === 'Inativo'
                          ? 'bg-amber-400/10 text-amber-500'
                          : 'bg-red-500/10 text-red-500'
                      }`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button 
                          onClick={() => setInspectAthlete(a)}
                          className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800 rounded-md transition cursor-pointer active:scale-95"
                          title="Ficha do Atleta"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {userRole !== 'comum' && (
                          <>
                            <button 
                              onClick={() => {
                                handleOpenForm(a);
                                setActiveTab('inscricao');
                              }}
                              className="p-1.5 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10 rounded-md transition cursor-pointer active:scale-95"
                              title="Inscrever em Campeonato & Gerar Chaveamento"
                            >
                              <Trophy className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleOpenForm(a)}
                              className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-md transition cursor-pointer active:scale-95"
                              title="Editar Atleta"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          </>
                        )}
                        {userRole === 'master' && (
                          <button 
                            onClick={() => {
                              if (confirm(`Deseja mesmo remover o atleta "${a.nome}"? Esta ação é irreversível.`)) {
                                onDelete(a.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-md transition-colors cursor-pointer active:scale-95"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    Nenhum atleta encontrado para os critérios selecionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer with Pagination Controls */}
        {totalPages > 1 && (
          <div className="px-5 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/10">
            <button
              onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
              disabled={currentPageSafe === 0}
              className="px-3 py-1.5 bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 text-xs font-semibold rounded-lg disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Anterior
            </button>
            <span className="text-xs text-slate-400">
              Página <strong className="text-slate-200">{currentPageSafe + 1}</strong> de {totalPages} ({totalRecords} atletas)
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
              disabled={currentPageSafe >= totalPages - 1}
              className="px-3 py-1.5 bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 text-xs font-semibold rounded-lg disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Próximo
            </button>
          </div>
        )}
      </div>

      {/* ATHLETE FORM MODAL */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 overflow-y-auto backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl transition">
            
            {/* Modal header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                {formId ? <Edit className="w-4 h-4 text-yellow-400" /> : <Plus className="w-4 h-4 text-yellow-400" />}
                {formId ? 'Editar Atleta' : 'Novo Atleta'}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body with Multi-tab options */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              
              {/* Form Tab selection */}
              <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveTab('pessoal')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'pessoal' ? 'bg-yellow-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Dados Pessoais
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('esportivo')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'esportivo' ? 'bg-yellow-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Dados Esportivos
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('inscricao')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'inscricao' ? 'bg-yellow-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  🏆 Campeonato
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('contato')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'contato' ? 'bg-yellow-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Contato / Emergência
                </button>
              </div>

              {/* TAB 1: DADOS PESSOAIS */}
              {activeTab === 'pessoal' && (
                <div className="space-y-4">
                  
                  {/* Photo area with camera triggering option */}
                  <div className="flex flex-col sm:flex-row gap-5 items-center bg-slate-950/20 p-4 border border-slate-850 rounded-xl">
                    <div className="relative w-28 h-36 border-2 border-dashed border-slate-700 hover:border-yellow-400/80 rounded-lg flex flex-col items-center justify-center bg-slate-950 gap-2 shrink-0 group overflow-hidden">
                      {formFoto ? (
                        <>
                          <img src={formFoto} alt="Cap" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => setIsCamOpen(true)}
                              className="px-2 py-1 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-3xs font-extrabold rounded"
                            >
                              Tirar Foto
                            </button>
                            <button
                              type="button"
                              onClick={() => setFormFoto('')}
                              className="px-2 py-1 bg-red-600 hover:bg-red-500 text-white text-3xs font-extrabold rounded"
                            >
                              Remover
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="text-center p-2 flex flex-col items-center pointer-events-none">
                          <Camera className="w-6 h-6 text-slate-400 mb-1" />
                          <span className="text-4xs text-slate-400 uppercase tracking-wider font-semibold">Tirar ou carregar</span>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2.5">
                      <button
                        type="button"
                        onClick={() => setIsCamOpen(true)}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                      >
                        <Camera className="w-4 h-4 text-slate-400" />
                        Tirar com Câmera
                      </button>
                      <label className="bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 px-3.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition cursor-pointer">
                        <Upload className="w-4 h-4 text-slate-400" />
                        Carregar Imagem
                        <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Nome Completo *</label>
                      <input 
                        type="text" 
                        value={formNome}
                        onChange={(e) => setFormNome(e.target.value.toUpperCase())}
                        placeholder="NOME COMPLETO DO ATLETA"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>
                    <DateInput 
                      label="Data de Nascimento"
                      value={formNasc}
                      onChange={(val) => setFormNasc(val)}
                    />

                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">CPF</label>
                        {formCpf.trim() && (
                          <span className={`text-4xs font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                            isValidCPF(formCpf) 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' 
                              : 'bg-rose-950 text-rose-400 border border-rose-800/40 animate-pulse'
                          }`}>
                            {isValidCPF(formCpf) ? '✓ VÁLIDO' : '⚠️ INVÁLIDO'}
                          </span>
                        )}
                      </div>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="000.000.000-00"
                        value={formCpf}
                        onChange={(e) => setFormCpf(maskCpf(e.target.value))}
                        className={`w-full bg-slate-950 border rounded-lg px-3 py-2 text-sm font-mono text-slate-100 outline-none ${
                          formCpf.trim() && !isValidCPF(formCpf)
                            ? 'border-rose-500 focus:border-rose-400'
                            : 'border-slate-800 focus:border-yellow-400'
                        }`}
                      />
                      {formCpf.trim() && !isValidCPF(formCpf) && (
                        <p className="text-3xs text-rose-400 font-semibold mt-0.5">
                          CPF com dígitos verificadores inválidos.
                        </p>
                      )}
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Gênero</label>
                      <select 
                        value={formGenero}
                        onChange={(e) => setFormGenero(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        <option value="Outro">Outro</option>
                      </select>
                    </div>

                    <div className="col-span-1 sm:col-span-2 space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Naturalidade</label>
                      <input 
                        type="text" 
                        placeholder="CIDADE — UF"
                        value={formNatural}
                        onChange={(e) => setFormNatural(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>

                    {/* Address Section */}
                    <div className="col-span-1 sm:col-span-2 border-t border-slate-800/80 pt-4 mt-2">
                      <h4 className="text-xs font-extrabold text-yellow-400 uppercase tracking-wider">Endereço de Correspondência</h4>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">CEP (Busca Automática) *</label>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="00000-000"
                        value={formCep}
                        onChange={(e) => handleCepChange(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Logradouro / Rua</label>
                      <input 
                        type="text" 
                        placeholder="EX: RUA DAS FLORES"
                        value={formLogradouro}
                        onChange={(e) => setFormLogradouro(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Número</label>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="EX: 123"
                        value={formNumero}
                        onChange={(e) => setFormNumero(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono uppercase"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Complemento *</label>
                      <input 
                        type="text" 
                        placeholder="EX: APTO 42, BLOCO B"
                        value={formComplemento}
                        onChange={(e) => setFormComplemento(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-lg px-3 py-2 text-sm text-slate-100 outline-none uppercase"
                      />
                    </div>

                    <div className="col-span-1 sm:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Bairro</label>
                        <input 
                          type="text" 
                          placeholder="BAIRRO"
                          value={formBairro}
                          onChange={(e) => setFormBairro(e.target.value.toUpperCase())}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Cidade</label>
                        <input 
                          type="text" 
                          placeholder="CIDADE"
                          value={formCidade}
                          onChange={(e) => setFormCidade(e.target.value.toUpperCase())}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">UF</label>
                        <input 
                          type="text" 
                          placeholder="SP"
                          value={formUf}
                          onChange={(e) => setFormUf(e.target.value.toUpperCase().slice(0, 2))}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none text-center font-mono"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: DADOS ESPORTIVOS */}
              {activeTab === 'esportivo' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="col-span-1 sm:col-span-2 space-y-2">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Categorias de Inscrição (Selecione uma ou mais) *</label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 bg-slate-950/40 p-3.5 border border-slate-850 rounded-xl max-h-[160px] overflow-y-auto">
                        {(categorias && categorias.length > 0 
                          ? Array.from(new Set(categorias.map(c => c.nome))) 
                          : ['Sub-9 Geral', 'Sub-11 Geral', 'Sub-13 Geral', 'Sub-15 Geral', 'Sub-17 Geral', 'Sub-21 Geral', 'Adulto Geral', 'Veterano +40', 'Veterano +50', 'Veterano +60']
                        ).map(catItem => {
                          const isChecked = formCats.includes(catItem);
                          return (
                            <label 
                              key={catItem} 
                              className={`flex items-center gap-2.5 p-2 rounded-lg border text-xs cursor-pointer select-none transition ${
                                isChecked 
                                  ? 'bg-yellow-400/10 border-yellow-400/50 text-yellow-400 font-semibold' 
                                  : 'bg-slate-950 border-slate-850 text-slate-400 hover:text-slate-350 hover:bg-slate-900/60'
                              }`}
                            >
                              <input 
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setFormCats([...formCats, catItem]);
                                  } else {
                                    setFormCats(formCats.filter(c => c !== catItem));
                                  }
                                }}
                                className="w-3.5 h-3.5 text-yellow-400 bg-slate-950 border-slate-800 rounded focus:ring-yellow-400 opacity-80 cursor-pointer"
                              />
                              <span className="truncate">{catItem}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Clube / Associação</label>
                      <input 
                        type="text" 
                        placeholder="CLUBE DO ATLETA"
                        value={formClube}
                        onChange={(e) => setFormClube(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Rating CBTT</label>
                      <input 
                        type="number" 
                        inputMode="numeric"
                        value={formRating}
                        onChange={(e) => setFormRating(Number(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold font-mono">Dístico CBTT (ID)</label>
                      <input 
                        type="text" 
                        placeholder="Nº DE ASSOCIADO CBTT"
                        value={formCbtt}
                        onChange={(e) => setFormCbtt(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono uppercase"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Nível Esportivo</label>
                      <select 
                        value={formNivel}
                        onChange={(e) => setFormNivel(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="Iniciante">Iniciante</option>
                        <option value="Intermediário">Intermediário</option>
                        <option value="Avançado">Avançado</option>
                        <option value="Elite">Elite</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Mão Dominante</label>
                      <select 
                        value={formMao}
                        onChange={(e) => setFormMao(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="Direita">Direita</option>
                        <option value="Esquerda">Esquerda</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Empunhadura</label>
                      <select 
                        value={formEmp}
                        onChange={(e) => setFormEmp(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="Shakehand">Shakehand</option>
                        <option value="Caneta">Caneta</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Status Cadastral</label>
                      <select 
                        value={formStatus}
                        onChange={(e) => setFormStatus(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="Ativo">Ativo</option>
                        <option value="Inativo">Inativo</option>
                        <option value="Suspenso">Suspenso</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Presença Física (Credenciamento)</label>
                      <select 
                        value={formPresenca}
                        onChange={(e) => setFormPresenca(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="CONFIRMADA">✓ CONFIRMADA / PRESENTE</option>
                        <option value="PENDENTE">⚠ PENDENTE</option>
                        <option value="AUSENTE">✗ AUSENTE</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold font-sans">Pagamento da Taxa</label>
                      <select 
                        value={formPagamento}
                        onChange={(e) => setFormPagamento(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                      >
                        <option value="PAGO">✓ PAGO</option>
                        <option value="PENDENTE">⚠ PENDENTE</option>
                        <option value="ISENTO">✦ ISENTO</option>
                      </select>
                    </div>

                    <div className="col-span-1 sm:col-span-2 space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Observações Esportivas</label>
                      <textarea 
                        rows={3}
                        placeholder="Lesões históricas, emparelhamentos preferenciais, etc..."
                        value={formObs}
                        onChange={(e) => setFormObs(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none resize-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: INSCRICAO EM CAMPEONATO */}
              {activeTab === 'inscricao' && (
                <div className="space-y-4">
                  <div className="bg-slate-950/60 p-4 border border-yellow-500/30 rounded-xl space-y-4 shadow-inner">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center shrink-0">
                          <Trophy className="w-4 h-4 text-yellow-400" />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-100 uppercase tracking-wider">Inscrição Direta em Campeonato</h4>
                          <p className="text-3xs text-slate-400 leading-snug">
                            Ao inscrever o atleta, ele participará do <strong>chaveamento automático</strong> independentemente da taxa estar Pendente, Paga ou Isenta.
                          </p>
                        </div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer shrink-0">
                        <input 
                          type="checkbox" 
                          checked={formAutoEnroll} 
                          onChange={(e) => setFormAutoEnroll(e.target.checked)}
                          className="sr-only peer" 
                        />
                        <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-yellow-400"></div>
                      </label>
                    </div>

                    {formAutoEnroll ? (
                      <div className="space-y-4 border-t border-slate-800/80 pt-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Campeonato / Torneio *</label>
                            <select 
                              value={formTorneioId}
                              onChange={(e) => setFormTorneioId(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                            >
                              <option value="">Selecione o Torneio</option>
                              {(torneios || []).map(t => (
                                <option key={t.id} value={t.id}>{t.nome}</option>
                              ))}
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Categoria da Inscrição *</label>
                            <select 
                              value={formInscricaoCat}
                              onChange={(e) => setFormInscricaoCat(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                            >
                              {categorias.map(c => (
                                <option key={c.id} value={c.nome}>{c.nome} ({c.fmt})</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Status do Pagamento</label>
                            <select 
                              value={formStatusPagamentoInscricao}
                              onChange={(e) => setFormStatusPagamentoInscricao(e.target.value as any)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                            >
                              <option value="Pendente">⚠️ Pendente (Participa do Chaveamento Automático)</option>
                              <option value="Pago">✓ Pago (Confirmado)</option>
                              <option value="Isento">✦ Isento (Gratuito)</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Valor da Taxa (R$)</label>
                            <input 
                              type="text"
                              value={formValorTaxa}
                              onChange={(e) => setFormValorTaxa(e.target.value)}
                              disabled={formStatusPagamentoInscricao === 'Isento'}
                              className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100 focus:border-yellow-400 outline-none disabled:opacity-40"
                            />
                          </div>
                        </div>

                        <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 space-y-1.5">
                          <label className="flex items-center gap-2 cursor-pointer select-none">
                            <input 
                              type="checkbox" 
                              checked={formAutoGenerateBracket} 
                              onChange={(e) => setFormAutoGenerateBracket(e.target.checked)}
                              className="w-4 h-4 rounded text-yellow-400 focus:ring-yellow-400 bg-slate-950 border-slate-800 cursor-pointer"
                            />
                            <span className="text-xs font-bold text-slate-200">
                              ⚡ Gerar / Atualizar Chaveamento Automático da Categoria ao Salvar
                            </span>
                          </label>
                          <p className="text-3xs text-slate-400 leading-relaxed pl-6">
                            O chaveamento incluirá <strong>automaticamente todos os inscritos</strong> nesta categoria, independente de terem pago ou não a taxa de inscrição.
                          </p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500 italic border-t border-slate-800/80 pt-2">
                        Marque a chave acima para inscrever diretamente este atleta em um torneio ativo.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 3: CONTACT & EMERGENCY */}
              {activeTab === 'contato' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">E-mail</label>
                      <input 
                        type="email" 
                        placeholder="EXEMPLO@ATLETA.COM"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder:text-slate-650 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">WhatsApp</label>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="+55 11 99999-9999"
                        value={formWa}
                        onChange={(e) => setFormWa(e.target.value.toUpperCase())}
                        onBlur={() => setFormWa(prev => normalizePhoneToBrazil(prev))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Telefone Residencial</label>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="(11) 3333-4444"
                        value={formTel}
                        onChange={(e) => setFormTel(e.target.value.toUpperCase())}
                        onBlur={() => setFormTel(prev => normalizePhoneToBrazil(prev))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Contato de Emergência</label>
                      <input 
                        type="text" 
                        placeholder="NOME - TELEFONE DE EMERGÊNCIA"
                        value={formEmerg}
                        onChange={(e) => setFormEmerg(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Responsável Legal (Menores)</label>
                      <input 
                        type="text" 
                        placeholder="NOME DO GENITOR OU TUTOR LEGAL"
                        value={formResp}
                        onChange={(e) => setFormResp(e.target.value.toUpperCase())}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none uppercase"
                      />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">CPF do Responsável</label>
                        {formRespCpf.trim() && (
                          <span className={`text-4xs font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                            isValidCPF(formRespCpf) 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' 
                              : 'bg-rose-950 text-rose-400 border border-rose-800/40 animate-pulse'
                          }`}>
                            {isValidCPF(formRespCpf) ? '✓ VÁLIDO' : '⚠️ INVÁLIDO'}
                          </span>
                        )}
                      </div>
                      <input 
                        type="text" 
                        inputMode="numeric"
                        placeholder="000.000.000-00"
                        value={formRespCpf}
                        onChange={(e) => setFormRespCpf(maskCpf(e.target.value))}
                        className={`w-full bg-slate-950 border rounded-lg px-3 py-2 text-sm font-mono text-slate-100 outline-none ${
                          formRespCpf.trim() && !isValidCPF(formRespCpf)
                            ? 'border-rose-500 focus:border-rose-400'
                            : 'border-slate-800 focus:border-yellow-400'
                        }`}
                      />
                      {formRespCpf.trim() && !isValidCPF(formRespCpf) && (
                        <p className="text-3xs text-rose-400 font-semibold mt-0.5">
                          CPF do responsável com dígitos verificadores inválidos.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Modal footer matching the original custom actions styling */}
            <div className="p-3.5 border-t border-slate-800 flex flex-wrap justify-end gap-2 bg-slate-950/40">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-2xs font-bold rounded-md transition cursor-pointer active:scale-95"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => handleSave(false)}
                className="px-3 py-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-2xs font-black rounded-md transition flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-sm"
              >
                <Save className="w-3.5 h-3.5" />
                Salvar Atleta
              </button>
              {formAutoEnroll && formTorneioId && (
                <button
                  type="button"
                  onClick={() => handleSave(true)}
                  className="px-3 py-1.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 text-2xs font-black rounded-md transition flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-sm"
                  title="Salva atleta, inscreve no campeonato, atualiza chaveamento automático e abre as chaves"
                >
                  <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                  ⚡ Salvar e Ver Chaveamento Automático
                </button>
              )}
            </div>

          </div>
        </div>
      )}

      {/* WEB CAMERA MODAL CAPTURER */}
      {isCamOpen && (
        <PhotoCaptureModal 
          onCapture={(dataUrl) => setFormFoto(dataUrl)}
          onClose={() => setIsCamOpen(false)}
        />
      )}

      {/* INSPECT SHEET MODAL WINDOW */}
      {inspectAthlete && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-805 flex items-center justify-between bg-slate-950/20">
              <h3 className="font-bold text-slate-200 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-400" />
                Ficha Geral de Atleta
              </h3>
              <button 
                onClick={() => setInspectAthlete(null)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              
              {/* Profile Card Summary Header */}
              <div className="flex items-center gap-4 bg-slate-950/40 p-4 border border-slate-800 rounded-xl">
                {inspectAthlete.foto ? (
                  <img src={inspectAthlete.foto} alt="Profile" className="w-16 h-16 rounded-full object-cover border border-slate-700 shrink-0" />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-2xl text-slate-200 shrink-0">
                    {inspectAthlete.nome[0].toUpperCase()}
                  </div>
                )}
                <div>
                  <h4 className="text-lg font-extrabold text-slate-100">{inspectAthlete.nome}</h4>
                  <p className="text-xs text-slate-400">{inspectAthlete.clube || 'Nenhum Clube Associado'} · {inspectAthlete.cat}</p>
                  <span className={`inline-block mt-1 else text-4xs uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-full ${
                    inspectAthlete.status === 'Ativo' ? 'bg-emerald-400/20 text-emerald-400' : 'bg-amber-400/20 text-amber-500'
                  }`}>
                    Status: {inspectAthlete.status}
                  </span>
                </div>
              </div>

              {/* Data fields container */}
              <div className="grid grid-cols-2 gap-4 text-slate-300">
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">CPF</span>
                  <span className="text-sm font-semibold font-mono">{inspectAthlete.cpf || '—'}</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Gênero</span>
                  <span className="text-sm font-semibold">{inspectAthlete.genero}</span>
                </div>

                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Data Nascimento</span>
                  <span className="text-sm font-semibold">
                    {inspectAthlete.nasc ? new Date(inspectAthlete.nasc + 'T12:00').toLocaleDateString('pt-BR') : '—'} ({calculateAge(inspectAthlete.nasc)})
                  </span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">CBTT ID</span>
                  <span className="text-sm font-semibold font-mono text-yellow-400">{inspectAthlete.cbtt || '—'}</span>
                </div>

                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Rating Oficial</span>
                  <span className="text-sm font-extrabold text-yellow-400 font-mono">{inspectAthlete.rating} pts</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Nível Esportivo</span>
                  <span className="text-sm font-semibold">{inspectAthlete.nivel}</span>
                </div>

                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Braço de Jogo</span>
                  <span className="text-sm font-semibold">{inspectAthlete.mao}</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Empunhadura</span>
                  <span className="text-sm font-semibold">{inspectAthlete.emp}</span>
                </div>

                <div className="space-y-1 col-span-2">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">E-mail de Contato</span>
                  <span className="text-sm font-semibold text-slate-200">{inspectAthlete.email || '—'}</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">WhatsApp</span>
                  <span className="text-sm font-semibold text-slate-200 font-mono">{inspectAthlete.wa || '—'}</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold font-semibold">Contato Emergência</span>
                  <span className="text-xs font-semibold text-red-400">{inspectAthlete.emerg || '—'}</span>
                </div>

                {inspectAthlete.resp && (
                  <div className="col-span-2 border-t border-slate-800/60 pt-3 flex gap-4">
                    <div>
                      <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Responsável</span>
                      <span className="text-sm font-semibold">{inspectAthlete.resp}</span>
                    </div>
                    {inspectAthlete.respCpf && (
                      <div>
                        <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">CPF Responsável</span>
                        <span className="text-sm font-mono font-semibold">{inspectAthlete.respCpf}</span>
                      </div>
                    )}
                  </div>
                )}

                {inspectAthlete.obs && (
                  <div className="col-span-2 border-t border-slate-800/60 pt-3">
                    <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Observações Geral</span>
                    <p className="text-xs italic text-slate-400 leading-relaxed mt-1">{inspectAthlete.obs}</p>
                  </div>
                )}

                {/* Registration Validation Quick Action box */}
                <div className="col-span-2 border-t border-slate-800/60 pt-3 space-y-2">
                  <span className="block text-4xs uppercase tracking-wider text-slate-500 font-extrabold">Inscrição & Validação de Presença</span>
                  <div className="bg-blue-950/40 p-2.5 rounded-lg border border-blue-800/40 text-xs text-slate-300 font-medium">
                    🏆 <strong>Inscrito Automático por Categoria:</strong> {inspectAthlete.cat || 'Todas Categorias'}. Apenas confirme a presença no local do jogo.
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-1 text-left">
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850 flex flex-col justify-between gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-extrabold block mb-1">Presença na Mesa Organizadora</span>
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                          (inspectAthlete.presenca || 'CONFIRMADA') === 'CONFIRMADA'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : (inspectAthlete.presenca || 'CONFIRMADA') === 'AUSENTE'
                            ? 'bg-red-500/10 text-red-500 border border-red-500/20'
                            : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                        }`}>
                          {(inspectAthlete.presenca || 'CONFIRMADA') === 'CONFIRMADA' ? '✓ PRESENTE' : (inspectAthlete.presenca || 'CONFIRMADA') === 'AUSENTE' ? '✗ AUSENTE' : '⚠ PRESENÇA PENDENTE'}
                        </span>
                      </div>
                      {userRole !== 'comum' && (
                        <button
                          type="button"
                          onClick={() => {
                            const isConfirmed = (inspectAthlete.presenca || 'CONFIRMADA') === 'CONFIRMADA';
                            const next = isConfirmed ? 'PENDENTE' : 'CONFIRMADA';
                            const updated = { ...inspectAthlete, presenca: next };
                            onSave(updated);
                            setInspectAthlete(updated);
                            triggerToast(next === 'CONFIRMADA' ? `✓ Presença na Mesa CONFIRMADA para ${inspectAthlete.nome}!` : `Presença de ${inspectAthlete.nome} alterada para PENDENTE.`, next === 'CONFIRMADA' ? 'success' : 'info');
                          }}
                          className={`w-full text-[10px] font-extrabold py-1.5 rounded transition cursor-pointer select-none uppercase tracking-wider ${
                            (inspectAthlete.presenca || 'CONFIRMADA') === 'CONFIRMADA'
                              ? 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-yellow-400'
                              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow'
                          }`}
                        >
                          {(inspectAthlete.presenca || 'CONFIRMADA') === 'CONFIRMADA' ? 'Alterar Presença' : '⚡ Confirmar Presença na Mesa'}
                        </button>
                      )}
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850 flex flex-col justify-between gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-extrabold block mb-1">Pagamento da Taxa de Inscrição</span>
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                          (inspectAthlete.pagamento || 'PAGO') === 'PAGO'
                            ? 'bg-green-500/10 text-green-300 border border-green-500/20'
                            : (inspectAthlete.pagamento || 'PAGO') === 'ISENTO'
                            ? 'bg-indigo-505/10 text-indigo-400 border border-indigo-500/20'
                            : 'bg-red-500/15 text-red-400 border border-red-500/20 animate-pulse'
                        }`}>
                          {(inspectAthlete.pagamento || 'PAGO') === 'PAGO' ? '✓ TAXA PAGA' : (inspectAthlete.pagamento || 'PAGO') === 'ISENTO' ? '✦ ISENTO' : '⚠ TAXA PENDENTE'}
                        </span>
                      </div>
                      {userRole !== 'comum' && (
                        <button
                          type="button"
                          onClick={() => {
                            const current = inspectAthlete.pagamento || 'PAGO';
                            const next = current === 'PAGO' ? 'PENDENTE' : current === 'PENDENTE' ? 'ISENTO' : 'PAGO';
                            const updated = { ...inspectAthlete, pagamento: next };
                            onSave(updated);
                            setInspectAthlete(updated);
                            triggerToast(`Status pagamento alterado para ${next}!`, 'success');
                          }}
                          className="w-full text-[10px] bg-slate-900 border border-slate-800 text-slate-350 hover:text-yellow-400 font-extrabold py-1 rounded transition cursor-pointer select-none uppercase tracking-wider"
                        >
                          Alterar Pagamento
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 flex justify-end bg-slate-950/20">
              <button
                onClick={() => setInspectAthlete(null)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-100 text-xs font-bold rounded-lg hover:bg-slate-750 transition"
              >
                Fechar Ficha
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
