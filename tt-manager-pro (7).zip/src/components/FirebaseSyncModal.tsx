import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  CheckCircle2, 
  X, 
  RefreshCw, 
  UploadCloud, 
  DownloadCloud, 
  Database,
  ArrowRight,
  Sparkles,
  ShieldAlert,
  Home
} from 'lucide-react';
import { 
  uploadStateToFirebase, 
  downloadStateFromFirebase, 
  FullSystemState 
} from '../lib/firebase';
import { triggerToast } from '../utils/toast';
import firebaseConfig from '../../firebase-applet-config.json';

interface FirebaseSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: FullSystemState;
  onApplySync: (newState: FullSystemState) => void;
  autoSyncEnabled: boolean;
  onToggleAutoSync: (enabled: boolean) => void;
}

export default function FirebaseSyncModal({
  isOpen,
  onClose,
  currentState,
  onApplySync,
  autoSyncEnabled,
  onToggleAutoSync
}: FirebaseSyncModalProps) {
  const [loading, setLoading] = useState(false);
  const [syncDoneMessage, setSyncDoneMessage] = useState<string | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem('ttmpro_firebase_last_sync');
  });

  // Escape key handler to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  // Handle manual backup upload
  const handleUploadBackup = async () => {
    setLoading(true);
    setSyncDoneMessage(null);
    try {
      await uploadStateToFirebase(currentState);
      const nowStr = new Date().toLocaleString('pt-BR');
      setLastSyncTime(nowStr);
      localStorage.setItem('ttmpro_firebase_last_sync', nowStr);
      setSyncDoneMessage('Backup enviado e salvo na Nuvem Firebase com sucesso!');
      triggerToast('Backup enviado para a Nuvem Firebase com sucesso!', 'success');
    } catch (err: any) {
      console.warn('Firebase Sync Notice:', err);
      const msg = err?.message || String(err);
      if (msg.includes('IndexedDB') || msg.includes('timeout') || msg.includes('lenta')) {
        setSyncDoneMessage('Modo Offline/IndexedDB Ativo: Seus dados estão salvos localmente e serão sincronizados automaticamente com a nuvem.');
        triggerToast('Dados salvos no IndexedDB. A sincronização com a nuvem continuará em segundo plano.', 'info');
      } else {
        triggerToast(`Aviso de sincronização com a nuvem: ${msg}`, 'warning');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle manual backup download & restore
  const handleDownloadRestore = async () => {
    const confirmRestore = window.confirm(
      'ATENÇÃO: Deseja realmente restaurar os dados da Nuvem? Isto irá substituir todos os dados locais do seu navegador pelo backup salvo na Nuvem Firebase. Esta operação não pode ser desfeita.'
    );
    if (!confirmRestore) return;

    setLoading(true);
    setSyncDoneMessage(null);
    try {
      const cloudData = await downloadStateFromFirebase();
      if (!cloudData) {
        triggerToast('Nenhum backup encontrado na nuvem para restauração.', 'warning');
        return;
      }
      
      onApplySync(cloudData);
      const nowStr = new Date().toLocaleString('pt-BR');
      setLastSyncTime(nowStr);
      localStorage.setItem('ttmpro_firebase_last_sync', nowStr);
      setSyncDoneMessage('Dados do sistema restaurados da Nuvem Firebase com sucesso!');
      triggerToast('Dados do sistema restaurados da Nuvem Firebase com sucesso!', 'success');
    } catch (err: any) {
      console.error(err);
      triggerToast(`Erro ao restaurar dados da nuvem: ${err.message || err}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/60 bg-gradient-to-r from-yellow-500/10 via-cyan-500/10 to-emerald-500/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-yellow-400/10 rounded-xl flex items-center justify-center border border-yellow-400/30 text-yellow-400 animate-pulse shrink-0">
              <Cloud className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
            </div>
            <div>
              <h3 className="font-black text-slate-100 text-xs sm:text-sm uppercase tracking-wider">
                Sincronização & Autosalvamento Nuvem Firebase ☁️
              </h3>
              <p className="text-[10px] text-slate-400 font-medium">
                Banco de dados gratuito em nuvem integrado com 1-Clique
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-100 rounded-lg transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 flex-1 overflow-y-auto">
          {/* Success Banner if sync completed */}
          {syncDoneMessage && (
            <div className="bg-emerald-950/80 border border-emerald-500/40 p-4 rounded-xl flex items-start gap-3 animate-fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-1 flex-1">
                <h4 className="text-xs font-black text-emerald-300 uppercase tracking-wider">
                  Operação Concluída com Sucesso!
                </h4>
                <p className="text-[11px] text-emerald-200/90 leading-snug">
                  {syncDoneMessage}
                </p>
              </div>
              <button
                onClick={onClose}
                className="px-3 py-1 bg-emerald-400 hover:bg-emerald-300 text-slate-950 text-xs font-black uppercase rounded-lg transition cursor-pointer shrink-0 shadow"
              >
                Concluir & Ir ao Menu
              </button>
            </div>
          )}

          {/* Project Details Panel */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-black tracking-widest text-slate-500">
                PROJETO FIREBASE CONECTADO
              </span>
              <span className="bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 px-2 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1 animate-pulse">
                <Database className="w-3 h-3" /> ONLINE
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="space-y-1">
                <span className="text-slate-450 text-3xs font-semibold block uppercase">ID do Projeto:</span>
                <span className="font-mono text-slate-200 font-extrabold select-all">{firebaseConfig.projectId}</span>
              </div>
              <div className="space-y-1">
                <span className="text-slate-450 text-3xs font-semibold block uppercase">Banco Firestore:</span>
                <span className="font-mono text-slate-300 block truncate" title={(firebaseConfig as any).firestoreDatabaseId || '(default)'}>
                  {(firebaseConfig as any).firestoreDatabaseId || '(padrão)'}
                </span>
              </div>
            </div>

            {lastSyncTime && (
              <div className="pt-2 border-t border-slate-850/60 flex items-center justify-between text-3xs text-slate-400">
                <span>Última sincronização / backup realizada:</span>
                <span className="font-mono text-yellow-400 font-black">{lastSyncTime}</span>
              </div>
            )}
          </div>

          {/* Core Action Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Upload Card */}
            <button
              onClick={handleUploadBackup}
              disabled={loading}
              className="bg-slate-950/40 border border-slate-800 hover:border-yellow-400/40 hover:bg-slate-850/50 p-4 sm:p-5 rounded-xl text-left transition duration-200 group flex flex-col justify-between h-36 sm:h-40 disabled:opacity-50 cursor-pointer"
            >
              <div className="space-y-1.5 sm:space-y-2">
                <div className="w-8 h-8 sm:w-8.5 sm:h-8.5 bg-yellow-400/10 group-hover:bg-yellow-400/20 text-yellow-400 rounded-lg flex items-center justify-center transition shrink-0">
                  <UploadCloud className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                </div>
                <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider group-hover:text-yellow-400 transition">
                  Enviar para a Nuvem 📤
                </h4>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  Salva todos os seus torneios, atletas cadastrados, súmulas e configurações atuais no banco de dados Firebase.
                </p>
              </div>
              <div className="text-3xs text-slate-500 font-black flex items-center gap-1 group-hover:text-slate-300">
                ENVIAR BACKUP <ArrowRight className="w-3 h-3" />
              </div>
            </button>

            {/* Download Card */}
            <button
              onClick={handleDownloadRestore}
              disabled={loading}
              className="bg-slate-950/40 border border-slate-800 hover:border-cyan-400/40 hover:bg-slate-850/50 p-4 sm:p-5 rounded-xl text-left transition duration-200 group flex flex-col justify-between h-36 sm:h-40 disabled:opacity-50 cursor-pointer"
            >
              <div className="space-y-1.5 sm:space-y-2">
                <div className="w-8 h-8 sm:w-8.5 sm:h-8.5 bg-cyan-400/10 group-hover:bg-cyan-400/20 text-cyan-400 rounded-lg flex items-center justify-center transition shrink-0">
                  <DownloadCloud className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                </div>
                <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider group-hover:text-cyan-400 transition">
                  Restaurar da Nuvem 📥
                </h4>
                <p className="text-[10px] text-slate-400 leading-relaxed font-medium">
                  Baixa os dados salvos na nuvem e restaura a informação no seu sistema.
                </p>
              </div>
              <div className="text-3xs text-slate-500 font-black flex items-center gap-1 group-hover:text-slate-300">
                BAIXAR DADOS <ArrowRight className="w-3 h-3" />
              </div>
            </button>
          </div>

          {/* Auto-Sync Toggle Control */}
          <div className="bg-gradient-to-r from-yellow-500/10 via-emerald-500/10 to-cyan-500/10 border border-yellow-400/20 rounded-xl p-4 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-400 animate-spin" style={{ animationDuration: '4s' }} />
                <h5 className="font-black text-slate-100 text-xs uppercase tracking-wider">
                  Sincronização Automática em Tempo Real (Auto-Save)
                </h5>
              </div>
              <p className="text-[10px] text-slate-400 leading-normal max-w-sm">
                Quando ativado, cada alteração feita no sistema (atletas, chaves, resultados) é salva automaticamente no Firebase em segundo plano!
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer select-none shrink-0">
              <input 
                type="checkbox" 
                checked={autoSyncEnabled} 
                onChange={(e) => {
                  onToggleAutoSync(e.target.checked);
                  triggerToast(
                    e.target.checked 
                      ? 'Salvamento automático na Nuvem ativado com sucesso!' 
                      : 'Salvamento automático desativado.', 
                    'info'
                  );
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-400 peer-checked:after:bg-slate-950 peer-checked:after:border-yellow-300"></div>
            </label>
          </div>

          {loading && (
            <div className="flex items-center justify-center gap-2 text-yellow-400 text-xs font-bold py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-xl animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin" />
              Conectando e salvando dados no Firebase Firestore... Por favor aguarde.
            </div>
          )}
        </div>

        {/* Footer with Concluir e Voltar ao Menu Principal */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span>Conexão direta com o banco de dados Firebase {firebaseConfig.projectId}.</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-2 cursor-pointer shadow-lg shadow-yellow-400/10"
          >
            <Home className="w-4 h-4" />
            Concluir & Voltar ao Menu Principal
          </button>
        </div>
      </div>
    </div>
  );
}
