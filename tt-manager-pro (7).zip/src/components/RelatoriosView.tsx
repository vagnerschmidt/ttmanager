import React from 'react';
import { Atleta, Torneio, Resultado, Arbitro, Funcionario } from '../types';
import { Download, Users, ClipboardList, BarChart3, UserCheck, Trophy, Database, FileSpreadsheet, Printer, Zap, HardDrive, CheckCircle2 } from 'lucide-react';
import { exportAtletasToPDF } from '../utils/pdfExport';
import { triggerToast } from '../utils/toast';

interface RelatoriosViewProps {
  atletas: Atleta[];
  torneios: Torneio[];
  resultados: Resultado[];
  arbitros: Arbitro[];
  funcionarios: Funcionario[];
  stateDump: any;
  onOpenSyncModal?: () => void;
}

export default function RelatoriosView({
  atletas,
  torneios,
  resultados,
  arbitros,
  funcionarios,
  stateDump,
  onOpenSyncModal
}: RelatoriosViewProps) {

  // Trigger file download helper
  const triggerDownload = (filename: string, content: string, bytePrefix = false) => {
    let blob;
    if (bytePrefix) {
      // Add UTF-8 BOM prefix to support Excel Portuguese characters correctly
      blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), content], { type: 'text/csv;charset=utf-8;' });
    } else {
      blob = new Blob([content], { type: 'application/json' });
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportAtletasPDF = () => {
    exportAtletasToPDF(atletas, { filterDescription: 'Relatório Completo de Atletas' });
    triggerToast('Relatório de atletas em PDF gerado com sucesso!', 'success');
  };

  const handleExportAtletas = () => {
    const csvHeader = "ID,Nome,Nascimento,CPF,RG,Genero,Naturalidade,Clube,Rating,CBTT_ID,Nivel,MaoDominante,Empunhadura,Status,Email,WhatsApp,Responsavel\n";
    const csvRows = atletas.map(a => (
      `"${a.id}","${a.nome}","${a.nasc}","${a.cpf || ''}","${a.rg || ''}","${a.genero}","${a.natural || ''}","${a.clube || ''}",${a.rating},"${a.cbtt || ''}","${a.nivel}","${a.mao}","${a.emp}","${a.status}","${a.email || ''}","${a.wa || ''}","${a.resp || ''}"`
    )).join('\n');
    triggerDownload("relatorio_atletas.csv", csvHeader + csvRows, true);
    triggerToast('Relatório de atletas em CSV baixado com sucesso!', 'success');
  };

  const handleExportResultados = () => {
    const csvHeader = "ID,Mesa,AtletaA,SetsA,SetsB,AtletaB,Arbitro,DataHora\n";
    const csvRows = resultados.map(r => (
      `"${r.id}",${r.mesa},"${r.nomeA}",${r.ponA},${r.ponB},"${r.nomeB}","${r.arb}","${r.dt}"`
    )).join('\n');
    triggerDownload("relatorio_resultados_jogos.csv", csvHeader + csvRows, true);
    triggerToast('Resultados de jogos em CSV baixados com sucesso!', 'success');
  };

  const handleExportRanking = () => {
    const csvHeader = "Rank,Atleta,Clube,Categoria,Rating,Status\n";
    const sorted = [...atletas].sort((x, y) => y.rating - x.rating);
    const csvRows = sorted.map((a, i) => (
      `${i+1},"${a.nome}","${a.clube || ''}","${a.cat}",${a.rating},"${a.status}"`
    )).join('\n');
    triggerDownload("relatorio_ranking_geral.csv", csvHeader + csvRows, true);
    triggerToast('Tabela de ranking baixada com sucesso!', 'success');
  };

  const handleExportArbitros = () => {
    const csvHeader = "ID,Nome,Nivel,CBTT,Email,WhatsApp,Status,RemuneracaoHora\n";
    const csvRows = arbitros.map(a => (
      `"${a.id}","${a.nome}","${a.nivel}","${a.cbtt || ''}","${a.email || ''}","${a.wa || ''}","${a.status}",${a.val || 0}`
    )).join('\n');
    triggerDownload("relatorio_arbitros.csv", csvHeader + csvRows, true);
    triggerToast('Relatório de árbitros baixado com sucesso!', 'success');
  };

  const handleExportTorneios = () => {
    const csvHeader = "ID,Nome,DataInicio,DataFim,Hora,Local,Cidade,Status,Formato,Inscritos_Limite\n";
    const csvRows = torneios.map(t => (
      `"${t.id}","${t.nome}","${t.ini}","${t.fim}","${t.hora}","${t.local || ''}","${t.cidade || ''}","${t.status}","${t.fmt}","${t.lim || 'Ilimitado'}"`
    )).join('\n');
    triggerDownload("relatorio_torneios.csv", csvHeader + csvRows, true);
    triggerToast('Índice de torneios baixado com sucesso!', 'success');
  };

  const handleExportBackup = () => {
    const dateStr = new Date().toISOString().split('T')[0];
    const dump = JSON.stringify(stateDump, null, 2);
    triggerDownload(`backup_tt_manager_pro_completo_${dateStr}.json`, dump, false);
    triggerToast('⚡ Download de Todos os Dados do Sistema (JSON Completo) realizado com sucesso!', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Banner de Destaque: Download de Todos os Dados (Backup Manual JSON) */}
      <div className="bg-gradient-to-r from-yellow-950/60 via-slate-900 to-slate-950 border border-yellow-500/50 rounded-xl p-5 sm:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-yellow-400/5 rounded-full blur-3xl pointer-events-none -z-10" />
        
        <div className="flex items-start sm:items-center gap-4">
          <div className="p-3.5 bg-yellow-400/20 border border-yellow-400/40 text-yellow-400 rounded-2xl shrink-0 shadow-inner">
            <HardDrive className="w-8 h-8 text-yellow-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base sm:text-lg font-black text-slate-100 uppercase tracking-wide">
                Download de Todos os Dados do Sistema
              </h3>
              <span className="bg-yellow-400 text-slate-950 text-3xs font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider font-mono">
                Backup JSON Completo
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl font-medium leading-relaxed">
              Gere e baixe instantaneamente um único arquivo JSON contendo o estado integral do aplicativo (atletas, torneios, categorias, chaves, partidas, árbitros, inscrições e configurações).
            </p>
            <div className="flex items-center gap-4 mt-2 text-3xs text-slate-400 font-bold uppercase tracking-wider flex-wrap">
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> {atletas.length} Atletas</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> {torneios.length} Torneios</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> {resultados.length} Partidas</span>
              <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-400" /> {arbitros.length} Árbitros</span>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExportBackup}
          className="w-full md:w-auto px-6 py-3.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center justify-center gap-2.5 shrink-0 shadow-lg cursor-pointer active:scale-95 border border-yellow-300"
          title="Fazer download manual de todo o banco de dados em arquivo JSON"
        >
          <Download className="w-4 h-4 text-slate-950 stroke-[2.5]" />
          <span>Download de Todos os Dados (JSON)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Sync Card: Spreadsheet Sync in 1 Click */}
        {onOpenSyncModal && (
          <div 
            onClick={onOpenSyncModal}
            className="bg-emerald-950/30 border border-emerald-500/40 hover:border-emerald-400 hover:bg-emerald-900/40 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-lg shadow-emerald-500/10 col-span-1 md:col-span-2 lg:col-span-3"
          >
            <div className="flex flex-col sm:flex-row items-center justify-between w-full gap-4">
              <div className="flex items-center gap-4 text-left">
                <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center shrink-0 border border-emerald-500/30">
                  <FileSpreadsheet className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-black text-emerald-400 text-base tracking-wide flex items-center gap-2">
                    <Zap className="w-4 h-4 fill-current" />
                    Sincronização de Planilha em 1 Clique
                    <span className="text-3xs bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full uppercase font-extrabold font-mono">
                      Inteligente
                    </span>
                  </h4>
                  <p className="text-slate-300 text-xs mt-1">
                    Alimente e sincronize atletas, árbitros, treinadores, funcionários e torneios. O sistema compara os campos um a um e ignora dados inalterados para máxima performance.
                  </p>
                </div>
              </div>
              <button className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-2 shrink-0 shadow-md">
                <Zap className="w-4 h-4 fill-current" />
                Sincronizar Agora
              </button>
            </div>
          </div>
        )}

        {/* Exporter Card 1: Athletes (PDF) */}
        <div 
          onClick={handleExportAtletasPDF}
          className="bg-slate-900 border border-slate-800 hover:border-yellow-400/40 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-emerald-500/10 text-emerald-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <Printer className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Lista de Atletas (PDF)</h4>
            <p className="text-slate-450 text-2xs mt-1">Gera um arquivo PDF formatado de forma limpa para impressão.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-450 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Printer className="w-3.5 h-3.5" />
            Gerar Arquivo PDF
          </div>
        </div>

        {/* Exporter Card 1.5: Athletes (CSV) */}
        <div 
          onClick={handleExportAtletas}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-blue-500/10 text-blue-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <Users className="w-6 h-6 text-2xl" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Lista de Atletas</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta todos os dados de registro dos atletas em CSV.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download CSV
          </div>
        </div>

        {/* Exporter Card 2: Match Results */}
        <div 
          onClick={handleExportResultados}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-yellow-400/10 text-yellow-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <ClipboardList className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Resultados (Jogos)</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta a listagem completa de partidas, placares e sets em CSV.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download CSV
          </div>
        </div>

        {/* Exporter Card 3: Ranking standings */}
        <div 
          onClick={handleExportRanking}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-green-500/10 text-green-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Tabela de Classificação</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta a classificação de ratings gerais em formato planilha CSV.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download CSV
          </div>
        </div>

        {/* Exporter Card 4: Referees */}
        <div 
          onClick={handleExportArbitros}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-red-500/10 text-red-500 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Relatório de Árbitros</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta a ficha de árbitros escalados e cargas de tarifas em CSV.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download CSV
          </div>
        </div>

        {/* Exporter Card 5: Tournaments */}
        <div 
          onClick={handleExportTorneios}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 hover:bg-slate-850/30 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm"
        >
          <div className="w-14 h-14 bg-orange-500/10 text-orange-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-extrabold text-slate-100 text-sm tracking-wide">Índice de Torneios</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta a listagem geral de todos os torneios inscritos em CSV.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-slate-950/40 text-slate-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download CSV
          </div>
        </div>

        {/* Exporter Card 6: Database Backup JSON */}
        <div 
          onClick={handleExportBackup}
          className="bg-slate-900 border border-slate-805 hover:border-yellow-400/40 hover:bg-slate-850/40 transition p-6 rounded-xl flex flex-col justify-between items-center text-center cursor-pointer group shadow-sm border-dashed"
        >
          <div className="w-14 h-14 bg-yellow-400/10 text-yellow-400 group-hover:scale-105 transition duration-200 rounded-2xl flex items-center justify-center mb-4 text-2xl">
            <Database className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h4 className="font-extrabold text-yellow-400 text-sm tracking-wide">Backup Total do Sistema</h4>
            <p className="text-slate-450 text-2xs mt-1">Exporta todo o banco de dados e registros do aplicativo em um único arquivo JSON.</p>
          </div>
          <div className="mt-5 w-full py-1.5 bg-yellow-400/10 text-yellow-400 text-3xs uppercase tracking-widest font-extrabold rounded-lg flex items-center justify-center gap-1">
            <Download className="w-3.5 h-3.5" />
            Fazer Download JSON
          </div>
        </div>

      </div>
    </div>
  );
}

