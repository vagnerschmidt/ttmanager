import React, { useState } from 'react';
import { Atleta, Arbitro, Treinador, Funcionario } from '../types';
import { UserCheck, Users, Briefcase, Award, CheckCircle2, Copy, Send, ArrowLeft, HeartPulse, Sparkles, BookOpen } from 'lucide-react';
import DateInput from './DateInput';
import { triggerToast } from '../utils/toast';
import { normalizePhoneToBrazil } from '../utils/phone';
import { isValidCPF, formatCPF } from '../utils/cpf';

interface AutoRegistroViewProps {
  onRegister: (type: 'atleta' | 'arbitro' | 'treinador' | 'funcionario', data: any) => void;
  onCancel: () => void;
}

export default function AutoRegistroView({ onRegister, onCancel }: AutoRegistroViewProps) {
  const [roleType, setRoleType] = useState<'atleta' | 'arbitro' | 'treinador' | 'funcionario'>('atleta');
  const [registeredSuccess, setRegisteredSuccess] = useState(false);
  const [registeredName, setRegisteredName] = useState('');

  // Form Fields State
  // Atleta Fields
  const [nome, setNome] = useState('');
  const [nasc, setNasc] = useState('');
  const [cpf, setCpf] = useState('');
  const [rg, setRg] = useState('');
  const [genero, setGenero] = useState('Masculino');
  const [natural, setNatural] = useState('');
  const [end, setEnd] = useState('');
  const [cat, setCat] = useState('Simples Masculino');
  const [clube, setClube] = useState('');
  const [rating, setRating] = useState('0');
  const [cbtt, setCbtt] = useState('');
  const [nivel, setNivel] = useState('Iniciante');
  const [mao, setMao] = useState('Direita');
  const [emp, setEmp] = useState('Shakehand');
  const [email, setEmail] = useState('');
  const [wa, setWa] = useState('');
  const [tel, setTel] = useState('');
  const [emerg, setEmerg] = useState('');
  const [resp, setResp] = useState('');
  const [respCpf, setRespCpf] = useState('');
  const [obs, setObs] = useState('');

  // Arbitro Specific Fields
  const [arbNivel, setArbNivel] = useState('Regional');
  const [arbVal, setArbVal] = useState('');

  // Treinador Specific Fields
  const [trCref, setTrCref] = useState('');

  // Funcionario Specific Fields
  const [funCargo, setFunCargo] = useState('Apoio de Quadra');
  const [funDepto, setFunDepto] = useState('Apoio Operacional');

  const handleCopyRegistrationLink = () => {
    // Generate simulated public share links
    const shareUrl = `${window.location.origin}${window.location.pathname}?autoReg=true`;
    navigator.clipboard.writeText(shareUrl)
      .then(() => {
        triggerToast('Link de auto-cadastro copiado para a área de transferência!', 'success');
      })
      .catch(() => {
        triggerToast('Erro ao copiar o link!', 'error');
      });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!nome.trim()) {
      triggerToast('Nome Completo é de preenchimento obrigatório!', 'error');
      return;
    }

    if (cpf.trim() && !isValidCPF(cpf)) {
      triggerToast(`O CPF informado (${cpf}) é inválido! Por favor, verifique os dígitos.`, 'error');
      return;
    }

    if (respCpf.trim() && !isValidCPF(respCpf)) {
      triggerToast(`O CPF do responsável informado (${respCpf}) é inválido! Por favor, verifique os dígitos.`, 'error');
      return;
    }

    if (roleType === 'atleta') {
      const data: Partial<Atleta> = {
        nome: nome.trim(),
        nasc,
        cpf: cpf.trim(),
        rg: rg.trim(),
        genero,
        natural: natural.trim(),
        end: end.trim(),
        cat,
        clube: clube.trim() || 'AVULSO',
        rating: Number(rating) || 0,
        cbtt: cbtt.trim(),
        nivel,
        mao,
        emp,
        status: 'Ativo',
        presenca: 'PENDENTE',
        pagamento: 'PENDENTE',
        obs: obs.trim(),
        email: email.trim(),
        wa: normalizePhoneToBrazil(wa),
        tel: normalizePhoneToBrazil(tel),
        emerg: emerg.trim(),
        resp: resp.trim(),
        respCpf: respCpf.trim(),
        foto: ''
      };
      onRegister('atleta', data);
    } else if (roleType === 'arbitro') {
      const data: Partial<Arbitro> = {
        nome: nome.trim(),
        nasc,
        cpf: cpf.trim(),
        nivel: arbNivel,
        cbtt: cbtt.trim(),
        email: email.trim(),
        wa: normalizePhoneToBrazil(wa),
        tel: normalizePhoneToBrazil(tel),
        status: 'Disponível',
        presenca: 'PENDENTE',
        pagamento: 'PENDENTE',
        val: arbVal,
        obs: obs.trim(),
        foto: ''
      };
      onRegister('arbitro', data);
    } else if (roleType === 'treinador') {
      const data: Partial<Treinador> = {
        nome: nome.trim(),
        clube: clube.trim() || 'AVULSO',
        cref: trCref.trim(),
        wa: normalizePhoneToBrazil(wa),
        email: email.trim(),
        status: 'Ativo'
      };
      onRegister('treinador', data);
    } else if (roleType === 'funcionario') {
      const data: Partial<Funcionario> = {
        nome: nome.trim(),
        nasc,
        cpf: cpf.trim(),
        rg: rg.trim(),
        genero,
        end: end.trim(),
        cargo: funCargo,
        depto: funDepto,
        admissao: new Date().toISOString().split('T')[0],
        contrato: 'Voluntário',
        salario: '0.00',
        ch: '24',
        ctps: '',
        pis: '',
        status: 'Ativo',
        demissao: '',
        obs: obs.trim(),
        email: email.trim(),
        wa: normalizePhoneToBrazil(wa),
        tel: normalizePhoneToBrazil(tel),
        ramal: '',
        emerg: emerg.trim(),
        email2: '',
        foto: ''
      };
      onRegister('funcionario', data);
    }

    setRegisteredName(nome);
    setRegisteredSuccess(true);
    triggerToast('Cadastro enviado e registrado com sucesso!', 'success');
  };

  const handleResetFormAndRegisterAnother = () => {
    setNome('');
    setNasc('');
    setCpf('');
    setRg('');
    setNatural('');
    setEnd('');
    setClube('');
    setRating('0');
    setCbtt('');
    setEmail('');
    setWa('');
    setTel('');
    setEmerg('');
    setResp('');
    setRespCpf('');
    setObs('');
    setArbVal('');
    setTrCref('');
    setRegisteredSuccess(false);
  };

  if (registeredSuccess) {
    return (
      <div className="max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-xl p-8 space-y-6 text-center select-none">
        <div className="w-11 h-11 sm:w-12 sm:h-12 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto shrink-0">
          <CheckCircle2 className="w-6 h-6 sm:w-7 sm:h-7" />
        </div>
        <div className="space-y-2">
          <h2 className="text-xl font-black text-slate-100 uppercase tracking-tight">Cadastro Concluído!</h2>
          <p className="text-sm text-slate-400 font-medium">
            Muito obrigado, <strong className="text-emerald-400 font-bold">{registeredName}</strong>. Seus dados de {roleType === 'atleta' ? 'atleta' : roleType === 'arbitro' ? 'árbitro' : roleType === 'treinador' ? 'treinador' : 'funcionário'} foram enviados automaticamente para o sistema principal.
          </p>
        </div>

        {/* Warning/Pending Info Box */}
        {(roleType === 'atleta' || roleType === 'arbitro') && (
          <div className="bg-slate-950 p-5 rounded-xl border border-yellow-500/20 text-left space-y-3">
            <h3 className="text-xs font-black text-yellow-400 uppercase tracking-wider flex items-center gap-1.5">
              ⚠️ PENDÊNCIAS DE INTEGRAÇÃO OFICIAL
            </h3>
            <ul className="text-2xs text-slate-350 space-y-2 leading-relaxed list-disc list-inside">
              <li>
                <span className="font-extrabold text-slate-105 text-slate-200">Presença Física:</span> Seu status está como <span className="p-0.5 px-1.5 bg-yellow-405/10 text-yellow-400 font-black rounded text-3xs">PENDENTE</span>. Você precisa confirmar sua presença no credenciamento físico da mesa controladora no dia do campeonato.
              </li>
              {roleType === 'atleta' && (
                <li>
                  <span className="font-extrabold text-slate-200">Comprovação da Taxa:</span> Seu status de pagamento está como <span className="p-0.5 px-1.5 bg-red-400/10 text-red-400 font-black rounded text-3xs">PENDENTE</span>. Favor procurar a secretaria do campeonato munido do comprovante de pagamento Pix ou dinheiro para regularizar sua inscrição e liberar sua credencial.
                </li>
              )}
            </ul>
          </div>
        )}

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
          <div className="text-2xs uppercase font-extrabold text-slate-500 tracking-wider">Apoie o Torneio</div>
          <p className="text-3xs text-slate-450 leading-relaxed">
            Compartilhe este formulário oficial de auto-cadastro com outros atletas, técnicos, árbitros ou voluntários do campeonato para que eles mesmos preencham seus dados!
          </p>
          <button
            type="button"
            onClick={handleCopyRegistrationLink}
            className="w-full bg-slate-900 hover:bg-slate-850 text-slate-200 border border-slate-800 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer"
          >
            <Copy className="w-4 h-4 text-yellow-400" />
            Copiar Link do Formulário
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            type="button"
            onClick={handleResetFormAndRegisterAnother}
            className="flex-1 bg-slate-950 border border-slate-850 hover:bg-slate-900 text-slate-400 hover:text-slate-200 font-bold py-2.5 rounded-lg text-xs transition cursor-pointer"
          >
            Cadastrar Outra Pessoa
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black py-2.5 rounded-lg text-xs tracking-wider uppercase transition cursor-pointer"
          >
            Voltar ao Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
      {/* Header Profile Band */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-950 px-6 py-5 border-b border-slate-850 flex items-center justify-between">
        <div className="space-y-1 text-left">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2 bg-yellow-400 text-slate-950 font-black text-3xs rounded uppercase tracking-wider">
              Público
            </span>
            <h1 className="text-base font-black text-slate-100 uppercase tracking-tight">Formulário de Auto-Registro</h1>
          </div>
          <p className="text-2xs text-slate-400">Preencha seus dados com atenção. Eles serão inseridos diretamente na base de dados oficial.</p>
        </div>
        
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 text-2xs hover:text-red-400 hover:bg-slate-850 border border-slate-800 text-slate-400 p-2 rounded-lg cursor-pointer transition font-bold"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Voltar</span>
        </button>
      </div>

      {/* Role Picker Toggles */}
      <div className="p-5 border-b border-slate-850 bg-slate-950/40">
        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block mb-2.5 text-center">
          Qual sua atuação no campeonato?
        </label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          <button
            type="button"
            onClick={() => setRoleType('atleta')}
            className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition font-extrabold cursor-pointer select-none ${
              roleType === 'atleta'
                ? 'bg-yellow-400/10 border-yellow-400 text-yellow-400'
                : 'bg-slate-950 border-slate-850 text-slate-450 hover:text-slate-250 hover:border-slate-700'
            }`}
          >
            <Users className="w-5 h-5 shrink-0" />
            <span>Atleta / Jogador</span>
          </button>
          
          <button
            type="button"
            onClick={() => setRoleType('arbitro')}
            className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition font-extrabold cursor-pointer select-none ${
              roleType === 'arbitro'
                ? 'bg-yellow-400/10 border-yellow-400 text-yellow-400'
                : 'bg-slate-950 border-slate-850 text-slate-450 hover:text-slate-250 hover:border-slate-700'
            }`}
          >
            <Award className="w-5 h-5 shrink-0" />
            <span>Árbitro Oficial</span>
          </button>

          <button
            type="button"
            onClick={() => setRoleType('treinador')}
            className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition font-extrabold cursor-pointer select-none ${
              roleType === 'treinador'
                ? 'bg-yellow-400/10 border-yellow-400 text-yellow-400'
                : 'bg-slate-950 border-slate-850 text-slate-450 hover:text-slate-250 hover:border-slate-700'
            }`}
          >
            <BookOpen className="w-5 h-5 shrink-0" />
            <span>Treinador / Técnico</span>
          </button>

          <button
            type="button"
            onClick={() => setRoleType('funcionario')}
            className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition font-extrabold cursor-pointer select-none ${
              roleType === 'funcionario'
                ? 'bg-yellow-400/10 border-yellow-400 text-yellow-400'
                : 'bg-slate-950 border-slate-850 text-slate-450 hover:text-slate-250 hover:border-slate-700'
            }`}
          >
            <Briefcase className="w-5 h-5 shrink-0" />
            <span>Funcionário / Staff</span>
          </button>
        </div>
      </div>

      {/* Main Registration Form */}
      <form onSubmit={handleSubmit} className="p-6 space-y-6 overflow-y-auto max-h-[62vh]">
        
        {/* Row 1: Common Personal Details */}
        <div className="space-y-4">
          <h3 className="text-2xs uppercase tracking-widest text-yellow-400 font-extrabold flex items-center gap-1.5 leading-none">
            <Sparkles className="w-3.5 h-3.5" />
            Informações Pessoais de Cadastro
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Nome Completo *</label>
              <input
                type="text"
                required
                placeholder="Ex: João da Silva Santos"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Endereço de E-mail</label>
              <input
                type="email"
                placeholder="Ex: joao@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-medium"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <DateInput
              label="Data de Nascimento"
              value={nasc}
              onChange={(val) => setNasc(val)}
            />

            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">CPF de Registro</label>
              <input
                type="text"
                placeholder="Apenas números"
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>

            {roleType !== 'treinador' && (
              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">RG ou ID Civil</label>
                <input
                  type="text"
                  placeholder="Apenas algarismos"
                  value={rg}
                  onChange={(e) => setRg(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">WhatsApp (DDD + Número)</label>
              <input
                type="text"
                placeholder="Ex: 11988887777"
                value={wa}
                onChange={(e) => setWa(e.target.value)}
                onBlur={() => setWa(prev => normalizePhoneToBrazil(prev))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Telefone Comercial / Fixo</label>
              <input
                type="text"
                placeholder="Fixo residencial/trabalho"
                value={tel}
                onChange={(e) => setTel(e.target.value)}
                onBlur={() => setTel(prev => normalizePhoneToBrazil(prev))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Contato de Emergência</label>
              <input
                type="text"
                placeholder="Ex: Mãe (11) 9777-6666"
                value={emerg}
                onChange={(e) => setEmerg(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
              />
            </div>
          </div>
        </div>

        {/* Row 2: Role Specific Formulations */}
        <div className="space-y-4 pt-4 border-t border-slate-850">
          <h3 className="text-2xs uppercase tracking-widest text-yellow-400 font-extrabold flex items-center gap-1.5 leading-none">
            <HeartPulse className="w-3.5 h-3.5" />
            Dados Específicos para Atuação [{roleType.toUpperCase()}]
          </h3>

          {roleType === 'atleta' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Clube ou Associação</label>
                  <input
                    type="text"
                    placeholder="Ex: Associação Real T.M."
                    value={clube}
                    onChange={(e) => setClube(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Registro CBTT / Unidade ID</label>
                  <input
                    type="text"
                    placeholder="Número de atleta confederado"
                    value={cbtt}
                    onChange={(e) => setCbtt(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Rating Inicial</label>
                  <input
                    type="number"
                    value={rating}
                    onChange={(e) => setRating(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Gênero</label>
                  <select
                    value={genero}
                    onChange={(e) => setGenero(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                  >
                    <option value="Masculino">MASCULINO</option>
                    <option value="Feminino">FEMININO</option>
                    <option value="Misto">MISTO</option>
                    <option value="Livre">LIVRE</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Nível Técnico</label>
                  <select
                    value={nivel}
                    onChange={(e) => setNivel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                  >
                    <option value="Iniciante">INICIANTE</option>
                    <option value="Intermediário">INTERMEDIÁRIO</option>
                    <option value="Avançado">AVANÇADO</option>
                    <option value="Elite">ELITE</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Mão Dominante</label>
                  <select
                    value={mao}
                    onChange={(e) => setMao(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                  >
                    <option value="Direita">CANHOTO / SESTREIRO (ESQUERDA)</option>
                    <option value="Esquerda">DESTRIMÃO (DIREITA)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Empunhadura</label>
                  <select
                    value={emp}
                    onChange={(e) => setEmp(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                  >
                    <option value="Caneta">CANETA JAPONESA / CHINESA</option>
                    <option value="Shakehand">SHAKEHAND / CLÁSSICO</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Cidade e Estado Natal</label>
                  <input
                    type="text"
                    placeholder="Ex: Santos - SP"
                    value={natural}
                    onChange={(e) => setNatural(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Endereço de Residência completo</label>
                  <input
                    type="text"
                    placeholder="Av, Rua, Número, CEP"
                    value={end}
                    onChange={(e) => setEnd(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
                  />
                </div>
              </div>

              <div className="bg-slate-950/50 p-4 rounded-xl border border-slate-850 space-y-4">
                <div className="text-3xs uppercase font-extrabold text-amber-500 tracking-wider">Se menor de idade (Responsável Legal)</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Nome do Responsável</label>
                    <input
                      type="text"
                      placeholder="Nome do Pai/Mãe ou Tutor legal"
                      value={resp}
                      onChange={(e) => setResp(e.target.value)}
                      className="w-full bg-slate-950/80 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">CPF do Responsável</label>
                    <input
                      type="text"
                      placeholder="Apenas dígitos"
                      value={respCpf}
                      onChange={(e) => setRespCpf(e.target.value)}
                      className="w-full bg-slate-950/80 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {roleType === 'arbitro' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Nível de Arbitragem</label>
                <select
                  value={arbNivel}
                  onChange={(e) => setArbNivel(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                >
                  <option value="Local">LOCAL</option>
                  <option value="Regional">REGIONAL</option>
                  <option value="Estadual">ESTADUAL</option>
                  <option value="Nacional">NACIONAL</option>
                  <option value="Internacional">INTERNACIONAL</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Inscrição CBTT / Credencial</label>
                <input
                  type="text"
                  placeholder="ID de árbitro credenciado"
                  value={cbtt}
                  onChange={(e) => setCbtt(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                />
              </div>

              <DateInput
                label="Validade de Credencial"
                value={arbVal}
                onChange={(val) => setArbVal(val)}
              />
            </div>
          )}

          {roleType === 'treinador' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Associação / Clube de Origem</label>
                <input
                  type="text"
                  placeholder="Ex: Pinheiros T.M."
                  value={clube}
                  onChange={(e) => setClube(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Registro CREF / Licença Esportiva</label>
                <input
                  type="text"
                  placeholder="Registro CREF ou similar"
                  value={trCref}
                  onChange={(e) => setTrCref(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
                />
              </div>
            </div>
          )}

          {roleType === 'funcionario' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Cargo / Atribuição desejada</label>
                <select
                  value={funCargo}
                  onChange={(e) => setFunCargo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                >
                  <option value="Apoio de Quadra">APOIO DE QUADRA / GINÁSIO</option>
                  <option value="Mesário">MESÁRIO DE MESA / COORDENADOR</option>
                  <option value="Técnico de Som/Vídeo">TÉCNICO DE PLACAR / STREAMING</option>
                  <option value="Segurança">APOIO DE SEGURANÇA / CONTROLE</option>
                  <option value="Voluntário Principal">VOLUNTÁRIO MULTI-TASK</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Departamento Vinculado</label>
                <select
                  value={funDepto}
                  onChange={(e) => setFunDepto(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer"
                >
                  <option value="Apoio Operacional">APOIO OPERACIONAL</option>
                  <option value="Técnico">DEPARTAMENTO TÉCNICO</option>
                  <option value="Administração">ADMINISTRAÇÃO / RECEPÇÃO</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Notes Block */}
        <div className="space-y-1">
          <label className="text-3xs uppercase tracking-wider text-slate-450 font-bold block">Informações de Observações / Notas Importantes</label>
          <textarea
            rows={2}
            value={obs}
            onChange={(e) => setObs(e.target.value)}
            placeholder="Campo livre para comunicar problemas de saúde, observações alimentares, restrições ou detalhes técnicos."
            className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none resize-none"
          ></textarea>
        </div>

        {/* Buttons submission */}
        <div className="flex gap-4 pt-1">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-slate-950 hover:bg-slate-850 text-slate-400 border border-slate-800 font-bold py-3 rounded-xl text-xs transition cursor-pointer text-center"
          >
            Cancelar Cadastro
          </button>
          <button
            type="submit"
            className="flex-1 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black py-3 rounded-xl text-xs tracking-wider uppercase transition cursor-pointer flex items-center justify-center gap-2 shadow-lg"
          >
            <Send className="w-4 h-4 text-slate-950" />
            Enviar Registro
          </button>
        </div>
      </form>
    </div>
  );
}
