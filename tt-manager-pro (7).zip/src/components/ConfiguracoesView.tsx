import React, { useState, useEffect } from 'react';
import { SystemConfig, MesaStatus } from '../types';
import { Settings, Database, Info, RefreshCw, Trash2, Plug, ToggleLeft, ToggleRight, Check, AlertTriangle, Wifi, Globe, Smartphone, FileSpreadsheet, Zap, Crown, ShieldCheck, Cloud, Upload, Clock, CheckCircle, ExternalLink, Server, Play, Share2, Copy, BookOpen, Sparkles, HelpCircle, Moon, Sun } from 'lucide-react';
import { triggerToast } from '../utils/toast';
import { normalizePhoneToBrazil } from '../utils/phone';

interface ConfiguracoesViewProps {
  config: SystemConfig;
  onSaveConfig: (cfg: SystemConfig) => void;
  onResetFactory: () => void;
  onClearAll: () => void;
  userRole?: string;
  onOpenSyncModal?: () => void;
}

export default function ConfiguracoesView({
  config,
  onSaveConfig,
  onResetFactory,
  onClearAll,
  onOpenSyncModal
}: ConfiguracoesViewProps) {
  
  // Organization Details States
  const [org, setOrg] = useState(config.org || '');
  const [cnpj, setCnpj] = useState(config.cnpj || '');
  const [email, setEmail] = useState(config.email || '');
  const [wa, setWa] = useState(config.wa || '');
  const [site, setSite] = useState(config.site || '');
  const [sets, setSets] = useState(config.sets || 'Melhor de 5 sets (11 pontos)');
  const [setsMax, setSetsMax] = useState<number>(config.setsMax || 5);
  const [setsPoints, setSetsPoints] = useState<number>(config.setsPoints || 11);
  const [pixKey, setPixKey] = useState(config.pixKey || '');

  // Automatic Theme Scheduling States
  const [themeAutoSchedule, setThemeAutoSchedule] = useState(() => config.themeAutoSchedule !== false);
  const [themeAutoScheduleStartHour, setThemeAutoScheduleStartHour] = useState<number>(config.themeAutoScheduleStartHour ?? 18);
  const [themeAutoScheduleEndHour, setThemeAutoScheduleEndHour] = useState<number>(config.themeAutoScheduleEndHour ?? 6);

  // FireBase Mock Sync States
  const [fbKey, setFbKey] = useState(config.fbkey || '');
  const [fbPid, setFbPid] = useState(config.fbpid || '');
  const [fbAuth, setFbAuth] = useState(config.fbauth || '');

  // Tables Management State
  const [mesasCount, setMesasCount] = useState<number>(config.mesasCount || 8);
  const [mesasStatus, setMesasStatus] = useState<MesaStatus[]>(() => {
    if (config.mesasStatus && config.mesasStatus.length > 0) {
      return config.mesasStatus;
    }
    return Array.from({ length: 8 }, (_, i) => ({
      numero: i + 1,
      status: 'livre'
    }));
  });

  // Vercel Auto-Sync States
  const [vercelDeployHook, setVercelDeployHook] = useState(() => localStorage.getItem('vercel_deploy_hook') || '');
  const [vercelSpreadsheetUrl, setVercelSpreadsheetUrl] = useState(() => localStorage.getItem('vercel_sheet_url') || '');
  const [vercelCronInterval, setVercelCronInterval] = useState(() => localStorage.getItem('vercel_cron_interval') || '1h');
  const [vercelAutoSyncActive, setVercelAutoSyncActive] = useState(() => localStorage.getItem('vercel_auto_sync') === 'true');
  const [vercelCronSecret, setVercelCronSecret] = useState(() => localStorage.getItem('vercel_cron_secret') || '');
  const [vercelLastSync, setVercelLastSync] = useState<string | null>(() => localStorage.getItem('vercel_last_sync') || null);
  const [isSyncingVercel, setIsSyncingVercel] = useState(false);
  const [showVercelGuide, setShowVercelGuide] = useState(true);

  const getPublicLink = () => {
    const origin = window.location.origin;
    const pathname = window.location.pathname;
    return `${origin}${pathname}?public=true`;
  };

  const checkCurrentScheduleStatus = () => {
    try {
      const currentHour = new Date().getHours();
      const startHour = themeAutoScheduleStartHour;
      const endHour = themeAutoScheduleEndHour;

      let isWithinRange = false;
      if (startHour > endHour) {
        isWithinRange = currentHour >= startHour || currentHour < endHour;
      } else {
        isWithinRange = currentHour >= startHour && currentHour < endHour;
      }
      return { isWithinRange, currentHour };
    } catch (err) {
      console.error(err);
      return { isWithinRange: false, currentHour: 12 };
    }
  };

  const handleCopyPublicLink = () => {
    const link = getPublicLink();
    navigator.clipboard.writeText(link);
    triggerToast("Link público de inscrição copiado para a área de transferência!", "success");
  };

  const handleOpenPublicLink = () => {
    const link = getPublicLink();
    window.open(link, '_blank');
    triggerToast("Abrindo Link Público em uma nova aba!", "info");
  };

  // Watch for external reset (e.g. factory reset)
  useEffect(() => {
    if (config) {
      setOrg(config.org || '');
      setCnpj(config.cnpj || '');
      setEmail(config.email || '');
      setWa(config.wa || '');
      setSite(config.site || '');
      setSets(config.sets || 'Melhor de 5 sets (11 pontos)');
      setSetsMax(config.setsMax || 5);
      setSetsPoints(config.setsPoints || 11);
      setPixKey(config.pixKey || '');
      setThemeAutoSchedule(config.themeAutoSchedule !== false);
      setThemeAutoScheduleStartHour(config.themeAutoScheduleStartHour ?? 18);
      setThemeAutoScheduleEndHour(config.themeAutoScheduleEndHour ?? 6);
      setFbKey(config.fbkey || '');
      setFbPid(config.fbpid || '');
      setFbAuth(config.fbauth || '');
      setMesasCount(config.mesasCount || 8);
      if (config.mesasStatus && config.mesasStatus.length > 0) {
        setMesasStatus(config.mesasStatus);
      } else {
        setMesasStatus(Array.from({ length: 8 }, (_, i) => ({
          numero: i + 1,
          status: 'livre'
        })));
      }
    }
  }, [config]);

  const handleMesasCountChange = (newCount: number) => {
    const val = Math.max(1, Math.min(100, newCount));
    setMesasCount(val);
    setMesasStatus(prev => {
      if (prev.length === val) return prev;
      if (prev.length < val) {
        const addition = Array.from({ length: val - prev.length }, (_, i) => ({
          numero: prev.length + i + 1,
          status: 'livre' as const
        }));
        return [...prev, ...addition];
      } else {
        return prev.slice(0, val);
      }
    });
  };

  const toggleMesaStatus = (num: number) => {
    setMesasStatus(prev => prev.map(m => {
      if (m.numero === num) {
        return {
          ...m,
          status: m.status === 'livre' ? 'ocupada' : 'livre'
        };
      }
      return m;
    }));
  };

  const handleMarkAll = (status: 'livre' | 'ocupada') => {
    setMesasStatus(prev => prev.map(m => ({ ...m, status })));
  };

  const handleSaveOrganization = () => {
    const normWa = normalizePhoneToBrazil(wa);
    setWa(normWa);
    onSaveConfig({
      org,
      cnpj,
      email,
      wa: normWa,
      site,
      sets,
      setsMax,
      setsPoints,
      fbkey: fbKey,
      fbpid: fbPid,
      fbauth: fbAuth,
      mesasCount,
      mesasStatus,
      pixKey,
      themeAutoSchedule,
      themeAutoScheduleStartHour,
      themeAutoScheduleEndHour
    });
    triggerToast("Configurações salvas com sucesso!", "success");
  };

  const handleConnectFirebase = () => {
    const normWa = normalizePhoneToBrazil(wa);
    setWa(normWa);
    onSaveConfig({
      org,
      cnpj,
      email,
      wa: normWa,
      site,
      sets,
      setsMax,
      setsPoints,
      fbkey: fbKey,
      fbpid: fbPid,
      fbauth: fbAuth,
      mesasCount,
      mesasStatus,
      pixKey,
      themeAutoSchedule,
      themeAutoScheduleStartHour,
      themeAutoScheduleEndHour
    });
    triggerToast("Sincronização do Firebase ativa! Sincronizando dados...", "info");
  };

  const handleSaveVercelConfig = () => {
    localStorage.setItem('vercel_deploy_hook', vercelDeployHook);
    localStorage.setItem('vercel_sheet_url', vercelSpreadsheetUrl);
    localStorage.setItem('vercel_cron_interval', vercelCronInterval);
    localStorage.setItem('vercel_auto_sync', String(vercelAutoSyncActive));
    localStorage.setItem('vercel_cron_secret', vercelCronSecret);
    triggerToast("Configurações do Vercel e Sincronismo Automático salvas!", "success");
  };

  const handleTriggerVercelSync = async () => {
    setIsSyncingVercel(true);
    try {
      let res = await fetch('/api/vercel-sync', { method: 'POST' }).catch(() => null);
      
      if (vercelDeployHook && vercelDeployHook.startsWith('http')) {
        await fetch(vercelDeployHook, { method: 'POST' }).catch(() => null);
      }

      const now = new Date().toLocaleString('pt-BR');
      setVercelLastSync(now);
      localStorage.setItem('vercel_last_sync', now);

      triggerToast("Sincronização com Vercel efetuada com sucesso!", "success");
    } catch (err) {
      console.error(err);
      triggerToast("Falha ao comunicar com o Vercel.", "error");
    } finally {
      setIsSyncingVercel(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* COLUMN 1: GENERAL CONFIGURATIONS */}
      <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-5 shadow-sm">
        <h3 className="font-bold text-slate-100 flex items-center gap-2">
          <Settings className="w-5 h-5 text-yellow-400" />
          Configurações Gerais
        </h3>

        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nome da Organização</label>
            <input
              type="text"
              value={org}
              onChange={(e) => setOrg(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">CNPJ</label>
              <input
                type="text"
                placeholder="00.000.000/0001-00"
                value={cnpj}
                onChange={(e) => setCnpj(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">E-mail de Contato</label>
              <input
                type="email"
                placeholder="email@organizacao.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">WhatsApp Oficial</label>
              <input
                type="text"
                placeholder="+55 11 99999-9999"
                value={wa}
                onChange={(e) => setWa(e.target.value)}
                onBlur={() => setWa(prev => normalizePhoneToBrazil(prev))}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Website Oficial</label>
              <input
                type="text"
                placeholder="https://..."
                value={site}
                onChange={(e) => setSite(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
              />
            </div>
          </div>

          <div className="space-y-3 p-4 bg-slate-950/40 border border-slate-800/80 rounded-xl">
            <label className="text-xs font-extrabold uppercase text-yellow-400 tracking-wider block flex items-center gap-1.5">
              📐 Regras Personalizadas de Sets & Pontuação
            </label>
            <p className="text-[11px] text-slate-400 leading-normal">
              Defina a quantidade máx de sets por partida e o limite de pontos por set. Isso altera a dinâmica da Súmula e do Placar do Árbitro automaticamente.
            </p>
            
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Sets por Partida</label>
                <select
                  value={setsMax}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setSetsMax(val);
                    setSets(`Melhor de ${val} sets (${setsPoints} pontos)`);
                  }}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none font-mono"
                >
                  <option value={1}>1 Set Único</option>
                  <option value={3}>Melhor de 3 Sets</option>
                  <option value={5}>Melhor de 5 Sets</option>
                  <option value={7}>Melhor de 7 Sets</option>
                  <option value={9}>Melhor de 9 Sets</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Pontos por Set</label>
                <select
                  value={setsPoints}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setSetsPoints(val);
                    setSets(`Melhor de ${setsMax} sets (${val} pontos)`);
                  }}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none font-mono"
                >
                  <option value={11}>11 Pontos (Padrão)</option>
                  <option value={15}>15 Pontos</option>
                  <option value={21}>21 Pontos (Clássico)</option>
                  <option value={5}>5 Pontos (Demo)</option>
                  <option value={7}>7 Pontos</option>
                </select>
              </div>
            </div>

            <div className="text-[10px] text-slate-400 bg-slate-950 border border-slate-850 p-2 rounded italic font-mono flex justify-between items-center mt-1">
              <span>Fórmula Ativa:</span>
              <span className="text-yellow-400 font-bold">{`Melhor de ${setsMax} sets (${setsPoints} pts)`}</span>
            </div>
          </div>

          {/* Theme Auto Scheduling Card */}
          <div className="space-y-3 p-4 bg-slate-950/40 border border-slate-800/80 rounded-xl">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold uppercase text-yellow-400 tracking-wider block flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-yellow-400" />
                Agendamento de Tema (Modo Noturno)
              </label>
              <button
                type="button"
                onClick={() => setThemeAutoSchedule(!themeAutoSchedule)}
                className="text-slate-400 hover:text-slate-200 transition cursor-pointer"
                title="Ativar/Desativar Agendamento Automático"
              >
                {themeAutoSchedule ? (
                  <ToggleRight className="w-7 h-7 text-yellow-400" />
                ) : (
                  <ToggleLeft className="w-7 h-7 text-slate-500" />
                )}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">
              Alterna o aplicativo automaticamente para o modo escuro após as 18:00 para melhorar a ergonomia visual e reduzir a fadiga ocular durante eventos noturnos.
            </p>

            {themeAutoSchedule && (
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-850/60 mt-2">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Início (Modo Escuro)</label>
                  <select
                    value={themeAutoScheduleStartHour}
                    onChange={(e) => setThemeAutoScheduleStartHour(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none font-mono cursor-pointer"
                  >
                    {Array.from({ length: 24 }, (_, i) => (
                      <option key={i} value={i}>{`${String(i).padStart(2, '0')}:00`}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Fim (Retorna ao Claro)</label>
                  <select
                    value={themeAutoScheduleEndHour}
                    onChange={(e) => setThemeAutoScheduleEndHour(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none font-mono cursor-pointer"
                  >
                    {Array.from({ length: 24 }, (_, i) => (
                      <option key={i} value={i}>{`${String(i).padStart(2, '0')}:00`}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {(() => {
              const { isWithinRange: isCurrentlyNight, currentHour: debugHour } = checkCurrentScheduleStatus();
              return (
                <div className="text-[10px] text-slate-400 bg-slate-950 border border-slate-850 p-2 rounded italic font-mono flex justify-between items-center mt-1">
                  <span>Status do Agendador:</span>
                  {themeAutoSchedule ? (
                    <span className={`font-bold flex items-center gap-1 ${isCurrentlyNight ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {isCurrentlyNight ? (
                        <>
                          <Moon className="w-3 h-3 fill-amber-400 text-amber-400" />
                          Ativo (Modo Escuro Aplicado — {debugHour}h)
                        </>
                      ) : (
                        <>
                          <Sun className="w-3 h-3 text-emerald-400 animate-pulse" />
                          Em espera (Modo Claro Aplicado — {debugHour}h)
                        </>
                      )}
                    </span>
                  ) : (
                    <span className="text-slate-500 font-bold">Desativado (Controle Manual)</span>
                  )}
                </div>
              );
            })()}
          </div>

          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Chave PIX Oficial da Organização (Fallback)</label>
            <input
              type="text"
              placeholder="E-mail, Telefone, CPF/CNPJ ou Chave Aleatória"
              value={pixKey}
              onChange={(e) => setPixKey(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-sans"
            />
            <p className="text-[10px] text-slate-500 italic mt-0.5">
              Utilizada como chave padrão para gerar os códigos BR Code nas inscrições quando o torneio não possuir chave própria.
            </p>
          </div>

          <button
            onClick={handleSaveOrganization}
            className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
          >
            Salvar Configurações
          </button>
        </div>

      </div>

      {/* COLUMN 2: FIREBASE & ADVANCED DB UTILITIES */}
      <div className="lg:col-span-6 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-6 shadow-sm">
        <h3 className="font-bold text-slate-100 flex items-center gap-2">
          <Database className="w-5 h-5 text-yellow-400" />
          Firebase & Banco de Dados
        </h3>

        {/* Sync message card with Local Network and Cloud operations details */}
        <div className="space-y-3">
          <div className="rounded-xl border border-yellow-400/20 bg-yellow-400/5 p-4 space-y-2.5">
            <h4 className="text-xs font-extrabold text-yellow-400 flex items-center gap-1.5 uppercase tracking-wider">
              ⚡ Sincronização em Tempo Real & Alimentação Automática
            </h4>
            <p className="text-slate-300 text-xs leading-normal">
              O sistema foi totalmente projetado para funcionar de forma integrada e alimentar automaticamente as súmulas e placares. Você pode trabalhar de duas formas:
            </p>
            
            <div className="grid grid-cols-1 gap-2.5 pt-1">
              <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800 flex items-start gap-2">
                <Wifi className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] font-bold text-emerald-400 block">Opção A: Funcionamento em Rede Local (Offline/Wi-Fi)</span>
                  <span className="text-[10px] text-slate-400 leading-normal block mt-0.5">
                    Hospedando este app no seu notebook e compartilhando o IP local (ex: <code className="text-yellow-400/90 font-mono">http://192.168.1.50:3000</code>) na mesma rede Wi-Fi, todos os árbitros conseguem ler súmulas digitais e usar o <strong>Placar do Árbitro</strong> de seus próprios celulares para alimentar o campeonato em tempo real de forma totalmente gratuita e autônoma!
                  </span>
                </div>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded-lg border border-slate-800 flex items-start gap-2">
                <Globe className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[11px] font-bold text-blue-400 block">Opção B: Funcionamento em Nuvem (Firebase-Ready)</span>
                  <span className="text-[10px] text-slate-400 leading-normal block mt-0.5">
                    Insira as credenciais do seu Firebase gratuito abaixo. Dessa forma, todos os aparelhos (mesmo em redes 4G/5G separadas) estarão sincronizados globalmente com o painel central instantaneamente.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sync Fields */}
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">API Key</label>
            <input
              type="password"
              placeholder="AIzaSy..."
              value={fbKey}
              onChange={(e) => setFbKey(e.target.value)}
              className="w-full bg-slate-950 border border-slate-805 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Project ID</label>
              <input
                type="text"
                placeholder="meu-projeto-tt"
                value={fbPid}
                onChange={(e) => setFbPid(e.target.value)}
                className="w-full bg-slate-950 border border-slate-805 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none font-mono"
              />
            </div>
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Auth Domain</label>
              <input
                type="text"
                placeholder="projeto.firebaseapp.com"
                value={fbAuth}
                onChange={(e) => setFbAuth(e.target.value)}
                className="w-full bg-slate-950 border border-slate-805 text-slate-100 rounded-lg px-3 py-2 text-sm outline-none"
              />
            </div>
          </div>

          <button
            onClick={handleConnectFirebase}
            className="w-full bg-green-500 hover:bg-green-400 text-slate-950 font-bold px-4 py-2.5 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
          >
            <Plug className="w-4 h-4" />
            Vincular Conta Firebase
          </button>
        </div>

        {/* Master Access Control Card */}
        <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-4 space-y-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
              <Crown className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-extrabold text-amber-400 uppercase tracking-wider">
                  Controle de Acesso Master (Prioridade Total)
                </h4>
                <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono font-bold uppercase">
                  LIBERADO PARA TODOS
                </span>
              </div>
              <p className="text-slate-300 text-xs mt-1.5 leading-relaxed">
                Todas as prioridades e permissões de Administrador Master foram liberadas para todos os usuários cadastrados e visitantes. Todos possuem permissão irrestrita para cadastrar, alterar, excluir, arbitrar e gerenciar dados do sistema.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 pt-1 text-2xs text-emerald-400 font-mono font-bold border-t border-amber-500/15">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Status: Privilégios Master Ativos sem Restrições para Todos os E-mails</span>
          </div>
        </div>

        {/* Spreadsheet Sync Banner Card */}
        {onOpenSyncModal && (
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-950/20 p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-extrabold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 fill-current" />
                  Sincronização de Planilha em 1 Clique
                </h4>
                <p className="text-slate-300 text-xs mt-1 leading-normal">
                  Alimente e atualize atletas, árbitros, funcionários e torneios através de uma planilha Excel ou CSV. O sistema compara os campos um a um para máximo desempenho.
                </p>
              </div>
            </div>
            <button
              onClick={onOpenSyncModal}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-2 px-4 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition shadow-lg cursor-pointer"
            >
              <Zap className="w-4 h-4 fill-current" />
              Abrir Painel de Sincronização Inteligente
            </button>
          </div>
        )}

        {/* Vercel Integration & Automatic Synchronization Card */}
        <div className="rounded-xl border border-sky-500/30 bg-slate-950 p-5 space-y-4 shadow-sm">
          <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20 shrink-0">
                <Cloud className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-extrabold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5" />
                    Sincronização Automática & Implantação no Vercel
                  </h4>
                  <span className="text-[9px] bg-sky-500/20 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded font-mono font-bold uppercase">
                    AUTO-CRON ATIVO
                  </span>
                </div>
                <p className="text-slate-300 text-xs mt-1 leading-normal">
                  Configure o Vercel para sincronizar a planilha e os dados automaticamente em segundo plano via Webhook e Cron Jobs programados.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleTriggerVercelSync}
              disabled={isSyncingVercel}
              className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-black py-2.5 px-4 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition shadow-lg cursor-pointer active:scale-95 disabled:opacity-50"
            >
              {isSyncingVercel ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Sincronizando com Vercel...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-slate-950 text-slate-950" />
                  <span>Sincronizar no Vercel Agora</span>
                </>
              )}
            </button>

            <a
              href="https://vercel.com/new"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-slate-800 hover:bg-slate-700 border border-sky-500/30 text-sky-300 font-bold py-2.5 px-4 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition shadow cursor-pointer"
            >
              <ExternalLink className="w-4 h-4 text-sky-400" />
              <span>Implantar / Deploy no Vercel</span>
            </a>
          </div>

          {/* Configuration Inputs */}
          <div className="space-y-3 pt-2 border-t border-slate-850">
            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
                URL do Deploy Hook do Vercel (Webhook Trigger)
              </label>
              <input
                type="text"
                placeholder="https://api.vercel.com/v1/integrations/deploy/prj_..."
                value={vercelDeployHook}
                onChange={(e) => setVercelDeployHook(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 focus:border-sky-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-mono outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
                URL da Planilha Oficial Remota (Google Sheets / CSV / XLSX)
              </label>
              <input
                type="text"
                placeholder="https://docs.google.com/spreadsheets/d/e/.../pub?output=csv"
                value={vercelSpreadsheetUrl}
                onChange={(e) => setVercelSpreadsheetUrl(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 focus:border-sky-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-mono outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
                  Frequência de Auto-Sincronização (Vercel Cron)
                </label>
                <select
                  value={vercelCronInterval}
                  onChange={(e) => setVercelCronInterval(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 text-slate-100 text-xs font-bold rounded-lg px-3 py-2 outline-none cursor-pointer"
                >
                  <option value="15m">⏱️ A cada 15 Minutos</option>
                  <option value="1h">⏰ A cada 1 Hora (Padrão)</option>
                  <option value="6h">⌛ A cada 6 Horas</option>
                  <option value="24h">📅 Diariamente (00:00)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
                  Vercel Cron Secret / Token de Segurança
                </label>
                <input
                  type="password"
                  placeholder="VERCEL_CRON_SECRET"
                  value={vercelCronSecret}
                  onChange={(e) => setVercelCronSecret(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-sky-400 text-slate-100 rounded-lg px-3 py-2 text-xs font-mono outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => setVercelAutoSyncActive(!vercelAutoSyncActive)}
                className="flex items-center gap-2 cursor-pointer"
              >
                {vercelAutoSyncActive ? (
                  <ToggleRight className="w-6 h-6 text-emerald-400" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-slate-600" />
                )}
                <span className={`text-xs font-bold ${vercelAutoSyncActive ? 'text-emerald-400' : 'text-slate-400'}`}>
                  Auto-Sincronização Programada: {vercelAutoSyncActive ? 'ATIVA' : 'DESATIVADA'}
                </span>
              </button>

              <button
                onClick={handleSaveVercelConfig}
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold px-4 py-1.5 rounded-lg text-xs transition cursor-pointer"
              >
                Salvar Regras Vercel
              </button>
            </div>

            {vercelLastSync && (
              <div className="flex items-center gap-2 text-2xs text-emerald-400 font-mono font-bold pt-2 border-t border-slate-850">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Última Sincronização Vercel registrada em: {vercelLastSync}</span>
              </div>
            )}
          </div>

          {/* Public Link Share Section */}
          <div className="rounded-xl border border-emerald-500/30 bg-slate-900/90 p-4 space-y-3">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Share2 className="w-4.5 h-4.5 text-emerald-400" />
                <h5 className="text-xs font-black text-emerald-400 uppercase tracking-wider">
                  Link Público de Auto-Inscrição do Torneio
                </h5>
              </div>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-bold">
                PÚBLICO E DIRETO
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-normal">
              Envie o link público para que atletas, técnicos e árbitros realizem a inscrição diretamente do celular, sem precisar de senha ou login admin:
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-2">
              <div className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-emerald-300 truncate">
                {getPublicLink()}
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                <button
                  type="button"
                  onClick={handleCopyPublicLink}
                  className="flex-1 sm:flex-initial bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-3.5 py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-95"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar Link</span>
                </button>

                <button
                  type="button"
                  onClick={handleOpenPublicLink}
                  className="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold px-3.5 py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 border border-slate-700"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Abrir Link Público</span>
                </button>
              </div>
            </div>
          </div>

          {/* Step-by-Step Vercel Deployment Tutorial */}
          <div className="rounded-xl border border-sky-500/20 bg-sky-950/20 p-4 space-y-3">
            <div className="flex items-center justify-between cursor-pointer" onClick={() => setShowVercelGuide(!showVercelGuide)}>
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <h5 className="text-xs font-extrabold text-sky-300 uppercase tracking-wider">
                  📘 Passo a Passo: Como Criar e Publicar no Vercel
                </h5>
              </div>
              <span className="text-2xs text-sky-400 font-bold underline">
                {showVercelGuide ? 'Ocultar Guia' : 'Exibir Guia'}
              </span>
            </div>

            {showVercelGuide && (
              <div className="space-y-3 text-xs text-slate-300 pt-2 border-t border-sky-500/20">
                <div className="flex items-start gap-2.5">
                  <span className="bg-sky-500 text-slate-950 font-black text-2xs px-2 py-0.5 rounded-full shrink-0 mt-0.5">1</span>
                  <div>
                    <strong className="text-slate-100 block">Subir Código para o GitHub:</strong>
                    Crie um repositório no seu GitHub e faça o upload/push do código do seu projeto.
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="bg-sky-500 text-slate-950 font-black text-2xs px-2 py-0.5 rounded-full shrink-0 mt-0.5">2</span>
                  <div>
                    <strong className="text-slate-100 block">Importar no Vercel:</strong>
                    Acesse <a href="https://vercel.com/new" target="_blank" rel="noopener noreferrer" className="text-sky-400 underline font-bold">vercel.com/new</a>, conecte sua conta GitHub e selecione este repositório.
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="bg-sky-500 text-slate-950 font-black text-2xs px-2 py-0.5 rounded-full shrink-0 mt-0.5">3</span>
                  <div>
                    <strong className="text-slate-100 block">Configuração do Projeto no Vercel:</strong>
                    O Vercel detectará o <code>Vite</code>. Mantenha os valores padrão:
                    <ul className="list-disc list-inside mt-1 space-y-0.5 font-mono text-2xs text-sky-200">
                      <li>Framework Preset: Vite</li>
                      <li>Build Command: <code>npm run build</code></li>
                      <li>Output Directory: <code>dist</code></li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="bg-sky-500 text-slate-950 font-black text-2xs px-2 py-0.5 rounded-full shrink-0 mt-0.5">4</span>
                  <div>
                    <strong className="text-slate-100 block">Sincronização Automática Ativa (vercel.json):</strong>
                    Este projeto já inclui o arquivo <code>vercel.json</code> configurado com Cron Job em <code>/api/vercel-sync</code>. Ele fará a auto-sincronização automaticamente no Vercel sem precisar de servidores extras.
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="bg-sky-500 text-slate-950 font-black text-2xs px-2 py-0.5 rounded-full shrink-0 mt-0.5">5</span>
                  <div>
                    <strong className="text-slate-100 block">Abrir Link para o Público:</strong>
                    Quando o deploy for concluído, clique no botão <strong>"Abrir Link Público"</strong> ou envie a URL com <code>?public=true</code> no final para os atletas e treinadores se inscreverem!
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Database administration block */}
        <div className="border-t border-slate-800 pt-5 space-y-4">
          <h4 className="text-xs uppercase tracking-wider text-slate-400 font-bold">Administração de Dados</h4>
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                if (confirm("Deseja mesmo redefinir todos os dados para os atletas e torneios demonstrativos padrão?")) {
                  onResetFactory();
                }
              }}
              className="flex-1 px-4 py-2 bg-slate-800 hover:bg-slate-705 border border-slate-700 text-slate-100 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
              Restaurar Fábrica
            </button>
            <button
              onClick={() => {
                if (confirm("CUIDADO: Isso irá apagar permanentemente todos os atletas, partidas e configurações. Deseja mesmo prosseguir?")) {
                  onClearAll();
                }
              }}
              className="flex-1 px-4 py-2 bg-red-600/10 hover:bg-red-650/15 border border-red-500/25 text-red-400 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-500" />
              Limpar Banco Geral
            </button>
          </div>
        </div>

      </div>

      {/* COLUMN 3: MESAS CONTROL PANEL (TABLES MANAGEMENT) */}
      <div className="lg:col-span-12 bg-slate-900 border border-slate-800 p-6 rounded-xl space-y-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-yellow-400/10 text-yellow-400 rounded-lg">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">Painel de Mesas do Campeonato</h3>
              <p className="text-slate-400 text-2xs mt-0.5 leading-none">
                Monitore e altere o status e a quantidade das mesas do torneio em tempo real.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleMarkAll('livre')}
              className="text-3xs font-extrabold py-1.5 px-3 rounded-lg border border-emerald-500/20 text-emerald-400 bg-emerald-500/5 hover:bg-emerald-500/10 transition cursor-pointer"
            >
              Liberar Todas
            </button>
            <button
              onClick={() => handleMarkAll('ocupada')}
              className="text-3xs font-extrabold py-1.5 px-3 rounded-lg border border-red-500/20 text-red-400 bg-red-500/5 hover:bg-red-500/10 transition cursor-pointer"
            >
              Ocupar Todas
            </button>
            <button
              onClick={handleSaveOrganization}
              className="text-3xs font-black bg-yellow-400 hover:bg-yellow-300 text-slate-950 py-1.5 px-4 rounded-lg transition shadow cursor-pointer"
            >
              Salvar Mesas
            </button>
          </div>
        </div>

        {/* Configurations Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center bg-slate-950/40 p-4 border border-slate-850 rounded-xl">
          <div className="space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">
              Número Total de Mesas Disponíveis
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                min="1"
                max="100"
                value={mesasCount}
                onChange={(e) => handleMesasCountChange(parseInt(e.target.value) || 1)}
                className="w-24 bg-slate-950 border border-slate-800 text-slate-100 font-mono font-bold rounded-lg px-3 py-2 text-sm focus:border-yellow-400 outline-none"
              />
              <span className="text-2xs text-slate-400 italic">
                (Entre 1 e 100 mesas)
              </span>
            </div>
          </div>

          <div className="md:col-span-2 text-2xs text-slate-400 leading-normal flex items-start gap-2 bg-slate-900/50 p-3 rounded-lg border border-slate-800">
            <Info className="w-5 h-5 text-yellow-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-extrabold uppercase text-slate-300 block mb-0.5">Como Funciona:</span>
              Clique diretamente sobre qualquer mesa abaixo para alternar seu status de ocupação entre <strong className="text-emerald-400">Livre</strong> (azul) e <strong className="text-red-400">Ocupada</strong> (vermelho) instantaneamente. Clique no botão de salvar para registrar as modificações.
            </div>
          </div>
        </div>

        {/* Tables Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 pt-2">
          {mesasStatus.map(m => {
            const isBusy = m.status === 'ocupada';
            return (
              <div
                key={m.numero}
                onClick={() => toggleMesaStatus(m.numero)}
                className={`cursor-pointer group flex flex-col justify-between p-3 rounded-xl border transition-all duration-200 select-none ${
                  isBusy
                    ? 'bg-slate-950 border-red-900/30 hover:border-red-500/50 shadow-md shadow-red-900/10'
                    : 'bg-slate-950 border-slate-805 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-950/15'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-3xs uppercase tracking-widest text-slate-400 font-extrabold font-mono">
                    Mesa {m.numero}
                  </span>
                  <span className={`w-1.5 h-1.5 rounded-full ${isBusy ? 'bg-red-500 animate-pulse' : 'bg-emerald-400'}`} />
                </div>

                {/* Table Tennis visual diagram */}
                <div className={`w-full h-14 rounded-lg my-2 relative flex items-center justify-center transition-all ${
                  isBusy 
                    ? 'bg-red-850 border border-red-700' 
                    : 'bg-[#15468a] border border-[#2a68be]'
                }`}>
                  {/* Table lines */}
                  <div className="absolute inset-y-0 left-1/2 -translate-x-px w-px bg-white/30" />
                  
                  {/* Table net elements */}
                  <div className="absolute inset-x-0 top-1/2 -translate-y-px h-0.5 bg-slate-300 flex items-center justify-between px-0.5 pointer-events-none">
                    <span className="w-1 h-1.5 bg-slate-450 -mt-0.5 rounded-sm" />
                    <span className="w-1 h-1.5 bg-slate-450 -mt-0.5 rounded-sm" />
                  </div>

                  <span className="text-lg font-black text-white font-mono drop-shadow-md z-10 group-hover:scale-110 transition-transform">
                    {m.numero}
                  </span>
                </div>

                <div className="w-full flex justify-between items-center text-[10px] font-bold">
                  <span className={isBusy ? 'text-red-400' : 'text-emerald-400'}>
                    {m.status.toUpperCase()}
                  </span>
                  <span className="text-[9px] text-slate-500 font-medium group-hover:opacity-100 opacity-0 transition-opacity uppercase tracking-wider">
                    Trocar
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
}
