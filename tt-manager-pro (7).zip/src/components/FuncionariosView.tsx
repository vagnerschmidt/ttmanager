import React, { useState } from 'react';
import { Funcionario } from '../types';
import { Search, Plus, Edit, Trash2, Briefcase, Mail, Phone, Calendar, LayoutGrid, List, FileSpreadsheet, X, Save, Camera, Upload, MapPin, RefreshCw } from 'lucide-react';
import PhotoCaptureModal from './PhotoCaptureModal';
import DateInput from './DateInput';
import { normalizePhoneToBrazil } from '../utils/phone';
import { isValidCPF, formatCPF } from '../utils/cpf';

interface FuncionariosViewProps {
  funcionarios: Funcionario[];
  onSave: (funcionario: Funcionario) => void;
  onDelete: (id: string) => void;
  userRole?: string;
}

export default function FuncionariosView({ funcionarios, onSave, onDelete }: FuncionariosViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDepto, setFilterDepto] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCamOpen, setIsCamOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'pessoal' | 'profissional' | 'contato'>('pessoal');

  // Form states
  const [formId, setFormId] = useState('');
  const [formNome, setFormNome] = useState('');
  const [formNasc, setFormNasc] = useState('');
  const [formCpf, setFormCpf] = useState('');
  const [formGenero, setFormGenero] = useState('Masculino');
  const [formECivil, setFormECivil] = useState('Solteiro(a)');
  const [formCep, setFormCep] = useState('');
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [formEnd, setFormEnd] = useState('');
  const [formCargo, setFormCargo] = useState('');
  const [formDepto, setFormDepto] = useState('Administração');
  const [formAdmissao, setFormAdmissao] = useState('');
  const [formContrato, setFormContrato] = useState('CLT');
  const [formSalario, setFormSalario] = useState('0');
  const [formCh, setFormCh] = useState('');
  const [formCtps, setFormCtps] = useState('');
  const [formPis, setFormPis] = useState('');
  const [formStatus, setFormStatus] = useState('Ativo');
  const [formDemissao, setFormDemissao] = useState('');
  const [formObs, setFormObs] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formWa, setFormWa] = useState('');
  const [formTel, setFormTel] = useState('');
  const [formRamal, setFormRamal] = useState('');
  const [formEmerg, setFormEmerg] = useState('');
  const [formEmail2, setFormEmail2] = useState('');
  const [formFoto, setFormFoto] = useState('');

  const maskCpf = (val: string) => {
    return formatCPF(val);
  };

  const handleCepSearch = async (cepVal: string) => {
    const cleanCep = cepVal.replace(/\D/g, '').slice(0, 8);
    if (cleanCep.length !== 8) {
      alert("Por favor, digite um CEP válido com 8 dígitos.");
      return;
    }
    setIsSearchingCep(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await res.json();
      if (data.erro) {
        alert("CEP não encontrado no serviço ViaCEP.");
      } else {
        const logradouro = data.logradouro || '';
        const bairro = data.bairro || '';
        const cidade = data.localidade || '';
        const uf = data.uf || '';
        const cepFormatted = `${cleanCep.slice(0, 5)}-${cleanCep.slice(5)}`;
        
        const fullAddr = `${logradouro}${logradouro ? ', ' : ''}${bairro}${bairro ? ' - ' : ''}${cidade}${cidade ? '/' : ''}${uf} (CEP: ${cepFormatted})`;
        setFormEnd(fullAddr);
      }
    } catch (err) {
      console.error("Erro na busca de CEP:", err);
      alert("Erro ao consultar o CEP na API ViaCEP.");
    } finally {
      setIsSearchingCep(false);
    }
  };

  const handleCepChange = (val: string) => {
    let clean = val.replace(/\D/g, '').slice(0, 8);
    let formatted = clean;
    if (clean.length > 5) {
      formatted = `${clean.slice(0, 5)}-${clean.slice(5)}`;
    }
    setFormCep(formatted);

    if (clean.length === 8) {
      handleCepSearch(clean);
    }
  };

  const handleOpenModal = (f?: Funcionario) => {
    if (f) {
      setFormId(f.id);
      setFormNome(f.nome);
      setFormNasc(f.nasc || '');
      setFormCpf(f.cpf || '');
      setFormGenero(f.genero || 'Masculino');
      setFormECivil(f.ecivil || 'Solteiro(a)');
      setFormEnd(f.end || '');
      const extractedCep = (f.end || '').match(/\d{5}-\d{3}|\d{8}/)?.[0] || '';
      setFormCep(extractedCep);
      setFormCargo(f.cargo || '');
      setFormDepto(f.depto || 'Administração');
      setFormAdmissao(f.admissao || '');
      setFormContrato(f.contrato || 'CLT');
      setFormSalario(f.salario || '0');
      setFormCh(f.ch || '');
      setFormCtps(f.ctps || '');
      setFormPis(f.pis || '');
      setFormStatus(f.status || 'Ativo');
      setFormDemissao(f.demissao || '');
      setFormObs(f.obs || '');
      setFormEmail(f.email || '');
      setFormWa(f.wa || '');
      setFormTel(f.tel || '');
      setFormRamal(f.ramal || '');
      setFormEmerg(f.emerg || '');
      setFormEmail2(f.email2 || '');
      setFormFoto(f.foto || '');
    } else {
      setFormId('');
      setFormNome('');
      setFormNasc('');
      setFormCpf('');
      setFormGenero('Masculino');
      setFormECivil('Solteiro(a)');
      setFormEnd('');
      setFormCep('');
      setFormCargo('');
      setFormDepto('Administração');
      setFormAdmissao('');
      setFormContrato('CLT');
      setFormSalario('0');
      setFormCh('');
      setFormCtps('');
      setFormPis('');
      setFormStatus('Ativo');
      setFormDemissao('');
      setFormObs('');
      setFormEmail('');
      setFormWa('');
      setFormTel('');
      setFormRamal('');
      setFormEmerg('');
      setFormEmail2('');
      setFormFoto('');
    }
    setActiveTab('pessoal');
    setIsModalOpen(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (upEv) => {
        if (upEv.target?.result) {
          setFormFoto(upEv.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!formNome.trim()) {
      alert("Nome de funcionário é obrigatório!");
      return;
    }
    if (formCpf.trim() && !isValidCPF(formCpf)) {
      alert(`O CPF informado (${formCpf}) é inválido! Por favor, verifique os dígitos.`);
      return;
    }
    const targetId = formId || 'func_' + Date.now().toString(36);
    onSave({
      id: targetId,
      nome: formNome,
      nasc: formNasc,
      cpf: formCpf,
      rg: '',
      genero: formGenero,
      ecivil: formECivil,
      end: formEnd,
      cargo: formCargo,
      depto: formDepto,
      admissao: formAdmissao,
      contrato: formContrato,
      salario: formSalario,
      ch: formCh,
      ctps: formCtps,
      pis: formPis,
      status: formStatus,
      demissao: formDemissao,
      obs: formObs,
      email: formEmail,
      wa: normalizePhoneToBrazil(formWa),
      tel: normalizePhoneToBrazil(formTel),
      ramal: formRamal,
      emerg: formEmerg,
      email2: formEmail2,
      foto: formFoto
    });
    setIsModalOpen(false);
  };

  const filteredFuncionarios = funcionarios.filter(f => {
    const matchesSearch = f.nome.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (f.cargo && f.cargo.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (f.email && f.email.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDepto = !filterDepto || f.depto === filterDepto;
    const matchesStatus = !filterStatus || f.status === filterStatus;
    return matchesSearch && matchesDepto && matchesStatus;
  });

  return (
    <div className="space-y-6">
      
      {/* Search and filters bar */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:flex-1">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar equipe por nome, cargo, e-mail..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition"
            />
          </div>

          <select
            value={filterDepto}
            onChange={(e) => setFilterDepto(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todos departamentos</option>
            <option value="Administração">Administração</option>
            <option value="Técnico">Técnico</option>
            <option value="Arbitragem">Arbitragem</option>
            <option value="Comunicação">Comunicação</option>
            <option value="Manutenção">Manutenção</option>
            <option value="Segurança">Segurança</option>
            <option value="Limpeza">Limpeza</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todos status</option>
            <option value="Ativo">Ativo</option>
            <option value="Férias">Férias</option>
            <option value="Afastado">Afastado</option>
            <option value="Demitido">Demitido</option>
          </select>
        </div>

        {/* View mode toggle and add button */}
        <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
          <div className="flex bg-slate-950 p-1 border border-slate-800 rounded-lg shrink-0">
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-md transition ${viewMode === 'cards' ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'}`}
              title="Exibição em Cards"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md transition ${viewMode === 'table' ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'}`}
              title="Exibição em Tabela"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => handleOpenModal()}
            className="bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm flex items-center gap-2 cursor-pointer transition shadow-lg shrink-0"
          >
            <Plus className="w-4 h-4" />
            Novo Funcionário
          </button>
        </div>
      </div>

      {/* Main Container Views - toggled between table list or cards grid */}
      {viewMode === 'cards' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredFuncionarios.length > 0 ? (
            filteredFuncionarios.map((f) => (
              <div key={f.id} className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 transition p-5 rounded-xl flex flex-col justify-between shadow">
                
                {/* Header row */}
                <div className="flex items-start gap-3.5 mb-4">
                  {f.foto ? (
                    <img src={f.foto} className="w-12 h-12 rounded-full object-cover border border-slate-700 font-bold" alt={f.nome} />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-lg text-slate-300 shrink-0">
                      {f.nome[0].toUpperCase()}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-extrabold text-slate-100 truncate text-sm">{f.nome}</h4>
                    <p className="text-xs text-slate-400 truncate">{f.cargo || 'Funcionário'}</p>
                    <span className="inline-block mt-2 text-3xs font-extrabold uppercase bg-blue-500/10 text-blue-400 border border-blue-500/10 px-2 py-0.5 rounded">
                      {f.depto}
                    </span>
                  </div>
                  <span className={`text-4xs font-extrabold uppercase px-2 py-0.5 rounded-full ${
                    f.status === 'Ativo' ? 'bg-emerald-400/10 text-emerald-400' : 'bg-amber-400/10 text-amber-500'
                  }`}>
                    {f.status}
                  </span>
                </div>

                {/* Info Lines */}
                <div className="space-y-2 py-3 border-t border-slate-800/80 text-xs text-slate-300">
                  {f.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate">{f.email}</span>
                    </div>
                  )}
                  {f.wa && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-slate-500 shrink-0 font-mono" />
                      <span className="font-mono">{f.wa}</span>
                    </div>
                  )}
                  {f.admissao && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span>Admissão: {new Date(f.admissao + 'T12:00').toLocaleDateString('pt-BR')}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-2xs text-slate-500 uppercase font-extrabold tracking-wider bg-slate-950/20 px-2.5 py-1 rounded">
                    CONTRATO: {f.contrato || 'INDETERMINADO'}
                  </div>
                </div>

                {/* Act buttons row */}
                <div className="flex gap-2 border-t border-slate-800/50 pt-4 mt-2">
                  <button
                    onClick={() => handleOpenModal(f)}
                    className="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5"
                  >
                    <Edit className="w-3.5 h-3.5 text-slate-400" />
                    Editar
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Deseja mesmo remover "${f.nome}" da equipe?`)) {
                        onDelete(f.id);
                      }
                    }}
                    className="px-2.5 py-1.5 bg-red-500/5 hover:bg-red-500/10 text-red-400 border border-red-500/20 rounded-lg text-xs transition"
                    title="Excluir"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            ))
          ) : (
            <div className="col-span-full py-12 text-center text-slate-500 text-sm">
              Nenhum funcionário encontrado.
            </div>
          )}
        </div>
      ) : (
        /* TABLE LIST DISPLAY */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm text-slate-200">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/20 text-slate-400 text-2xs uppercase tracking-wider font-semibold">
                  <th className="py-3 px-4 w-12 text-center">#</th>
                  <th className="py-3 px-4">Funcionário</th>
                  <th className="py-3 px-4">Cargo / Função</th>
                  <th className="py-3 px-4">Departamento</th>
                  <th className="py-3 px-4">Tipo Contrato</th>
                  <th className="py-3 px-4">Data Admissão</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center w-28">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredFuncionarios.length > 0 ? (
                  filteredFuncionarios.map((f, i) => (
                    <tr key={f.id} className="hover:bg-slate-950/20 transition-colors">
                      <td className="py-3 px-4 text-center text-slate-500 font-mono text-xs">{i+1}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          {f.foto ? (
                            <img src={f.foto} className="w-8 h-8 rounded-full object-cover border border-slate-705 shrink-0" alt={f.nome} />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-705 flex items-center justify-center font-bold text-xs text-slate-350 shrink-0">
                              {f.nome[0].toUpperCase()}
                            </div>
                          )}
                          <div>
                            <div className="font-bold text-slate-100 text-sm">{f.nome}</div>
                            <div className="text-slate-400 text-2xs truncate max-w-[140px]">{f.email || 'sem email'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-200 font-medium">{f.cargo || '—'}</td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="text-2xs bg-blue-500/10 text-blue-400 border border-blue-500/10 px-2 py-0.5 rounded font-bold">
                          {f.depto}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-400 text-xs">{f.contrato || '—'}</td>
                      <td className="py-3 px-4 font-mono text-slate-400 text-xs">
                        {f.admissao ? new Date(f.admissao + 'T12:00').toLocaleDateString('pt-BR') : '—'}
                      </td>
                      <td className="py-3 px-4 text-center text-xs">
                        <span className={`text-2xs font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          f.status === 'Ativo' ? 'bg-emerald-400/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {f.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleOpenModal(f)}
                            className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-md transition"
                            title="Editar"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Deseja mesmo remover "${f.nome}"?`)) {
                                onDelete(f.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-md transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-500">
                      Nenhum funcionário encontrado.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STAFF DETAIL MODAL FORM */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl transition">
            
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-yellow-400" />
                {formId ? 'Editar Funcionário' : 'Novo Funcionário'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Forms body */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              
              {/* Form Tab selectors */}
              <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveTab('pessoal')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'pessoal' ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Dados Pessoais
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('profissional')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'profissional' ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Dados Profissionais
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('contato')}
                  className={`flex-1 py-1 px-3 text-xs font-semibold rounded-md transition ${
                    activeTab === 'contato' ? 'bg-yellow-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Contato / Emergência
                </button>
              </div>

              {/* TAB 1: DADOS PESSOAIS */}
              {activeTab === 'pessoal' && (
                <div className="space-y-4">
                  
                  {/* Photo details container */}
                  <div className="flex flex-col sm:flex-row gap-5 items-center bg-slate-950/20 p-4 border border-slate-850 rounded-xl">
                    <div className="relative w-24 h-30 border border-dashed border-slate-750 hover:border-yellow-400/85 rounded bg-slate-950 overflow-hidden shrink-0 group flex items-center justify-center">
                      {formFoto ? (
                        <>
                          <img src={formFoto} alt="Cap" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => setIsCamOpen(true)}
                              className="px-1.5 py-0.5 bg-yellow-400 text-slate-950 text-4xs font-black rounded"
                            >
                              Tirar
                            </button>
                            <button
                              type="button"
                              onClick={() => setFormFoto('')}
                              className="px-1.5 py-0.5 bg-red-600 text-white text-4xs font-black rounded"
                            >
                              Remover
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="text-slate-400 text-center flex flex-col items-center pointer-events-none">
                          <Camera className="w-5 h-5 mb-1" />
                          <span className="text-4xs uppercase tracking-wider font-extrabold">Foto</span>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => setIsCamOpen(true)}
                        className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                      >
                        <Camera className="w-4 h-4 text-slate-400" />
                        Tirar com câmera
                      </button>
                      <label className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer">
                        <Upload className="w-4 h-4 text-slate-400" />
                        Upload can
                        <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Nome Completo *</label>
                      <input
                        type="text"
                        placeholder="Nome completo do empregado"
                        value={formNome}
                        onChange={(e) => setFormNome(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100"
                      />
                    </div>
                    <DateInput
                      label="Data de Nascimento"
                      value={formNasc}
                      onChange={(val) => setFormNasc(val)}
                    />

                    <div className="col-span-1 sm:col-span-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Documento CPF *</label>
                        {formCpf.trim() && (
                          <span className={`text-4xs font-mono font-bold uppercase px-1.5 py-0.5 rounded ${
                            isValidCPF(formCpf) 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' 
                              : 'bg-rose-950 text-rose-400 border border-rose-800/40 animate-pulse'
                          }`}>
                            {isValidCPF(formCpf) ? '✓ CPF VÁLIDO' : '⚠️ CPF INVÁLIDO'}
                          </span>
                        )}
                      </div>
                      <input
                        type="text"
                        placeholder="000.000.000-00"
                        value={formCpf}
                        onChange={(e) => setFormCpf(maskCpf(e.target.value))}
                        className={`w-full bg-slate-950 border rounded-lg px-3 py-2 text-sm font-mono text-slate-100 ${
                          formCpf.trim() && !isValidCPF(formCpf) 
                            ? 'border-rose-500 focus:border-rose-400' 
                            : 'border-slate-800 focus:border-yellow-400'
                        }`}
                      />
                      {formCpf.trim() && !isValidCPF(formCpf) && (
                        <p className="text-3xs text-rose-400 font-semibold mt-0.5">
                          CPF com dígitos verificadores incorretos. Por favor, verifique o número digitado.
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Gênero</label>
                      <select
                        value={formGenero}
                        onChange={(e) => setFormGenero(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      >
                        <option value="Masculino">Masculino</option>
                        <option value="Feminino">Feminino</option>
                        <option value="Outro">Outro</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Estado Civil</label>
                      <select
                        value={formECivil}
                        onChange={(e) => setFormECivil(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      >
                        <option>Solteiro(a)</option>
                        <option>Casado(a)</option>
                        <option>Divorciado(a)</option>
                        <option>Viúvo(a)</option>
                        <option>União Estável</option>
                      </select>
                    </div>

                    {/* Address Lookup via CEP */}
                    <div className="col-span-1 sm:col-span-2 bg-slate-950/70 p-4 border border-slate-800/80 rounded-xl space-y-3 mt-1">
                      <div className="flex items-center justify-between">
                        <label className="text-2xs uppercase tracking-wider text-yellow-400 font-extrabold flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" /> Busca de Endereço por CEP
                        </label>
                        <span className="text-4xs text-slate-400">ViaCEP Automático</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="space-y-1">
                          <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Digitar CEP</label>
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              placeholder="00000-000"
                              value={formCep}
                              onChange={(e) => handleCepChange(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 focus:border-yellow-400 rounded-lg px-3 py-2 text-sm font-mono text-slate-100 outline-none transition"
                            />
                            <button
                              type="button"
                              onClick={() => handleCepSearch(formCep)}
                              disabled={isSearchingCep}
                              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-yellow-400 border border-slate-700 rounded-lg text-xs font-bold transition flex items-center gap-1 shrink-0 cursor-pointer disabled:opacity-50"
                              title="Buscar CEP na base ViaCEP"
                            >
                              {isSearchingCep ? (
                                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Search className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </div>

                        <div className="col-span-1 sm:col-span-2 space-y-1">
                          <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Endereço Encontrado / Completo</label>
                          <input
                            type="text"
                            placeholder="Rua, Bairro, Cidade/UF (Preenchido ao digitar o CEP)"
                            value={formEnd}
                            onChange={(e) => setFormEnd(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-800 focus:border-yellow-400 rounded-lg px-3 py-2 text-sm text-slate-100 outline-none transition"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: DADOS PROFISSIONAIS */}
              {activeTab === 'profissional' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Cargo / Função *</label>
                      <input
                        type="text"
                        placeholder="Ex: Supervisor Geral, Técnico, Auxiliar..."
                        value={formCargo}
                        onChange={(e) => setFormCargo(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Departamento</label>
                      <select
                        value={formDepto}
                        onChange={(e) => setFormDepto(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      >
                        <option>Administração</option>
                        <option>Técnico</option>
                        <option>Arbitragem</option>
                        <option>Comunicação</option>
                        <option>Manutenção</option>
                        <option>Segurança</option>
                        <option>Limpeza</option>
                      </select>
                    </div>

                    <DateInput
                      label="Data de Admissão"
                      value={formAdmissao}
                      onChange={(val) => setFormAdmissao(val)}
                    />
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Regime Contratual</label>
                      <select
                        value={formContrato}
                        onChange={(e) => setFormContrato(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      >
                        <option value="CLT">CLT</option>
                        <option value="PJ">PJ</option>
                        <option value="Temporário">Temporário</option>
                        <option value="Voluntário">Voluntário</option>
                        <option value="Estágio">Estágio</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Remuneração Base (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={formSalario}
                        onChange={(e) => setFormSalario(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono text-slate-100"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Carga Horária</label>
                      <input
                        type="text"
                        placeholder="Ex: 40h/semanas"
                        value={formCh}
                        onChange={(e) => setFormCh(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">CTPS / Série</label>
                      <input
                        type="text"
                        placeholder="Carteira de Trabalho"
                        value={formCtps}
                        onChange={(e) => setFormCtps(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold font-mono">PIS / PASEP</label>
                      <input
                        type="text"
                        placeholder="Número PIS/NIS"
                        value={formPis}
                        onChange={(e) => setFormPis(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Status Ocupacional</label>
                      <select
                        value={formStatus}
                        onChange={(e) => setFormStatus(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      >
                        <option value="Ativo">Ativo</option>
                        <option value="Férias">Férias</option>
                        <option value="Afastado">Afastado</option>
                        <option value="Demitido">Demitido</option>
                      </select>
                    </div>
                    <DateInput
                      label="Data de Demissão"
                      value={formDemissao}
                      onChange={(val) => setFormDemissao(val)}
                      disabled={formStatus !== 'Demitido'}
                    />

                    <div className="col-span-2 space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Observações Profissionais</label>
                      <textarea
                        rows={2}
                        placeholder="Habilidades adicionais, cursos específicos ou restrições..."
                        value={formObs}
                        onChange={(e) => setFormObs(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: CONTACTS */}
              {activeTab === 'contato' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">E-mail de Contato</label>
                      <input
                        type="email"
                        placeholder="nome@email.com"
                        value={formEmail}
                        onChange={(e) => setFormEmail(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">WhatsApp</label>
                      <input
                        type="text"
                        placeholder="+55 11 99999-9999"
                        value={formWa}
                        onChange={(e) => setFormWa(e.target.value)}
                        onBlur={() => setFormWa(prev => normalizePhoneToBrazil(prev))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono text-slate-100"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Telefone Fixo</label>
                      <input
                        type="text"
                        placeholder="(11) 3333-4444"
                        value={formTel}
                        onChange={(e) => setFormTel(e.target.value)}
                        onBlur={() => setFormTel(prev => normalizePhoneToBrazil(prev))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono text-slate-100"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Ramal</label>
                      <input
                        type="text"
                        placeholder="000"
                        value={formRamal}
                        onChange={(e) => setFormRamal(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm font-mono"
                      />
                    </div>

                    <div className="col-span-2 space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">E-mail Institucional</label>
                      <input
                        type="email"
                        placeholder="nome@organizacao.com.br"
                        value={formEmail2}
                        onChange={(e) => setFormEmail2(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>

                    <div className="col-span-2 space-y-1">
                      <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Contato de Emergência</label>
                      <input
                        type="text"
                        placeholder="Nome — parentesco — telefone de emergência"
                        value={formEmerg}
                        onChange={(e) => setFormEmerg(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950/25">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-755 text-xs font-bold rounded-lg transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black rounded-lg transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Funcionário
              </button>
            </div>

          </div>
        </div>
      )}

      {/* WEB CAMERA MODAL CAPTURER */}
      {isCamOpen && (
        <PhotoCaptureModal 
          onCapture={(dataUrl) => setFormFoto(dataUrl)}
          onClose={() => setIsCamOpen(false)}
        />
      )}

    </div>
  );
}
