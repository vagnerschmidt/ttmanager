import React, { useState } from 'react';
import { Torneio } from '../types';
import { Search, Plus, Edit, Trash2, Trophy, Save, X, Calendar, MapPin } from 'lucide-react';
import DateInput from './DateInput';

interface TorneiosViewProps {
  torneios: Torneio[];
  onSave: (torneio: Torneio) => void;
  onDelete: (id: string) => void;
  userRole?: 'comum' | 'admin' | 'master';
}

export default function TorneiosView({ torneios, onSave, onDelete, userRole = 'comum' }: TorneiosViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [formId, setFormId] = useState('');
  const [formNome, setFormNome] = useState('');
  const [formIni, setFormIni] = useState('');
  const [formFim, setFormFim] = useState('');
  const [formHora, setFormHora] = useState('08:00');
  const [formStatus, setFormStatus] = useState('Inscrições Abertas');
  const [formLocal, setFormLocal] = useState('');
  const [formCidade, setFormCidade] = useState('');
  const [formEnd, setFormEnd] = useState('');
  const [formFmt, setFormFmt] = useState('Eliminatória Simples');
  const [formTaxa, setFormTaxa] = useState('0');
  const [formLim, setFormLim] = useState('');
  const [formOrg, setFormOrg] = useState('');
  const [formCont, setFormCont] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formMesas, setFormMesas] = useState('4');
  const [formPixKey, setFormPixKey] = useState('');
  const [formSetsMax, setFormSetsMax] = useState('5');
  const [formSetsPoints, setFormSetsPoints] = useState('11');

  const handleOpenModal = (t?: Torneio) => {
    if (t) {
      setFormId(t.id);
      setFormNome(t.nome);
      setFormIni(t.ini);
      setFormFim(t.fim);
      setFormHora(t.hora || '08:00');
      setFormStatus(t.status);
      setFormLocal(t.local || '');
      setFormCidade(t.cidade || '');
      setFormEnd(t.end || '');
      setFormFmt(t.fmt || 'Eliminatória Simples');
      setFormTaxa(t.taxa || '0');
      setFormLim(t.lim || '');
      setFormOrg(t.org || '');
      setFormCont(t.cont || '');
      setFormDesc(t.desc || '');
      setFormMesas(t.mesas ? String(t.mesas) : '4');
      setFormPixKey(t.pixKey || '');
      setFormSetsMax(t.setsMax ? String(t.setsMax) : '5');
      setFormSetsPoints(t.setsPoints ? String(t.setsPoints) : '11');
    } else {
      setFormId('');
      setFormNome('');
      setFormIni('');
      setFormFim('');
      setFormHora('08:00');
      setFormStatus('Inscrições Abertas');
      setFormLocal('');
      setFormCidade('');
      setFormEnd('');
      setFormFmt('Eliminatória Simples');
      setFormTaxa('0');
      setFormLim('');
      setFormOrg('');
      setFormCont('');
      setFormDesc('');
      setFormMesas('4');
      setFormPixKey('');
      setFormSetsMax('5');
      setFormSetsPoints('11');
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formNome.trim()) {
      alert("Nome do torneio é obrigatório!");
      return;
    }
    if (!formIni) {
      alert("Data de início do torneio é obrigatória!");
      return;
    }
    const targetId = formId || 'tor_' + Date.now().toString(36);
    onSave({
      id: targetId,
      nome: formNome,
      ini: formIni,
      fim: formFim || formIni,
      hora: formHora,
      status: formStatus,
      local: formLocal,
      cidade: formCidade,
      end: formEnd,
      fmt: formFmt,
      taxa: formTaxa,
      lim: formLim,
      org: formOrg,
      cont: formCont,
      desc: formDesc,
      mesas: Number(formMesas) || 4,
      pixKey: formPixKey,
      setsMax: Number(formSetsMax) || 5,
      setsPoints: Number(formSetsPoints) || 11
    });
    setIsModalOpen(false);
  };

  const filteredTorneios = torneios.filter(t => {
    const matchesSearch = t.nome.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (t.cidade && t.cidade.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = !filterStatus || t.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Filters bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:flex-1">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar torneio por título ou cidade..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition"
            />
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition"
          >
            <option value="">Todos os status</option>
            <option value="Inscrições Abertas">Inscrições Abertas</option>
            <option value="Em Andamento">Em Andamento</option>
            <option value="Encerrado">Encerrado</option>
            <option value="Cancelado">Cancelado</option>
          </select>
        </div>

        {userRole !== 'comum' && (
          <button
            onClick={() => handleOpenModal()}
            className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0"
          >
            <Plus className="w-4 h-4" />
            Novo Torneio
          </button>
        )}
      </div>

      {/* Main List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm text-slate-200">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/20 text-slate-400 text-2xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Torneio / Regulador</th>
                <th className="py-3 px-4">Período de Realização</th>
                <th className="py-3 px-4 text-left">Local / Município</th>
                <th className="py-3 px-4 text-center">Mesas</th>
                <th className="py-3 px-4 text-center">Formato Chaveamento</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center w-28">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredTorneios.length > 0 ? (
                filteredTorneios.map((t, i) => (
                  <tr key={t.id} className="hover:bg-slate-950/20 transition-colors">
                    <td className="py-3.5 px-4 text-center text-slate-500 font-mono text-xs">{i+1}</td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-100">{t.nome}</div>
                      <div className="text-slate-400 text-xs">{t.org || 'Clube Organizador'}</div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-300">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>
                          {new Date(t.ini + 'T12:00').toLocaleDateString('pt-BR')} 
                          {t.fim && t.fim !== t.ini && ` a ${new Date(t.fim + 'T12:00').toLocaleDateString('pt-BR')}`}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 text-xs">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <div>
                          <span>{t.local || 'Sem local defined'}</span>
                          {t.cidade && <span className="block text-slate-500 font-semibold">{t.cidade}</span>}
                        </div>
                      </div>
                      {t.pixKey && (
                        <div className="mt-1 text-[10px] font-mono text-emerald-400 font-extrabold flex items-center gap-1" title="Chave Pix Ativa">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                          <span>Chave Pix: {t.pixKey}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center text-slate-150 font-mono text-xs">
                      {t.mesas || 4}
                    </td>
                    <td className="py-3.5 px-4 text-center text-slate-400 text-xs">
                      {t.fmt || 'Livre'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className={`text-2xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                        t.status === 'Em Andamento' 
                          ? 'bg-emerald-400/10 text-emerald-400' 
                          : t.status === 'Inscrições Abertas'
                          ? 'bg-blue-400/10 text-blue-400'
                          : t.status === 'Encerrado'
                          ? 'bg-slate-800 text-slate-400'
                          : 'bg-red-500/10 text-red-500'
                      }`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleOpenModal(t)}
                          className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-md transition"
                          title="Editar"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Deseja mesmo remover o torneio "${t.nome}"?`)) {
                              onDelete(t.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-md transition-colors"
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    Nenhum torneio registrado ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* TOURNAMENT FORM MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-xl overflow-hidden flex flex-col shadow-2xl">
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-yellow-400" />
                {formId ? 'Editar Torneio' : 'Novo Torneio'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form body */}
            <div className="p-6 overflow-y-auto space-y-4 max-h-[80vh]">
              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nome do Torneio *</label>
                <input
                  type="text"
                  placeholder="Ex: Aberto Paulista de TT 2025"
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <DateInput
                  label="Data Início"
                  required
                  value={formIni}
                  onChange={(val) => setFormIni(val)}
                />
                <DateInput
                  label="Data Término"
                  value={formFim}
                  onChange={(val) => setFormFim(val)}
                />

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Horário de Início</label>
                  <input
                    type="time"
                    value={formHora}
                    onChange={(e) => setFormHora(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Status Cadastral</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Inscrições Abertas">Inscrições Abertas</option>
                    <option value="Em Andamento">Em Andamento</option>
                    <option value="Encerrado">Encerrado</option>
                    <option value="Cancelado">Cancelado</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Local / Ginásio</label>
                  <input
                    type="text"
                    placeholder="Ginásio Municipal"
                    value={formLocal}
                    onChange={(e) => setFormLocal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Cidade — UF</label>
                  <input
                    type="text"
                    placeholder="São Paulo — SP"
                    value={formCidade}
                    onChange={(e) => setFormCidade(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  />
                </div>

                <div className="col-span-2 space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Logradouro / Endereço completo</label>
                  <input
                    type="text"
                    placeholder="Rua, número, bairro, CEP..."
                    value={formEnd}
                    onChange={(e) => setFormEnd(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Modelo Chaveamento Geral</label>
                  <select
                    value={formFmt}
                    onChange={(e) => setFormFmt(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Eliminatória Simples">Eliminatória Simples</option>
                    <option value="Dupla Eliminação">Dupla Eliminação</option>
                    <option value="Round Robin">Round Robin</option>
                    <option value="Grupos + Eliminatória">Grupos + Eliminatória</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Taxa de Inscrição (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formTaxa}
                    onChange={(e) => setFormTaxa(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Lotação Limite Inscrições</label>
                  <input
                    type="number"
                    placeholder="Sem limite"
                    value={formLim}
                    onChange={(e) => setFormLim(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Quantidade de Mesas</label>
                  <input
                    type="number"
                    min="1"
                    placeholder="Ex: 4"
                    value={formMesas}
                    onChange={(e) => setFormMesas(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="col-span-2 grid grid-cols-2 gap-4 border-t border-b border-slate-800/60 py-3 my-1">
                  <div className="space-y-1">
                    <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Regra de Sets (Melhor de...)</label>
                    <select
                      value={formSetsMax}
                      onChange={(e) => setFormSetsMax(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                    >
                      <option value="3">Melhor de 3 (vence 2 sets)</option>
                      <option value="5">Melhor de 5 (vence 3 sets)</option>
                      <option value="7">Melhor de 7 (vence 4 sets)</option>
                      <option value="9">Melhor de 9 (vence 5 sets)</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Pontuação do Set</label>
                    <select
                      value={formSetsPoints}
                      onChange={(e) => setFormSetsPoints(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                    >
                      <option value="11">11 pontos (Padrão Oficial)</option>
                      <option value="21">21 pontos (Clássico/Antigo)</option>
                      <option value="15">15 pontos</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Entidade Organizadora</label>
                  <input
                    type="text"
                    placeholder="Federação ou Clube Executivo"
                    value={formOrg}
                    onChange={(e) => setFormOrg(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  />
                </div>

                <div className="col-span-2 space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Meios de Contato</label>
                  <input
                    type="text"
                    placeholder="Telefone / e-mail de contato oficial"
                    value={formCont}
                    onChange={(e) => setFormCont(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  />
                </div>

                <div className="col-span-2 space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block text-emerald-400">Chave Pix do Torneio para Recebimento de Taxas</label>
                  <input
                    type="text"
                    placeholder="Ex: CNPJ, Celular, E-mail, ou Chave Aleatória"
                    value={formPixKey}
                    onChange={(e) => setFormPixKey(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-emerald-300 focus:border-emerald-400 outline-none font-bold"
                  />
                  <p className="text-[10px] text-slate-450 leading-normal pl-0.5 mt-0.5">
                    Insira a chave Pix ativa de recebimento de inscrições. Quando os atletas realizarem as inscrições, esta chave será usada para gerar o QR Code em tempo real!
                  </p>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Descrição & Regulamento</label>
                <textarea
                  rows={3}
                  placeholder="Premiações, horários de vistorias, regras de tolerância, etc..."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none resize-none"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950/25">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-755 text-xs font-bold rounded-lg transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black rounded-lg transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Torneio
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
