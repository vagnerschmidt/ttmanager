import React, { useState, useEffect } from 'react';
import { 
  Rocket, 
  CheckCircle2, 
  RefreshCw, 
  X, 
  Cloud, 
  Database, 
  Server, 
  Sparkles, 
  Home, 
  ShieldCheck,
  Zap,
  Globe
} from 'lucide-react';
import { uploadStateToFirebase, FullSystemState } from '../lib/firebase';
import { triggerToast } from '../utils/toast';

interface AutoDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentState: FullSystemState;
}

export default function AutoDeployModal({
  isOpen,
  onClose,
  currentState
}: AutoDeployModalProps) {
  const [deploying, setDeploying] = useState(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [completed, setCompleted] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Escape key handler to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const handleRunAutoDeploy = async () => {
    setDeploying(true);
    setCompleted(false);
    setErrorMsg(null);
    setCurrentStep(1);

    try {
      // Step 1: Prepare payload
      await new Promise(r => setTimeout(r, 600));
      setCurrentStep(2);

      // Step 2: Upload to Firebase Firestore
      await uploadStateToFirebase(currentState);
      const nowStr = new Date().toLocaleString('pt-BR');
      localStorage.setItem('ttmpro_firebase_last_sync', nowStr);
      await new Promise(r => setTimeout(r, 800));
      setCurrentStep(3);

      // Step 3: Trigger Vercel & Edge Sync API
      try {
        await fetch('/api/vercel-sync');
      } catch (e) {
        console.warn('Vercel sync ping notice:', e);
      }
      await new Promise(r => setTimeout(r, 600));
      setCurrentStep(4);

      setCompleted(true);
      triggerToast('🚀 DEPLOY AUTOMÁTICO de Atualizações concluído com Sucesso!', 'success');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Erro durante a execução do Deploy Automático.');
      triggerToast('Falha no Deploy Automático: ' + (err.message || err), 'error');
    } finally {
      setDeploying(false);
    }
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-r from-yellow-500/10 via-emerald-500/10 to-cyan-500/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-gradient-to-br from-yellow-400 to-amber-500 rounded-xl flex items-center justify-center text-slate-950 font-black shadow-md shadow-yellow-500/20 shrink-0">
              <Rocket className="w-4 h-4 sm:w-4.5 sm:h-4.5 animate-bounce" />
            </div>
            <div>
              <h3 className="font-black text-slate-100 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                Deploy Automático de Atualizações 🚀
              </h3>
              <p className="text-[10px] text-slate-400 font-medium">
                Publicação instantânea do banco de dados na Nuvem Firebase e Vercel
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-100 rounded-lg transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5 flex-1 overflow-y-auto">
          {/* Main Action Banner */}
          {!deploying && !completed && !errorMsg && (
            <div className="bg-slate-950/60 border border-yellow-500/30 p-4 sm:p-5 rounded-2xl space-y-3.5 text-center">
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-yellow-400/10 border border-yellow-400/30 rounded-xl flex items-center justify-center mx-auto text-yellow-400 shrink-0">
                <Sparkles className="w-5 h-5 sm:w-5.5 sm:h-5.5" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-black text-slate-100 uppercase tracking-wider">
                  Pronto para Publicar Novas Atualizações!
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed font-medium">
                  Este comando irá consolidar todas as alterações de atletas, chaves por idade, torneios e tabelas, enviando-as instantaneamente para o banco de dados Firebase e servidores em nuvem.
                </p>
              </div>

              <button
                onClick={handleRunAutoDeploy}
                className="w-full py-3.5 bg-gradient-to-r from-yellow-400 via-amber-400 to-yellow-500 hover:from-yellow-300 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-widest rounded-xl transition cursor-pointer shadow-xl shadow-yellow-500/20 flex items-center justify-center gap-2 group"
              >
                <Rocket className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                Executar Deploy Automático Agora 🚀
              </button>
            </div>
          )}

          {/* Progress Steps Display */}
          {(deploying || completed || currentStep > 0) && (
            <div className="space-y-4">
              <h5 className="text-3xs uppercase font-black tracking-widest text-slate-400">
                PROGRESSO DO DEPLOY AUTOMÁTICO:
              </h5>

              <div className="space-y-3">
                {/* Step 1 */}
                <div className={`p-3 rounded-xl border transition flex items-center justify-between ${
                  currentStep > 1 
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                    : currentStep === 1 
                    ? 'bg-yellow-500/10 border-yellow-500/40 text-yellow-400 animate-pulse' 
                    : 'bg-slate-950/40 border-slate-850 text-slate-500'
                }`}>
                  <div className="flex items-center gap-2.5 text-xs font-bold">
                    {currentStep > 1 ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <RefreshCw className={`w-4 h-4 shrink-0 ${currentStep === 1 ? 'animate-spin' : ''}`} />}
                    <span>1. Consolidação de Atletas, Chaves e Dados Locais</span>
                  </div>
                  {currentStep > 1 && <span className="text-4xs font-mono font-black uppercase text-emerald-400">OK</span>}
                </div>

                {/* Step 2 */}
                <div className={`p-3 rounded-xl border transition flex items-center justify-between ${
                  currentStep > 2 
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                    : currentStep === 2 
                    ? 'bg-yellow-500/10 border-yellow-500/40 text-yellow-400 animate-pulse' 
                    : 'bg-slate-950/40 border-slate-850 text-slate-500'
                }`}>
                  <div className="flex items-center gap-2.5 text-xs font-bold">
                    {currentStep > 2 ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <Cloud className={`w-4 h-4 shrink-0 ${currentStep === 2 ? 'animate-bounce' : ''}`} />}
                    <span>2. Sincronização no Banco Firebase Firestore</span>
                  </div>
                  {currentStep > 2 && <span className="text-4xs font-mono font-black uppercase text-emerald-400">OK</span>}
                </div>

                {/* Step 3 */}
                <div className={`p-3 rounded-xl border transition flex items-center justify-between ${
                  currentStep > 3 
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                    : currentStep === 3 
                    ? 'bg-yellow-500/10 border-yellow-500/40 text-yellow-400 animate-pulse' 
                    : 'bg-slate-950/40 border-slate-850 text-slate-500'
                }`}>
                  <div className="flex items-center gap-2.5 text-xs font-bold">
                    {currentStep > 3 ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <Server className={`w-4 h-4 shrink-0 ${currentStep === 3 ? 'animate-pulse' : ''}`} />}
                    <span>3. Atualização de Endpoints Vercel & GitHub</span>
                  </div>
                  {currentStep > 3 && <span className="text-4xs font-mono font-black uppercase text-emerald-400">OK</span>}
                </div>
              </div>
            </div>
          )}

          {/* Success Summary */}
          {completed && (
            <div className="bg-emerald-950/80 border border-emerald-500/50 p-4 rounded-xl text-center space-y-3 animate-fade-in">
              <div className="flex items-center justify-center gap-2 text-emerald-400 font-black text-sm uppercase">
                <CheckCircle2 className="w-5 h-5" /> DEPLOY CONCLUÍDO COM SUCESSO!
              </div>
              <p className="text-xs text-emerald-200/90 font-medium">
                Todas as atualizações do sistema foram publicadas e sincronizadas com a nuvem Firebase e serviços associados.
              </p>
            </div>
          )}

          {/* Error Notice */}
          {errorMsg && (
            <div className="bg-rose-950/80 border border-rose-500/50 p-4 rounded-xl text-center space-y-2 text-rose-300 text-xs font-bold">
              <div>⚠️ Falha no Deploy Automático</div>
              <div className="font-mono text-4xs text-rose-200">{errorMsg}</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Sua aplicação está rodando em ambiente seguro.</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-2 cursor-pointer shadow-lg"
          >
            <Home className="w-4 h-4" />
            Concluir & Voltar ao Menu Principal
          </button>
        </div>
      </div>
    </div>
  );
}
