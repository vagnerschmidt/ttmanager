import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  Database, 
  GitCommit, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  RefreshCw, 
  Zap, 
  HardDrive, 
  Github, 
  Server, 
  Check, 
  Sparkles,
  ShieldCheck,
  Globe,
  Rocket,
  FolderUp,
  Clock,
  ExternalLink,
  FileSpreadsheet
} from 'lucide-react';
import { triggerToast } from '../utils/toast';
import firebaseConfig from '../../firebase-applet-config.json';
import { 
  getDriveSettings, 
  saveDriveSettings, 
  requestDriveAccessToken, 
  uploadBackupToDrive,
  DriveBackupSettings 
} from '../utils/googleDrive';
import { getGoogleSheetsSettings, GoogleSheetsSettings } from '../utils/googleSheets';

interface CloudIntegrationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  autoSyncFirebase: boolean;
  onToggleAutoSyncFirebase: (enabled: boolean) => void;
  onOpenAutoDeploy?: () => void;
  getCurrentPayload?: () => any;
}

export default function CloudIntegrationsModal({
  isOpen,
  onClose,
  autoSyncFirebase,
  onToggleAutoSyncFirebase,
  onOpenAutoDeploy,
  getCurrentPayload
}: CloudIntegrationsModalProps) {
  const [testingVercel, setTestingVercel] = useState(false);
  const [vercelResult, setVercelResult] = useState<any>(null);

  // Google Drive state
  const [driveSettings, setDriveSettings] = useState<DriveBackupSettings>(getDriveSettings);
  const [isUploadingDrive, setIsUploadingDrive] = useState(false);
  const [driveMessage, setDriveMessage] = useState<string | null>(null);

  // Sync drive settings on open
  useEffect(() => {
    if (isOpen) {
      setDriveSettings(getDriveSettings());
    }
  }, [isOpen]);

  // Escape key handler to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  const handleToggleDriveAuto = (enabled: boolean) => {
    saveDriveSettings({ autoBackupEnabled: enabled });
    setDriveSettings(getDriveSettings());
    triggerToast(
      enabled
        ? `Backup automático no Google Drive ativado (Intervalo: a cada ${driveSettings.intervalHours}h)!`
        : 'Backup automático no Google Drive desativado.',
      enabled ? 'success' : 'info'
    );
  };

  const handleChangeInterval = (hours: number) => {
    saveDriveSettings({ intervalHours: hours });
    setDriveSettings(getDriveSettings());
    triggerToast(`Intervalo de backup atualizado para a cada ${hours} horas!`, 'info');
  };

  const handleManualDriveBackup = async () => {
    setIsUploadingDrive(true);
    setDriveMessage(null);

    try {
      let token = driveSettings.accessToken;
      const now = Date.now();

      // If token is missing or expired, request new token via OAuth popup
      if (!token || !driveSettings.tokenExpiresAt || driveSettings.tokenExpiresAt < now + 60000) {
        triggerToast('Solicitando autorização segura do Google Drive...', 'info');
        token = await requestDriveAccessToken();
      }

      const payload = getCurrentPayload ? getCurrentPayload() : {};
      const res = await uploadBackupToDrive(payload, token);

      const msg = `Backup enviado com sucesso para o Google Drive! Arquivo: ${res.name}`;
      setDriveMessage(msg);
      setDriveSettings(getDriveSettings());
      triggerToast(msg, 'success');
    } catch (err: any) {
      console.warn('Google Drive Backup Notice:', err);
      const errMsg = err?.message || 'Falha ao realizar backup no Google Drive.';
      const isClosedErr = errMsg.toLowerCase().includes('fechada') || 
                          errMsg.toLowerCase().includes('closed') || 
                          errMsg.toLowerCase().includes('cancelad') ||
                          errMsg.toLowerCase().includes('popup');

      if (isClosedErr) {
        setDriveMessage('Autorização pendente: A janela de login do Google Drive foi fechada.');
        triggerToast('Janela de autorização do Google fechada. Tente novamente quando desejar autorizar.', 'warning');
      } else {
        setDriveMessage(`Erro: ${errMsg}`);
        triggerToast(errMsg, 'error');
      }
    } finally {
      setIsUploadingDrive(false);
    }
  };

  const handleTestVercelSync = async () => {
    setTestingVercel(true);
    try {
      const res = await fetch('/api/vercel-sync');
      const data = await res.json();
      setVercelResult(data);
      if (data.success) {
        triggerToast('API Vercel Sync respondendo com sucesso (200 OK)!', 'success');
      } else {
        triggerToast('Vercel API offline ou resposta com erro', 'warning');
      }
    } catch (err: any) {
      console.error(err);
      triggerToast('Falha na requisição para /api/vercel-sync: ' + (err.message || err), 'error');
    } finally {
      setTestingVercel(false);
    }
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-r from-yellow-500/10 via-cyan-500/10 to-purple-500/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-yellow-400/10 rounded-xl flex items-center justify-center border border-yellow-400/20 text-yellow-400 shrink-0">
              <Zap className="w-4 h-4 sm:w-4.5 sm:h-4.5 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-100 text-xs sm:text-sm uppercase tracking-wider">
                  Nuvem & Banco de Dados Integrados ⚡
                </h3>
                <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-1.5 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> ONLINE
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">
                Conexões ativas com Firebase Firestore, Vercel Database e GitHub Repository
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-100 rounded-lg transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 flex-1 overflow-y-auto">
          
          {/* Card 0: IndexedDB Local Offline Persistence */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-blue-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    IndexedDB (Persistência Local & Offline) 💾
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Engine: HTML5 IndexedDB | Fila de Árbitros & Placares Garantidos
                  </span>
                </div>
              </div>
              <span className="bg-blue-500/10 text-blue-400 border border-blue-500/30 text-4xs font-black uppercase px-2.5 py-1 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-blue-400" /> Ativo & Resiliente
              </span>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              O sistema utiliza banco de dados <code className="text-blue-300 bg-slate-900 px-1 py-0.5 rounded font-mono">IndexedDB</code> de alta capacidade no navegador. Em caso de queda de sinal de internet, as alterações na fila de árbitros, convocações e placares são armazenadas localmente e sincronizadas automaticamente com o Firebase assim que a conexão é reestabelecida.
            </p>
          </div>

          {/* Card 1: Firebase Cloud Firestore */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-yellow-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 flex items-center justify-center">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Firebase Cloud Database (Firestore)
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    ID: {firebaseConfig.projectId}
                  </span>
                </div>
              </div>
              <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-400/30 text-4xs font-black uppercase px-2 py-1 rounded flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-yellow-400" /> Ativo & Conectado
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-3xs pt-1 border-t border-slate-850">
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Região / Servidor:</span>
                <span className="text-slate-200 font-mono font-bold">us-east1 (Cloud Run)</span>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Modo Auto-Save:</span>
                <span className={autoSyncFirebase ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                  {autoSyncFirebase ? "⚡ Ativado (Realtime)" : "⏸️ Manual"}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-3xs text-slate-400">Ativar sincronização automática em tempo real:</span>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input 
                  type="checkbox" 
                  checked={autoSyncFirebase} 
                  onChange={(e) => onToggleAutoSyncFirebase(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-yellow-400 peer-checked:after:bg-slate-950"></div>
              </label>
            </div>
          </div>

          {/* Card 1.5: Google Drive Automated Periodic Backup */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-emerald-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-400/10 border border-emerald-400/30 text-emerald-400 flex items-center justify-center">
                  <FolderUp className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Google Drive (Backup Automático Periódico) 📁
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Redundância e exportação periódica de segurança em nuvem (JSON)
                  </span>
                </div>
              </div>
              <span className={`border text-4xs font-black uppercase px-2 py-1 rounded flex items-center gap-1 ${
                driveSettings.autoBackupEnabled 
                  ? 'bg-emerald-400/10 text-emerald-400 border-emerald-400/30' 
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                <Clock className="w-3 h-3" />
                {driveSettings.autoBackupEnabled ? `Ativado (a cada ${driveSettings.intervalHours}h)` : 'Desativado'}
              </span>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              Exporta automaticamente uma cópia completa de redundância do banco de dados do TT Manager Pro para o seu Google Drive na frequência desejada (ex: a cada 24 horas), garantindo imunidade a falhas de dispositivos e perda de dados.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-3xs pt-1 border-t border-slate-850">
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Último Backup:</span>
                <span className="text-slate-200 font-mono font-bold">
                  {driveSettings.lastBackupTime ? new Date(driveSettings.lastBackupTime).toLocaleString('pt-BR') : 'Nenhum realizado'}
                </span>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Status do Backup:</span>
                <span className={driveSettings.lastBackupStatus === 'Sucesso' ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                  {driveSettings.lastBackupStatus || 'Pronto'}
                </span>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Frequência da Cópia:</span>
                <div className="flex items-center gap-1 mt-0.5">
                  {[6, 12, 24, 48].map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => handleChangeInterval(h)}
                      className={`px-1.5 py-0.5 rounded text-4xs font-bold font-mono transition cursor-pointer ${
                        driveSettings.intervalHours === h
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      {h}h
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {driveMessage && (
              <div className={`p-2.5 rounded-lg border text-3xs font-mono ${
                driveMessage.startsWith('Erro')
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}>
                {driveMessage}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-850">
              <div className="flex items-center gap-2">
                <span className="text-3xs text-slate-400">Ativar Backup Automático no Google Drive:</span>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={driveSettings.autoBackupEnabled} 
                    onChange={(e) => handleToggleDriveAuto(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-400 peer-checked:after:bg-slate-950"></div>
                </label>
              </div>

              <button
                type="button"
                onClick={handleManualDriveBackup}
                disabled={isUploadingDrive}
                className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-4xs font-black uppercase px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50 active:scale-95 shadow-sm"
              >
                {isUploadingDrive ? <RefreshCw className="w-3 h-3 animate-spin text-emerald-400" /> : <FolderUp className="w-3 h-3 text-emerald-400" />}
                {isUploadingDrive ? 'Enviando ao Drive...' : 'Fazer Backup Agora no Drive 📁'}
              </button>
            </div>
          </div>

          {/* Card 2: Vercel Serverless Sync API & Vercel DB */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-cyan-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-cyan-400/10 border border-cyan-400/30 text-cyan-400 flex items-center justify-center">
                  <Server className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Vercel Cron & Database Sync API
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Endpoint: /api/vercel-sync | Schedule: Cron Horário (0 */1 * * *)
                  </span>
                </div>
              </div>
              <button
                onClick={handleTestVercelSync}
                disabled={testingVercel}
                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/40 text-4xs font-black uppercase px-2.5 py-1 rounded flex items-center gap-1 transition cursor-pointer disabled:opacity-50"
              >
                {testingVercel ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                {testingVercel ? 'Testando...' : 'Testar Sync Vercel'}
              </button>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              Serviço Serverless e Cron Job configurados no arquivo <code className="text-cyan-300 bg-slate-900 px-1 py-0.5 rounded font-mono">vercel.json</code> para sincronização periódica automatizada e compatibilidade total com Vercel Postgres e Edge Functions.
            </p>

            {vercelResult && (
              <div className="bg-slate-900 p-2.5 rounded-lg border border-cyan-500/30 text-3xs space-y-1 font-mono">
                <div className="text-cyan-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Resposta da Vercel API:
                </div>
                <div className="text-slate-300">Mensagem: {vercelResult.message}</div>
                <div className="text-slate-400">Ambiente: {vercelResult.environment}</div>
                <div className="text-slate-500 text-4xs">Timestamp: {vercelResult.timestamp}</div>
              </div>
            )}
          </div>

          {/* Card 3: Netlify Free Hosting & Continuous Deployment */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-teal-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-teal-400/10 border border-teal-400/30 text-teal-400 flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Netlify (Hospedagem Gratuita Direct Link) 🌐
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Build: npm run build | Pasta: dist | Redirects: netlify.toml
                  </span>
                </div>
              </div>
              <a
                href="https://app.netlify.com/start"
                target="_blank"
                rel="noreferrer"
                className="bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-4xs font-black uppercase px-2.5 py-1 rounded flex items-center gap-1 transition cursor-pointer"
              >
                <Rocket className="w-3 h-3 text-teal-400" />
                Conectar ao Netlify
              </a>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              O projeto já conta com arquivo <code className="text-teal-300 bg-slate-900 px-1 py-0.5 rounded font-mono">netlify.toml</code> pré-configurado e workflow do GitHub Actions (<code className="text-teal-300 bg-slate-900 px-1 py-0.5 rounded font-mono">deploy-netlify.yml</code>) para publicação direta, rápida e 100% gratuita.
            </p>
          </div>

          {/* Card 4: HostGator Paid Hosting (cPanel / Apache) */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-amber-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400/10 border border-amber-400/30 text-amber-400 flex items-center justify-center">
                  <HardDrive className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    HostGator (Hospedagem Paga cPanel) 🌐
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Build: npm run build | Apache Rewrite: .htaccess | Destino: public_html
                  </span>
                </div>
              </div>
              <span className="bg-amber-400/10 text-amber-400 border border-amber-400/30 text-4xs font-black uppercase px-2.5 py-1 rounded flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" /> Pronto cPanel
              </span>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              O projeto já está 100% preparado para servidores de hospedagem paga da HostGator. Um arquivo de redirecionamento <code className="text-amber-300 bg-slate-900 px-1 py-0.5 rounded font-mono">.htaccess</code> para evitar erros de rotas 404 e o manual de instrução <code className="text-amber-300 bg-slate-900 px-1 py-0.5 rounded font-mono">HOSTGATOR_DEPLOY.md</code> foram adicionados ao seu código-fonte para sua comodidade.
            </p>
          </div>

          {/* Card 5: GitHub Integration */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-purple-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-purple-400/10 border border-purple-400/30 text-purple-400 flex items-center justify-center">
                  <Github className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider">
                    Sincronização & Repositório GitHub
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Estrutura de código e deploys automatizados em sintonia com o Git
                  </span>
                </div>
              </div>
              <span className="bg-purple-400/10 text-purple-400 border border-purple-400/30 text-4xs font-black uppercase px-2 py-1 rounded flex items-center gap-1">
                <GitCommit className="w-3 h-3 text-purple-400" /> Prontidão Git
              </span>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              O projeto possui arquitetura completa com type checks estritos, scripts de build CJS/ESM otimizados e suporte para importação/exportação direta no GitHub ou download do código-fonte limpo via menu de exportação do sistema.
            </p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-3 text-3xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Ícones inteligentes ativos • Dados seguros e autenticados</span>
          </div>
          <div className="flex items-center gap-2">
            {onOpenAutoDeploy && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAutoDeploy();
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-lg text-xs tracking-wider uppercase transition cursor-pointer flex items-center gap-1.5 shadow"
              >
                <Rocket className="w-3.5 h-3.5" />
                Deploy Automático 🚀
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black rounded-lg text-xs tracking-wider uppercase transition cursor-pointer flex items-center gap-1.5 shadow"
            >
              Concluir & Voltar ao Menu Principal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
