import React, { useState } from 'react';
import { Categoria } from '../types';
import { Search, Plus, Edit, Trash2, Tag, Save, X, Zap } from 'lucide-react';

interface CategoriasViewProps {
  categorias: Categoria[];
  onSave: (categoria: Categoria) => void;
  onSaveMultiple?: (categorias: Categoria[]) => void;
  onDelete: (id: string) => void;
  userRole?: 'comum' | 'admin' | 'master';
}

export default function CategoriasView({ categorias, onSave, onSaveMultiple, onDelete, userRole = 'comum' }: CategoriasViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAutoGenerateAgeCategories = () => {
    if (!onSaveMultiple) {
      alert("Operação em lote não suportada pelo componente pai.");
      return;
    }
    const confirmGen = confirm(
      "Deseja gerar automaticamente as categorias oficiais de jogo de acordo com as faixas de idade (Sub-9 a Veteranos)? Categorias existentes com o mesmo nome serão preservadas."
    );
    if (!confirmGen) return;

    const agePresets = [
      { nome: 'Sub-9 Geral', idmin: '0', idmax: '9', desc: 'Atletas com idade de até 9 anos completos.' },
      { nome: 'Sub-11 Geral', idmin: '10', idmax: '11', desc: 'Atletas com idade entre 10 e 11 anos completos.' },
      { nome: 'Sub-13 Geral', idmin: '12', idmax: '13', desc: 'Atletas com idade entre 12 e 13 anos completos.' },
      { nome: 'Sub-15 Geral', idmin: '14', idmax: '15', desc: 'Atletas com idade entre 14 e 15 anos completos.' },
      { nome: 'Sub-17 Geral', idmin: '16', idmax: '17', desc: 'Atletas com idade entre 16 e 17 anos completos.' },
      { nome: 'Sub-19 Geral', idmin: '18', idmax: '19', desc: 'Atletas com idade entre 18 e 19 anos completos.' },
      { nome: 'Sub-21 Geral', idmin: '20', idmax: '21', desc: 'Atletas com idade entre 20 e 21 anos completos.' },
      { nome: 'Adulto Geral', idmin: '22', idmax: '39', desc: 'Atletas na faixa etária adulta geral de 22 a 39 anos.' },
      { nome: 'Veterano +40', idmin: '40', idmax: '49', desc: 'Atletas veteranos com idade entre 40 e 49 anos.' },
      { nome: 'Veterano +50', idmin: '50', idmax: '59', desc: 'Atletas veteranos com idade entre 50 e 59 anos.' },
      { nome: 'Veterano +60', idmin: '60', idmax: '69', desc: 'Atletas veteranos com idade entre 60 e 69 anos.' },
      { nome: 'Veterano +70', idmin: '70', idmax: '99', desc: 'Atletas veteranos com idade de 70 anos em diante.' },
    ];

    const toSave: Categoria[] = agePresets.map((preset, idx) => {
      const existing = categorias.find(c => c.nome.toLowerCase() === preset.nome.toLowerCase());
      return {
        id: existing?.id || `cat_age_${idx}_` + Date.now().toString(36),
        nome: preset.nome,
        tipo: 'Simples',
        genero: 'Livre',
        idmin: preset.idmin,
        idmax: preset.idmax,
        rmin: '0',
        rmax: '9999',
        fmt: 'Grupos + Eliminatória',
        max: '',
        desc: preset.desc
      };
    });

    onSaveMultiple(toSave);
    alert(`${toSave.length} Categorias oficiais por idade geradas/atualizadas com sucesso no sistema!`);
  };

  // Form State
  const [formId, setFormId] = useState('');
  const [formNome, setFormNome] = useState('');
  const [formTipo, setFormTipo] = useState('Simples');
  const [formGenero, setFormGenero] = useState('Masculino');
  const [formIdMin, setFormIdMin] = useState('0');
  const [formIdMax, setFormIdMax] = useState('99');
  const [formRMin, setFormRMin] = useState('0');
  const [formRMax, setFormRMax] = useState('9999');
  const [formFmt, setFormFmt] = useState('Eliminatória Simples');
  const [formMax, setFormMax] = useState('');
  const [formDesc, setFormDesc] = useState('');

  const handleOpenModal = (c?: Categoria) => {
    if (c) {
      setFormId(c.id);
      setFormNome(c.nome);
      setFormTipo(c.tipo);
      setFormGenero(c.genero);
      setFormIdMin(c.idmin || '0');
      setFormIdMax(c.idmax || '99');
      setFormRMin(c.rmin || '0');
      setFormRMax(c.rmax || '9999');
      setFormFmt(c.fmt);
      setFormMax(c.max || '');
      setFormDesc(c.desc || '');
    } else {
      setFormId('');
      setFormNome('');
      setFormTipo('Simples');
      setFormGenero('Masculino');
      setFormIdMin('0');
      setFormIdMax('99');
      setFormRMin('0');
      setFormRMax('9999');
      setFormFmt('Eliminatória Simples');
      setFormMax('');
      setFormDesc('');
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formNome.trim()) {
      alert("Nome de categoria é obrigatório!");
      return;
    }
    const targetId = formId || 'cat_' + Date.now().toString(36);
    onSave({
      id: targetId,
      nome: formNome,
      tipo: formTipo,
      genero: formGenero,
      idmin: formIdMin,
      idmax: formIdMax,
      rmin: formRMin,
      rmax: formRMax,
      fmt: formFmt,
      max: formMax,
      desc: formDesc
    });
    setIsModalOpen(false);
  };

  const filteredCategories = categorias.filter(c =>
    c.nome.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Parameter filtering search bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar categoria por título..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition"
          />
        </div>

        {userRole !== 'comum' && (
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto shrink-0">
            <button
              onClick={handleAutoGenerateAgeCategories}
              className="w-full sm:w-auto bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold px-4 py-2 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-md"
              title="Gerar automaticamente categorias padrão com base na idade (Sub-9 a Veteranos)"
            >
              <Zap className="w-4 h-4 text-yellow-400" />
              Gerar por Idade
            </button>

            <button
              onClick={() => handleOpenModal()}
              className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg"
            >
              <Plus className="w-4 h-4" />
              Nova Categoria
            </button>
          </div>
        )}
      </div>

      {/* Main List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm text-slate-200">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/20 text-slate-400 text-2xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Nome Categoria</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Gênero</th>
                <th className="py-3 px-4">Faixa de Idade</th>
                <th className="py-3 px-4 text-center">Faixa de Rating</th>
                <th className="py-3 px-4 text-center">Formato Chaveamento</th>
                <th className="py-3 px-4 text-center w-28">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredCategories.length > 0 ? (
                filteredCategories.map((c, i) => (
                  <tr key={c.id} className="hover:bg-slate-950/20 transition-colors">
                    <td className="py-3.5 px-4 text-center text-slate-500 font-mono text-xs">{i+1}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-100">{c.nome}</td>
                    <td className="py-3.5 px-4 text-xs whitespace-nowrap">
                      <span className="bg-blue-400/10 text-blue-400 border border-blue-400/20 px-2 py-0.5 rounded font-bold">
                        {c.tipo}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 text-xs">{c.genero}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-400 text-xs">
                      {c.idmin === '0' && c.idmax === '99' ? 'Livre' : `${c.idmin || 0} a ${c.idmax || 99} anos`}
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-slate-400 text-xs">
                      {c.rmin || '0'} – {c.rmax || '9999'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="text-2xs font-extrabold uppercase bg-slate-800 text-slate-300 px-2 py-0.5 border border-slate-700/80 rounded">
                        {c.fmt}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {userRole !== 'comum' && (
                          <button
                            onClick={() => handleOpenModal(c)}
                            className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-md transition"
                            title="Editar"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        {userRole === 'master' && (
                          <button
                            onClick={() => {
                              if (confirm(`Deseja mesmo remover a categoria "${c.nome}"?`)) {
                                onDelete(c.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-md transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    Nenhuma categoria registrada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CATEGORY FORM MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg overflow-hidden flex flex-col shadow-2xl">
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Tag className="w-4 h-4 text-yellow-400" />
                {formId ? 'Editar Categoria' : 'Nova Categoria'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form body */}
            <div className="p-6 overflow-y-auto space-y-4 max-h-[80vh]">
              <div className="bg-slate-950/45 p-3.5 rounded-lg border border-slate-800/60 space-y-1.5 shadow-inner">
                <label className="text-[10px] uppercase tracking-wider text-yellow-400 font-black block">Preencher com Faixa Etária Padrão</label>
                <select
                  onChange={(e) => {
                    const val = e.target.value;
                    if (!val) return;
                    const selected = JSON.parse(val);
                    setFormNome(selected.nome);
                    setFormIdMin(selected.idmin);
                    setFormIdMax(selected.idmax);
                    setFormDesc(selected.desc);
                    setFormGenero('Livre');
                  }}
                  className="w-full bg-slate-950 border border-slate-850 focus:border-yellow-400 rounded-md px-2.5 py-1.5 text-xs text-slate-200 outline-none"
                >
                  <option value="">-- Selecione uma classe de idade padrão --</option>
                  <option value={JSON.stringify({ nome: 'Sub-9 Geral', idmin: '0', idmax: '9', desc: 'Atletas com idade de até 9 anos completos.' })}>Sub-9 Geral (Até 9 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-11 Geral', idmin: '10', idmax: '11', desc: 'Atletas com idade entre 10 e 11 anos completos.' })}>Sub-11 Geral (10 a 11 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-13 Geral', idmin: '12', idmax: '13', desc: 'Atletas com idade entre 12 e 13 anos completos.' })}>Sub-13 Geral (12 a 13 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-15 Geral', idmin: '14', idmax: '15', desc: 'Atletas com idade entre 14 e 15 anos completos.' })}>Sub-15 Geral (14 a 15 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-17 Geral', idmin: '16', idmax: '17', desc: 'Atletas com idade entre 16 e 17 anos completos.' })}>Sub-17 Geral (16 a 17 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-19 Geral', idmin: '18', idmax: '19', desc: 'Atletas com idade entre 18 e 19 anos completos.' })}>Sub-19 Geral (18 a 19 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-21 Geral', idmin: '20', idmax: '21', desc: 'Atletas com idade entre 20 e 21 anos completos.' })}>Sub-21 Geral (20 a 21 anos)</option>
                  <option value={JSON.stringify({ nome: 'Adulto Geral', idmin: '22', idmax: '39', desc: 'Atletas na categoria adulta de 22 a 39 anos.' })}>Adulto Geral (22 a 39 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +40', idmin: '40', idmax: '49', desc: 'Atletas veteranos com idade de 40 a 49 anos.' })}>Veterano +40 (40 a 49 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +50', idmin: '50', idmax: '59', desc: 'Atletas veteranos com idade de 50 e 59 anos.' })}>Veterano +50 (50 e 59 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +60', idmin: '60', idmax: '69', desc: 'Atletas veteranos com idade de 60 e 69 anos.' })}>Veterano +60 (60 e 69 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +70', idmin: '70', idmax: '99', desc: 'Atletas veteranos com idade de 70 anos em diante.' })}>Veterano +70 (70 a 99 anos)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nome de Categoria *</label>
                <input
                  type="text"
                  placeholder="Ex: Sub-17 Masculino"
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 cursor-text rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Tipo</label>
                  <select
                    value={formTipo}
                    onChange={(e) => setFormTipo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Simples">Simples</option>
                    <option value="Duplas">Duplas</option>
                    <option value="Misto">Misto</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Gênero</label>
                  <select
                    value={formGenero}
                    onChange={(e) => setFormGenero(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <option value="Misto">Misto</option>
                    <option value="Livre">Livre</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Idade Mínima</label>
                  <input
                    type="number"
                    value={formIdMin}
                    onChange={(e) => setFormIdMin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Idade Máxima</label>
                  <input
                    type="number"
                    value={formIdMax}
                    onChange={(e) => setFormIdMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Rating Mínimo</label>
                  <input
                    type="number"
                    value={formRMin}
                    onChange={(e) => setFormRMin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Rating Máximo</label>
                  <input
                    type="number"
                    value={formRMax}
                    onChange={(e) => setFormRMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Formato Chaveamento</label>
                  <select
                    value={formFmt}
                    onChange={(e) => setFormFmt(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Eliminatória Simples">Eliminatória Simples</option>
                    <option value="Dupla Eliminação">Dupla Eliminação</option>
                    <option value="Round Robin">Round Robin</option>
                    <option value="Grupos + Eliminatória">Grupos + Eliminatória</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Max Participantes</label>
                  <input
                    type="number"
                    placeholder="Sem limite"
                    value={formMax}
                    onChange={(e) => setFormMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Descrição / Notas Específicas</label>
                <textarea
                  rows={2}
                  placeholder="Restrições, regras ou especificações do chaveamento..."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none resize-none"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950/25">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-755 text-xs font-bold rounded-lg transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black rounded-lg transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Categoria
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
