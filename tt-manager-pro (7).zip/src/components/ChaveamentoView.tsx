import React, { useState, useEffect } from 'react';
import { Torneio, Atleta, Categoria, Inscricao, Arbitro, SystemConfig } from '../types';
import { 
  GitBranch, RefreshCw, Trophy, User, Shield, 
  Shuffle, Award, CheckSquare, ListFilter, AlertCircle, Save, Trash2,
  CheckCircle2, AlertTriangle, XCircle, Info, Users,
  Calendar, Clock, MapPin, Printer, MessageCircle, Play, FileText, Search,
  Check, Download, Sparkles
} from 'lucide-react';
import { triggerToast } from '../utils/toast';
import { exportRelacaoInscritosPDF } from '../utils/pdfExport';

interface ChaveamentoViewProps {
  torneios: Torneio[];
  atletas: Atleta[];
  categorias: Categoria[];
  inscricoes?: Inscricao[];
  arbitros?: Arbitro[];
  config?: SystemConfig;
  userRole?: string;
  onSaveAtleta?: (updated: Atleta) => void;
  onSaveAtletasBulk?: (updatedList: Atleta[]) => void;
}

export interface BracketMatch {
  id: string; // 'q1' | 'q2' | 'q3' | 'q4' | 's1' | 's2' | 'f1'
  round: 'quartas' | 'semis' | 'final';
  p1: Atleta | null;
  p2: Atleta | null;
  score1: number;
  score2: number;
}

export interface ScheduledGame {
  id: string;
  torneioId: string;
  categoriaId: string;
  categoriaNome: string;
  rodada: string;
  matchId: string;
  p1: Atleta | null;
  p2: Atleta | null;
  mesa: number;
  horario: string;
  arbitroNome: string;
  status: 'Aguardando' | 'Em Jogo' | 'Concluído';
  score1: number;
  score2: number;
}

export interface GroupMatch {
  id: string; // 'gA_m0', 'gA_m1', ...
  p1: Atleta | null;
  p2: Atleta | null;
  score1: number;
  score2: number;
  status: 'Aguardando' | 'Concluído';
}

export interface AthleteGroup {
  id: string; // 'A', 'B', 'C'...
  nome: string; // 'Grupo A'
  atletas: Atleta[];
  matches: GroupMatch[];
}

export interface GroupStanding {
  atleta: Atleta;
  jogos: number;
  vitorias: number;
  derrotas: number;
  setsPro: number;
  setsContra: number;
  saldoSets: number;
  pontos: number;
}

// Generates a full round-robin (todos contra todos) match list for a group of athletes
const generateRoundRobinMatches = (players: Atleta[], groupId: string): GroupMatch[] => {
  const matches: GroupMatch[] = [];
  let idx = 0;
  for (let i = 0; i < players.length; i++) {
    for (let j = i + 1; j < players.length; j++) {
      matches.push({
        id: `g${groupId}_m${idx}`,
        p1: players[i],
        p2: players[j],
        score1: 0,
        score2: 0,
        status: 'Aguardando'
      });
      idx++;
    }
  }
  return matches;
};

// Distributes athletes into balanced groups using serpentine (snake) seeding by rating,
// or plain shuffled chunks for random draw, so skill level spreads evenly across groups.
const distributeIntoGroups = (
  players: Atleta[],
  numGroups: number,
  strategy: 'rating' | 'random'
): Atleta[][] => {
  const sorted = strategy === 'rating'
    ? [...players].sort((a, b) => b.rating - a.rating)
    : [...players].sort(() => Math.random() - 0.5);

  const groups: Atleta[][] = Array.from({ length: numGroups }, () => []);

  if (strategy === 'rating') {
    // Serpentine distribution: 1,2,3,4 | 4,3,2,1 | 1,2,3,4 ...
    let groupIdx = 0;
    let direction = 1;
    sorted.forEach(player => {
      groups[groupIdx].push(player);
      groupIdx += direction;
      if (groupIdx === numGroups) { groupIdx = numGroups - 1; direction = -1; }
      else if (groupIdx < 0) { groupIdx = 0; direction = 1; }
    });
  } else {
    // Sequential chunks of an already-shuffled list
    sorted.forEach((player, i) => {
      groups[i % numGroups].push(player);
    });
  }

  return groups;
};

// Computes the standings table (V-D, sets, points) for a single group based on its matches
const computeGroupStandings = (group: AthleteGroup): GroupStanding[] => {
  const table: Record<string, GroupStanding> = {};
  group.atletas.forEach(a => {
    table[a.id] = { atleta: a, jogos: 0, vitorias: 0, derrotas: 0, setsPro: 0, setsContra: 0, saldoSets: 0, pontos: 0 };
  });

  group.matches.forEach(m => {
    if (!m.p1 || !m.p2) return;
    if (m.score1 === 0 && m.score2 === 0) return; // not played yet
    const s1 = table[m.p1.id];
    const s2 = table[m.p2.id];
    if (!s1 || !s2) return;

    s1.jogos++; s2.jogos++;
    s1.setsPro += m.score1; s1.setsContra += m.score2;
    s2.setsPro += m.score2; s2.setsContra += m.score1;

    if (m.score1 > m.score2) {
      s1.vitorias++; s1.pontos += 2;
      s2.derrotas++; s2.pontos += 1;
    } else if (m.score2 > m.score1) {
      s2.vitorias++; s2.pontos += 2;
      s1.derrotas++; s1.pontos += 1;
    }
  });

  Object.values(table).forEach(s => { s.saldoSets = s.setsPro - s.setsContra; });

  return Object.values(table).sort((a, b) => {
    if (b.pontos !== a.pontos) return b.pontos - a.pontos;
    if (b.saldoSets !== a.saldoSets) return b.saldoSets - a.saldoSets;
    return b.setsPro - a.setsPro;
  });
};

const createEmptyMatches = (): BracketMatch[] => [
  { id: 'q1', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q2', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q3', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q4', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 's1', round: 'semis', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 's2', round: 'semis', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'f1', round: 'final', p1: null, p2: null, score1: 0, score2: 0 }
];

// Simple, accurate age calculation based on birthdate (YYYY-MM-DD)
const calculateAge = (birthDateString: string): number => {
  if (!birthDateString) return 0;
  const birth = new Date(birthDateString);
  const today = new Date();
  if (isNaN(birth.getTime())) return 0;
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
};

// Helper to parse age range from Categoria object or category name
const parseAgeLimitsForCategory = (cat: Categoria): { minAge: number; maxAge: number } => {
  let minAge = cat.idmin ? parseInt(cat.idmin, 10) : 0;
  let maxAge = cat.idmax ? parseInt(cat.idmax, 10) : 99;

  const nameUpper = (cat.nome || '').toUpperCase();
  if (nameUpper.includes('SUB-7') || nameUpper.includes('SUB 7')) { minAge = 0; maxAge = 7; }
  else if (nameUpper.includes('SUB-9') || nameUpper.includes('SUB 9')) { minAge = 0; maxAge = 9; }
  else if (nameUpper.includes('SUB-11') || nameUpper.includes('SUB 11')) { minAge = 0; maxAge = 11; }
  else if (nameUpper.includes('SUB-13') || nameUpper.includes('SUB 13')) { minAge = 0; maxAge = 13; }
  else if (nameUpper.includes('SUB-15') || nameUpper.includes('SUB 15')) { minAge = 0; maxAge = 15; }
  else if (nameUpper.includes('SUB-19') || nameUpper.includes('SUB 19')) { minAge = 0; maxAge = 19; }
  else if (nameUpper.includes('SUB-21') || nameUpper.includes('SUB 21')) { minAge = 0; maxAge = 21; }
  else if (nameUpper.includes('ADULTO') || nameUpper.includes('ADULT')) { minAge = 18; maxAge = 39; }
  else if (nameUpper.includes('VET40') || nameUpper.includes('VET 40') || nameUpper.includes('VETERANO 40')) { minAge = 40; maxAge = 49; }
  else if (nameUpper.includes('VET50') || nameUpper.includes('VET 50') || nameUpper.includes('VETERANO 50')) { minAge = 50; maxAge = 59; }
  else if (nameUpper.includes('VET60') || nameUpper.includes('VET 60') || nameUpper.includes('VETERANO 60')) { minAge = 60; maxAge = 99; }

  return { minAge: isNaN(minAge) ? 0 : minAge, maxAge: isNaN(maxAge) ? 99 : maxAge };
};

export default function ChaveamentoView({ 
  torneios, 
  atletas, 
  categorias, 
  inscricoes = [], 
  arbitros = [],
  config,
  userRole = 'comum',
  onSaveAtleta,
  onSaveAtletasBulk
}: ChaveamentoViewProps) {
  const [selectedTorneioId, setSelectedTorneioId] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState('');
  const [bracketGenerated, setBracketGenerated] = useState(false);
  const [matches, setMatches] = useState<BracketMatch[]>(createEmptyMatches());
  
  const [onlyBusyTables, setOnlyBusyTables] = useState(false);

  // Status changer for scheduled games (allows referees to set tables as busy/ongoing)
  const handleUpdateGameStatus = (gameId: string, newStatus: 'Aguardando' | 'Em Jogo' | 'Concluído') => {
    const updated = scheduledGames.map(g => g.id === gameId ? { ...g, status: newStatus } : g);
    setScheduledGames(updated);
    if (selectedTorneioId) {
      const storageKey = `ttmpro_escala_${selectedTorneioId}`;
      localStorage.setItem(storageKey, JSON.stringify(updated));
    }
    const match = scheduledGames.find(g => g.id === gameId);
    if (match) {
      triggerToast(`Mesa #${match.mesa}: Status alterado para "${newStatus}"!`, newStatus === 'Em Jogo' ? 'success' : 'info');
    }
  };

  const checkPermission = (): boolean => {
    if (userRole === 'comum') {
      triggerToast("Erro de Permissão: Apenas o administrador oficial de e-mail 'schmidtvagner@gmail.com' pode modificar o chaveamento!", "error");
      return false;
    }
    return true;
  };
  
  // Custom states for validation options
  const [filterStrategy, setFilterStrategy] = useState<'inscricoes' | 'categoria-geral' | 'ativos-all'>('inscricoes');
  const [onlyConfirmedPresence, setOnlyConfirmedPresence] = useState(false);
  const [preventDuplicatesAcrossBrackets, setPreventDuplicatesAcrossBrackets] = useState(true);
  const [viewTab, setViewTab] = useState<'categorias' | 'arvore' | 'grupos' | 'escala'>('categorias');

  // Group stage (Fase de Grupos) states
  const [groups, setGroups] = useState<AthleteGroup[]>([]);
  const [groupsGenerated, setGroupsGenerated] = useState(false);
  const [groupSizeInput, setGroupSizeInput] = useState(4);

  // Relação de Atletas Inscritos (full roster per category, for pre-bracket confirmation)
  const [relacaoModalCatId, setRelacaoModalCatId] = useState<string | null>(null);

  // Confirm presence at mesa organizadora for a single athlete
  const handleTogglePresenceAtleta = (a: Atleta) => {
    const isConfirmed = (a.presenca || 'CONFIRMADA') === 'CONFIRMADA';
    const nextPresenca = isConfirmed ? 'PENDENTE' : 'CONFIRMADA';
    const updated: Atleta = { ...a, presenca: nextPresenca };
    if (onSaveAtleta) {
      onSaveAtleta(updated);
    }
    if (nextPresenca === 'CONFIRMADA') {
      triggerToast(`✓ Presença de ${a.nome} CONFIRMADA na Mesa Organizadora!`, 'success');
    } else {
      triggerToast(`Presença de ${a.nome} alterada para PENDENTE.`, 'info');
    }
  };

  // Confirm presence for all candidates of a category
  const handleConfirmPresenceBulk = (catId: string) => {
    const cat = categorias.find(c => c.id === catId);
    if (!cat) return;
    const candidates = getCandidatesForCategory(catId, undefined, false);
    if (candidates.length === 0) {
      triggerToast(`Nenhum atleta encontrado para a categoria "${cat.nome}".`, 'warning');
      return;
    }
    let count = 0;
    const updatedList = atletas.map(a => {
      if (candidates.some(c => c.id === a.id) && (a.presenca || 'CONFIRMADA') !== 'CONFIRMADA') {
        count++;
        return { ...a, presenca: 'CONFIRMADA' as const };
      }
      return a;
    });

    if (onSaveAtletasBulk) {
      onSaveAtletasBulk(updatedList);
    } else if (onSaveAtleta) {
      updatedList.forEach(a => {
        if (candidates.some(c => c.id === a.id)) {
          onSaveAtleta(a);
        }
      });
    }

    triggerToast(`⚡ Presença confirmada na Mesa Organizadora para todos os ${candidates.length} atletas de "${cat.nome}"!`, 'success');
  };

  // Master Automated Game Schedule States
  const [scheduledGames, setScheduledGames] = useState<ScheduledGame[]>([]);
  const [startHour, setStartHour] = useState('08:00');
  const [matchDurationMinutes, setMatchDurationMinutes] = useState(20);
  const [numTablesConfig, setNumTablesConfig] = useState(8);
  const [escalaSearch, setEscalaSearch] = useState('');
  const [escalaCatFilter, setEscalaCatFilter] = useState('');
  const [escalaMesaFilter, setEscalaMesaFilter] = useState('todas');
  const [escalaStatusFilter, setEscalaStatusFilter] = useState('todos');

  // Propagates winners of quarterfinals and semifinals upwards
  const propagateBracket = (targetMatches: BracketMatch[]): BracketMatch[] => {
    const updated = targetMatches.map(m => ({ ...m }));
    
    const findMatch = (id: string) => updated.find(m => m.id === id)!;
    
    const q1 = findMatch('q1');
    const q2 = findMatch('q2');
    const q3 = findMatch('q3');
    const q4 = findMatch('q4');
    const s1 = findMatch('s1');
    const s2 = findMatch('s2');
    const f1 = findMatch('f1');
    
    // Helper to determine winner based on score or auto-advancement for BYEs
    const getWinner = (m: BracketMatch): Atleta | null => {
      if (!m.p1 && !m.p2) return null;
      if (m.p1 && !m.p2) return m.p1;
      if (!m.p1 && m.p2) return m.p2;
      
      // Both exist - compare scores
      if (m.score1 > m.score2) return m.p1;
      if (m.score2 > m.score1) return m.p2;
      // Default to p1 if tie during generation setup
      return m.p1;
    };
    
    // Update Semifinal slots
    s1.p1 = getWinner(q1);
    s1.p2 = getWinner(q2);
    
    s2.p1 = getWinner(q3);
    s2.p2 = getWinner(q4);
    
    // Update Final slots
    f1.p1 = getWinner(s1);
    f1.p2 = getWinner(s2);
    
    return updated;
  };

  // Auto-select first tournament if none is selected
  useEffect(() => {
    if (!selectedTorneioId && torneios && torneios.length > 0) {
      setSelectedTorneioId(torneios[0].id);
    }
  }, [torneios, selectedTorneioId]);

  // Sync state with localStorage when tournament or category changes
  useEffect(() => {
    if (selectedTorneioId && selectedCategoryId) {
      const key = `ttmpro_bracket_${selectedTorneioId}_${selectedCategoryId}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && Array.isArray(parsed.matches)) {
            setMatches(propagateBracket(parsed.matches));
            setBracketGenerated(parsed.generated || false);
          } else {
            setMatches(createEmptyMatches());
            setBracketGenerated(false);
          }
        } catch (e) {
          console.error("Erro ao carregar chaveamento:", e);
          setMatches(createEmptyMatches());
          setBracketGenerated(false);
        }
      } else {
        setMatches(createEmptyMatches());
        setBracketGenerated(false);
      }
    } else {
      setMatches(createEmptyMatches());
      setBracketGenerated(false);
    }
  }, [selectedTorneioId, selectedCategoryId, atletas]);

  // Sync group-stage state with localStorage when tournament or category changes
  useEffect(() => {
    if (selectedTorneioId && selectedCategoryId) {
      const key = `ttmpro_grupos_${selectedTorneioId}_${selectedCategoryId}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && Array.isArray(parsed.groups)) {
            setGroups(parsed.groups);
            setGroupsGenerated(parsed.generated || false);
            if (parsed.groupSize) setGroupSizeInput(parsed.groupSize);
          } else {
            setGroups([]);
            setGroupsGenerated(false);
          }
        } catch (e) {
          console.error("Erro ao carregar fase de grupos:", e);
          setGroups([]);
          setGroupsGenerated(false);
        }
      } else {
        setGroups([]);
        setGroupsGenerated(false);
      }
    } else {
      setGroups([]);
      setGroupsGenerated(false);
    }
  }, [selectedTorneioId, selectedCategoryId, atletas]);

  // Load / Sync master schedule when tournament changes
  useEffect(() => {
    if (selectedTorneioId) {
      const storageKey = `ttmpro_escala_${selectedTorneioId}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            setScheduledGames(parsed);
          }
        } catch (e) {
          console.error("Erro ao carregar escala de jogos:", e);
        }
      } else {
        setScheduledGames([]);
      }
      const selectedT = torneios.find(t => t.id === selectedTorneioId);
      if (selectedT) {
        if (selectedT.mesas) setNumTablesConfig(selectedT.mesas);
        else if (config?.mesasCount) setNumTablesConfig(config.mesasCount);
        if (selectedT.hora) setStartHour(selectedT.hora);
      }
    } else {
      setScheduledGames([]);
    }
  }, [selectedTorneioId, torneios, config]);

  // Generate Master Automated Game Schedule across all categories for the active tournament
  const generateAutomaticMasterSchedule = (
    customStartHour = startHour,
    customDuration = matchDurationMinutes,
    customTables = numTablesConfig
  ) => {
    if (!selectedTorneioId) {
      triggerToast("Selecione um torneio ativo para gerar a escala de jogos!", "warning");
      return;
    }

    const selectedT = torneios.find(t => t.id === selectedTorneioId);
    const tablesCount = customTables || selectedT?.mesas || config?.mesasCount || 8;
    const initialTimeStr = customStartHour || selectedT?.hora || '08:00';
    
    // Parse initial time e.g. "08:30" -> total minutes
    const [hStr, mStr] = initialTimeStr.split(':');
    const startTotalMins = (parseInt(hStr, 10) || 8) * 60 + (parseInt(mStr, 10) || 0);

    // Collect all matches from all categories
    const allCategoryMatches: {
      catId: string;
      catNome: string;
      round: string;
      matchId: string;
      p1: Atleta | null;
      p2: Atleta | null;
      score1: number;
      score2: number;
      roundPriority: number;
    }[] = [];

    categorias.forEach(cat => {
      const key = `ttmpro_bracket_${selectedTorneioId}_${cat.id}`;
      let catBracketMatches: BracketMatch[] = [];
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && Array.isArray(parsed.matches) && parsed.matches.length > 0) {
            catBracketMatches = parsed.matches;
          }
        } catch (e) { console.error(e); }
      }

      // Auto-generate bracket if not generated yet or empty
      if (catBracketMatches.length === 0 || !catBracketMatches.some(m => m.p1 || m.p2)) {
        generateBracketForCategory(cat.id, 'rating', true);
        const savedNew = localStorage.getItem(key);
        if (savedNew) {
          try {
            const parsedNew = JSON.parse(savedNew);
            catBracketMatches = parsedNew.matches || [];
          } catch(e) {}
        }
      }

      // Add valid matches to collection
      catBracketMatches.forEach(m => {
        if (m.p1 || m.p2) {
          const roundName = m.round === 'quartas' ? 'Quartas de Final' : (m.round === 'semis' ? 'Semifinal' : 'Grande Final');
          const prio = m.round === 'quartas' ? 1 : (m.round === 'semis' ? 2 : 3);
          allCategoryMatches.push({
            catId: cat.id,
            catNome: cat.nome,
            round: roundName,
            matchId: m.id,
            p1: m.p1,
            p2: m.p2,
            score1: m.score1,
            score2: m.score2,
            roundPriority: prio
          });
        }
      });

      // Add group-stage (Fase de Grupos) matches, always scheduled before knockout rounds
      const groupsKey = `ttmpro_grupos_${selectedTorneioId}_${cat.id}`;
      const savedGroups = localStorage.getItem(groupsKey);
      if (savedGroups) {
        try {
          const parsedGroups = JSON.parse(savedGroups);
          if (parsedGroups && Array.isArray(parsedGroups.groups)) {
            (parsedGroups.groups as AthleteGroup[]).forEach(g => {
              g.matches.forEach(m => {
                if (m.p1 || m.p2) {
                  allCategoryMatches.push({
                    catId: cat.id,
                    catNome: cat.nome,
                    round: `Fase de Grupos - ${g.nome}`,
                    matchId: m.id,
                    p1: m.p1,
                    p2: m.p2,
                    score1: m.score1,
                    score2: m.score2,
                    roundPriority: 0
                  });
                }
              });
            });
          }
        } catch (e) { console.error(e); }
      }
    });

    if (allCategoryMatches.length === 0) {
      triggerToast("Nenhuma partida encontrada nas categorias deste torneio. Verifique se há atletas inscritos!", "warning");
      return;
    }

    // Sort by Round Priority (Quartas first, Semis second, Final third)
    allCategoryMatches.sort((a, b) => {
      if (a.roundPriority !== b.roundPriority) return a.roundPriority - b.roundPriority;
      return a.catNome.localeCompare(b.catNome);
    });

    // Allocate tables & times sequentially
    const tableFreeMinutes = new Array(tablesCount).fill(startTotalMins);
    const activeArbitros = arbitros.filter(arb => arb.status !== 'Indisponível');
    let arbIndex = 0;

    const newScheduledGames: ScheduledGame[] = allCategoryMatches.map((m, idx) => {
      // Find earliest free table
      let minTableIdx = 0;
      let minFreeTime = tableFreeMinutes[0];
      for (let t = 1; t < tablesCount; t++) {
        if (tableFreeMinutes[t] < minFreeTime) {
          minFreeTime = tableFreeMinutes[t];
          minTableIdx = t;
        }
      }

      const assignedMesa = minTableIdx + 1;
      const assignedTimeMins = minFreeTime;
      
      const hrs = Math.floor(assignedTimeMins / 60) % 24;
      const mins = assignedTimeMins % 60;
      const timeFormatted = `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;

      // Advance table free time by match duration
      tableFreeMinutes[minTableIdx] += customDuration;

      // Assign referee
      let assignedArbName = 'Mesa Coordenadora';
      if (activeArbitros.length > 0) {
        assignedArbName = activeArbitros[arbIndex % activeArbitros.length].nome;
        arbIndex++;
      }

      return {
        id: `sched_${m.catId}_${m.matchId}_${idx}`,
        torneioId: selectedTorneioId,
        categoriaId: m.catId,
        categoriaNome: m.catNome,
        rodada: m.round,
        matchId: m.matchId,
        p1: m.p1,
        p2: m.p2,
        mesa: assignedMesa,
        horario: timeFormatted,
        arbitroNome: assignedArbName,
        status: m.score1 > 0 || m.score2 > 0 ? 'Concluído' : 'Aguardando',
        score1: m.score1,
        score2: m.score2
      };
    });

    // Save schedule
    const storageKey = `ttmpro_escala_${selectedTorneioId}`;
    localStorage.setItem(storageKey, JSON.stringify(newScheduledGames));
    setScheduledGames(newScheduledGames);

    triggerToast(`⚡ Escala Automática de Jogos gerada com sucesso! ${newScheduledGames.length} partidas distribuídas em ${tablesCount} mesas.`, "success");
  };

  // Export / Print complete Match Schedule
  const handlePrintEscala = () => {
    if (scheduledGames.length === 0) {
      triggerToast("Nenhuma partida na escala para imprimir!", "warning");
      return;
    }
    const selectedT = torneios.find(t => t.id === selectedTorneioId);
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      triggerToast("Permita popups no navegador para imprimir a escala!", "error");
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Escala Oficial de Jogos - ${selectedT?.nome || 'Torneio'}</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; padding: 24px; color: #0f172a; background: #fff; }
            .header { border-bottom: 2px solid #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
            h1 { margin: 0 0 6px 0; color: #0f172a; font-size: 22px; font-weight: 800; }
            h2 { margin: 0; color: #475569; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
            .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px; background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0; font-size: 11px; }
            .summary-item { font-weight: bold; }
            .summary-label { color: #64748b; font-size: 9px; text-transform: uppercase; display: block; margin-bottom: 2px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px; }
            th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; }
            th { background: #0f172a; color: #fff; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
            tr:nth-child(even) { background: #f8fafc; }
            .mesa-badge { background: #fef08a; color: #854d0e; font-weight: bold; padding: 2px 6px; border-radius: 4px; border: 1px solid #fde047; }
            .time-badge { font-family: monospace; font-weight: bold; font-size: 12px; color: #0f172a; }
            .vs { font-weight: 900; color: #ea580c; margin: 0 6px; }
            @media print {
              body { padding: 0; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🏓 ${selectedT?.nome || 'Escala de Jogos Oficial'}</h1>
            <h2>Programação Automática de Mesas e Horários por Categoria dos Inscritos — ${new Date().toLocaleDateString('pt-BR')}</h2>
          </div>
          
          <div class="summary">
            <div class="summary-item"><span class="summary-label">Total de Partidas</span>${scheduledGames.length} Jogos</div>
            <div class="summary-item"><span class="summary-label">Mesas Alocadas</span>${Math.max(...scheduledGames.map(g => g.mesa), 0)} Mesas</div>
            <div class="summary-item"><span class="summary-label">Horário Inicial</span>${scheduledGames[0]?.horario || '08:00'}</div>
            <div class="summary-item"><span class="summary-label">Término Estimado</span>${scheduledGames[scheduledGames.length - 1]?.horario || '18:00'}</div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Horário</th>
                <th>Mesa</th>
                <th>Categoria</th>
                <th>Fase / Rodada</th>
                <th>Confronto Escalado</th>
                <th>Árbitro Designado</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${scheduledGames.map(g => `
                <tr>
                  <td class="time-badge">${g.horario}</td>
                  <td><span class="mesa-badge">Mesa #${g.mesa}</span></td>
                  <td><strong>${g.categoriaNome}</strong></td>
                  <td>${g.rodada}</td>
                  <td>
                    <strong>${g.p1?.nome || 'BYE'}</strong>
                    <span class="vs">VS</span>
                    <strong>${g.p2?.nome || 'BYE'}</strong>
                  </td>
                  <td>${g.arbitroNome}</td>
                  <td>${g.status}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  // WhatsApp Convocação Notice Generator
  const handleSendWhatsAppNotice = (game: ScheduledGame) => {
    const selectedT = torneios.find(t => t.id === selectedTorneioId);
    const p1Name = game.p1?.nome || 'Atleta A';
    const p2Name = game.p2?.nome || 'Atleta B';
    const text = encodeURIComponent(
      `🏓 *TT Manager Pro — Escala de Jogos Oficial*\n\n` +
      `Olá! A partida da categoria *${game.categoriaNome}* (${game.rodada}) foi escalada:\n` +
      `👤 *${p1Name}* 🆚 *${p2Name}*\n` +
      `📍 *Mesa ${game.mesa}*\n` +
      `⏰ Horário Estimado: *${game.horario}*\n` +
      `🏆 Torneio: *${selectedT?.nome || 'Campeonato'}*\n` +
      `👤 Árbitro Designado: *${game.arbitroNome}*\n\n` +
      `Por favor, dirijam-se com raquete em mãos à mesa no horário indicado!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const saveBracket = (updatedMatches: BracketMatch[], isGen: boolean) => {
    if (!checkPermission()) return;
    if (selectedTorneioId && selectedCategoryId) {
      const key = `ttmpro_bracket_${selectedTorneioId}_${selectedCategoryId}`;
      localStorage.setItem(key, JSON.stringify({
        matches: updatedMatches,
        generated: isGen
      }));
      setMatches(updatedMatches);
      setBracketGenerated(isGen);
    }
  };

  const selectedTorneio = torneios.find(t => t.id === selectedTorneioId);
  const selectedCat = categorias.find(c => c.id === selectedCategoryId);
  const catName = selectedCat?.nome || '';

  // Scan other category brackets under this tournament from localStorage to prevent duplicate allocations
  const getAllocatedAthletesInOtherCategory = (otherCatId: string): Atleta[] => {
    if (!selectedTorneioId) return [];
    const list: Atleta[] = [];

    const bracketKey = `ttmpro_bracket_${selectedTorneioId}_${otherCatId}`;
    const savedBracket = localStorage.getItem(bracketKey);
    if (savedBracket) {
      try {
        const parsed = JSON.parse(savedBracket);
        if (parsed && Array.isArray(parsed.matches)) {
          parsed.matches.forEach((m: any) => {
            // Only check starting quarterfinals slots because higher rounds are auto-propagated
            if (m.round === 'quartas') {
              if (m.p1) list.push(m.p1);
              if (m.p2) list.push(m.p2);
            }
          });
        }
      } catch (e) {
        console.error(e);
      }
    }

    const groupsKey = `ttmpro_grupos_${selectedTorneioId}_${otherCatId}`;
    const savedGroups = localStorage.getItem(groupsKey);
    if (savedGroups) {
      try {
        const parsed = JSON.parse(savedGroups);
        if (parsed && Array.isArray(parsed.groups)) {
          parsed.groups.forEach((g: AthleteGroup) => {
            (g.atletas || []).forEach(a => list.push(a));
          });
        }
      } catch (e) {
        console.error(e);
      }
    }

    return list;
  };

  // Helper to gather athletes for ANY category based on selected strategies
  const getCandidatesForCategory = (
    catId: string, 
    customStrategy?: 'inscricoes' | 'categoria-geral' | 'ativos-all' | 'idade-auto',
    applyPresenceFilter: boolean = true
  ): Atleta[] => {
    if (!selectedTorneioId || !catId) return [];
    const cat = categorias.find(c => c.id === catId);
    if (!cat) return [];
    const cName = cat.nome;
    const strategy = customStrategy || filterStrategy;

    let candidates: Atleta[] = [];

    if (strategy === 'idade-auto') {
      const { minAge, maxAge } = parseAgeLimitsForCategory(cat);
      candidates = atletas.filter(a => {
        if (a.status !== 'Ativo') return false;
        const age = calculateAge(a.nasc);
        if (age < minAge || age > maxAge) return false;
        if (cat.genero) {
          const cGen = cat.genero.toLowerCase();
          const aGen = (a.genero || '').toLowerCase();
          if (cGen.startsWith('masc') && !aGen.startsWith('masc')) return false;
          if (cGen.startsWith('fem') && !aGen.startsWith('fem')) return false;
        }
        return true;
      });
    } else if (strategy === 'inscricoes') {
      const matchedInscricoes = inscricoes.filter(
        i => (i.torneioId === selectedTorneioId || !i.torneioId) && 
             i.categoria.trim().toLowerCase() === cName.trim().toLowerCase()
      );
      if (matchedInscricoes.length > 0) {
        const found = atletas.filter(a => matchedInscricoes.some(ins => ins.atletaId === a.id));
        if (found.length > 0) candidates = found;
      }
      
      if (candidates.length === 0) {
        // Fallback 1: category name on athlete profile
        const catMatches = atletas.filter(a => {
          if (!a.cat) return false;
          return a.cat.split(',').map(c => c.trim().toLowerCase()).includes(cName.trim().toLowerCase());
        });
        if (catMatches.length > 0) candidates = catMatches;
      }

      if (candidates.length === 0) {
        // Fallback 2: age classification
        const ageMatches = getCandidatesForCategory(catId, 'idade-auto', false);
        if (ageMatches.length > 0) candidates = ageMatches;
      }

      if (candidates.length === 0) {
        // Fallback 3: all active athletes
        candidates = atletas.filter(a => a.status === 'Ativo');
      }
    } else if (strategy === 'categoria-geral') {
      const list = atletas.filter(a => {
        if (!a.cat) return false;
        const athleteCats = a.cat.split(',').map(c => c.trim().toLowerCase());
        return athleteCats.includes(cName.toLowerCase());
      });
      if (list.length > 0) candidates = list;
      else {
        const ageMatches = getCandidatesForCategory(catId, 'idade-auto', false);
        if (ageMatches.length > 0) candidates = ageMatches;
        else candidates = atletas.filter(a => a.status === 'Ativo');
      }
    } else {
      candidates = atletas.filter(a => a.status === 'Ativo');
    }

    if (applyPresenceFilter && onlyConfirmedPresence) {
      candidates = candidates.filter(a => (a.presenca || 'CONFIRMADA') === 'CONFIRMADA');
    }

    return candidates;
  };

  // Robust Athlete/Candidate Gathering Strategy Selector
  const getCandidatesForSelection = (): Atleta[] => {
    return getCandidatesForCategory(selectedCategoryId);
  };

  // Generate Validation Audit Report dynamically
  const runValidationAudit = () => {
    const report = {
      isValid: true,
      hasIneligibility: false,
      hasConflicts: false,
      errors: [] as string[],
      warnings: [] as string[],
      eligibleCount: 0,
      maxLimit: 8,
      ageFails: 0,
      genderFails: 0,
      ratingFails: 0,
      overallState: 'VALIDADO' as 'VALIDADO' | 'CONFLITO' | 'REJEITADO',
      duplicateAllocations: [] as { name: string; otherCat: string }[],
    };

    if (!selectedTorneioId || !selectedCategoryId || !selectedCat) {
      report.isValid = false;
      report.overallState = 'REJEITADO';
      return report;
    }

    const currentCandidates = getCandidatesForSelection();
    report.eligibleCount = currentCandidates.length;

    // 1. Max participants limit evaluation
    const maxLimit = selectedCat.max ? parseInt(selectedCat.max, 10) : 8;
    report.maxLimit = maxLimit;
    if (currentCandidates.length > maxLimit) {
      report.isValid = false;
      report.errors.push(`Excesso de Participantes: ${currentCandidates.length} atletas elegíveis excede o limite máximo de ${maxLimit} estipulado no cadastro da categoria.`);
    }

    // 2. Minimum bracket requirements
    if (currentCandidates.length < 2) {
      report.isValid = false;
      report.errors.push(`Inscritos Insuficientes: São necessários pelo menos 2 atletas inscritos / elegíveis para simular ou gerar a chave de disputa.`);
    }

    // 3. Check duplicate allocations across other created brackets in the same tournament
    categorias.forEach(otherCat => {
      if (otherCat.id !== selectedCategoryId) {
        const otherAllocated = getAllocatedAthletesInOtherCategory(otherCat.id);
        currentCandidates.forEach(cand => {
          if (otherAllocated.some(oa => oa.id === cand.id)) {
            report.hasConflicts = true;
            report.duplicateAllocations.push({
              name: cand.nome,
              otherCat: otherCat.nome
            });
            report.warnings.push(`Conflito de Chaves: Atleta "${cand.nome}" já está alocado e disputando no chaveamento da categoria "${otherCat.nome}".`);
          }
        });
      }
    });

    // 4. Candidate Qualification Audit (Age, Gender, Rating Checks)
    currentCandidates.forEach(cand => {
      // Age Check
      const age = calculateAge(cand.nasc);
      const minAge = selectedCat.idmin ? parseInt(selectedCat.idmin, 10) : 0;
      const maxAge = selectedCat.idmax ? parseInt(selectedCat.idmax, 10) : 99;
      if (age < minAge || age > maxAge) {
        report.hasIneligibility = true;
        report.ageFails++;
        report.warnings.push(`Incompatibilidade Etária: "${cand.nome}" possui ${age} anos (nasc. ${cand.nasc}), fora do estipulado para a categoria [${minAge} a ${maxAge} anos].`);
      }

      // Gender Check
      const catGender = selectedCat.genero ? selectedCat.genero.toLowerCase() : 'livre';
      const athleteGender = cand.genero ? cand.genero.toLowerCase() : '';
      if (catGender !== 'livre' && catGender !== 'misto') {
        if (catGender.startsWith('masc') && !athleteGender.startsWith('masc')) {
          report.hasIneligibility = true;
          report.genderFails++;
          report.warnings.push(`Incompatibilidade de Gênero: "${cand.nome}" é registrado como "${cand.genero}", mas a categoria selecionada é restrita ao gênero Masculino.`);
        } else if (catGender.startsWith('fem') && !athleteGender.startsWith('fem')) {
          report.hasIneligibility = true;
          report.genderFails++;
          report.warnings.push(`Incompatibilidade de Gênero: "${cand.nome}" é registrado como "${cand.genero}", mas a categoria selecionada é restrita ao gênero Feminino.`);
        }
      }

      // Rating Check
      const minRating = selectedCat.rmin ? parseFloat(selectedCat.rmin) : 0;
      const maxRating = selectedCat.rmax ? parseFloat(selectedCat.rmax) : Infinity;
      if (cand.rating < minRating || cand.rating > maxRating) {
        report.hasIneligibility = true;
        report.ratingFails++;
        report.warnings.push(`Divergência de Classe / Rating: "${cand.nome}" possui Rating de ${cand.rating} pts, fora do intervalo [${minRating} - ${maxRating}] desta categoria.`);
      }
    });

    // Update Overall state
    if (report.errors.length > 0) {
      report.overallState = 'REJEITADO';
    } else if (report.warnings.length > 0) {
      report.overallState = 'CONFLITO';
    } else {
      report.overallState = 'VALIDADO';
    }

    return report;
  };

  const audit = runValidationAudit();

  // Generalized bracket drawing engine per category
  // Builds the full (untruncated) sorted roster of a single category — used both by
  // the "Relação Completa" modal and by the PDF export.
  const getFullRosterForCategory = (catId: string): Atleta[] => {
    const cat = categorias.find(c => c.id === catId);
    if (!cat) return [];
    const catAthletes = getCandidatesForCategory(catId);
    const generalAthletes = getCandidatesForCategory(catId, 'categoria-geral');
    const finalAthletes = catAthletes.length > 0 ? catAthletes : generalAthletes;
    return [...finalAthletes].sort((a, b) => b.rating - a.rating);
  };

  // Exports the official "Relação de Atletas Inscritos por Categoria" PDF for the
  // whole tournament — the document used to confirm registrations before the draw.
  const handleExportRelacaoGeral = () => {
    if (!selectedTorneioId) {
      triggerToast("Selecione um torneio para exportar a relação de inscritos!", "warning");
      return;
    }
    const torneio = torneios.find(t => t.id === selectedTorneioId);
    const categoriasComAtletas = categorias.map(cat => ({
      catNome: cat.nome,
      atletas: getFullRosterForCategory(cat.id)
    }));
    exportRelacaoInscritosPDF(torneio?.nome || 'Torneio', categoriasComAtletas);
  };

  const generateBracketForCategory = (catId: string, strategy: 'rating' | 'random', silent = false) => {
    if (!selectedTorneioId || !catId) return false;

    const cat = categorias.find(c => c.id === catId);
    if (!cat) return false;

    let candidates = getCandidatesForCategory(catId);
    
    // Prevent duplicate entries across other categories if enabled
    if (preventDuplicatesAcrossBrackets && selectedTorneioId) {
      const alreadyAllocatedIds = new Set<string>();
      categorias.forEach(otherCat => {
        if (otherCat.id !== catId) {
          const list = getAllocatedAthletesInOtherCategory(otherCat.id);
          list.forEach(item => alreadyAllocatedIds.add(item.id));
        }
      });

      candidates = candidates.filter(c => !alreadyAllocatedIds.has(c.id));
    }

    if (candidates.length < 2) {
      // Fallback 1: try general interest if inscriptions are empty
      candidates = getCandidatesForCategory(catId, 'categoria-geral');
      if (preventDuplicatesAcrossBrackets) {
        const alreadyAllocatedIds = new Set<string>();
        categorias.forEach(otherCat => {
          if (otherCat.id !== catId) {
            const list = getAllocatedAthletesInOtherCategory(otherCat.id);
            list.forEach(item => alreadyAllocatedIds.add(item.id));
          }
        });
        candidates = candidates.filter(c => !alreadyAllocatedIds.has(c.id));
      }
    }

    if (candidates.length < 2) {
      if (!silent) {
        triggerToast(`São necessários no mínimo 2 atletas qualificados para gerar o chaveamento da categoria "${cat.nome}"!`, "error");
      }
      return false;
    }

    // Respect Category limits by slicing candidates pool safely
    if (cat.max) {
      const categoryLimit = parseInt(cat.max, 10);
      if (candidates.length > categoryLimit) {
        candidates = candidates.slice(0, categoryLimit);
      }
    }

    // Sort according to target strategy
    if (strategy === 'rating') {
      candidates = [...candidates].sort((a, b) => b.rating - a.rating);
    } else {
      candidates = [...candidates].sort(() => Math.random() - 0.5);
    }

    // Limit to actual bracket size of 8
    const top8 = candidates.slice(0, 8);
    const qMatches = createEmptyMatches();

    if (strategy === 'rating') {
      // Professional tournament seeding (quarterfinals split by rating seeds)
      qMatches[0].p1 = top8[0] || null; qMatches[0].p2 = top8[7] || null;
      qMatches[1].p1 = top8[3] || null; qMatches[1].p2 = top8[4] || null;
      qMatches[2].p1 = top8[2] || null; qMatches[2].p2 = top8[5] || null;
      qMatches[3].p1 = top8[1] || null; qMatches[3].p2 = top8[6] || null;
    } else {
      // Random generation
      qMatches[0].p1 = top8[0] || null; qMatches[0].p2 = top8[1] || null;
      qMatches[1].p1 = top8[2] || null; qMatches[1].p2 = top8[3] || null;
      qMatches[2].p1 = top8[4] || null; qMatches[2].p2 = top8[5] || null;
      qMatches[3].p1 = top8[6] || null; qMatches[3].p2 = top8[7] || null;
    }

    // Reset score counts
    qMatches.forEach(m => {
      m.score1 = 0;
      m.score2 = 0;
    });

    const propagated = propagateBracket(qMatches);
    
    // Save to localStorage specifically for this category
    const key = `ttmpro_bracket_${selectedTorneioId}_${catId}`;
    localStorage.setItem(key, JSON.stringify({
      matches: propagated,
      generated: true
    }));

    // If it's the currently selected category, update the current screen state too!
    if (catId === selectedCategoryId) {
      setMatches(propagated);
      setBracketGenerated(true);
    }

    return true;
  };

  // Generate Brackets Engine based on selected strategy (Single category context)
  const handleGenerateBracket = (strategy: 'rating' | 'random') => {
    if (!selectedTorneioId || !selectedCategoryId) {
      triggerToast("Selecione um torneio e uma categoria para gerar!", "warning");
      return;
    }
    const success = generateBracketForCategory(selectedCategoryId, strategy);
    if (success) {
      const cat = categorias.find(c => c.id === selectedCategoryId);
      triggerToast(`Chaveamento para "${cat?.nome}" gerado via ${strategy === 'rating' ? 'Cabeças de Chave por Pontos' : 'Sorteio Aleatório'}!`, "success");
    }
  };

  // Generalized group-stage drawing engine per category (Fase de Grupos)
  const generateGroupsForCategory = (
    catId: string,
    sizePerGroup: number,
    strategy: 'rating' | 'random',
    silent = false
  ): boolean => {
    if (!selectedTorneioId || !catId) return false;
    const cat = categorias.find(c => c.id === catId);
    if (!cat) return false;

    let candidates = getCandidatesForCategory(catId);

    if (preventDuplicatesAcrossBrackets) {
      const alreadyAllocatedIds = new Set<string>();
      categorias.forEach(otherCat => {
        if (otherCat.id !== catId) {
          getAllocatedAthletesInOtherCategory(otherCat.id).forEach(item => alreadyAllocatedIds.add(item.id));
        }
      });
      candidates = candidates.filter(c => !alreadyAllocatedIds.has(c.id));
    }

    if (candidates.length < 2) {
      candidates = getCandidatesForCategory(catId, 'categoria-geral');
    }

    if (candidates.length < 3) {
      if (!silent) {
        triggerToast(`São necessários no mínimo 3 atletas para formar grupos na categoria "${cat.nome}"!`, "error");
      }
      return false;
    }

    if (cat.max) {
      const limit = parseInt(cat.max, 10);
      if (candidates.length > limit) {
        candidates = candidates.slice(0, limit);
      }
    }

    const safeSize = Math.max(2, sizePerGroup || 4);
    const numGroups = Math.max(1, Math.round(candidates.length / safeSize));
    const distributed = distributeIntoGroups(candidates, numGroups, strategy);

    const newGroups: AthleteGroup[] = distributed
      .filter(g => g.length > 0)
      .map((groupPlayers, i) => {
        const groupId = String.fromCharCode(65 + i); // A, B, C, D...
        return {
          id: groupId,
          nome: `Grupo ${groupId}`,
          atletas: groupPlayers,
          matches: generateRoundRobinMatches(groupPlayers, groupId)
        };
      });

    const key = `ttmpro_grupos_${selectedTorneioId}_${catId}`;
    localStorage.setItem(key, JSON.stringify({
      groups: newGroups,
      groupSize: safeSize,
      generated: true
    }));

    if (catId === selectedCategoryId) {
      setGroups(newGroups);
      setGroupsGenerated(true);
    }

    return true;
  };

  // Generate group stage for the currently selected category (single category context)
  const handleGenerateGroups = (strategy: 'rating' | 'random') => {
    if (!checkPermission()) return;
    if (!selectedTorneioId || !selectedCategoryId) {
      triggerToast("Selecione um torneio e uma categoria para gerar os grupos!", "warning");
      return;
    }
    const success = generateGroupsForCategory(selectedCategoryId, groupSizeInput, strategy);
    if (success) {
      const cat = categorias.find(c => c.id === selectedCategoryId);
      triggerToast(`Fase de Grupos para "${cat?.nome}" gerada via ${strategy === 'rating' ? 'Distribuição Balanceada por Rating' : 'Sorteio Aleatório'}!`, "success");
    }
  };

  // Bulk group generation for ALL categories in the tournament
  const handleGenerateAllGroups = (strategy: 'rating' | 'random') => {
    if (!checkPermission()) return;
    if (!selectedTorneioId) {
      triggerToast("Selecione um torneio primeiro!", "warning");
      return;
    }
    const confirmGen = window.confirm(
      `Deseja realmente gerar AUTOMATICAMENTE a Fase de Grupos (grupos de ${groupSizeInput} atletas) para TODAS as ${categorias.length} categorias deste torneio usando ${strategy === 'rating' ? 'Distribuição Balanceada por Rating' : 'Sorteio Aleatório'}?`
    );
    if (!confirmGen) return;

    let successCount = 0;
    categorias.forEach(cat => {
      const ok = generateGroupsForCategory(cat.id, groupSizeInput, strategy, true);
      if (ok) successCount++;
    });
    triggerToast(`⚡ Fase de Grupos gerada para ${successCount} de ${categorias.length} categorias!`, "success");
  };

  // Update the score of one match inside one group, recompute status, and persist
  const handleUpdateGroupScore = (groupId: string, matchId: string, field: 'score1' | 'score2', delta: number) => {
    if (!checkPermission()) return;
    const updatedGroups = groups.map(g => {
      if (g.id !== groupId) return g;
      return {
        ...g,
        matches: g.matches.map(m => {
          if (m.id !== matchId) return m;
          const newScore = Math.max(0, (m[field] || 0) + delta);
          const updatedMatch = { ...m, [field]: newScore };
          updatedMatch.status = (updatedMatch.score1 > 0 || updatedMatch.score2 > 0) ? 'Concluído' : 'Aguardando';
          return updatedMatch;
        })
      };
    });
    setGroups(updatedGroups);
    if (selectedTorneioId && selectedCategoryId) {
      const key = `ttmpro_grupos_${selectedTorneioId}_${selectedCategoryId}`;
      localStorage.setItem(key, JSON.stringify({
        groups: updatedGroups,
        groupSize: groupSizeInput,
        generated: true
      }));
    }
  };

  // Clears the group stage of the currently selected category
  const handleResetGroups = () => {
    if (!checkPermission()) return;
    if (!selectedTorneioId || !selectedCategoryId) return;
    const confirmReset = window.confirm("Deseja realmente APAGAR a Fase de Grupos desta categoria? Esta ação não pode ser desfeita.");
    if (!confirmReset) return;
    const key = `ttmpro_grupos_${selectedTorneioId}_${selectedCategoryId}`;
    localStorage.removeItem(key);
    setGroups([]);
    setGroupsGenerated(false);
    triggerToast("Fase de Grupos removida com sucesso!", "info");
  };

  // Automating Bulk Bracket Generation for ALL categories in the tournament
  const handleGenerateAllBrackets = (strategy: 'rating' | 'random') => {
    if (!selectedTorneioId) {
      triggerToast("Selecione um torneio primeiro!", "warning");
      return;
    }
    if (userRole === 'comum') {
      triggerToast("Erro de Permissão: Apenas o administrador oficial de e-mail pode modificar chaveamentos!", "error");
      return;
    }

    const confirmGen = window.confirm(
      `Deseja realmente gerar AUTOMATICAMENTE o chaveamento para TODAS as ${categorias.length} categorias deste torneio usando a estratégia de ${strategy === 'rating' ? 'Rating/Pontos' : 'Sorteio Aleatório'}?`
    );
    if (!confirmGen) return;

    let successCount = 0;
    categorias.forEach(cat => {
      const candidates = getCandidatesForCategory(cat.id);
      const generalCandidates = getCandidatesForCategory(cat.id, 'categoria-geral');
      if (candidates.length >= 2 || generalCandidates.length >= 2) {
        const ok = generateBracketForCategory(cat.id, strategy, true);
        if (ok) successCount++;
      }
    });

    // Reload active category if one was selected
    if (selectedCategoryId) {
      const key = `ttmpro_bracket_${selectedTorneioId}_${selectedCategoryId}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setMatches(propagateBracket(parsed.matches));
          setBracketGenerated(parsed.generated || false);
        } catch (e) {
          console.error(e);
        }
      }
    }

    triggerToast(`Chaveamento automático concluído! ${successCount} de ${categorias.length} categorias desenhadas com sucesso.`, "success");
  };

  // Automating Bulk Bracket Generation specifically BY AGE CATEGORIES (Data de Nascimento)
  const handleGenerateAllBracketsByAge = () => {
    if (!selectedTorneioId) {
      triggerToast("Selecione um torneio primeiro!", "warning");
      return;
    }
    if (userRole === 'comum') {
      triggerToast("Erro de Permissão: Apenas o administrador oficial de e-mail pode modificar chaveamentos!", "error");
      return;
    }

    const confirmGen = window.confirm(
      `Deseja executar o CHAVEAMENTO AUTOMÁTICO POR IDADE para TODAS as ${categorias.length} categorias do torneio? Os atletas serão filtrados e agrupados automaticamente segundo a data de nascimento e idade calculada.`
    );
    if (!confirmGen) return;

    let successCount = 0;
    categorias.forEach(cat => {
      let candidates = getCandidatesForCategory(cat.id, 'idade-auto');
      if (candidates.length < 2) {
        candidates = getCandidatesForCategory(cat.id, 'categoria-geral');
      }

      if (candidates.length >= 2) {
        const ok = generateBracketForCategory(cat.id, 'rating', true);
        if (ok) successCount++;
      }
    });

    if (selectedCategoryId) {
      const key = `ttmpro_bracket_${selectedTorneioId}_${selectedCategoryId}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          setMatches(propagateBracket(parsed.matches));
          setBracketGenerated(parsed.generated || false);
        } catch (e) {
          console.error(e);
        }
      }
    }

    triggerToast(`⚡ Chaveamento Automático por Idade concluído! ${successCount} de ${categorias.length} categorias desenhadas por faixa etária.`, "success");
  };

  // Handle Score Updates & Propagation
  const handleUpdateScore = (matchId: string, playerNum: 1 | 2, currentScore: number, increment: number) => {
    const newScore = Math.max(0, currentScore + increment);
    
    const updated = matches.map(m => {
      if (m.id === matchId) {
        if (playerNum === 1) {
          return { ...m, score1: newScore };
        } else {
          return { ...m, score2: newScore };
        }
      }
      return m;
    });

    const propagated = propagateBracket(updated);
    saveBracket(propagated, true);
  };

  // Assign athlete to slot manually and check for multiple allocations instantly
  const handleUpdateSeed = (matchId: string, playerNum: 1 | 2, athleteId: string) => {
    if (!athleteId) {
      const updated = matches.map(m => {
        if (m.id === matchId) {
          if (playerNum === 1) return { ...m, p1: null };
          return { ...m, p2: null };
        }
        return m;
      });
      const propagated = propagateBracket(updated);
      saveBracket(propagated, true);
      return;
    }

    // 1. Check duplicate within the CURRENT bracket matches (No double registry inside key)
    const isAlreadyAllocatedInSelf = matches.some(m => 
      m.round === 'quartas' && 
      (m.p1?.id === athleteId || m.p2?.id === athleteId)
    );

    if (isAlreadyAllocatedInSelf) {
      triggerToast("Erro de Duplicidade: Este atleta já está escalado em outra partida no chaveamento atual!", "error");
      return;
    }

    // 2. Check duplicate across OTHER brackets in this tournament
    if (preventDuplicatesAcrossBrackets && selectedTorneioId) {
      let isEnrolledElsewhere = false;
      let matchedOtherCategory = '';

      categorias.forEach(otherCat => {
        if (otherCat.id !== selectedCategoryId) {
          const others = getAllocatedAthletesInOtherCategory(otherCat.id);
          if (others.some(oa => oa.id === athleteId)) {
            isEnrolledElsewhere = true;
            matchedOtherCategory = otherCat.nome;
          }
        }
      });

      if (isEnrolledElsewhere) {
        const confirmSkip = window.confirm(
          `AVISO DE DUPLICIDADE: O atleta selecionado já está alocado na categoria "${matchedOtherCategory}" para este torneio. Deseja realmente aloca-lo em duas chaves distintas?`
        );
        if (!confirmSkip) return;
      }
    }

    const selectedAthlete = atletas.find(a => a.id === athleteId) || null;
    
    const updated = matches.map(m => {
      if (m.id === matchId) {
        if (playerNum === 1) {
          return { ...m, p1: selectedAthlete };
        } else {
          return { ...m, p2: selectedAthlete };
        }
      }
      return m;
    });

    const propagated = propagateBracket(updated);
    saveBracket(propagated, true);
    triggerToast("Atleta alocado no chaveamento com sucesso!", "success");
  };

  // Clear Bracket
  const handleClearBracket = () => {
    if (window.confirm("Deseja realmente limpar e excluir este chaveamento?")) {
      saveBracket(createEmptyMatches(), false);
      triggerToast("Chaveamento redefinido e limpo!", "warning");
    }
  };

  const qMatches = matches.filter(m => m.round === 'quartas');
  const sMatches = matches.filter(m => m.round === 'semis');
  const fMatch = matches.find(m => m.round === 'final') || createEmptyMatches()[6];

  // Derive Champion
  const getFinalChampion = (): Atleta | null => {
    if (!fMatch.p1 && !fMatch.p2) return null;
    if (fMatch.p1 && !fMatch.p2) return fMatch.p1;
    if (!fMatch.p1 && fMatch.p2) return fMatch.p2;
    return fMatch.score1 > fMatch.score2 ? fMatch.p1 : (fMatch.score2 > fMatch.score1 ? fMatch.p2 : fMatch.p1);
  };

  const champion = getFinalChampion();
  const dropdownCandidates = getCandidatesForSelection().length > 0 
    ? getCandidatesForSelection() 
    : atletas.filter(a => a.status === 'Ativo');

  return (
    <div className="space-y-6 chaveamento-view">
      
      {userRole === 'comum' && (
        <div className="p-3.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl flex items-center gap-3 text-xs leading-normal font-medium">
          <Info className="w-5 h-5 shrink-0 text-blue-400" />
          <div>
            <strong>Modo de Visualização (Apenas Leitura):</strong> Somente o administrador oficial (<strong>schmidtvagner@gmail.com</strong>) tem privilégios para gerar chaveamentos, alterar placares, redefinir ou salvar chaves. OUTROS USUÁRIOS estão estritamente proibidos de realizar modificações.
          </div>
        </div>
      )}

      {/* Tab Selector: Categories vs Tree View vs Escala Automática */}
      <div className="flex border-b border-slate-800 gap-2 overflow-x-auto">
        <button
          onClick={() => setViewTab('categorias')}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${viewTab === 'categorias' ? 'border-yellow-400 text-yellow-400 bg-yellow-405/5' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
        >
          <Users className="w-4 h-4" />
          Divisões por Categoria & Chaveamento em Massa
        </button>
        <button
          onClick={() => setViewTab('arvore')}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${viewTab === 'arvore' ? 'border-yellow-400 text-yellow-400 bg-yellow-405/5' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
        >
          <GitBranch className="w-4 h-4" />
          Visualização da Árvore de Disputa
        </button>
        <button
          onClick={() => setViewTab('grupos')}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${viewTab === 'grupos' ? 'border-sky-400 text-sky-400 bg-sky-500/10' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
        >
          <Users className="w-4 h-4 text-sky-400" />
          Fase de Grupos
          {groupsGenerated && groups.length > 0 && (
            <span className="ml-1 bg-sky-500/20 text-sky-400 text-[10px] font-mono px-2 py-0.5 rounded-full border border-sky-500/30">
              {groups.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setViewTab('escala')}
          className={`px-4 py-2.5 text-xs font-extrabold uppercase tracking-wider border-b-2 transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${viewTab === 'escala' ? 'border-emerald-400 text-emerald-400 bg-emerald-500/10' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
        >
          <Calendar className="w-4 h-4 text-emerald-400" />
          📅 Escala Automática de Jogos (Horários & Mesas)
          {scheduledGames.length > 0 && (
            <span className="ml-1 bg-emerald-500/20 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">
              {scheduledGames.length}
            </span>
          )}
        </button>
      </div>

      {viewTab === 'categorias' ? (
        <div className="space-y-6">
          {/* Main Select Torneio Bar for Categories view */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-slate-900 p-4 border border-slate-800 rounded-xl shadow-lg">
            <div className="space-y-1.5 flex-1 max-w-md">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Torneio Ativo</span>
              <select
                value={selectedTorneioId}
                onChange={(e) => { 
                  setSelectedTorneioId(e.target.value); 
                  setSelectedCategoryId('');
                }}
                className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-xl px-3 py-2 text-xs outline-none transition"
              >
                <option value="">Selecionar torneio...</option>
                {torneios.map(t => (
                  <option key={t.id} value={t.id}>{t.nome}</option>
                ))}
              </select>
            </div>

            {selectedTorneioId && (
              <div className="flex flex-wrap gap-2 pt-2 sm:pt-0">
                <button
                  type="button"
                  onClick={handleExportRelacaoGeral}
                  className="px-3.5 py-2 bg-slate-850 hover:bg-slate-800 border border-slate-700 text-slate-100 font-black rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md"
                  title="Gerar PDF com a relação de todos os atletas inscritos, por categoria"
                >
                  <FileText className="w-3.5 h-3.5 text-yellow-400" />
                  📋 Relação de Inscritos (PDF)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    generateAutomaticMasterSchedule();
                    setViewTab('escala');
                  }}
                  disabled={userRole === 'comum'}
                  className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                  ⚡ Escala Automática de Jogos
                </button>
                <button
                  type="button"
                  onClick={handleGenerateAllBracketsByAge}
                  disabled={userRole === 'comum'}
                  className="px-3 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-black rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <ListFilter className="w-3.5 h-3.5 text-slate-950" />
                  Chaveamento por Idade
                </button>
                <button
                  type="button"
                  onClick={() => handleGenerateAllBrackets('rating')}
                  disabled={userRole === 'comum'}
                  className="px-3 py-2 bg-yellow-400 hover:bg-yellow-300 disabled:bg-slate-800 disabled:text-slate-550 text-slate-950 font-extrabold rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Trophy className="w-3.5 h-3.5" />
                  Rating 🏆
                </button>
                <button
                  type="button"
                  onClick={() => handleGenerateAllBrackets('random')}
                  disabled={userRole === 'comum'}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-750 disabled:bg-slate-805 disabled:text-slate-550 text-slate-200 font-extrabold rounded-lg text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
                >
                  <Shuffle className="w-3.5 h-3.5" />
                  Sorteio 🎲
                </button>
              </div>
            )}
          </div>

          {!selectedTorneioId ? (
            <div className="text-center py-16 sm:py-20 bg-slate-900 border border-slate-800/60 rounded-xl text-slate-500 space-y-4 max-w-md mx-auto p-4">
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-slate-850 border border-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto text-lg sm:text-xl shrink-0">
                🏆
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-slate-300">Escolha um Torneio</h5>
                <p className="text-xs text-slate-500 leading-normal">
                  Selecione um torneio ativo acima para separar automaticamente os atletas por suas respectivas categorias e gerar as chaves de disputa de forma automatizada.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Automated Registration & Presence Information Bar */}
              <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-yellow-950/30 border border-yellow-500/30 rounded-xl p-3.5 space-y-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div className="flex items-start gap-3 text-xs text-yellow-200">
                    <Sparkles className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-yellow-300 font-bold block mb-0.5">
                        Inscrições Automáticas Interligadas por Categoria:
                      </strong>
                      Todos os atletas cadastrados no sistema já estão <strong>inscritos por padrão</strong> em suas respectivas categorias. Para o chaveamento, basta confirmar a presença dos atletas na mesa organizadora no dia do campeonato.
                    </div>
                  </div>

                  <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-950 border border-slate-800 hover:border-yellow-500/50 rounded-lg text-xs text-slate-300 font-medium cursor-pointer shrink-0 transition">
                    <input
                      type="checkbox"
                      checked={onlyConfirmedPresence}
                      onChange={(e) => setOnlyConfirmedPresence(e.target.checked)}
                      className="accent-yellow-400 w-3.5 h-3.5 rounded"
                    />
                    <span>Filtrar Apenas Presença Confirmada (Mesa)</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {categorias.map(cat => {
                // Check if bracket already exists
                const key = `ttmpro_bracket_${selectedTorneioId}_${cat.id}`;
                const saved = localStorage.getItem(key);
                let isGenerated = false;
                if (saved) {
                  try {
                    const parsed = JSON.parse(saved);
                    isGenerated = parsed.generated || false;
                  } catch (e) {
                    console.error(e);
                  }
                }

                // Get athletes in this category
                const catAthletes = getCandidatesForCategory(cat.id);
                const generalAthletes = getCandidatesForCategory(cat.id, 'categoria-geral');
                const finalAthletes = catAthletes.length > 0 ? catAthletes : generalAthletes;

                // Presence stats
                const confirmedInCat = finalAthletes.filter(a => (a.presenca || 'CONFIRMADA') === 'CONFIRMADA').length;
                const pendingInCat = finalAthletes.length - confirmedInCat;

                return (
                  <div key={cat.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-750 transition space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="font-black text-slate-100 text-xs uppercase tracking-wider">
                            {cat.nome}
                          </h4>
                          <span className="text-4xs font-bold text-slate-500 uppercase tracking-widest block">
                            Modalidade: {cat.fmt} | Limite: {cat.max || 'Ilimitado'} atletas
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {isGenerated ? (
                            <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-2 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Ativo
                            </span>
                          ) : (
                            <span className="bg-amber-950/80 text-amber-400 border border-amber-800/60 px-2 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3 text-amber-400" /> Pendente
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Display list of separated athletes in this category */}
                      <div className="space-y-1 bg-slate-950/50 p-2.5 rounded-lg border border-slate-850">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1.5">
                          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">
                            Atletas Na Categoria ({finalAthletes.length})
                          </span>
                          <div className="flex items-center gap-1.5 text-4xs">
                            <span className="text-emerald-400 font-bold">{confirmedInCat} Conf.</span>
                            {pendingInCat > 0 && (
                              <span className="text-amber-400 font-bold">| {pendingInCat} Pend.</span>
                            )}
                            <button
                              type="button"
                              onClick={() => handleConfirmPresenceBulk(cat.id)}
                              className="ml-1 text-[9px] bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.5 rounded font-extrabold transition cursor-pointer"
                              title="Confirmar presença de todos desta categoria"
                            >
                              ✓ Confirmar Todos
                            </button>
                            {finalAthletes.length > 0 && (
                              <button
                                type="button"
                                onClick={() => setRelacaoModalCatId(cat.id)}
                                className="ml-1 text-[9px] bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-300 border border-yellow-500/40 px-1.5 py-0.5 rounded font-extrabold transition cursor-pointer"
                                title="Ver relação completa de inscritos desta categoria"
                              >
                                📋 Relação
                              </button>
                            )}
                          </div>
                        </div>

                        {finalAthletes.length === 0 ? (
                          <span className="text-3xs text-slate-500 italic block py-1.5 text-center">
                            Nenhum atleta separado para esta categoria.
                          </span>
                        ) : (
                          <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                            {finalAthletes.slice(0, 10).map((ath, idx) => {
                              const ageVal = calculateAge(ath.nasc);
                              const isConfirmed = (ath.presenca || 'CONFIRMADA') === 'CONFIRMADA';
                              return (
                                <div key={ath.id} className="flex items-center justify-between text-3xs text-slate-300 py-1 border-b border-slate-850/40 last:border-0 gap-2">
                                  <div className="flex items-center gap-1.5 truncate max-w-[170px]">
                                    <span className="font-mono text-slate-500 text-4xs">#{idx + 1}</span>
                                    <span className="font-bold truncate">{ath.nome}</span>
                                    {ageVal > 0 && (
                                      <span className="text-[9px] bg-cyan-950/70 text-cyan-400 border border-cyan-800/40 px-1 py-0.2 rounded font-extrabold shrink-0">
                                        {ageVal}a
                                      </span>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-1.5 text-4xs shrink-0">
                                    <span className="bg-slate-900 border border-slate-800 text-yellow-500 font-bold px-1 py-0.5 rounded">
                                      {ath.rating} pts
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleTogglePresenceAtleta(ath)}
                                      className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold border transition cursor-pointer ${
                                        isConfirmed
                                          ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/60 hover:bg-emerald-900'
                                          : 'bg-amber-950/80 text-amber-400 border-amber-800/60 hover:bg-amber-900'
                                      }`}
                                      title="Clique para alternar presença"
                                    >
                                      {isConfirmed ? '✓ Presença' : '⚡ Confirmar'}
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                            {finalAthletes.length > 10 && (
                              <span className="text-4xs text-slate-500 italic text-center block pt-1">
                                + {finalAthletes.length - 10} outros atletas...
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action buttons inside Card */}
                    <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-850/60">
                      <button
                        type="button"
                        onClick={() => {
                          const ok = generateBracketForCategory(cat.id, 'rating');
                          if (ok) {
                            triggerToast(`Chaveamento gerado por Rating para ${cat.nome}!`, "success");
                          }
                        }}
                        disabled={finalAthletes.length < 2}
                        className="flex-1 min-w-[75px] px-2 py-1.5 bg-yellow-400 hover:bg-yellow-300 disabled:bg-slate-800 disabled:text-slate-550 text-slate-950 font-black rounded text-[10px] flex items-center justify-center gap-1 cursor-pointer transition"
                      >
                        Rating 🏆
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const ok = generateBracketForCategory(cat.id, 'random');
                          if (ok) {
                            triggerToast(`Chaveamento gerado por Sorteio para ${cat.nome}!`, "success");
                          }
                        }}
                        disabled={finalAthletes.length < 2}
                        className="flex-1 min-w-[75px] px-2 py-1.5 bg-slate-800 hover:bg-slate-750 disabled:bg-slate-805 disabled:text-slate-550 text-slate-200 font-black border border-slate-700 rounded text-[10px] flex items-center justify-center gap-1 cursor-pointer transition"
                      >
                        Sorteio 🎲
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          // Select this category and switch view tab
                          setSelectedCategoryId(cat.id);
                          setViewTab('arvore');
                          // Load bracket matches from storage or generate if missing
                          const saved = localStorage.getItem(`ttmpro_bracket_${selectedTorneioId}_${cat.id}`);
                          if (saved) {
                            const parsed = JSON.parse(saved);
                            setMatches(parsed.matches);
                            setBracketGenerated(parsed.generated);
                          } else {
                            setMatches(createEmptyMatches());
                            setBracketGenerated(false);
                          }
                        }}
                        className="flex-1 min-w-[75px] px-2 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-400 font-black border border-cyan-800 rounded text-[10px] flex items-center justify-center gap-1 cursor-pointer transition"
                      >
                        Ver Árvore 📊
                      </button>
                      {isGenerated && userRole !== 'comum' && (
                        <button
                          type="button"
                          onClick={() => {
                            if (window.confirm(`Deseja realmente limpar o chaveamento de ${cat.nome}?`)) {
                              localStorage.removeItem(key);
                              if (selectedCategoryId === cat.id) {
                                setMatches(createEmptyMatches());
                                setBracketGenerated(false);
                              }
                              triggerToast("Chaveamento limpo com sucesso!", "warning");
                            }
                          }}
                          className="px-2 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-400 rounded border border-red-800/40 font-bold text-[10px] flex items-center justify-center cursor-pointer transition"
                          title="Limpar chaveamento"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
      ) : viewTab === 'arvore' ? (
        <>
          {/* Info Warning card for correct alignment usage */}
      <div className="rounded-xl border border-blue-500/10 bg-blue-500/5 p-4 flex gap-3">
        <AlertCircle className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs">
          <h5 className="font-bold text-blue-400 uppercase tracking-widest text-[10.5px]">
            ⚡ Acertos, Modificações e Sorteios do Chaveamento
          </h5>
          <p className="text-slate-300 leading-relaxed font-medium">
            Você pode realizar modificações em tempo real para organizar as disputas. 
            Nos slots de <strong>Quartas de Final</strong>, ajuste os atletas usando os botões de seleção de cabeça de chave. 
            Modifique os sets usando os botões <span className="bg-slate-950 px-1 py-0.5 rounded border border-slate-850 font-bold text-yellow-500 font-mono">-</span> e <span className="bg-slate-950 px-1 py-0.5 rounded border border-slate-850 font-bold text-yellow-500 font-mono">+</span> de cada atleta para classificar os vencedores para a rodada seguinte automaticamente!
          </p>
        </div>
      </div>

      {/* Bracket Tree Layout Board */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-md overflow-hidden min-h-[500px]">
        
        <div className="pb-4 mb-6 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-yellow-500" />
            <div>
              <h4 className="font-extrabold text-slate-100 text-sm uppercase tracking-wider">
                Árvore de Disputa & Ajustes de Chaves
              </h4>
              <span className="text-3xs font-extrabold text-slate-500 uppercase tracking-widest block">
                {selectedTorneio?.nome || 'Nenhum torneio'} | {selectedCat?.nome || 'Nenhuma categoria'}
              </span>
            </div>
          </div>

          {bracketGenerated && (
            <div className="bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-4xs font-black uppercase tracking-widest px-2.5 py-1.5 rounded-lg flex items-center gap-1">
              <CheckSquare className="w-3.5 h-3.5" /> Sincronizado Localmente (Auto-Save)
            </div>
          )}
        </div>

        {bracketGenerated ? (
          <div className="overflow-x-auto pb-4 pt-2">
            <div className="min-w-[1000px] grid grid-cols-4 gap-6 items-center">
              
              {/* 1. QUARTERFINALS COLUMN */}
              <div className="space-y-6">
                <div className="text-4xs uppercase tracking-widest text-slate-500 font-black text-center border-b border-slate-805/80 pb-2">
                  Quartas de Final (1/4)
                </div>
                {qMatches.map((m) => (
                  <div key={m.id} className="relative bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-3.5 shadow-xl hover:border-slate-700 transition">
                    
                    {/* Identification Badge Top Right */}
                    <span className="absolute top-2.5 right-2.5 bg-slate-900 text-slate-500 font-mono text-[9px] font-extrabold px-1.5 py-0.5 rounded border border-slate-800">
                      M{m.id.toUpperCase()}
                    </span>

                    {/* PLAYER 1 SLOT */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        {/* Selector / Head of Key */}
                        <select
                          value={m.p1?.id || ''}
                          onChange={(e) => handleUpdateSeed(m.id, 1, e.target.value)}
                          disabled={userRole === 'comum'}
                          className="flex-1 bg-slate-900 border border-slate-800 focus:border-yellow-400 text-slate-150 rounded-lg px-2 py-1 text-2xs font-extrabold outline-none transition disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                          <option value="">-- {m.p1 ? 'Mudar Atleta 1' : 'BYE (W.O. / Vazio)'} --</option>
                          {dropdownCandidates.map(a => (
                            <option key={a.id} value={a.id}>{a.nome} (Rating: {a.rating})</option>
                          ))}
                        </select>

                        {/* Player 1 Score clickers */}
                        {m.p1 && (
                          <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800">
                            {userRole !== 'comum' && (
                              <button
                                type="button"
                                onClick={() => handleUpdateScore(m.id, 1, m.score1, -1)}
                                className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                              >
                                -
                              </button>
                            )}
                            <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">
                              {m.score1}
                            </span>
                            {userRole !== 'comum' && (
                              <button
                                type="button"
                                onClick={() => handleUpdateScore(m.id, 1, m.score1, 1)}
                                className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                              >
                                +
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {m.p1 ? (
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 pl-1 font-mono">
                          <Shield className="w-3 h-3 text-cyan-400 shrink-0" />
                          <span className="truncate max-w-[120px]">{m.p1.clube || 'Sem clube'}</span>
                           <span className="text-[10px] text-slate-500">({m.p1.rating} pts)</span>
                        </div>
                      ) : (
                        <span className="text-[10.5px] pl-1 font-bold text-slate-600 block italic">Classificação Direta (BYE)</span>
                      )}
                    </div>

                    <div className="border-t border-slate-850/80"></div>

                    {/* PLAYER 2 SLOT */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        {/* Selector / Head of Key */}
                        <select
                          value={m.p2?.id || ''}
                          onChange={(e) => handleUpdateSeed(m.id, 2, e.target.value)}
                          disabled={userRole === 'comum'}
                          className="flex-1 bg-slate-900 border border-slate-800 focus:border-yellow-400 text-slate-150 rounded-lg px-2 py-1 text-2xs font-extrabold outline-none transition disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                          <option value="">-- {m.p2 ? 'Mudar Atleta 2' : 'BYE (W.O. / Vazio)'} --</option>
                          {dropdownCandidates.map(a => (
                            <option key={a.id} value={a.id}>{a.nome} (Rating: {a.rating})</option>
                          ))}
                        </select>

                        {/* Player 2 Score clickers */}
                        {m.p2 && (
                          <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800">
                            {userRole !== 'comum' && (
                              <button
                                type="button"
                                onClick={() => handleUpdateScore(m.id, 2, m.score2, -1)}
                                className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                              >
                                -
                              </button>
                            )}
                            <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">
                              {m.score2}
                            </span>
                            {userRole !== 'comum' && (
                              <button
                                type="button"
                                onClick={() => handleUpdateScore(m.id, 2, m.score2, 1)}
                                className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                              >
                                +
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {m.p2 ? (
                        <div className="flex items-center gap-1 text-[10px] text-slate-400 pl-1 font-mono">
                          <Shield className="w-3 h-3 text-cyan-400 shrink-0" />
                          <span className="truncate max-w-[120px]">{m.p2.clube || 'Sem clube'}</span>
                          <span className="text-[10px] text-slate-500">({m.p2.rating} pts)</span>
                        </div>
                      ) : (
                        <span className="text-[10.5px] pl-1 font-bold text-slate-600 block italic">Classificação Direta (BYE)</span>
                      )}
                    </div>

                  </div>
                ))}
              </div>

              {/* 2. SEMIFINALS COLUMN */}
              <div className="space-y-20 pt-10">
                <div className="text-4xs uppercase tracking-widest text-slate-500 font-black text-center border-b border-slate-805/80 pb-2">
                  Semifinais (1/2)
                </div>
                {sMatches.map((m) => (
                  <div key={m.id} className="relative bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-4 shadow-xl">
                    <span className="absolute top-2.5 right-2.5 bg-slate-900 text-slate-500 font-mono text-[9px] font-extrabold px-1.5 py-0.5 rounded border border-slate-800">
                      M{m.id.toUpperCase()}
                    </span>

                    {/* Player 1 Advanced state */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex-1 truncate">
                        <span className="text-2xs uppercase tracking-wider text-slate-500 font-black block leading-none">Vencedor Quadra A</span>
                        <span className={`text-xs font-extrabold truncate block mt-1 ${m.score1 > m.score2 ? 'text-yellow-400' : 'text-slate-200'}`}>
                          {m.p1?.nome || 'Aguardando...'}
                        </span>
                      </div>
                      {m.p1 && (
                        <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 shrink-0">
                          {userRole !== 'comum' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateScore(m.id, 1, m.score1, -1)}
                              className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                            >
                              -
                            </button>
                          )}
                          <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">{m.score1}</span>
                          {userRole !== 'comum' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateScore(m.id, 1, m.score1, 1)}
                              className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                            >
                              +
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="border-t border-slate-850/80"></div>

                    {/* Player 2 Advanced state */}
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex-1 truncate">
                        <span className="text-2xs uppercase tracking-wider text-slate-500 font-black block leading-none">Vencedor Quadra B</span>
                        <span className={`text-xs font-extrabold truncate block mt-1 ${m.score2 > m.score1 ? 'text-yellow-400' : 'text-slate-200'}`}>
                          {m.p2?.nome || 'Aguardando...'}
                        </span>
                      </div>
                      {m.p2 && (
                        <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 shrink-0">
                          {userRole !== 'comum' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateScore(m.id, 2, m.score2, -1)}
                              className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                            >
                              -
                            </button>
                          )}
                          <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">{m.score2}</span>
                          {userRole !== 'comum' && (
                            <button
                              type="button"
                              onClick={() => handleUpdateScore(m.id, 2, m.score2, 1)}
                              className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                            >
                              +
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* 3. GRANDE FINAL COLUMN */}
              <div className="space-y-4 pt-16">
                <div className="text-4xs uppercase tracking-widest text-slate-500 font-black text-center border-b border-slate-805/80 pb-2">
                  Grande Final (Local)
                </div>
                <div className="relative bg-slate-950 border-2 border-yellow-400 rounded-2xl p-5 space-y-4 shadow-xl">
                  <span className="absolute top-2.5 right-2.5 bg-slate-900 text-slate-500 font-mono text-[9px] font-extrabold px-1.5 py-0.5 rounded border border-slate-800">
                    M{fMatch.id.toUpperCase()}
                  </span>

                  {/* Player 1 finalist */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 truncate">
                      <span className="text-2xs uppercase tracking-wider text-slate-500 font-black block leading-none">Chave Superior</span>
                      <span className={`text-xs font-black truncate block mt-1 ${fMatch.score1 > fMatch.score2 ? 'text-yellow-450' : 'text-slate-200'}`}>
                        {fMatch.p1?.nome || 'Aguardando...'}
                      </span>
                    </div>
                    {fMatch.p1 && (
                      <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 shrink-0">
                        {userRole !== 'comum' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateScore(fMatch.id, 1, fMatch.score1, -1)}
                            className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                          >
                            -
                          </button>
                        )}
                        <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">{fMatch.score1}</span>
                        {userRole !== 'comum' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateScore(fMatch.id, 1, fMatch.score1, 1)}
                            className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="border-t border-slate-850/80"></div>

                  {/* Player 2 finalist */}
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 truncate">
                      <span className="text-2xs uppercase tracking-wider text-slate-500 font-black block leading-none">Chave Inferior</span>
                      <span className={`text-xs font-black truncate block mt-1 ${fMatch.score2 > fMatch.score1 ? 'text-yellow-450' : 'text-slate-200'}`}>
                        {fMatch.p2?.nome || 'Aguardando...'}
                      </span>
                    </div>
                    {fMatch.p2 && (
                      <div className="flex items-center gap-1.5 bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 shrink-0">
                        {userRole !== 'comum' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateScore(fMatch.id, 2, fMatch.score2, -1)}
                            className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                          >
                            -
                          </button>
                        )}
                        <span className="font-mono text-xs font-black text-yellow-400 w-4 text-center">{fMatch.score2}</span>
                        {userRole !== 'comum' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateScore(fMatch.id, 2, fMatch.score2, 1)}
                            className="w-5 h-5 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition text-[11px] font-extrabold flex items-center justify-center rounded cursor-pointer"
                          >
                            +
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* 4. CHAMPION BOARD */}
              <div className="flex flex-col items-center justify-center p-6 border-l border-slate-800/80">
                <div className="relative">
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-yellow-400/10 border-2 border-yellow-400/50 text-yellow-400 flex items-center justify-center font-black animate-pulse shadow-xl text-2xl sm:text-3xl shrink-0">
                    🏆
                  </div>
                  <div className="absolute -bottom-1.5 -right-1 bg-yellow-400 text-slate-950 rounded-full p-1 border-2 border-slate-900">
                    <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                  </div>
                </div>
                
                <span className="text-4xs uppercase tracking-widest text-slate-500 font-extrabold block text-center mb-1.5 mt-5">
                  Campeão da Categoria
                </span>

                <span className="text-sm font-black text-slate-200 text-center truncate max-w-[180px] block leading-snug">
                  {champion ? champion.nome : 'A disputar...'}
                </span>

                {champion && (
                  <div className="space-y-1 mt-2 mb-1 flex flex-col items-center">
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800 font-mono text-[10px] text-yellow-400">
                      Rating: {champion.rating} pts
                    </span>
                    <span className="block text-3xs text-slate-400 italic text-center">
                      Clube: {champion.clube || 'Sem clube definido'}
                    </span>
                  </div>
                )}
              </div>

            </div>
          </div>
        ) : (
          <div className="text-center py-16 sm:py-20 text-slate-500 space-y-4 max-w-sm mx-auto p-4">
            <div className="w-10 h-10 sm:w-11 sm:h-11 bg-slate-850 border border-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto text-lg sm:text-xl shrink-0">
              📊
            </div>
            <div className="space-y-1">
              <h5 className="font-bold text-slate-300">Chaveamento não gerado</h5>
              <p className="text-xs text-slate-500 leading-normal">
                Selecione o Torneio e a Categoria de interesse, em seguida escolha entre gerar por <strong>Rating Oficial</strong> ou <strong>Sorteio Aleatório</strong>.
              </p>
            </div>
          </div>
        )}

      </div>

        </>
      ) : viewTab === 'grupos' ? (
        <div className="space-y-6">
          {/* Torneio & Categoria selector, shared with other tabs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-slate-900 p-4 border border-slate-800 rounded-xl shadow-lg">
            <div className="space-y-1.5 flex-1 max-w-md">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Torneio Ativo</span>
              <select
                value={selectedTorneioId}
                onChange={(e) => setSelectedTorneioId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-sky-400 text-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none transition font-semibold"
              >
                <option value="">Selecione um torneio</option>
                {torneios.map(t => (
                  <option key={t.id} value={t.id}>{t.nome}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5 flex-1 max-w-md">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Categoria</span>
              <select
                value={selectedCategoryId}
                onChange={(e) => setSelectedCategoryId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-sky-400 text-slate-200 rounded-lg px-3 py-2.5 text-sm outline-none transition font-semibold"
              >
                <option value="">Selecione uma categoria</option>
                {categorias.map(c => (
                  <option key={c.id} value={c.id}>{c.nome}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Generation controls */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-lg">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end justify-between">
              <div className="space-y-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 block">Atletas por Grupo</span>
                <input
                  type="number"
                  min={2}
                  max={10}
                  value={groupSizeInput}
                  onChange={(e) => setGroupSizeInput(Math.max(2, parseInt(e.target.value, 10) || 4))}
                  className="w-28 bg-slate-950 border border-slate-800 focus:border-sky-400 text-slate-200 rounded-lg px-3 py-2 text-sm outline-none transition font-mono font-bold text-center"
                />
                <p className="text-2xs text-slate-500">Os atletas serão divididos automaticamente no número de grupos necessário.</p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => handleGenerateGroups('rating')}
                  disabled={!selectedTorneioId || !selectedCategoryId}
                  className="bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-extrabold px-4 py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer transition shadow-sm"
                >
                  <Award className="w-4 h-4" />
                  Gerar Balanceado (Rating)
                </button>
                <button
                  onClick={() => handleGenerateGroups('random')}
                  disabled={!selectedTorneioId || !selectedCategoryId}
                  className="bg-slate-850 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700 text-slate-100 font-extrabold px-4 py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer transition shadow-sm"
                >
                  <Shuffle className="w-4 h-4" />
                  Sorteio Aleatório
                </button>
                {groupsGenerated && groups.length > 0 && (
                  <button
                    onClick={handleResetGroups}
                    className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 font-extrabold px-4 py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer transition"
                  >
                    <Trash2 className="w-4 h-4" />
                    Apagar Grupos
                  </button>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex flex-wrap gap-2">
              <button
                onClick={() => handleGenerateAllGroups('rating')}
                disabled={!selectedTorneioId}
                className="bg-slate-850 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed border border-sky-500/30 text-sky-400 font-bold px-3.5 py-2 rounded-lg text-2xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Gerar Grupos para TODAS as Categorias (Balanceado)
              </button>
              <button
                onClick={() => handleGenerateAllGroups('random')}
                disabled={!selectedTorneioId}
                className="bg-slate-850 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700 text-slate-300 font-bold px-3.5 py-2 rounded-lg text-2xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Gerar Grupos para TODAS (Sorteio)
              </button>
            </div>
          </div>

          {/* Groups display */}
          {groupsGenerated && groups.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {groups.map(group => {
                const standings = computeGroupStandings(group);
                return (
                  <div key={group.id} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
                    <div className="px-4 py-3 bg-sky-500/10 border-b border-sky-500/20 flex items-center justify-between">
                      <h4 className="font-black text-sky-400 text-sm uppercase tracking-wider flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        {group.nome}
                      </h4>
                      <span className="text-2xs text-slate-400 font-mono">{group.atletas.length} atletas · {group.matches.length} jogos</span>
                    </div>

                    {/* Standings mini-table */}
                    <div className="p-3 border-b border-slate-800 overflow-x-auto">
                      <table className="w-full text-2xs">
                        <thead>
                          <tr className="text-slate-500 uppercase tracking-wider text-[9px]">
                            <th className="text-left pb-1.5 pl-1">Atleta</th>
                            <th className="pb-1.5 w-8">J</th>
                            <th className="pb-1.5 w-8">V</th>
                            <th className="pb-1.5 w-8">D</th>
                            <th className="pb-1.5 w-10">SS</th>
                            <th className="pb-1.5 w-10">Pts</th>
                          </tr>
                        </thead>
                        <tbody>
                          {standings.map((s, i) => (
                            <tr key={s.atleta.id} className={`${i === 0 ? 'text-emerald-400' : 'text-slate-300'} font-semibold border-t border-slate-850`}>
                              <td className="py-1 pl-1 truncate max-w-[140px]">{i + 1}. {s.atleta.nome}</td>
                              <td className="text-center font-mono">{s.jogos}</td>
                              <td className="text-center font-mono">{s.vitorias}</td>
                              <td className="text-center font-mono">{s.derrotas}</td>
                              <td className="text-center font-mono">{s.saldoSets > 0 ? `+${s.saldoSets}` : s.saldoSets}</td>
                              <td className="text-center font-mono font-black">{s.pontos}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Round-robin match list with editable scores */}
                    <div className="divide-y divide-slate-850">
                      {group.matches.map(m => (
                        <div key={m.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                          <div className="flex-1 min-w-0 text-2xs font-semibold text-slate-200 truncate">
                            {m.p1?.nome || '—'} <span className="text-slate-600">vs</span> {m.p2?.nome || '—'}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleUpdateGroupScore(group.id, m.id, 'score1', -1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-850 hover:bg-slate-800 rounded text-slate-400 font-bold text-xs cursor-pointer"
                            >−</button>
                            <span className="w-5 text-center font-mono font-black text-slate-100 text-xs">{m.score1}</span>
                            <button
                              onClick={() => handleUpdateGroupScore(group.id, m.id, 'score1', 1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-850 hover:bg-slate-800 rounded text-slate-400 font-bold text-xs cursor-pointer"
                            >+</button>
                            <span className="text-slate-600 text-2xs px-0.5">×</span>
                            <button
                              onClick={() => handleUpdateGroupScore(group.id, m.id, 'score2', -1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-850 hover:bg-slate-800 rounded text-slate-400 font-bold text-xs cursor-pointer"
                            >−</button>
                            <span className="w-5 text-center font-mono font-black text-slate-100 text-xs">{m.score2}</span>
                            <button
                              onClick={() => handleUpdateGroupScore(group.id, m.id, 'score2', 1)}
                              className="w-5 h-5 flex items-center justify-center bg-slate-850 hover:bg-slate-800 rounded text-slate-400 font-bold text-xs cursor-pointer"
                            >+</button>
                            {m.status === 'Concluído' && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-1" />
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-16 sm:py-20 text-slate-500 space-y-4 max-w-sm mx-auto p-4">
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-slate-850 border border-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto text-lg sm:text-xl shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-slate-300">Fase de Grupos não gerada</h5>
                <p className="text-xs text-slate-500 leading-normal">
                  Selecione o Torneio e a Categoria, defina quantos atletas por grupo, e clique em <strong>Gerar Balanceado</strong> ou <strong>Sorteio Aleatório</strong> para montar os grupos e as partidas de todos-contra-todos.
                </p>
              </div>
            </div>
          )}
        </div>
      ) : viewTab === 'escala' ? (
        <div className="space-y-6">
          {/* Main Controls & Generator for Escala Automática */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-lg">
            <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-black shrink-0">
                  <Calendar className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-wider flex items-center gap-2">
                    Escala Automática de Jogos por Categoria
                    <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-500/30">
                      PRO ENGINE
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 font-medium">
                    Programação de partidas, alocação de mesas, horários e designação de árbitros para todos os inscritos.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 w-full md:w-auto">
                <button
                  type="button"
                  onClick={() => generateAutomaticMasterSchedule()}
                  disabled={!selectedTorneioId}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-black rounded-xl text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  ⚡ Gerar Escala Automática dos Inscritos
                </button>
                {scheduledGames.length > 0 && (
                  <button
                    type="button"
                    onClick={handlePrintEscala}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 font-extrabold rounded-xl text-xs flex items-center gap-2 border border-slate-700 transition cursor-pointer"
                  >
                    <Printer className="w-4 h-4 text-slate-400" />
                    🖨️ Imprimir / Exportar PDF
                  </button>
                )}
              </div>
            </div>

            {/* Config & Parameters Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">Torneio Ativo</label>
                <select
                  value={selectedTorneioId}
                  onChange={(e) => setSelectedTorneioId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 text-slate-200 rounded-xl px-3 py-2 text-xs outline-none transition"
                >
                  <option value="">Selecione o torneio...</option>
                  {torneios.map(t => (
                    <option key={t.id} value={t.id}>{t.nome}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">Horário de Início</label>
                <div className="relative">
                  <Clock className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="time"
                    value={startHour}
                    onChange={(e) => setStartHour(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 text-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs outline-none transition font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">Duração Estimada / Jogo (min)</label>
                <input
                  type="number"
                  min={10}
                  max={60}
                  value={matchDurationMinutes}
                  onChange={(e) => setMatchDurationMinutes(Number(e.target.value) || 20)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 text-slate-200 rounded-xl px-3 py-2 text-xs outline-none transition font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block">Número de Mesas Disponíveis</label>
                <input
                  type="number"
                  min={1}
                  max={32}
                  value={numTablesConfig}
                  onChange={(e) => setNumTablesConfig(Number(e.target.value) || 8)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 text-slate-200 rounded-xl px-3 py-2 text-xs outline-none transition font-mono"
                />
              </div>
            </div>
          </div>

          {!selectedTorneioId ? (
            <div className="text-center py-16 sm:py-20 bg-slate-900 border border-slate-800 rounded-xl text-slate-500 space-y-4 max-w-md mx-auto p-4">
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-slate-850 border border-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto text-lg sm:text-xl shrink-0">
                📅
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-slate-300">Selecione um Torneio</h5>
                <p className="text-xs text-slate-500 leading-normal">
                  Escolha um torneio no menu acima e clique em <strong>"⚡ Gerar Escala Automática dos Inscritos"</strong> para calcular a programação de jogos, mesas e horários.
                </p>
              </div>
            </div>
          ) : scheduledGames.length === 0 ? (
            <div className="text-center py-16 sm:py-20 bg-slate-900 border border-slate-800 rounded-xl text-slate-500 space-y-4 max-w-md mx-auto p-4">
              <div className="w-10 h-10 sm:w-11 sm:h-11 bg-slate-850 border border-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto text-lg sm:text-xl shrink-0">
                ⚡
              </div>
              <div className="space-y-1">
                <h5 className="font-bold text-slate-300">Nenhuma Escala Gerada Ainda</h5>
                <p className="text-xs text-slate-500 leading-normal">
                  Clique no botão verde acima para distribuir as partidas de todas as categorias automaticamente pelas mesas disponíveis.
                </p>
              </div>
              <button
                type="button"
                onClick={() => generateAutomaticMasterSchedule()}
                className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs inline-flex items-center gap-2 transition cursor-pointer shadow-lg"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                Gerar Escala de Jogos Agora
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Metrics Summary Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Total de Jogos</span>
                    <span className="text-xl font-black text-slate-100">{scheduledGames.length}</span>
                  </div>
                  <Trophy className="w-6 h-6 text-yellow-400 opacity-80" />
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Mesas Utilizadas</span>
                    <span className="text-xl font-black text-emerald-400">
                      {Math.max(...scheduledGames.map(g => g.mesa), 0)}
                    </span>
                  </div>
                  <MapPin className="w-6 h-6 text-emerald-400 opacity-80" />
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Horário de Término</span>
                    <span className="text-xl font-black text-cyan-400 font-mono">
                      {scheduledGames[scheduledGames.length - 1]?.horario || '18:00'}
                    </span>
                  </div>
                  <Clock className="w-6 h-6 text-cyan-400 opacity-80" />
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Categorias</span>
                    <span className="text-xl font-black text-purple-400">
                      {new Set(scheduledGames.map(g => g.categoriaId)).size}
                    </span>
                  </div>
                  <Users className="w-6 h-6 text-purple-400 opacity-80" />
                </div>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-col sm:flex-row gap-3 bg-slate-900 p-3.5 border border-slate-800 rounded-xl items-stretch sm:items-center">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Buscar por nome do atleta..."
                    value={escalaSearch}
                    onChange={(e) => setEscalaSearch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-400 text-slate-200 rounded-lg pl-9 pr-3 py-1.5 text-xs outline-none transition"
                  />
                </div>

                <select
                  value={escalaCatFilter}
                  onChange={(e) => setEscalaCatFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none"
                >
                  <option value="">Todas as Categorias</option>
                  {categorias.map(c => (
                    <option key={c.id} value={c.id}>{c.nome}</option>
                  ))}
                </select>

                <select
                  value={escalaMesaFilter}
                  onChange={(e) => setEscalaMesaFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none"
                >
                  <option value="todas">Todas as Mesas</option>
                  {Array.from({ length: numTablesConfig }, (_, i) => i + 1).map(m => (
                    <option key={m} value={String(m)}>Mesa #{m}</option>
                  ))}
                </select>

                <select
                  value={escalaStatusFilter}
                  onChange={(e) => setEscalaStatusFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-slate-300 rounded-lg px-3 py-1.5 text-xs outline-none"
                >
                  <option value="todos">Todos os Status</option>
                  <option value="Aguardando">Aguardando</option>
                  <option value="Em Jogo">Em Jogo</option>
                  <option value="Concluído">Concluído</option>
                </select>

                {/* Show only busy tables filter toggle */}
                <button
                  type="button"
                  onClick={() => setOnlyBusyTables(!onlyBusyTables)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-extrabold border transition flex items-center gap-2 cursor-pointer shrink-0 ${
                    onlyBusyTables
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-md shadow-amber-500/10'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                  title="Exibir apenas mesas com partidas em andamento"
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${onlyBusyTables ? 'bg-amber-400 animate-ping' : 'bg-slate-600'}`} />
                  <span>
                    {onlyBusyTables ? '🔥 Apenas Mesas Ocupadas' : '⚡ Mostrar Mesas Ocupadas'}
                  </span>
                  <span className="ml-1 bg-slate-900 border border-slate-800 text-yellow-400 px-1.5 py-0.2 rounded text-4xs font-mono">
                    {scheduledGames.filter(g => g.status === 'Em Jogo').length}
                  </span>
                </button>
              </div>

              {/* Scheduled Games List */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {scheduledGames
                  .filter(g => {
                    const matchSearch = !escalaSearch || 
                      (g.p1?.nome || '').toLowerCase().includes(escalaSearch.toLowerCase()) ||
                      (g.p2?.nome || '').toLowerCase().includes(escalaSearch.toLowerCase());
                    const matchCat = !escalaCatFilter || g.categoriaId === escalaCatFilter;
                    const matchMesa = escalaMesaFilter === 'todas' || String(g.mesa) === escalaMesaFilter;
                    const matchStatus = escalaStatusFilter === 'todos' || g.status === escalaStatusFilter;
                    const matchBusy = !onlyBusyTables || g.status === 'Em Jogo';
                    return matchSearch && matchCat && matchMesa && matchStatus && matchBusy;
                  })
                  .map((game) => (
                    <div
                      key={game.id}
                      className={`border rounded-xl p-4 space-y-3 transition shadow-md ${
                        game.status === 'Em Jogo'
                          ? 'bg-slate-900/90 border-amber-500/40 ring-1 ring-amber-500/20'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
                            ⏰ {game.horario}
                          </span>
                          <span className="font-mono text-xs font-black bg-yellow-400/10 text-yellow-400 border border-yellow-400/30 px-2 py-0.5 rounded">
                            📍 Mesa #{game.mesa}
                          </span>
                          {game.status === 'Em Jogo' && (
                            <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider flex items-center gap-1 animate-pulse">
                              🔥 Ocupada
                            </span>
                          )}
                        </div>

                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 truncate max-w-[140px]">
                          {game.categoriaNome}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-2 text-[10px] font-extrabold uppercase tracking-widest text-slate-500">
                        <span>{game.rodada}</span>

                        {/* Referee status control selector */}
                        <select
                          value={game.status}
                          onChange={(e) => handleUpdateGameStatus(game.id, e.target.value as 'Aguardando' | 'Em Jogo' | 'Concluído')}
                          className={`text-[10px] font-extrabold rounded px-2 py-0.5 border outline-none transition cursor-pointer ${
                            game.status === 'Em Jogo'
                              ? 'bg-amber-950 text-amber-300 border-amber-500/60 font-black'
                              : game.status === 'Concluído'
                              ? 'bg-blue-950 text-blue-400 border-blue-800/60'
                              : 'bg-slate-950 text-slate-400 border-slate-800'
                          }`}
                        >
                          <option value="Aguardando">⏱️ Aguardando</option>
                          <option value="Em Jogo">🔴 MESA OCUPADA (Em Jogo)</option>
                          <option value="Concluído">✓ Concluído</option>
                        </select>
                      </div>

                      {/* Athletes matchup */}
                      <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <div className="truncate flex-1">
                            <span className="text-xs font-bold text-slate-200 block truncate">
                              {game.p1?.nome || 'BYE'}
                            </span>
                            {game.p1 && (
                              <span className="text-[10px] text-slate-500 block">
                                {game.p1.clube || 'Sem clube'} • {game.p1.rating} pts
                              </span>
                            )}
                          </div>
                          {game.score1 > 0 && (
                            <span className="font-mono text-xs font-black text-yellow-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                              {game.score1}
                            </span>
                          )}
                        </div>

                        <div className="text-center text-[10px] font-black text-slate-600 uppercase">VS</div>

                        <div className="flex items-center justify-between gap-2">
                          <div className="truncate flex-1">
                            <span className="text-xs font-bold text-slate-200 block truncate">
                              {game.p2?.nome || 'BYE'}
                            </span>
                            {game.p2 && (
                              <span className="text-[10px] text-slate-500 block">
                                {game.p2.clube || 'Sem clube'} • {game.p2.rating} pts
                              </span>
                            )}
                          </div>
                          {game.score2 > 0 && (
                            <span className="font-mono text-xs font-black text-yellow-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                              {game.score2}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Referee & Action Buttons */}
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <span className="text-[10px] text-slate-400 flex items-center gap-1 font-medium truncate">
                          <Shield className="w-3 h-3 text-slate-500 shrink-0" />
                          {game.arbitroNome}
                        </span>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleSendWhatsAppNotice(game)}
                            className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                            title="Enviar convocação no WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      ) : null}

      {/* Modal: Relação Completa de Atletas Inscritos (pré-chaveamento) */}
      {relacaoModalCatId && (() => {
        const cat = categorias.find(c => c.id === relacaoModalCatId);
        if (!cat) return null;
        const roster = getFullRosterForCategory(relacaoModalCatId);
        return (
          <div
            className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4"
            onClick={() => setRelacaoModalCatId(null)}
          >
            <div
              className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg max-h-[85vh] flex flex-col shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b border-slate-800">
                <div>
                  <h3 className="font-black text-slate-100 text-sm uppercase tracking-wider flex items-center gap-2">
                    <Users className="w-4 h-4 text-yellow-400" />
                    Relação de Inscritos — {cat.nome}
                  </h3>
                  <p className="text-2xs text-slate-500">{roster.length} atletas, ordenados por rating</p>
                </div>
                <button
                  type="button"
                  onClick={() => setRelacaoModalCatId(null)}
                  className="p-1.5 bg-slate-850 hover:bg-slate-800 rounded-lg text-slate-400 cursor-pointer transition"
                >
                  <XCircle className="w-4 h-4" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1 p-2">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-slate-900">
                    <tr className="text-[10px] uppercase tracking-wider text-slate-500 border-b border-slate-800">
                      <th className="text-left py-2 px-2 w-8">#</th>
                      <th className="text-left py-2 px-2">Nome</th>
                      <th className="text-center py-2 px-2 w-14">Idade</th>
                      <th className="text-center py-2 px-2 w-16">Rating</th>
                      <th className="text-center py-2 px-2 w-24">Presença</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roster.map((ath, idx) => {
                      const ageVal = calculateAge(ath.nasc);
                      const isConfirmed = (ath.presenca || 'CONFIRMADA') === 'CONFIRMADA';
                      return (
                        <tr key={ath.id} className="border-b border-slate-850/60">
                          <td className="py-1.5 px-2 font-mono text-slate-500">{idx + 1}</td>
                          <td className="py-1.5 px-2 font-bold text-slate-200 truncate max-w-[160px]">{ath.nome}</td>
                          <td className="py-1.5 px-2 text-center text-slate-400">{ageVal > 0 ? `${ageVal}a` : '—'}</td>
                          <td className="py-1.5 px-2 text-center font-mono font-bold text-yellow-500">{ath.rating}</td>
                          <td className="py-1.5 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleTogglePresenceAtleta(ath)}
                              className={`px-2 py-0.5 rounded text-[9px] font-extrabold border transition cursor-pointer ${
                                isConfirmed
                                  ? 'bg-emerald-950/80 text-emerald-400 border-emerald-800/60 hover:bg-emerald-900'
                                  : 'bg-amber-950/80 text-amber-400 border-amber-800/60 hover:bg-amber-900'
                              }`}
                            >
                              {isConfirmed ? '✓ Confirmada' : '⚡ Pendente'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              <div className="p-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const torneio = torneios.find(t => t.id === selectedTorneioId);
                    exportRelacaoInscritosPDF(torneio?.nome || 'Torneio', [{ catNome: cat.nome, atletas: roster }]);
                  }}
                  className="px-3.5 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black rounded-lg text-xs flex items-center gap-1.5 transition cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  Exportar PDF desta Categoria
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
