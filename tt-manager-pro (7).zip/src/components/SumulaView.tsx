import React, { useState } from 'react';
import { Torneio, Atleta, Arbitro, Resultado, SystemConfig } from '../types';
import { 
  Printer, FileText, Settings, FileSignature, 
  Eye, Check, AlertCircle, FileCheck,
  Maximize2, Minimize2, FileDown, CheckCircle2, ShieldCheck, Sparkles, UserCheck
} from 'lucide-react';
import { generateCustomSumulaPdf } from '../utils/pdfGenerator';
import { triggerToast } from '../utils/toast';

interface SumulaViewProps {
  torneios: Torneio[];
  atletas: Atleta[];
  arbitros?: Arbitro[];
  resultados?: Resultado[];
  immersiveMode?: boolean;
  onToggleImmersive?: () => void;
  config: SystemConfig;
}

type PaperSize = 'a4' | 'a6' | 'thermal80' | 'thermal58';
type Density = 'compact' | 'normal' | 'large';

export default function SumulaView({ 
  torneios, 
  atletas, 
  arbitros = [],
  resultados = [],
  immersiveMode = false, 
  onToggleImmersive,
  config
}: SumulaViewProps) {
  const setsMax = config.setsMax || 5;
  const setsPoints = config.setsPoints || 11;
  const [selectedTorneioId, setSelectedTorneioId] = useState('');
  const [selectedRound, setSelectedRound] = useState('Rodada 1');
  const [paperSize, setPaperSize] = useState<PaperSize>('a6'); // Default to 1/4 A4
  const [layoutDensity, setLayoutDensity] = useState<Density>('normal');
  const [showSignatures, setShowSignatures] = useState(true);
  const [customObservation, setCustomObservation] = useState('Súmula com assinaturas eletrônicas automáticas validadas digitalmente ao término do jogo.');
  const [showObs, setShowObs] = useState(true);
  
  // Option to simulate auto-signatures for demonstration if no matches are closed yet
  const [simulateSignatures, setSimulateSignatures] = useState(true);
  
  // Confirmation state before printer trigger
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const selectedTorneio = torneios.find(t => t.id === selectedTorneioId);

  // Group athletes into pairs to populate match rows
  const rawMatchRows: { num: number; p1: Atleta; p2: Atleta | null }[] = [];
  for (let i = 0; i < atletas.length; i += 2) {
    const a1 = atletas[i];
    const a2 = atletas[i + 1] || null;
    if (a1) {
      rawMatchRows.push({
        num: Math.floor(i / 2) + 1,
        p1: a1,
        p2: a2
      });
    }
  }

  // Enrich match rows with saved results or simulated completion
  const matchRows = rawMatchRows.map((m) => {
    // Find matching real result if present
    const realRes = resultados.find(r => 
      (selectedTorneioId ? r.torId === selectedTorneioId : true) &&
      ((r.nomeA === m.p1.nome && r.nomeB === m.p2?.nome) ||
       (r.nomeA === m.p2?.nome && r.nomeB === m.p1.nome))
    ) || null;

    let res = realRes;

    // If simulateSignatures is enabled and no real result exists, provide a simulated finished result
    if (!res && simulateSignatures && m.p2) {
      const isA1Win = m.num % 2 !== 0;
      const defaultArb = arbitros.length > 0 ? arbitros[m.num % arbitros.length].nome : 'Árbitro Oficial';
      res = {
        id: `sim-${m.num}`,
        torId: selectedTorneioId || 'sim-tor',
        catId: 'sim-cat',
        nomeA: m.p1.nome,
        nomeB: m.p2.nome,
        ponA: isA1Win ? 3 : 1,
        ponB: isA1Win ? 1 : 3,
        setsA: 11,
        setsB: 9,
        arb: defaultArb,
        mesa: m.num,
        dt: new Date().toISOString(),
        obs: 'Partida concluída e validada pelo árbitro.'
      };
    }

    return {
      ...m,
      resultado: res
    };
  });

  // Export customizable PDF (A4, 1/4 A4 [A6], Thermal 80mm, Thermal 58mm) using jsPDF
  const handleExportPdf = (overrideSize?: PaperSize) => {
    const sizeToUse = overrideSize || paperSize;
    try {
      generateCustomSumulaPdf({
        torneio: selectedTorneio,
        roundName: selectedRound,
        matchRows,
        config,
        showSignatures,
        customObservation,
        showObs,
        paperSize: sizeToUse
      });
      const formatNames: Record<PaperSize, string> = {
        a4: 'A4 Inteira (Relatório Completo)',
        a6: '1/4 A4 (A6 Mini Súmulas)',
        thermal80: 'Bobina Térmica 80mm',
        thermal58: 'Bobina Térmica 58mm'
      };
      triggerToast(`Súmula gerada em PDF no formato ${formatNames[sizeToUse]} com sucesso!`, 'success');
    } catch (err) {
      console.error('Erro ao exportar PDF:', err);
      triggerToast('Não foi possível gerar o arquivo PDF. Tente novamente.', 'error');
    }
  };

  // Trigger system physical printer dialog
  const executeSystemPrint = () => {
    setShowConfirmModal(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const getTableSpacing = () => {
    if (layoutDensity === 'compact') return 'space-y-2';
    if (layoutDensity === 'large') return 'space-y-5';
    return 'space-y-3';
  };

  return (
    <div className="space-y-6">
      
      {/* EXPLANATORY HEADER BANNER */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 no-print">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-yellow-400/10 text-yellow-400 rounded-lg">
            <Printer className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-sm">Central Inteligente de Súmulas & Assinaturas Digitais</h3>
            <p className="text-slate-400 text-2xs mt-0.5 leading-normal max-w-xl">
              Gere e imprima súmulas oficiais com **Assinaturas Eletrônicas Automáticas** dos atletas e árbitros após o término do jogo. Exporte em **1/4 da folha A4 (A6)** ou imprima em bobina térmica.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onToggleImmersive && (
            <button
              type="button"
              onClick={onToggleImmersive}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition uppercase flex items-center gap-1.5 cursor-pointer shadow-md border ${
                immersiveMode 
                  ? 'bg-yellow-400 text-slate-950 border-yellow-400 hover:bg-yellow-300' 
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-slate-100 hover:bg-slate-700'
              }`}
              title={immersiveMode ? "Restaurar visualização padrão" : "Ativar Modo Imersivo"}
            >
              {immersiveMode ? <Minimize2 className="w-4 h-4 text-slate-950" /> : <Maximize2 className="w-4 h-4 text-yellow-400" />}
              {immersiveMode ? "Menu Oculto" : "Modo Imersivo"}
            </button>
          )}
          <span className="text-[10px] font-extrabold uppercase bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-1 rounded hidden sm:inline-block">
            Assinatura Digital Ativa ✓
          </span>
        </div>
      </div>

      {/* CORE CONTROLLER DASHBOARD BLOCK */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 no-print shadow-md">
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Settings className="w-4.5 h-4.5 text-slate-400" />
            <h4 className="text-xs font-black text-slate-200 uppercase tracking-wider">Ajustes & Exportação da Súmula</h4>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSimulateSignatures(!simulateSignatures)}
              className={`px-2.5 py-1 rounded text-3xs font-extrabold uppercase transition flex items-center gap-1 border ${
                simulateSignatures 
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' 
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
              title="Ativar/desativar exibição de assinaturas automáticas para jogos finalizados"
            >
              <Sparkles className="w-3 h-3" />
              <span>{simulateSignatures ? 'Assinaturas Automáticas: ATIVAS' : 'Assinaturas Automáticas: DESATIVADAS'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Tournament Selection */}
          <div className="space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Selecione o Torneio</label>
            <select
              value={selectedTorneioId}
              onChange={(e) => setSelectedTorneioId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition font-medium"
            >
              <option value="">Escolher torneio para súmula...</option>
              {torneios.map(t => (
                <option key={t.id} value={t.id}>{t.nome}</option>
              ))}
            </select>
          </div>

          {/* Phase Round Selector */}
          <div className="space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Fase / Rodada</label>
            <select
              value={selectedRound}
              onChange={(e) => setSelectedRound(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition font-medium"
            >
              <option value="Fase de Grupos">Fase de Grupos</option>
              <option value="Rodada de 16">Dezesseis-avos (R16)</option>
              <option value="Oitavas de Final">Oitavas de Final</option>
              <option value="Quartas de Final">Quartas de Final</option>
              <option value="Semifinais">Semifinais</option>
              <option value="Grande Final">Grande Final / Decisão</option>
            </select>
          </div>

          {/* Paper format selector */}
          <div className="space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Tipo de Mídia / Formato</label>
            <div className="grid grid-cols-4 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-850 text-[10px]">
              <button
                type="button"
                onClick={() => setPaperSize('a6')}
                className={`py-1 font-bold rounded transition text-center ${
                  paperSize === 'a6' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Súmula compacta formatada em 1/4 da folha A4"
              >
                1/4 A4
              </button>
              <button
                type="button"
                onClick={() => setPaperSize('a4')}
                className={`py-1 font-bold rounded transition text-center ${
                  paperSize === 'a4' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title="A4 Inteira (Laser/Jato de Tinta)"
              >
                A4
              </button>
              <button
                type="button"
                onClick={() => setPaperSize('thermal80')}
                className={`py-1 font-bold rounded transition text-center ${
                  paperSize === 'thermal80' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                80mm
              </button>
              <button
                type="button"
                onClick={() => setPaperSize('thermal58')}
                className={`py-1 font-bold rounded transition text-center ${
                  paperSize === 'thermal58' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                58mm
              </button>
            </div>
          </div>

          {/* Density Control */}
          <div className="space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Densidade / Espaçamento</label>
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-850">
              <button
                type="button"
                onClick={() => setLayoutDensity('compact')}
                className={`py-1 text-[10px] font-bold rounded transition text-center ${
                  layoutDensity === 'compact' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Compacto
              </button>
              <button
                type="button"
                onClick={() => setLayoutDensity('normal')}
                className={`py-1 text-[10px] font-bold rounded transition text-center ${
                  layoutDensity === 'normal' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Padrão
              </button>
              <button
                type="button"
                onClick={() => setLayoutDensity('large')}
                className={`py-1 text-[10px] font-bold rounded transition text-center ${
                  layoutDensity === 'large' 
                    ? 'bg-yellow-400 text-slate-950' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Largo
              </button>
            </div>
          </div>

        </div>

        {/* Observation editing and signature toggles */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-2">
          
          <div className="lg:col-span-8 space-y-1.5">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block flex items-center justify-between">
              <span>Observação Adicional da Súmula (Texto Customizado)</span>
              <button
                onClick={() => setShowObs(!showObs)}
                className="text-yellow-400 text-3xs font-extrabold hover:underline"
              >
                {showObs ? 'Esconder do papel' : 'Mostrar no papel'}
              </button>
            </label>
            <input
              type="text"
              disabled={!showObs}
              value={customObservation}
              onChange={(e) => setCustomObservation(e.target.value)}
              placeholder="Ex: Assinaturas eletrônicas validadas no término do jogo."
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none transition disabled:opacity-40"
            />
          </div>

          <div className="lg:col-span-4 flex items-end">
            <div className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileSignature className="w-4 h-4 text-slate-400" />
                <span className="text-[11px] font-bold text-slate-300">Bloco de Assinaturas</span>
              </div>
              <button
                type="button"
                onClick={() => setShowSignatures(!showSignatures)}
                className={`px-3 py-1 rounded text-2xs font-extrabold transition uppercase ${
                  showSignatures 
                    ? 'bg-emerald-600/25 border border-emerald-500/35 text-emerald-400' 
                    : 'bg-slate-850 text-slate-500'
                }`}
              >
                {showSignatures ? 'Exibir Assinaturas ✓' : 'Ocultar'}
              </button>
            </div>
          </div>

        </div>

        {/* ACTION TRIGGERING MODULES */}
        <div className="pt-3 border-t border-slate-850 flex flex-col md:flex-row justify-between items-center gap-3">
          <div className="text-[10.5px] text-slate-400 italic flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            Ao término de cada jogo, as assinaturas eletrônicas são vinculadas ao resultado com código de validação.
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            {/* EXPORT PDF BUTTON WITH DYNAMIC FORMAT LABEL */}
            <button
              type="button"
              onClick={() => handleExportPdf()}
              className="flex-1 md:flex-initial bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-5 py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0 active:scale-95"
              title={`Gerar e baixar arquivo PDF no formato ${paperSize === 'a4' ? 'A4 Inteira' : paperSize === 'a6' ? '1/4 A4 (A6)' : paperSize === 'thermal80' ? 'Térmica 80mm' : 'Térmica 58mm'}`}
            >
              <FileDown className="w-4 h-4 text-slate-950" />
              <span>EXPORTAR SÚMULA EM PDF ({paperSize === 'a4' ? 'A4' : paperSize === 'a6' ? '1/4 A4' : paperSize === 'thermal80' ? '80mm' : '58mm'}) 📄</span>
            </button>

            {/* PRINT BUTTON */}
            <button
              type="button"
              onClick={() => window.print()}
              className="flex-1 md:flex-initial bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-5 py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shrink-0 active:scale-95"
              title="Disparar impressão física da súmula"
            >
              <Printer className="w-4 h-4 text-slate-950 fill-slate-950" />
              <span>IMPRIMIR 🖨️</span>
            </button>

            <button
              type="button"
              onClick={() => setShowConfirmModal(true)}
              className="flex-1 md:flex-initial bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold px-4 py-2.5 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-sm shrink-0 active:scale-95"
            >
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Opções & Confirmar</span>
            </button>
          </div>
        </div>

      </div>

      {/* INTERACTIVE WORKSPACE PREVIEW HEADER */}
      <div className="bg-slate-900 border border-slate-800 p-3 px-4 rounded-xl no-print text-center flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-2 text-left">
          <Printer className="w-4.5 h-4.5 text-yellow-400 shrink-0" />
          <span className="text-3xs uppercase tracking-widest text-slate-300 font-extrabold block">
            👁️ PRÉ-VISUALIZAÇÃO DA SÚMULA ({paperSize === 'a6' ? 'FORMATO 1/4 DA FOLHA A4' : paperSize === 'a4' ? 'FOLHA A4 INTEIRA' : paperSize === 'thermal80' ? 'BOBINA TÉRMICA 80MM' : 'BOBINA TÉRMICA 58MM'})
          </span>
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => handleExportPdf()}
            className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-4 py-2 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-md no-print active:scale-95"
          >
            <FileDown className="w-4 h-4" />
            <span>Exportar PDF ({paperSize === 'a4' ? 'A4' : paperSize === 'a6' ? '1/4 A4' : paperSize === 'thermal80' ? '80mm' : '58mm'})</span>
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-4 py-2 rounded-lg text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-md no-print active:scale-95"
          >
            <Printer className="w-4 h-4 text-slate-950 fill-slate-950" />
            <span>Imprimir</span>
          </button>
        </div>
      </div>

      {/* VIRTUAL CANVAS WRAPPER - Printable target area */}
      <div className="bg-slate-950 p-4 sm:p-8 border border-slate-850 rounded-2xl overflow-x-auto shadow-inner no-scrollbar flex items-start justify-center min-h-[500px]">
        
        {/* PHYSICAL PRINT TARGET CONTAINER */}
        <div 
          id="sumula-print-sheet" 
          className={`printable-area text-slate-950 font-sans shadow-lg select-none p-5 sm:p-8 flex flex-col justify-between ${
            paperSize === 'a4' 
              ? 'paper-preview-a4 bg-white' 
              : paperSize === 'a6'
                ? 'paper-preview-a6 bg-white'
                : paperSize === 'thermal80' 
                  ? 'paper-preview-thermal-80 bg-white' 
                  : 'paper-preview-thermal-58 bg-white'
          }`}
        >
          
          {/* HEADER SECTOR */}
          <div className="text-center pb-3 border-b-2 border-slate-900 mb-4">
            <h2 className="text-base sm:text-lg font-black uppercase text-slate-900 tracking-wide flex items-center justify-center gap-1.5 leading-none">
              🏓 Súmula Oficial de Competição
            </h2>
            <p className="text-[10px] text-slate-700 uppercase tracking-widest font-extrabold mt-1">
              {selectedTorneio?.nome || 'TORNEIO DE TÊNIS DE MESA'}
            </p>
            <div className="flex justify-center items-center gap-2.5 text-[8.5px] text-slate-600 font-mono tracking-wider mt-1 border-t border-slate-200 pt-1">
              <span>FASE: <strong>{selectedRound.toUpperCase()}</strong></span>
              <span>•</span>
              <span>DATA: {new Date().toLocaleDateString('pt-BR')}</span>
              <span>•</span>
              <span>FORMATO: <strong>{paperSize === 'a6' ? '1/4 A4 (105x148mm)' : paperSize.toUpperCase()}</strong></span>
            </div>
          </div>

          {/* DYNAMIC LAYOUT ADAPTIVITY: A6 (1/4 A4) OR A4 SPREADSHEET OR THERMAL */}
          {paperSize === 'a6' ? (

            /* 1/4 A4 (A6) MINI SÚMULA CARDS FORMAT */
            <div className="flex-1 space-y-4 py-1">
              {matchRows.length > 0 && selectedTorneioId ? (
                matchRows.map((m) => {
                  const res = m.resultado;
                  const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));
                  const arbName = res?.arb || (arbitros.length > 0 ? arbitros[0].nome : 'Árbitro Oficial');
                  const dtStr = res?.dt ? new Date(res.dt).toLocaleDateString('pt-BR') : new Date().toLocaleDateString('pt-BR');
                  const timeStr = res?.dt ? new Date(res.dt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

                  const hashA = Math.abs(m.p1.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * 17 % 9999).toString().padStart(4, '0');
                  const hashB = m.p2 ? Math.abs(m.p2.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * 19 % 9999).toString().padStart(4, '0') : '0000';
                  const hashArb = Math.abs(arbName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * 23 % 9999).toString().padStart(4, '0');

                  return (
                    <div 
                      key={m.num} 
                      className="border-2 border-slate-900 p-3 space-y-2 text-left rounded-lg bg-slate-50/50 relative overflow-hidden"
                    >
                      {/* Card Header Bar */}
                      <div className="flex justify-between items-center text-[9px] font-mono border-b border-slate-300 pb-1">
                        <span className="font-black uppercase text-slate-900">CONFRONTO Nº {m.num}</span>
                        <div className="flex items-center gap-1.5">
                          {isFinished ? (
                            <span className="bg-emerald-600 text-white font-extrabold px-1.5 py-0.5 rounded text-[7.5px] uppercase flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5" /> Encerrado ({res?.ponA} x {res?.ponB})
                            </span>
                          ) : (
                            <span className="bg-amber-500 text-slate-950 font-extrabold px-1.5 py-0.5 rounded text-[7.5px] uppercase">
                              Em Andamento
                            </span>
                          )}
                          <span className="bg-slate-900 text-white px-1.5 py-0.5 rounded text-[8px] font-black">
                            MESA {m.num}
                          </span>
                        </div>
                      </div>

                      {/* Players & Scores */}
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between items-center bg-white p-1.5 px-2 rounded border border-slate-200">
                          <span className="font-black text-slate-900 truncate max-w-[200px]">
                            {m.p1.nome} <span className="text-[8.5px] text-slate-500 font-normal">({m.p1.clube || 'Livre'})</span>
                          </span>
                          <span className="font-extrabold font-mono text-sm text-slate-900">
                            {isFinished ? res?.ponA : '[ ]'}
                          </span>
                        </div>

                        <div className="flex justify-between items-center bg-white p-1.5 px-2 rounded border border-slate-200">
                          <span className="font-black text-slate-900 truncate max-w-[200px]">
                            {m.p2 ? (
                              <>{m.p2.nome} <span className="text-[8.5px] text-slate-500 font-normal">({m.p2.clube || 'Livre'})</span></>
                            ) : (
                              <span className="text-slate-400 italic font-medium">BYE / ISENTO</span>
                            )}
                          </span>
                          <span className="font-extrabold font-mono text-sm text-slate-900">
                            {isFinished ? res?.ponB : '[ ]'}
                          </span>
                        </div>
                      </div>

                      {/* Set boxes */}
                      <div className="space-y-0.5">
                        <span className="text-[8px] uppercase tracking-wider text-slate-500 font-bold block">Controle de Sets ({setsPoints} pts):</span>
                        <div className="grid gap-1 text-center font-mono font-bold text-[9px]" style={{ gridTemplateColumns: `repeat(${setsMax}, minmax(0, 1fr))` }}>
                          {Array.from({ length: setsMax }).map((_, idx) => (
                            <div key={idx} className="border border-slate-400 py-0.5 bg-white rounded text-[8px]">
                              <div className="text-[7px] text-slate-500 font-bold">S{idx + 1}</div>
                              <div className="text-slate-800 font-mono text-[8.5px]">[ .x. ]</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* AUTOMATIC ELECTRONIC SIGNATURES BLOCK */}
                      {showSignatures && (
                        <div className="bg-emerald-50/90 border border-emerald-300 p-2 rounded-md mt-2 text-[8px] space-y-1">
                          <div className="flex items-center justify-between text-[7.5px] font-black uppercase text-emerald-800 border-b border-emerald-200 pb-1">
                            <span className="flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-emerald-600" />
                              Assinaturas Eletrônicas Automáticas ({dtStr} {timeStr})
                            </span>
                            <span className="bg-emerald-700 text-white px-1 py-0.2 rounded text-[7px] font-mono">
                              ✓ VALIDADO
                            </span>
                          </div>

                          <div className="grid grid-cols-3 gap-1.5 text-center pt-0.5">
                            {/* Atleta A Signature */}
                            <div className="bg-white p-1 rounded border border-emerald-200">
                              <span className="text-[7px] text-slate-500 font-bold uppercase block">Atleta A</span>
                              <span className="font-extrabold text-slate-900 text-[8px] truncate block">{m.p1.nome.split(' ')[0]}</span>
                              <span className="font-serif italic text-emerald-700 text-[9px] font-bold block my-0.5">~ {m.p1.nome} ~</span>
                              <span className="text-[6.5px] font-mono text-slate-400 block">SIG-A{hashA}</span>
                            </div>

                            {/* Atleta B Signature */}
                            <div className="bg-white p-1 rounded border border-emerald-200">
                              <span className="text-[7px] text-slate-500 font-bold uppercase block">Atleta B</span>
                              <span className="font-extrabold text-slate-900 text-[8px] truncate block">{m.p2 ? m.p2.nome.split(' ')[0] : 'BYE'}</span>
                              <span className="font-serif italic text-emerald-700 text-[9px] font-bold block my-0.5">~ {m.p2 ? m.p2.nome : 'BYE'} ~</span>
                              <span className="text-[6.5px] font-mono text-slate-400 block">SIG-B{hashB}</span>
                            </div>

                            {/* Árbitro Signature */}
                            <div className="bg-white p-1 rounded border border-emerald-200">
                              <span className="text-[7px] text-slate-500 font-bold uppercase block">Árbitro Oficial</span>
                              <span className="font-extrabold text-slate-900 text-[8px] truncate block">{arbName.split(' ')[0]}</span>
                              <span className="font-serif italic text-emerald-700 text-[9px] font-bold block my-0.5">~ {arbName} ~</span>
                              <span className="text-[6.5px] font-mono text-slate-400 block">SIG-ARB{hashArb}</span>
                            </div>
                          </div>
                        </div>
                      )}

                    </div>
                  );
                })
              ) : (
                <div className="py-12 border-2 border-dashed border-slate-350 text-center italic text-xs text-slate-500">
                  Por favor, selecione um torneio ativo no menu acima para gerar a súmula em 1/4 A4.
                </div>
              )}
            </div>

          ) : paperSize === 'a4' ? (
            
            /* A4 COMPREHENSIVE SPREADSHEET TABLE GRID */
            <div className="flex-1 overflow-x-auto py-2">
              <table className="w-full text-center border-collapse border-2 border-slate-900 text-[11px] font-medium leading-none">
                <thead>
                  <tr className="bg-slate-100 text-slate-900 uppercase text-[9px] tracking-wider font-extrabold border-b-2 border-slate-900">
                    <th className="py-2 border-r border-slate-900 px-1 w-9">Mesa</th>
                    <th className="py-2 border-r border-slate-900 px-2 text-left w-44">Atleta A (Clube)</th>
                    {Array.from({ length: setsMax }).map((_, idx) => (
                      <th key={idx} className="py-2 border-r border-slate-900 w-10 text-[8px]">{`Set ${idx + 1}`}</th>
                    ))}
                    <th className="py-2 border-r border-slate-900 px-2 text-left w-44">Atleta B (Clube)</th>
                    <th className="py-2 border-r border-slate-900 w-14">Placar</th>
                    <th className="py-2 w-28 text-[8px]">Assinatura Digital</th>
                  </tr>
                </thead>
                <tbody>
                  {matchRows.length > 0 && selectedTorneioId ? (
                    matchRows.map((m) => {
                      const res = m.resultado;
                      const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));
                      const hashA = Math.abs(m.p1.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * 17 % 9999).toString().padStart(4, '0');
                      return (
                        <tr key={m.num} className="border-b border-slate-900 h-10">
                          <td className="py-1.5 border-r border-slate-900 font-mono font-bold text-slate-800 text-center">
                            {m.num}
                          </td>
                          <td className="py-1.5 px-2 border-r border-slate-900 text-left font-black text-slate-900 truncate max-w-[170px]">
                            {m.p1.nome} <span className="text-[8px] text-slate-500 font-normal">({m.p1.clube || 'Livre'})</span>
                          </td>
                          {Array.from({ length: setsMax }).map((_, idx) => (
                            <td key={idx} className="border-r border-slate-900 bg-slate-50/50"></td>
                          ))}
                          <td className="py-1.5 px-2 border-r border-slate-900 text-left font-black text-slate-900 truncate max-w-[170px]">
                            {m.p2 ? (
                              <>{m.p2.nome} <span className="text-[8px] text-slate-500 font-normal">({m.p2.clube || 'Livre'})</span></>
                            ) : (
                              <span className="text-slate-400 italic font-medium">BYE / ISENTO</span>
                            )}
                          </td>
                          <td className="border-r border-slate-900 font-mono text-[10px] text-center font-extrabold">
                            {isFinished ? `[ ${res?.ponA} x ${res?.ponB} ]` : '[ ] x [ ]'}
                          </td>
                          <td className="py-1 px-1 text-[7.5px] font-mono text-center">
                            {isFinished ? (
                              <span className="text-emerald-700 font-extrabold block">
                                ✓ SIG-A{hashA}
                              </span>
                            ) : (
                              <span className="text-slate-400 italic">Pendente</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={6 + setsMax} className="py-16 border border-slate-900 text-center text-slate-550 italic text-xs">
                        Por favor, selecione um torneio ativo nas configurações de controle para preencher as partidas.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          ) : (

            /* THERMAL PAPER SPOOL */
            <div className={`flex-1 ${getTableSpacing()} py-1`}>
              {matchRows.length > 0 && selectedTorneioId ? (
                matchRows.map((m) => {
                  const res = m.resultado;
                  const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));
                  const arbName = res?.arb || 'Árbitro Oficial';
                  return (
                    <div 
                      key={m.num} 
                      className="border-2 border-dashed border-slate-900 p-3.5 space-y-2 text-left rounded-md bg-white relative overflow-hidden"
                    >
                      <div className="flex justify-between items-center text-[9px] font-mono border-b border-slate-350 pb-1">
                        <span className="font-extrabold uppercase text-slate-900">CONFRONTO Nº {m.num}</span>
                        <span className="font-black bg-slate-900 text-white px-1.5 py-0.5 rounded text-[8px]">
                          MESA {m.num}
                        </span>
                      </div>

                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between items-center bg-slate-100 p-1 px-2 rounded">
                          <span className="font-extrabold text-slate-900 truncate max-w-[180px]">{m.p1.nome}</span>
                          <span className="text-[9px] font-bold text-slate-500">[{m.p1.clube || 'LPT'}]</span>
                        </div>
                        <div className="flex justify-between items-center bg-slate-100 p-1 px-2 rounded">
                          <span className="font-extrabold text-slate-950 truncate max-w-[180px]">
                            {m.p2 ? m.p2.nome : 'BYE / ISENTO'}
                          </span>
                          <span className="text-[9px] font-bold text-slate-500">[{m.p2?.clube || 'BYE'}]</span>
                        </div>
                      </div>

                      {showSignatures && (
                        <div className="bg-emerald-50 p-1.5 border border-emerald-300 rounded text-[7.5px] text-center mt-2">
                          <span className="font-extrabold text-emerald-800 uppercase block">✓ Assinatura Eletrônica Registrada</span>
                          <span className="font-serif italic text-emerald-700 font-bold block">~ {m.p1.nome} / {m.p2 ? m.p2.nome : 'BYE'} / {arbName} ~</span>
                        </div>
                      )}
                    </div>
                  );
                })
              ) : (
                <div className="py-12 border-2 border-dashed border-slate-350 text-center italic text-xs text-slate-500">
                  Nenhum torneio selecionado para gerar os cupons de bobina.
                </div>
              )}
            </div>

          )}

          {/* OBSERVATIONS SECTOR */}
          {showObs && customObservation && (
            <div className="mt-4 pt-2 border-t border-slate-300 text-[9px] text-justify leading-relaxed text-slate-700 italic">
              <strong>Observações:</strong> {customObservation}
            </div>
          )}

          {/* FOOTER SIGNATURE SECTOR FOR FULL A4 SHEET */}
          {showSignatures && paperSize === 'a4' && (
            <div className="grid grid-cols-3 gap-8 border-t border-slate-300 pt-4 mt-4 text-slate-800">
              <div className="text-center">
                <div className="h-px bg-slate-950 mb-1"></div>
                <span className="text-[8.5px] tracking-wider uppercase font-bold text-slate-600 block">Coordenação Geral</span>
              </div>
              <div className="text-center">
                <div className="h-px bg-slate-950 mb-1"></div>
                <span className="text-[8.5px] tracking-wider uppercase font-bold text-slate-600 block">Árbitro Geral</span>
              </div>
              <div className="text-center">
                <div className="h-px bg-slate-950 mb-1"></div>
                <span className="text-[8.5px] tracking-wider uppercase font-bold text-slate-600 block">Responsável pelas Mesas</span>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* CONFIRMATION DIALOG MODAL WITH PAGE FORMAT SELECTION */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition duration-200">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl p-6 space-y-4 shadow-xl text-left">
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="p-2.5 bg-yellow-400/10 text-yellow-400 rounded-lg">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-slate-100 text-sm">Opções de Impressão & Exportação de Súmula</h3>
                <span className="text-[10px] text-slate-400 font-mono">Escolha o formato do papel antes de gerar</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Selecione o formato desejado para a súmula e clique em <strong>Gerar PDF</strong> ou <strong>Imprimir</strong>:
            </p>

            {/* FORMAT SELECTOR GRID INSIDE MODAL */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Formato da Página / Mídia:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaperSize('a4')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    paperSize === 'a4'
                      ? 'bg-yellow-400/15 border-yellow-400 text-yellow-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs font-black uppercase text-slate-200">📄 Folha A4 Inteira</span>
                  <span className="text-[10.5px] opacity-80 mt-1">Relatório executivo completo em tabela com lista de jogos e assinaturas</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaperSize('a6')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    paperSize === 'a6'
                      ? 'bg-yellow-400/15 border-yellow-400 text-yellow-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs font-black uppercase text-slate-200">📑 1/4 da Folha A4 (A6)</span>
                  <span className="text-[10.5px] opacity-80 mt-1">Mini-súmulas em cards individuais ideais para recorte e mesas</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaperSize('thermal80')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    paperSize === 'thermal80'
                      ? 'bg-yellow-400/15 border-yellow-400 text-yellow-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs font-black uppercase text-slate-200">🖨️ Bobina Térmica 80mm</span>
                  <span className="text-[10.5px] opacity-80 mt-1">Cupom contínuo para impressoras não-fiscais térmicas (Daruma/Elgin)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaperSize('thermal58')}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    paperSize === 'thermal58'
                      ? 'bg-yellow-400/15 border-yellow-400 text-yellow-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="text-xs font-black uppercase text-slate-200">📱 Bobina Térmica 58mm</span>
                  <span className="text-[10.5px] opacity-80 mt-1">Formato compacto para impressoras térmicas portáteis Bluetooth</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 bg-slate-950/80 p-3 rounded-xl border border-slate-850 text-2xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Torneio Selecionado:</span>
                <span className="text-slate-200 font-bold truncate max-w-[200px]">
                  {selectedTorneio?.nome || 'Torneio Padrão'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total de Partidas no Lote:</span>
                <span className="text-slate-200 font-bold">{matchRows.length} confrontos</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Bloco de Assinaturas Eletrônicas:</span>
                <span className={`font-bold ${showSignatures ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {showSignatures ? 'Habilitado ✓' : 'Desabilitado'}
                </span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowConfirmModal(false);
                  handleExportPdf();
                }}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-2.5 rounded-lg text-xs transition uppercase flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                Baixar PDF em {paperSize === 'a4' ? 'Folha A4' : paperSize === 'a6' ? '1/4 A4 (A6)' : paperSize === 'thermal80' ? 'Térmica 80mm' : 'Térmica 58mm'}
              </button>

              <button
                type="button"
                onClick={executeSystemPrint}
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black py-2.5 rounded-lg text-xs transition uppercase flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <Printer className="w-4 h-4 fill-slate-950" />
                Imprimir Direto na Impressora ({paperSize === 'a4' ? 'A4' : paperSize === 'a6' ? '1/4 A4' : paperSize === 'thermal80' ? '80mm' : '58mm'})
              </button>

              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-lg text-xs transition uppercase mt-1 cursor-pointer"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Exit Button for Immersive Mode */}
      {immersiveMode && onToggleImmersive && (
        <button
          type="button"
          onClick={onToggleImmersive}
          className="fixed bottom-6 right-6 z-50 no-print bg-yellow-400 hover:bg-yellow-300 text-slate-950 p-3.5 rounded-full shadow-2xl flex items-center justify-center cursor-pointer transition active:scale-95 duration-150 aspect-square border-2 border-slate-950 hover:scale-105"
          title="Sair do Modo Imersivo"
        >
          <Minimize2 className="w-5 h-5 animate-pulse" />
        </button>
      )}

    </div>
  );
}
