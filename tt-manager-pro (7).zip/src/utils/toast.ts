/**
 * Helper to dispatch beautiful toast notifications from any module or component in the system.
 */
export type ToastType = 'success' | 'error' | 'info' | 'warning';

export const triggerToast = (message: string, type: ToastType = 'success') => {
  const event = new CustomEvent('ttm-toast', {
    detail: { message, type }
  });
  window.dispatchEvent(event);
};
