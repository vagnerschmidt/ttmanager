import { jsPDF } from 'jspdf';
import { Torneio, Atleta, Resultado, SystemConfig } from '../types';

export type PaperSizeFormat = 'a4' | 'a6' | 'thermal80' | 'thermal58';

export interface MatchRow {
  num: number;
  p1: Atleta;
  p2: Atleta | null;
  resultado?: Resultado | null;
}

export interface GeneratePdfOptions {
  torneio?: Torneio;
  roundName: string;
  matchRows: MatchRow[];
  config: SystemConfig;
  showSignatures: boolean;
  customObservation?: string;
  showObs?: boolean;
  paperSize?: PaperSizeFormat;
}

/**
 * Main dispatcher function to generate PDF sumula in any requested format (A4, 1/4 A4, 80mm, 58mm)
 */
export function generateCustomSumulaPdf(options: GeneratePdfOptions) {
  const format = options.paperSize || 'a6';
  switch (format) {
    case 'a4':
      return generateFullA4SumulaPdf(options);
    case 'thermal80':
    case 'thermal58':
      return generateThermalSumulaPdf(options);
    case 'a6':
    default:
      return generateQuarterA4SumulaPdf(options);
  }
}

/**
 * 1/4 A4 (A6 Portrait: 105mm x 148.5mm) Mini Súmula Cards PDF Generator
 */
export function generateQuarterA4SumulaPdf({
  torneio,
  roundName,
  matchRows,
  config,
  showSignatures,
  customObservation,
  showObs
}: GeneratePdfOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [105, 148.5]
  });

  const pageWidth = 105;
  const pageHeight = 148.5;
  const margin = 5;
  const contentWidth = pageWidth - (margin * 2); // 95mm
  const setsMax = config.setsMax || 5;

  const drawPageHeader = (pageNum: number, totalPages: number) => {
    // Header background bar
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(margin, margin, contentWidth, 14, 'F');

    // Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(250, 204, 21); // yellow-400
    doc.text('SÚMULA OFICIAL - TÊNIS DE MESA', margin + (contentWidth / 2), margin + 4.5, { align: 'center' });

    // Torneio & Round
    doc.setFontSize(6.5);
    doc.setTextColor(255, 255, 255);
    const torNome = torneio?.nome ? torneio.nome.substring(0, 32).toUpperCase() : 'COMPETIÇÃO OFICIAL';
    doc.text(torNome, margin + (contentWidth / 2), margin + 8.5, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(5.5);
    doc.setTextColor(203, 213, 225);
    const roundText = `FASE: ${roundName.toUpperCase()} | DATA: ${new Date().toLocaleDateString('pt-BR')} | PÁG ${pageNum}/${totalPages}`;
    doc.text(roundText, margin + (contentWidth / 2), margin + 12, { align: 'center' });
  };

  const itemsPerPage = 2;
  const totalPages = Math.max(1, Math.ceil(matchRows.length / itemsPerPage));

  for (let p = 0; p < totalPages; p++) {
    if (p > 0) {
      doc.addPage([105, 148.5], 'portrait');
    }

    drawPageHeader(p + 1, totalPages);

    let currentY = margin + 16;
    const pageMatches = matchRows.slice(p * itemsPerPage, (p + 1) * itemsPerPage);

    if (pageMatches.length === 0) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text('Nenhuma partida cadastrada para este torneio.', margin + (contentWidth / 2), currentY + 15, { align: 'center' });
    }

    pageMatches.forEach((m) => {
      const cardHeight = showSignatures ? 54 : 42;

      // Card outer border
      doc.setDrawColor(30, 41, 59);
      doc.setFillColor(248, 250, 252);
      doc.roundedRect(margin, currentY, contentWidth, cardHeight, 1.5, 1.5, 'FD');

      // Card header bar
      doc.setFillColor(30, 41, 59);
      doc.rect(margin, currentY, contentWidth, 5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.setTextColor(255, 255, 255);
      doc.text(`CONFRONTO Nº ${m.num}  •  MESA ${m.num}`, margin + 3, currentY + 3.5);

      const res = m.resultado;
      const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));
      if (isFinished) {
        doc.setFillColor(16, 185, 129);
        doc.rect(margin + contentWidth - 22, currentY + 0.8, 20, 3.4, 'F');
        doc.setFontSize(5);
        doc.setTextColor(255, 255, 255);
        doc.text('ENCERRADO ✓', margin + contentWidth - 12, currentY + 3.2, { align: 'center' });
      } else {
        doc.setFillColor(234, 179, 8);
        doc.rect(margin + contentWidth - 22, currentY + 0.8, 20, 3.4, 'F');
        doc.setFontSize(5);
        doc.setTextColor(0, 0, 0);
        doc.text('EM ANDAMENTO', margin + contentWidth - 12, currentY + 3.2, { align: 'center' });
      }

      // Players block
      let py = currentY + 8;
      
      // Player A
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(15, 23, 42);
      const nameA = m.p1.nome.substring(0, 22);
      doc.text(nameA, margin + 3, py);
      
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(5.5);
      doc.setTextColor(100, 116, 139);
      const clubA = m.p1.clube ? `(${m.p1.clube.substring(0, 14)})` : '(Livre)';
      doc.text(clubA, margin + 38, py);

      // Score / Sets A
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      const scoreAText = isFinished ? String(res?.ponA ?? 0) : '[ ]';
      doc.text(scoreAText, margin + contentWidth - 6, py, { align: 'right' });

      py += 5;

      // Player B
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(15, 23, 42);
      const nameB = m.p2 ? m.p2.nome.substring(0, 22) : 'BYE / ISENTO';
      doc.text(nameB, margin + 3, py);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(5.5);
      doc.setTextColor(100, 116, 139);
      const clubB = m.p2 ? (m.p2.clube ? `(${m.p2.clube.substring(0, 14)})` : '(Livre)') : '-';
      doc.text(clubB, margin + 38, py);

      // Score / Sets B
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      const scoreBText = isFinished ? String(res?.ponB ?? 0) : '[ ]';
      doc.text(scoreBText, margin + contentWidth - 6, py, { align: 'right' });

      py += 4.5;

      // Sets table boxes
      const boxWidth = (contentWidth - 6) / setsMax;
      doc.setDrawColor(203, 213, 225);
      doc.setFillColor(255, 255, 255);
      
      for (let s = 0; s < setsMax; s++) {
        const bx = margin + 3 + (s * boxWidth);
        doc.rect(bx, py, boxWidth - 1, 6, 'FD');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(5);
        doc.setTextColor(100, 116, 139);
        doc.text(`S${s + 1}`, bx + (boxWidth / 2) - 0.5, py + 2.2, { align: 'center' });

        doc.setFontSize(5.5);
        doc.setTextColor(15, 23, 42);
        doc.text('. x .', bx + (boxWidth / 2) - 0.5, py + 5, { align: 'center' });
      }

      py += 8;

      // Electronic Signatures Block
      if (showSignatures) {
        doc.setDrawColor(226, 232, 240);
        doc.line(margin + 3, py, margin + contentWidth - 3, py);
        py += 2;

        const arbName = res?.arb || 'Árbitro Oficial';
        const timestamp = res?.dt ? new Date(res.dt).toLocaleString('pt-BR') : new Date().toLocaleString('pt-BR');
        const hashValA = `SIG-A${Math.abs(m.p1.id.split('').reduce((a, b) => a + b.charCodeAt(0), 0) * 17 % 9999).toString().padStart(4, '0')}`;
        const hashValB = m.p2 ? `SIG-B${Math.abs(m.p2.id.split('').reduce((a, b) => a + b.charCodeAt(0), 0) * 19 % 9999).toString().padStart(4, '0')}` : 'SIG-BYE';
        const hashValArb = `SIG-ARB${Math.abs(arbName.split('').reduce((a, b) => a + b.charCodeAt(0), 0) * 23 % 9999).toString().padStart(4, '0')}`;

        const colW = (contentWidth - 6) / 3;

        // Signature Col 1: Atleta A
        let sx1 = margin + 3;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(4.8);
        doc.setTextColor(15, 23, 42);
        doc.text(`Atleta: ${m.p1.nome.split(' ')[0]}`, sx1, py + 2);

        if (isFinished) {
          doc.setFont('times', 'italic');
          doc.setFontSize(6);
          doc.setTextColor(16, 185, 129);
          doc.text(`~ ${m.p1.nome} ~`, sx1, py + 5);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(4);
          doc.setTextColor(100, 116, 139);
          doc.text(`✓ ASSINADO DIGITAL`, sx1, py + 7.5);
          doc.text(`${hashValA} | ${timestamp.split(' ')[0]}`, sx1, py + 9.5);
        } else {
          doc.setDrawColor(100, 116, 139);
          doc.line(sx1, py + 7, sx1 + colW - 3, py + 7);
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(4);
          doc.setTextColor(148, 163, 184);
          doc.text('Assinatura do Atleta', sx1, py + 9.5);
        }

        // Signature Col 2: Atleta B
        let sx2 = sx1 + colW;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(4.8);
        doc.setTextColor(15, 23, 42);
        doc.text(`Atleta: ${m.p2 ? m.p2.nome.split(' ')[0] : 'BYE'}`, sx2, py + 2);

        if (isFinished && m.p2) {
          doc.setFont('times', 'italic');
          doc.setFontSize(6);
          doc.setTextColor(16, 185, 129);
          doc.text(`~ ${m.p2.nome} ~`, sx2, py + 5);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(4);
          doc.setTextColor(100, 116, 139);
          doc.text(`✓ ASSINADO DIGITAL`, sx2, py + 7.5);
          doc.text(`${hashValB} | ${timestamp.split(' ')[0]}`, sx2, py + 9.5);
        } else {
          doc.setDrawColor(100, 116, 139);
          doc.line(sx2, py + 7, sx2 + colW - 3, py + 7);
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(4);
          doc.setTextColor(148, 163, 184);
          doc.text('Assinatura do Atleta', sx2, py + 9.5);
        }

        // Signature Col 3: Árbitro
        let sx3 = sx2 + colW;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(4.8);
        doc.setTextColor(15, 23, 42);
        doc.text(`Árbitro: ${arbName.split(' ')[0]}`, sx3, py + 2);

        if (isFinished) {
          doc.setFont('times', 'italic');
          doc.setFontSize(6);
          doc.setTextColor(16, 185, 129);
          doc.text(`~ ${arbName} ~`, sx3, py + 5);

          doc.setFont('helvetica', 'normal');
          doc.setFontSize(4);
          doc.setTextColor(100, 116, 139);
          doc.text(`✓ VALIDADOR OFICIAL`, sx3, py + 7.5);
          doc.text(`${hashValArb} | ${timestamp.split(' ')[0]}`, sx3, py + 9.5);
        } else {
          doc.setDrawColor(100, 116, 139);
          doc.line(sx3, py + 7, sx3 + colW - 3, py + 7);
          doc.setFont('helvetica', 'italic');
          doc.setFontSize(4);
          doc.setTextColor(148, 163, 184);
          doc.text('Assinatura Árbitro', sx3, py + 9.5);
        }
      }

      currentY += cardHeight + 4;
    });

    // Custom Observation footer on last page
    if (p === totalPages - 1 && showObs && customObservation) {
      const obsY = Math.min(pageHeight - 12, currentY + 2);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(5);
      doc.setTextColor(71, 85, 105);
      doc.text(`Obs: ${customObservation.substring(0, 110)}`, margin, obsY, { maxWidth: contentWidth });
    }

    // Page footer
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(4.5);
    doc.setTextColor(100, 116, 139);
    doc.text('SÚMULA FORMATADA EM 1/4 A4 (105x148mm) • TT MANAGER PRO DIGITAL SIGNATURE ENGINE', margin + (contentWidth / 2), pageHeight - 2, { align: 'center' });
  }

  const safeName = (torneio?.nome || 'torneio').replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
  doc.save(`sumula_1-4_A4_${safeName}.pdf`);
}

/**
 * Full A4 Page (210mm x 297mm) Comprehensive Table Grid PDF Generator
 */
export function generateFullA4SumulaPdf({
  torneio,
  roundName,
  matchRows,
  config,
  showSignatures,
  customObservation,
  showObs
}: GeneratePdfOptions) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 10;
  const contentWidth = pageWidth - (margin * 2); // 190mm
  const setsMax = config.setsMax || 5;

  const itemsPerPage = 12;
  const totalPages = Math.max(1, Math.ceil(matchRows.length / itemsPerPage));

  const drawA4Header = (pageNum: number) => {
    // Top banner
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(margin, margin, contentWidth, 20, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(250, 204, 21); // yellow-400
    doc.text('SÚMULA OFICIAL DE COMPETIÇÃO', margin + 6, margin + 7);

    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    const torNome = torneio?.nome ? torneio.nome.toUpperCase() : 'TORNEIO DE TÊNIS DE MESA';
    doc.text(torNome, margin + 6, margin + 13);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(203, 213, 225);
    doc.text(`FASE: ${roundName.toUpperCase()}  |  SISTEMA: MELHOR DE ${setsMax} SETS (${config.setsPoints || 11} PTS)`, margin + 6, margin + 17.5);

    // Right header metadata
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text(`DATA: ${new Date().toLocaleDateString('pt-BR')}`, margin + contentWidth - 6, margin + 8, { align: 'right' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(203, 213, 225);
    doc.text(`FORMATO: FOLHA A4 INTEIRA`, margin + contentWidth - 6, margin + 13, { align: 'right' });
    doc.text(`PÁGINA ${pageNum} DE ${totalPages}`, margin + contentWidth - 6, margin + 17.5, { align: 'right' });
  };

  for (let p = 0; p < totalPages; p++) {
    if (p > 0) {
      doc.addPage('a4', 'portrait');
    }

    drawA4Header(p + 1);

    let currentY = margin + 24;
    const pageMatches = matchRows.slice(p * itemsPerPage, (p + 1) * itemsPerPage);

    // Table Column Dimensions
    const colMesa = 12;
    const colAtletaA = 48;
    const colSetsTotal = 35; // 35 / setsMax per set box
    const colSetBox = colSetsTotal / setsMax;
    const colAtletaB = 48;
    const colPlacar = 20;
    const colStatus = 27;

    // Table Header
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(margin, currentY, contentWidth, 8, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);

    let cx = margin;
    doc.text('MESA', cx + (colMesa / 2), currentY + 5.5, { align: 'center' });
    cx += colMesa;

    doc.text('ATLETA A (CLUBE)', cx + 3, currentY + 5.5);
    cx += colAtletaA;

    doc.text(`SETS (1-${setsMax})`, cx + (colSetsTotal / 2), currentY + 5.5, { align: 'center' });
    cx += colSetsTotal;

    doc.text('ATLETA B (CLUBE)', cx + 3, currentY + 5.5);
    cx += colAtletaB;

    doc.text('PLACAR', cx + (colPlacar / 2), currentY + 5.5, { align: 'center' });
    cx += colPlacar;

    doc.text('ASSINATURA / STATUS', cx + (colStatus / 2), currentY + 5.5, { align: 'center' });

    currentY += 8;

    if (pageMatches.length === 0) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text('Nenhum confronto cadastrado para este torneio.', margin + (contentWidth / 2), currentY + 20, { align: 'center' });
    }

    // Table Rows
    pageMatches.forEach((m, idx) => {
      const rowHeight = 15;
      const isEven = idx % 2 === 0;

      // Row background
      if (isEven) {
        doc.setFillColor(248, 250, 252); // slate-50
      } else {
        doc.setFillColor(255, 255, 255);
      }
      doc.rect(margin, currentY, contentWidth, rowHeight, 'F');

      // Outer border for row
      doc.setDrawColor(203, 213, 225);
      doc.rect(margin, currentY, contentWidth, rowHeight, 'D');

      const res = m.resultado;
      const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));

      let x = margin;

      // Col Mesa
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text(String(m.num), x + (colMesa / 2), currentY + 9, { align: 'center' });
      x += colMesa;

      // Col Atleta A
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      const nameA = m.p1.nome.substring(0, 26);
      doc.text(nameA, x + 3, currentY + 6.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      const clubA = m.p1.clube ? `Clube: ${m.p1.clube.substring(0, 22)}` : 'Atleta Livre';
      doc.text(clubA, x + 3, currentY + 11.5);
      x += colAtletaA;

      // Col Sets Boxes
      for (let s = 0; s < setsMax; s++) {
        const bx = x + (s * colSetBox);
        doc.setDrawColor(226, 232, 240);
        doc.rect(bx + 0.5, currentY + 2, colSetBox - 1, rowHeight - 4, 'D');

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5);
        doc.setTextColor(148, 163, 184);
        doc.text(`S${s + 1}`, bx + (colSetBox / 2), currentY + 5.5, { align: 'center' });

        doc.setFontSize(6.5);
        doc.setTextColor(71, 85, 105);
        doc.text('.x.', bx + (colSetBox / 2), currentY + 11, { align: 'center' });
      }
      x += colSetsTotal;

      // Col Atleta B
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      const nameB = m.p2 ? m.p2.nome.substring(0, 26) : 'BYE / ISENTO';
      doc.text(nameB, x + 3, currentY + 6.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      const clubB = m.p2 ? (m.p2.clube ? `Clube: ${m.p2.clube.substring(0, 22)}` : 'Atleta Livre') : '-';
      doc.text(clubB, x + 3, currentY + 11.5);
      x += colAtletaB;

      // Col Placar
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      if (isFinished) {
        doc.setTextColor(16, 185, 129); // emerald
        doc.text(`[ ${res?.ponA} x ${res?.ponB} ]`, x + (colPlacar / 2), currentY + 9, { align: 'center' });
      } else {
        doc.setTextColor(100, 116, 139);
        doc.text('[ ] x [ ]', x + (colPlacar / 2), currentY + 9, { align: 'center' });
      }
      x += colPlacar;

      // Col Status & Hash
      const hashA = Math.abs(m.p1.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) * 17 % 9999).toString().padStart(4, '0');
      if (isFinished) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(6.5);
        doc.setTextColor(16, 185, 129);
        doc.text('✓ VALIDADO', x + (colStatus / 2), currentY + 6, { align: 'center' });

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5.5);
        doc.setTextColor(100, 116, 139);
        doc.text(`SIG-A${hashA}`, x + (colStatus / 2), currentY + 11, { align: 'center' });
      } else {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(6.5);
        doc.setTextColor(148, 163, 184);
        doc.text('Em Andamento', x + (colStatus / 2), currentY + 9, { align: 'center' });
      }

      currentY += rowHeight;
    });

    // Custom Observation Box
    if (p === totalPages - 1 && showObs && customObservation) {
      currentY += 4;
      doc.setFillColor(241, 245, 249); // slate-100
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(margin, currentY, contentWidth, 12, 1, 1, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(15, 23, 42);
      doc.text('OBSERVAÇÕES ADICIONAIS DA COMISSÃO ORGANIZADORA:', margin + 3, currentY + 4.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(51, 65, 85);
      doc.text(customObservation.substring(0, 180), margin + 3, currentY + 9, { maxWidth: contentWidth - 6 });

      currentY += 14;
    }

    // Full A4 Official Signatures Footer (on last page)
    if (p === totalPages - 1 && showSignatures) {
      const sigBlockY = Math.max(currentY + 6, pageHeight - 38);

      doc.setDrawColor(203, 213, 225);
      doc.line(margin, sigBlockY, margin + contentWidth, sigBlockY);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(15, 23, 42);
      doc.text('VALIDAÇÃO OFICIAL DA COMISSÃO ORGANIZADORA E ÁRBITROS', margin, sigBlockY + 4);

      const colSigW = contentWidth / 3;

      // Sig 1
      const s1x = margin + 5;
      doc.line(s1x, sigBlockY + 18, s1x + colSigW - 10, sigBlockY + 18);
      doc.setFontSize(7);
      doc.text('Coordenação Geral do Torneio', s1x + ((colSigW - 10) / 2), sigBlockY + 22, { align: 'center' });

      // Sig 2
      const s2x = margin + colSigW + 5;
      doc.line(s2x, sigBlockY + 18, s2x + colSigW - 10, sigBlockY + 18);
      doc.text('Árbitro Geral Responsável', s2x + ((colSigW - 10) / 2), sigBlockY + 22, { align: 'center' });

      // Sig 3
      const s3x = margin + (colSigW * 2) + 5;
      doc.line(s3x, sigBlockY + 18, s3x + colSigW - 10, sigBlockY + 18);
      doc.text('Responsável pelas Mesas', s3x + ((colSigW - 10) / 2), sigBlockY + 22, { align: 'center' });
    }

    // Page Footer
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6);
    doc.setTextColor(148, 163, 184);
    doc.text('TT MANAGER PRO • SISTEMA OFICIAL DE GESTÃO DE TORNEIOS DE TÊNIS DE MESA', margin + (contentWidth / 2), pageHeight - 4, { align: 'center' });
  }

  const safeName = (torneio?.nome || 'torneio').replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
  doc.save(`sumula_A4_${safeName}.pdf`);
}

/**
 * Thermal Printer (80mm or 58mm Spool) PDF Generator
 */
export function generateThermalSumulaPdf({
  torneio,
  roundName,
  matchRows,
  config,
  showSignatures,
  customObservation,
  showObs,
  paperSize = 'thermal80'
}: GeneratePdfOptions) {
  const is58mm = paperSize === 'thermal58';
  const pageWidth = is58mm ? 58 : 80;
  const pageHeight = is58mm ? 180 : 220; // Standard thermal spool cut length per batch
  const margin = 3;
  const contentWidth = pageWidth - (margin * 2);

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [pageWidth, pageHeight]
  });

  const setsMax = config.setsMax || 5;
  const itemsPerPage = is58mm ? 2 : 3;
  const totalPages = Math.max(1, Math.ceil(matchRows.length / itemsPerPage));

  const drawThermalHeader = (pageNum: number) => {
    doc.setFillColor(15, 23, 42);
    doc.rect(margin, margin, contentWidth, 12, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(is58mm ? 6.5 : 8);
    doc.setTextColor(250, 204, 21);
    doc.text('SÚMULA TÊNIS DE MESA', margin + (contentWidth / 2), margin + 4, { align: 'center' });

    doc.setFontSize(is58mm ? 5 : 6);
    doc.setTextColor(255, 255, 255);
    const torNome = torneio?.nome ? torneio.nome.substring(0, is58mm ? 20 : 30).toUpperCase() : 'COMPETIÇÃO OFICIAL';
    doc.text(torNome, margin + (contentWidth / 2), margin + 7.5, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(4.5);
    doc.setTextColor(203, 213, 225);
    doc.text(`FASE: ${roundName.toUpperCase()} | PÁG ${pageNum}/${totalPages}`, margin + (contentWidth / 2), margin + 10.5, { align: 'center' });
  };

  for (let p = 0; p < totalPages; p++) {
    if (p > 0) {
      doc.addPage([pageWidth, pageHeight], 'portrait');
    }

    drawThermalHeader(p + 1);

    let currentY = margin + 14;
    const pageMatches = matchRows.slice(p * itemsPerPage, (p + 1) * itemsPerPage);

    pageMatches.forEach((m) => {
      const cardHeight = showSignatures ? (is58mm ? 48 : 42) : (is58mm ? 36 : 30);

      doc.setDrawColor(0, 0, 0);
      doc.setFillColor(255, 255, 255);
      doc.roundedRect(margin, currentY, contentWidth, cardHeight, 1, 1, 'FD');

      // Card Header
      doc.setFillColor(0, 0, 0);
      doc.rect(margin, currentY, contentWidth, 4.5, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(is58mm ? 5.5 : 6.5);
      doc.setTextColor(255, 255, 255);
      doc.text(`CONFRONTO Nº ${m.num} - MESA ${m.num}`, margin + 2, currentY + 3.2);

      const res = m.resultado;
      const isFinished = !!(res && (res.ponA > 0 || res.ponB > 0 || res.wo));

      let py = currentY + 7;

      // Player A
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(is58mm ? 6 : 7);
      doc.setTextColor(0, 0, 0);
      doc.text(m.p1.nome.substring(0, is58mm ? 16 : 22), margin + 2, py);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(is58mm ? 7 : 8);
      const scoreAText = isFinished ? String(res?.ponA ?? 0) : '[ ]';
      doc.text(scoreAText, margin + contentWidth - 3, py, { align: 'right' });

      py += 4.5;

      // Player B
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(is58mm ? 6 : 7);
      doc.setTextColor(0, 0, 0);
      const nameB = m.p2 ? m.p2.nome.substring(0, is58mm ? 16 : 22) : 'BYE / ISENTO';
      doc.text(nameB, margin + 2, py);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(is58mm ? 7 : 8);
      const scoreBText = isFinished ? String(res?.ponB ?? 0) : '[ ]';
      doc.text(scoreBText, margin + contentWidth - 3, py, { align: 'right' });

      py += 4.5;

      // Sets boxes
      const boxWidth = (contentWidth - 4) / setsMax;
      for (let s = 0; s < setsMax; s++) {
        const bx = margin + 2 + (s * boxWidth);
        doc.setDrawColor(150, 150, 150);
        doc.rect(bx, py, boxWidth - 0.8, 4.5, 'D');

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(4);
        doc.setTextColor(80, 80, 80);
        doc.text(`S${s + 1}`, bx + (boxWidth / 2) - 0.4, py + 1.8, { align: 'center' });
        doc.text('.x.', bx + (boxWidth / 2) - 0.4, py + 3.8, { align: 'center' });
      }

      py += 6.5;

      // Electronic Signatures
      if (showSignatures) {
        doc.setDrawColor(0, 0, 0);
        doc.line(margin + 2, py, margin + contentWidth - 2, py);
        py += 1.5;

        const arbName = res?.arb || 'Árbitro Oficial';
        const hashValA = `SIG-A${Math.abs(m.p1.id.split('').reduce((a, b) => a + b.charCodeAt(0), 0) * 17 % 9999).toString().padStart(4, '0')}`;
        const hashValArb = `SIG-ARB${Math.abs(arbName.split('').reduce((a, b) => a + b.charCodeAt(0), 0) * 23 % 9999).toString().padStart(4, '0')}`;

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(4.5);
        doc.setTextColor(0, 0, 0);
        doc.text(`✓ ASSINATURAS ELETRÔNICAS`, margin + 2, py + 2);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(4);
        doc.setTextColor(60, 60, 60);
        doc.text(`A: ${m.p1.nome.split(' ')[0]} (${hashValA})`, margin + 2, py + 4.5);
        doc.text(`ARB: ${arbName.split(' ')[0]} (${hashValArb})`, margin + 2, py + 7);
      }

      currentY += cardHeight + 3;
    });

    if (p === totalPages - 1 && showObs && customObservation) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(4.5);
      doc.setTextColor(80, 80, 80);
      doc.text(`Obs: ${customObservation.substring(0, 70)}`, margin, pageHeight - 6, { maxWidth: contentWidth });
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(4);
    doc.setTextColor(100, 100, 100);
    doc.text(`IMPRESSÃO TÉRMICA (${paperSize.toUpperCase()}) • TT MANAGER PRO`, margin + (contentWidth / 2), pageHeight - 2, { align: 'center' });
  }

  const safeName = (torneio?.nome || 'torneio').replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
  doc.save(`sumula_${paperSize}_${safeName}.pdf`);
}
