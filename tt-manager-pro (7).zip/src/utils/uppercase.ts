/**
 * Utility to convert string strings to uppercase (Caixa Alta) recursively.
 * Keeps system-level safe tags (like IDs, emails, dates and profile photographs) intact.
 */
export function toUpperCaseRecursive<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;

  if (typeof obj === 'string') {
    return obj.toUpperCase() as unknown as T;
  }

  if (Array.isArray(obj)) {
    return obj.map(item => toUpperCaseRecursive(item)) as unknown as T;
  }

  if (typeof obj === 'object') {
    const copy = { ...obj } as any;
    for (const key in copy) {
      if (Object.prototype.hasOwnProperty.call(copy, key)) {
        const value = copy[key];
        
        // Skip properties that shouldn't be capitalized
        if (
          key.toLowerCase().endsWith('id') || 
          key === 'id' ||
          key === 'idmin' ||
          key === 'idmax' ||
          key === 'foto' ||
          key === 'email' ||
          key === 'email2' ||
          key === 'fbkey' ||
          key === 'fbpid' ||
          key === 'fbauth' ||
          key === 'dt' ||
          key === 'nasc' ||
          key === 'ini' ||
          key === 'fim' ||
          key === 'hora' ||
          key === 'admissao' ||
          key === 'demissao' ||
          key === 'dt' ||
          key === 'site'
        ) {
          continue;
        }

        if (typeof value === 'string') {
          copy[key] = value.toUpperCase();
        } else if (typeof value === 'object' && value !== null) {
          copy[key] = toUpperCaseRecursive(value);
        }
      }
    }
    return copy as T;
  }

  return obj;
}
