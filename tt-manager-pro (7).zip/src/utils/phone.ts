/**
 * Normalizes Brazilian phone numbers to have the +55 country code and a standard format.
 */
export function normalizePhoneToBrazil(value: string): string {
  if (!value) return '';
  
  // Keep only digits
  const digits = value.replace(/\D/g, '');
  if (!digits) return value;

  // Case 1: Already has country code 55
  if (digits.startsWith('55') && (digits.length === 12 || digits.length === 13)) {
    const ddd = digits.slice(2, 4);
    const rest = digits.slice(4);
    if (rest.length === 9) {
      return `+55 (${ddd}) ${rest.slice(0, 5)}-${rest.slice(5)}`;
    } else {
      return `+55 (${ddd}) ${rest.slice(0, 4)}-${rest.slice(4)}`;
    }
  }

  // Case 2: DDD (2 digits) + number (8 or 9 digits) -> total 10 or 11 digits
  if (digits.length === 11) {
    const ddd = digits.slice(0, 2);
    const rest = digits.slice(2);
    return `+55 (${ddd}) ${rest.slice(0, 5)}-${rest.slice(5)}`;
  }
  if (digits.length === 10) {
    const ddd = digits.slice(0, 2);
    const rest = digits.slice(2);
    return `+55 (${ddd}) ${rest.slice(0, 4)}-${rest.slice(4)}`;
  }

  // Case 3: Just local number without DDD (8 or 9 digits) -> format with +55 but no DDD parenthesis
  if (digits.length === 9) {
    return `+55 9${digits.slice(1, 5)}-${digits.slice(5)}`;
  }
  if (digits.length === 8) {
    return `+55 ${digits.slice(0, 4)}-${digits.slice(4)}`;
  }

  // Fallback: if it doesn't start with 55, prepend +55
  if (!digits.startsWith('55')) {
    return `+55 ${digits}`;
  }

  return `+${digits}`;
}
