/**
 * Calculates the standard CRC16 CCITT (0x1021) validation code required for standard Brazilian PIX.
 */
function calculateCRC16(str: string): string {
  let crc = 0xFFFF;
  const polynomial = 0x1021;

  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    for (let b = 0; b < 8; b++) {
      const bit = ((code >> (7 - b)) & 1) === 1;
      const c15 = ((crc >> 15) & 1) === 1;
      crc <<= 1;
      if (bit !== c15) {
        crc ^= polynomial;
      }
    }
  }

  crc &= 0xFFFF;
  const hex = crc.toString(16).toUpperCase();
  return hex.padStart(4, '0');
}

export interface PixConfig {
  key: string;
  amount: number;
  recipientName: string;
  recipientCity: string;
  txid: string; // Dynamic unique transaction identifier
}

/**
 * Formats a payload for Pix using compliance with EMV-co standards (BR Code)
 */
export function generatePixPayload(config: PixConfig): string {
  const sanitize = (val: string) => 
    val.normalize("NFD")
       .replace(/[\u0300-\u036f]/g, "") // removes accents
       .replace(/[^a-zA-Z0-9 ]/g, "") // retains alphanumeric + spaces
       .toUpperCase();

  const name = sanitize(config.recipientName || 'ORGANIZACAO COPA').substring(0, 25).trim();
  const city = sanitize(config.recipientCity || 'SAO PAULO').substring(0, 15).trim();
  const key = (config.key || 'chave@exemplo.com').trim();
  const txid = sanitize(config.txid || 'COPATTPAY').replace(/\s/g, '').substring(0, 25);
  const amountStr = (config.amount || 0).toFixed(2);

  // Helper function to format EMV data objects [ID][Length][Value]
  const f = (id: string, value: string) => {
    const lenStr = value.length.toString().padStart(2, '0');
    return id + lenStr + value;
  };

  // Merchant Account Information (ID 26)
  const gui = f('00', 'br.gov.bcb.pix');
  const merchantKey = f('01', key);
  const merchantAccountInfo = f('26', gui + merchantKey);

  // Payload segments
  let payload = f('00', '01'); // Pay-out format indicator
  payload += merchantAccountInfo;
  payload += f('52', '0000'); // Merchant category code
  payload += f('53', '986'); // Currency (BRL is 986)
  payload += f('54', amountStr); // Amount
  payload += f('58', 'BR'); // Country Code
  payload += f('59', name); // Recipient
  payload += f('60', city); // City

  const additionalData = f('05', txid);
  payload += f('62', additionalData);

  // 63 is the CRC identifier; 04 stands for the length of CRC16 string (always 4 chars)
  payload += '6304';

  const crc = calculateCRC16(payload);
  return payload + crc;
}

/**
 * Returns a high-speed Google Charts or QRServer image link rendering the Pix Copy & Paste string
 * inside an iframe/img widget.
 */
export function getPixQRCodeUrl(pixString: string, size = 300): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(pixString)}`;
}

/**
 * Helper to produce a unique user-friendly Athlete ID
 */
export function generateAthleteId(atletaId: string, cpf?: string): string {
  const cleanId = atletaId.replace(/[^0-9]/g, '').slice(-4);
  const nameSuffix = cleanId || Math.floor(100 + Math.random() * 900).toString();
  const cpfSegment = cpf ? cpf.replace(/[^0-9]/g, '').slice(0, 3) : 'X';
  return `ATL-2026-${cpfSegment}-${nameSuffix}`;
}

/**
 * Helper to produce a unique transaction / payment ID
 */
export function generatePaymentId(inscriptionId: string): string {
  const cleanIns = inscriptionId.replace(/[^0-9]/g, '').slice(-6);
  const suffix = cleanIns || Math.floor(1000 + Math.random() * 9000).toString();
  return `TX-PIX-${suffix}`;
}

/**
 * Generates a standard RFC4122 UUID v4 string.
 */
export function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
