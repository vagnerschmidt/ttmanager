import { Atleta, Categoria, Inscricao, BracketMatch, Torneio } from '../types';

/**
 * Keeps already-generated brackets (chaveamentos) and group stages (fases de grupos)
 * in sync with the athlete data whenever it's updated — for example via the
 * "Sincronizar Planilha" import. Brackets store their own snapshot of each Atleta at
 * generation time, so without this, importing an updated spreadsheet (new rating,
 * corrected name, new club, etc.) would not reflect on chaveamentos already drawn.
 * Matches athletes by id and replaces the snapshot, preserving all scores/results.
 * Returns how many bracket/group entries were updated.
 */
export function refreshAthleteSnapshotsInStorage(
  torneios: Torneio[],
  categorias: Categoria[],
  atletas: Atleta[]
): number {
  const atletaMap = new Map(atletas.map(a => [a.id, a]));
  let updatedCount = 0;

  const refreshAthlete = (a: Atleta | null | undefined): Atleta | null => {
    if (!a) return null;
    const fresh = atletaMap.get(a.id);
    return fresh || a;
  };

  torneios.forEach(t => {
    categorias.forEach(c => {
      // Refresh knockout bracket (chaveamento eliminatório)
      const bracketKey = `ttmpro_bracket_${t.id}_${c.id}`;
      const savedBracket = localStorage.getItem(bracketKey);
      if (savedBracket) {
        try {
          const parsed = JSON.parse(savedBracket);
          if (parsed && Array.isArray(parsed.matches)) {
            let changed = false;
            parsed.matches = parsed.matches.map((m: any) => {
              const newP1 = refreshAthlete(m.p1);
              const newP2 = refreshAthlete(m.p2);
              if (newP1 !== m.p1 || newP2 !== m.p2) changed = true;
              return { ...m, p1: newP1, p2: newP2 };
            });
            if (changed) {
              localStorage.setItem(bracketKey, JSON.stringify(parsed));
              updatedCount++;
            }
          }
        } catch (e) {
          console.error('Erro ao atualizar chaveamento a partir da planilha:', e);
        }
      }

      // Refresh group stage (fase de grupos / round-robin)
      const groupsKey = `ttmpro_grupos_${t.id}_${c.id}`;
      const savedGroups = localStorage.getItem(groupsKey);
      if (savedGroups) {
        try {
          const parsed = JSON.parse(savedGroups);
          if (parsed && Array.isArray(parsed.groups)) {
            let changed = false;
            parsed.groups = parsed.groups.map((g: any) => ({
              ...g,
              atletas: (g.atletas || []).map((a: Atleta) => {
                const fresh = refreshAthlete(a);
                if (fresh !== a) changed = true;
                return fresh;
              }),
              matches: (g.matches || []).map((m: any) => {
                const newP1 = refreshAthlete(m.p1);
                const newP2 = refreshAthlete(m.p2);
                if (newP1 !== m.p1 || newP2 !== m.p2) changed = true;
                return { ...m, p1: newP1, p2: newP2 };
              })
            }));
            if (changed) {
              localStorage.setItem(groupsKey, JSON.stringify(parsed));
              updatedCount++;
            }
          }
        } catch (e) {
          console.error('Erro ao atualizar fase de grupos a partir da planilha:', e);
        }
      }
    });
  });

  return updatedCount;
}

export const createEmptyMatches = (): BracketMatch[] => [
  { id: 'q1', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q2', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q3', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'q4', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 's1', round: 'semis', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 's2', round: 'semis', p1: null, p2: null, score1: 0, score2: 0 },
  { id: 'f1', round: 'final', p1: null, p2: null, score1: 0, score2: 0 }
];

export function propagateBracket(targetMatches: BracketMatch[]): BracketMatch[] {
  const updated = targetMatches.map(m => ({ ...m }));
  const findMatch = (id: string) => updated.find(m => m.id === id)!;
  
  const q1 = findMatch('q1');
  const q2 = findMatch('q2');
  const q3 = findMatch('q3');
  const q4 = findMatch('q4');
  const s1 = findMatch('s1');
  const s2 = findMatch('s2');
  const f1 = findMatch('f1');
  
  const getWinner = (m: BracketMatch): Atleta | null => {
    if (!m.p1 && !m.p2) return null;
    if (m.p1 && !m.p2) return m.p1;
    if (!m.p1 && m.p2) return m.p2;
    if (m.score1 > m.score2) return m.p1;
    if (m.score2 > m.score1) return m.p2;
    return m.p1;
  };
  
  s1.p1 = getWinner(q1);
  s1.p2 = getWinner(q2);
  s2.p1 = getWinner(q3);
  s2.p2 = getWinner(q4);
  f1.p1 = getWinner(s1);
  f1.p2 = getWinner(s2);
  
  return updated;
}

/**
 * Generates and saves automatic bracket for a category, including ALL registered athletes
 * regardless of whether subscription fee is paid, pending, or exempt.
 */
export function generateAutoBracketForCategory(
  torneioId: string,
  catIdOrName: string,
  atletas: Atleta[],
  inscricoes: Inscricao[],
  categorias: Categoria[],
  strategy: 'rating' | 'random' = 'rating'
): { success: boolean; message: string; count: number } {
  if (!torneioId || !catIdOrName) {
    return { success: false, message: 'Torneio ou categoria não selecionados', count: 0 };
  }

  // Find matching category
  const cat = categorias.find(
    c => c.id === catIdOrName || c.nome.trim().toLowerCase() === catIdOrName.trim().toLowerCase()
  );
  if (!cat) {
    return { success: false, message: `Categoria "${catIdOrName}" não encontrada`, count: 0 };
  }

  const catName = cat.nome.trim().toLowerCase();

  // Find all enrolled athletes in this tournament and category (regardless of payment status)
  const matchedInscricoes = inscricoes.filter(
    i => i.torneioId === torneioId && i.categoria.trim().toLowerCase() === catName
  );

  let candidates: Atleta[] = [];
  if (matchedInscricoes.length > 0) {
    // Include ALL enrolled athletes, regardless of payment status (Pendente, Pago, Isento)
    candidates = atletas.filter(a => matchedInscricoes.some(ins => ins.atletaId === a.id));
  } else {
    // Fallback to athletes associated with category name
    candidates = atletas.filter(a => {
      if (!a.cat) return false;
      return a.cat.split(',').map(s => s.trim().toLowerCase()).includes(catName);
    });
  }

  if (candidates.length < 2) {
    // Fallback to all active athletes
    candidates = atletas.filter(a => a.status === 'Ativo');
  }

  if (candidates.length < 2) {
    return {
      success: false,
      message: `São necessários no mínimo 2 atletas cadastrados para gerar o chaveamento da categoria "${cat.nome}"`,
      count: candidates.length
    };
  }

  // Slice if category has max limit
  if (cat.max) {
    const limit = parseInt(cat.max, 10);
    if (candidates.length > limit) {
      candidates = candidates.slice(0, limit);
    }
  }

  // Sort candidates by strategy
  if (strategy === 'rating') {
    candidates = [...candidates].sort((a, b) => b.rating - a.rating);
  } else {
    candidates = [...candidates].sort(() => Math.random() - 0.5);
  }

  const top8 = candidates.slice(0, 8);
  const qMatches = createEmptyMatches();

  if (strategy === 'rating') {
    qMatches[0].p1 = top8[0] || null; qMatches[0].p2 = top8[7] || null;
    qMatches[1].p1 = top8[3] || null; qMatches[1].p2 = top8[4] || null;
    qMatches[2].p1 = top8[2] || null; qMatches[2].p2 = top8[5] || null;
    qMatches[3].p1 = top8[1] || null; qMatches[3].p2 = top8[6] || null;
  } else {
    qMatches[0].p1 = top8[0] || null; qMatches[0].p2 = top8[1] || null;
    qMatches[1].p1 = top8[2] || null; qMatches[1].p2 = top8[3] || null;
    qMatches[2].p1 = top8[4] || null; qMatches[2].p2 = top8[5] || null;
    qMatches[3].p1 = top8[6] || null; qMatches[3].p2 = top8[7] || null;
  }

  const propagated = propagateBracket(qMatches);

  // Save bracket to localStorage
  const key = `ttmpro_bracket_${torneioId}_${cat.id}`;
  localStorage.setItem(key, JSON.stringify({
    matches: propagated,
    generated: true
  }));

  return {
    success: true,
    message: `Chaveamento automático gerado para ${top8.length} atletas na categoria "${cat.nome}" (independentemente de pagamento)!`,
    count: top8.length
  };
}
