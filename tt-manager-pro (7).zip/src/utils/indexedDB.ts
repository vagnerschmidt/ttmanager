// IndexedDB Persistence Utility for TT Manager Pro
// Provides resilient offline storage and queue management during internet outages

const DB_NAME = 'TTManagerPro_IDB';
const DB_VERSION = 1;
const STORE_APP_STATE = 'appState';
const STORE_OFFLINE_QUEUE = 'offlineQueue';

export interface OfflineMutation {
  id: string;
  type: 'UPDATE_REFEREE_QUEUE' | 'UPDATE_ARBITRO' | 'SAVE_RESULTADO' | 'FULL_STATE_SYNC';
  payload: any;
  timestamp: number;
}

let dbInstance: IDBDatabase | null = null;

/**
 * Initialize IndexedDB Database and Object Stores
 */
export function initIDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB não é suportado neste navegador.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Create appState store for full state caching
      if (!db.objectStoreNames.contains(STORE_APP_STATE)) {
        db.createObjectStore(STORE_APP_STATE);
      }

      // Create offlineQueue store for pending offline operations
      if (!db.objectStoreNames.contains(STORE_OFFLINE_QUEUE)) {
        db.createObjectStore(STORE_OFFLINE_QUEUE, { keyPath: 'id' });
      }
    };

    request.onsuccess = (event: Event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      
      // Handle connection closing or version change
      dbInstance.onversionchange = () => {
        dbInstance?.close();
        dbInstance = null;
      };

      resolve(dbInstance);
    };

    request.onerror = (event: Event) => {
      console.error('[IndexedDB] Erro ao abrir o banco de dados:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

/**
 * Save complete application state to IndexedDB asynchronously
 */
export async function saveStateToIDB(state: any): Promise<void> {
  try {
    const db = await initIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_APP_STATE, 'readwrite');
      const store = tx.objectStore(STORE_APP_STATE);
      
      const payloadToSave = {
        ...state,
        _lastUpdated: Date.now()
      };

      const request = store.put(payloadToSave, 'current_state');

      request.onsuccess = () => resolve();
      request.onerror = (e) => {
        console.warn('[IndexedDB] Erro ao salvar estado:', (e.target as IDBRequest).error);
        reject((e.target as IDBRequest).error);
      };
    });
  } catch (err) {
    console.warn('[IndexedDB] Falha ao acessar IndexedDB:', err);
  }
}

/**
 * Load complete application state from IndexedDB
 */
export async function loadStateFromIDB(): Promise<any | null> {
  try {
    const db = await initIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_APP_STATE, 'readonly');
      const store = tx.objectStore(STORE_APP_STATE);
      const request = store.get('current_state');

      request.onsuccess = () => {
        if (request.result) {
          console.log('[IndexedDB] Estado restaurado do IndexedDB local com sucesso!');
          resolve(request.result);
        } else {
          resolve(null);
        }
      };

      request.onerror = () => {
        console.warn('[IndexedDB] Erro ao carregar do IndexedDB.');
        resolve(null);
      };
    });
  } catch (err) {
    console.warn('[IndexedDB] Não foi possível ler do IndexedDB:', err);
    return null;
  }
}

/**
 * Enqueue a pending mutation when offline (e.g., refereeQueue change)
 */
export async function enqueueOfflineMutation(
  type: OfflineMutation['type'],
  payload: any
): Promise<void> {
  try {
    const db = await initIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_OFFLINE_QUEUE, 'readwrite');
      const store = tx.objectStore(STORE_OFFLINE_QUEUE);

      const item: OfflineMutation = {
        id: `mut_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        type,
        payload,
        timestamp: Date.now()
      };

      const request = store.put(item);
      request.onsuccess = () => {
        console.log(`[IndexedDB Queue] Mutação offline '${type}' enfileirada com sucesso.`);
        resolve();
      };
      request.onerror = (e) => reject((e.target as IDBRequest).error);
    });
  } catch (err) {
    console.warn('[IndexedDB Queue] Falha ao enfileirar operação offline:', err);
  }
}

/**
 * Retrieve all pending mutations in the offline queue
 */
export async function getPendingOfflineMutations(): Promise<OfflineMutation[]> {
  try {
    const db = await initIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_OFFLINE_QUEUE, 'readonly');
      const store = tx.objectStore(STORE_OFFLINE_QUEUE);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => resolve([]);
    });
  } catch (err) {
    return [];
  }
}

/**
 * Clear specific mutation from offline queue after successful sync
 */
export async function removeOfflineMutation(id: string): Promise<void> {
  try {
    const db = await initIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_OFFLINE_QUEUE, 'readwrite');
      const store = tx.objectStore(STORE_OFFLINE_QUEUE);
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => resolve();
    });
  } catch (err) {
    // Ignore error
  }
}

/**
 * Clear entire offline mutation queue
 */
export async function clearAllOfflineMutations(): Promise<void> {
  try {
    const db = await initIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_OFFLINE_QUEUE, 'readwrite');
      const store = tx.objectStore(STORE_OFFLINE_QUEUE);
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => resolve();
    });
  } catch (err) {
    // Ignore error
  }
}

/**
 * Flush all pending offline mutations to Firebase Firestore when internet connection returns
 */
export async function syncOfflineQueueToFirebase(
  uploadFn: (state: any) => Promise<void>,
  getCurrentStatePayload: () => any
): Promise<{ syncedCount: number; errors: number }> {
  const pending = await getPendingOfflineMutations();
  if (pending.length === 0) {
    return { syncedCount: 0, errors: 0 };
  }

  console.log(`[IndexedDB Sync Engine] Sincronizando ${pending.length} alterações salvas localmente para a nuvem...`);
  
  let syncedCount = 0;
  let errors = 0;

  // Perform full state upload to ensure everything (especially referee queue) is consistent
  try {
    const statePayload = getCurrentStatePayload();
    await uploadFn(statePayload);
    
    // Clear processed queue
    for (const item of pending) {
      await removeOfflineMutation(item.id);
      syncedCount++;
    }
    console.log('[IndexedDB Sync Engine] Sincronização da fila offline concluída com sucesso!');
  } catch (err) {
    console.warn('[IndexedDB Sync Engine] Falha na sincronização da fila offline com a nuvem:', err);
    errors++;
  }

  return { syncedCount, errors };
}
