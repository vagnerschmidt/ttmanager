import * as XLSX from 'xlsx';
import { Atleta, Arbitro, Treinador, Funcionario, Torneio, Categoria } from '../types';
import { normalizePhoneToBrazil } from './phone';

export interface EntityDiff<T> {
  id: string;
  name: string;
  status: 'ADDED' | 'UPDATED' | 'UNCHANGED';
  item: T;
  changes: Array<{
    field: string;
    label: string;
    oldVal: any;
    newVal: any;
  }>;
}

export interface SectionDiffReport<T> {
  added: T[];
  updated: T[];
  unchangedCount: number;
  diffs: EntityDiff<T>[];
}

export interface SyncDiffReport {
  atletas: SectionDiffReport<Atleta>;
  arbitros: SectionDiffReport<Arbitro>;
  treinadores: SectionDiffReport<Treinador>;
  funcionarios: SectionDiffReport<Funcionario>;
  torneios: SectionDiffReport<Torneio>;
  categorias: SectionDiffReport<Categoria>;
  summary: {
    totalAdded: number;
    totalUpdated: number;
    totalUnchanged: number;
    executionTimeMs: number;
  };
}

export interface CurrentSystemState {
  atletas: Atleta[];
  arbitros: Arbitro[];
  treinadores: Treinador[];
  funcionarios: Funcionario[];
  torneios: Torneio[];
  categorias: Categoria[];
}

/**
 * Normalizes string keys and values for comparison and matching
 */
function cleanStr(val: any): string {
  if (val === undefined || val === null) return '';
  return String(val)
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // strip accents
    .toUpperCase();
}

/**
 * Robust helper to extract cell values from a row regardless of header casing or variation
 */
function getVal(row: any, candidates: string[], defaultVal: string = ''): string {
  if (!row || typeof row !== 'object') return defaultVal;

  const normalizedRowKeys = new Map<string, string>();
  for (const key of Object.keys(row)) {
    const normKey = cleanStr(key).replace(/[^A-Z0-9]/g, '');
    normalizedRowKeys.set(normKey, key);
  }

  for (const cand of candidates) {
    const normCand = cleanStr(cand).replace(/[^A-Z0-9]/g, '');
    if (normalizedRowKeys.has(normCand)) {
      const originalKey = normalizedRowKeys.get(normCand)!;
      const rawVal = row[originalKey];
      if (rawVal !== undefined && rawVal !== null) {
        const strVal = String(rawVal).trim();
        if (strVal !== '') return strVal;
      }
    }
  }

  return defaultVal;
}

/**
 * Helper to parse Excel dates (serial numbers, DD/MM/YYYY, or YYYY-MM-DD)
 */
function formatExcelDate(rawDate: any, fallback: string = ''): string {
  if (rawDate === undefined || rawDate === null || rawDate === '') return fallback;

  // Handle Excel serial date numbers (e.g., 44196 -> 2021-01-01)
  if (typeof rawDate === 'number' || (!isNaN(Number(rawDate)) && Number(rawDate) > 10000 && Number(rawDate) < 60000)) {
    const num = Number(rawDate);
    const dateObj = new Date(Math.round((num - (25567 + 2)) * 86400 * 1000));
    if (!isNaN(dateObj.getTime())) {
      return dateObj.toISOString().slice(0, 10);
    }
  }

  const str = String(rawDate).trim();

  // Match DD/MM/YYYY or DD-MM-YYYY
  const brDateMatch = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
  if (brDateMatch) {
    const day = brDateMatch[1].padStart(2, '0');
    const month = brDateMatch[2].padStart(2, '0');
    const year = brDateMatch[3];
    return `${year}-${month}-${day}`;
  }

  // Match YYYY-MM-DD
  const isoDateMatch = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
  if (isoDateMatch) {
    const year = isoDateMatch[1];
    const month = isoDateMatch[2].padStart(2, '0');
    const day = isoDateMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  return str || fallback;
}

/**
 * Helper to parse numeric values from text (e.g. "1.250" -> 1250)
 */
function parseNumVal(val: any, fallback: number = 0): number {
  if (val === undefined || val === null || val === '') return fallback;
  if (typeof val === 'number') return isNaN(val) ? fallback : val;
  const cleaned = String(val).replace(/\./g, '').replace(',', '.').replace(/[^0-9.-]/g, '');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? fallback : parsed;
}

/**
 * Helper to format currency/monetary fields (e.g., "R$ 1.500,00" -> "1500.00")
 */
function parseCurrencyVal(val: any, fallback: string = '0.00'): string {
  if (val === undefined || val === null || val === '') return fallback;
  const num = parseNumVal(val, -1);
  if (num === -1) return fallback;
  return num.toFixed(2);
}

/**
 * Generates an Excel workbook template (.xlsx) with sheets for all system entities.
 */
export function generateSpreadsheetTemplate(): Blob {
  const wb = XLSX.utils.book_new();

  // 1. Atletas Sheet
  const atletasData = [
    {
      'ID': 'ATL001',
      'NOME': 'CARLOS SILVA',
      'NASCIMENTO': '2005-03-15',
      'CPF': '111.222.333-44',
      'RG': '12.345.678-9',
      'GENERO': 'Masculino',
      'CLUBE': 'A.A. PALMEIRAS',
      'CATEGORIA': 'Sub-21',
      'RATING': 1250,
      'CBTT_ID': 'CBTT-8849',
      'NIVEL': 'Avançado',
      'MAO_DOMINANTE': 'Direita',
      'EMPUNHADURA': 'Shakehand',
      'STATUS': 'Ativo',
      'EMAIL': 'carlos.silva@email.com',
      'WHATSAPP': '+55 (11) 99888-7766',
      'TELEFONE': '+55 (11) 3333-4444',
      'RESPONSAVEL': 'MARCOS SILVA',
      'RESPONSAVEL_CPF': '000.111.222-33',
      'PRESENCA': 'CONFIRMADA',
      'PAGAMENTO': 'PAGO',
      'OBSERVACOES': 'Atleta federado'
    }
  ];
  const wsAtletas = XLSX.utils.json_to_sheet(atletasData);
  XLSX.utils.book_append_sheet(wb, wsAtletas, 'Atletas');

  // 2. Arbitros Sheet
  const arbitrosData = [
    {
      'ID': 'ARB001',
      'NOME': 'ROBERTO ALMEIDA',
      'NASCIMENTO': '1982-08-20',
      'CPF': '222.333.444-55',
      'NIVEL': 'Nacional',
      'CBTT': 'ARB-102',
      'EMAIL': 'roberto.arbitro@email.com',
      'WHATSAPP': '+55 (11) 98765-4321',
      'TELEFONE': '+55 (11) 3222-1100',
      'STATUS': 'Disponível',
      'VALOR_HORA': '150.00',
      'PRESENCA': 'CONFIRMADA',
      'PAGAMENTO': 'PAGO',
      'OBSERVACOES': 'Disponível finais de semana'
    }
  ];
  const wsArbitros = XLSX.utils.json_to_sheet(arbitrosData);
  XLSX.utils.book_append_sheet(wb, wsArbitros, 'Arbitros');

  // 3. Treinadores Sheet
  const treinadoresData = [
    {
      'ID': 'TRN001',
      'NOME': 'FERNANDO ALVES',
      'CLUBE': 'A.A. PALMEIRAS',
      'CREF': '012345-G/SP',
      'WHATSAPP': '+55 (11) 97654-3210',
      'EMAIL': 'fernando.treinador@email.com',
      'STATUS': 'Ativo'
    }
  ];
  const wsTreinadores = XLSX.utils.json_to_sheet(treinadoresData);
  XLSX.utils.book_append_sheet(wb, wsTreinadores, 'Treinadores');

  // 4. Funcionarios Sheet
  const funcionariosData = [
    {
      'ID': 'FUNC001',
      'NOME': 'JULIANA COSTA',
      'NASCIMENTO': '1990-05-12',
      'CPF': '333.444.555-66',
      'CARGO': 'Coordenadora de Eventos',
      'DEPARTAMENTO': 'Administração',
      'ADMISSAO': '2022-01-10',
      'CONTRATO': 'CLT',
      'SALARIO': '4500.00',
      'STATUS': 'Ativo',
      'EMAIL': 'juliana.coordenacao@ttmanager.com',
      'WHATSAPP': '+55 (11) 95555-4444'
    }
  ];
  const wsFuncionarios = XLSX.utils.json_to_sheet(funcionariosData);
  XLSX.utils.book_append_sheet(wb, wsFuncionarios, 'Funcionarios');

  // 5. Torneios Sheet
  const torneiosData = [
    {
      'ID': 'TOR001',
      'NOME': 'GRANDE OPEN PAULISTA DE TÊNIS DE MESA 2026',
      'DATA_INICIO': '2026-08-15',
      'DATA_FIM': '2026-08-16',
      'HORA': '08:00',
      'LOCAL': 'GINÁSIO IBIRAPUERA',
      'CIDADE': 'SÃO PAULO',
      'STATUS': 'Inscrições Abertas',
      'FORMATO': 'Grupos + Eliminatória',
      'TAXA': '80.00',
      'LIMITE': '128',
      'ORGANIZACAO': 'FEDERAÇÃO PAULISTA'
    }
  ];
  const wsTorneios = XLSX.utils.json_to_sheet(torneiosData);
  XLSX.utils.book_append_sheet(wb, wsTorneios, 'Torneios');

  // 6. Categorias Sheet
  const categoriasData = [
    {
      'ID': 'CAT001',
      'NOME': 'SUB-21 MASCULINO',
      'TIPO': 'Simples',
      'GENERO': 'Masculino',
      'IDADE_MIN': '15',
      'IDADE_MAX': '21',
      'RATING_MIN': '0',
      'RATING_MAX': '3000',
      'FORMATO': 'Grupos + Eliminatória'
    }
  ];
  const wsCategorias = XLSX.utils.json_to_sheet(categoriasData);
  XLSX.utils.book_append_sheet(wb, wsCategorias, 'Categorias');

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  return new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

/**
 * Parses an incoming file (.xlsx, .xls, .csv, .json) into structured entity objects
 */
export async function parseSpreadsheetFile(file: File): Promise<Partial<CurrentSystemState>> {
  const fileExt = file.name.split('.').pop()?.toLowerCase();

  if (fileExt === 'json') {
    const text = await file.text();
    const json = JSON.parse(text);
    return {
      atletas: Array.isArray(json.atletas) ? json.atletas : [],
      arbitros: Array.isArray(json.arbitros) ? json.arbitros : [],
      treinadores: Array.isArray(json.treinadores) ? json.treinadores : [],
      funcionarios: Array.isArray(json.funcionarios) ? json.funcionarios : [],
      torneios: Array.isArray(json.torneios) ? json.torneios : [],
      categorias: Array.isArray(json.categorias) ? json.categorias : []
    };
  }

  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true });

  const result: {
    atletas: Atleta[];
    arbitros: Arbitro[];
    treinadores: Treinador[];
    funcionarios: Funcionario[];
    torneios: Torneio[];
    categorias: Categoria[];
  } = {
    atletas: [],
    arbitros: [],
    treinadores: [],
    funcionarios: [],
    torneios: [],
    categorias: []
  };

  workbook.SheetNames.forEach(sheetName => {
    const sheet = workbook.Sheets[sheetName];
    const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    if (rows.length === 0) return;

    const normSheetName = cleanStr(sheetName);

    // Classification strategy: 1. Sheet Name, 2. Header Columns Detection
    let handled = false;

    if (
      normSheetName.includes('ATLETA') ||
      normSheetName.includes('JOGADOR') ||
      normSheetName.includes('PARTICIPANTE') ||
      normSheetName.includes('INSCRITO') ||
      normSheetName.includes('PLAYER')
    ) {
      result.atletas.push(...rows.map((r, idx) => parseAtletaRow(r, result.atletas.length + idx)));
      handled = true;
    } else if (
      normSheetName.includes('ARBITRO') ||
      normSheetName.includes('JUIZ') ||
      normSheetName.includes('REFEREE')
    ) {
      result.arbitros.push(...rows.map((r, idx) => parseArbitroRow(r, result.arbitros.length + idx)));
      handled = true;
    } else if (
      normSheetName.includes('TREINADOR') ||
      normSheetName.includes('TECNICO') ||
      normSheetName.includes('COACH')
    ) {
      result.treinadores.push(...rows.map((r, idx) => parseTreinadorRow(r, result.treinadores.length + idx)));
      handled = true;
    } else if (
      normSheetName.includes('FUNCIONARIO') ||
      normSheetName.includes('STAFF') ||
      normSheetName.includes('EQUIPE') ||
      normSheetName.includes('COLABORADOR')
    ) {
      result.funcionarios.push(...rows.map((r, idx) => parseFuncionarioRow(r, result.funcionarios.length + idx)));
      handled = true;
    } else if (
      normSheetName.includes('TORNEIO') ||
      normSheetName.includes('COMPETICAO') ||
      normSheetName.includes('CAMPEONATO') ||
      normSheetName.includes('EVENTO') ||
      normSheetName.includes('ETAPA')
    ) {
      result.torneios.push(...rows.map((r, idx) => parseTorneioRow(r, result.torneios.length + idx)));
      handled = true;
    } else if (
      normSheetName.includes('CATEGORIA') ||
      normSheetName.includes('CLASSE') ||
      normSheetName.includes('MODALIDADE')
    ) {
      result.categorias.push(...rows.map((r, idx) => parseCategoriaRow(r, idx)));
      handled = true;
    }

    // Auto-detect by column headers if sheet name didn't match standard keywords
    if (!handled) {
      const firstRowKeys = Object.keys(rows[0]).map(k => cleanStr(k));
      if (firstRowKeys.some(k => k.includes('RATING') || k.includes('EMPUNHADURA') || k.includes('CLUBE') || k.includes('CATEGORIA'))) {
        result.atletas.push(...rows.map((r, idx) => parseAtletaRow(r, result.atletas.length + idx)));
      } else if (firstRowKeys.some(k => k.includes('VALOR') || k.includes('ARBITRO') || k.includes('NIVEL') && firstRowKeys.some(k => k.includes('HORA')))) {
        result.arbitros.push(...rows.map((r, idx) => parseArbitroRow(r, result.arbitros.length + idx)));
      } else if (firstRowKeys.some(k => k.includes('CREF') || k.includes('TREINADOR'))) {
        result.treinadores.push(...rows.map((r, idx) => parseTreinadorRow(r, result.treinadores.length + idx)));
      } else if (firstRowKeys.some(k => k.includes('CARGO') || k.includes('SALARIO') || k.includes('DEPARTAMENTO'))) {
        result.funcionarios.push(...rows.map((r, idx) => parseFuncionarioRow(r, result.funcionarios.length + idx)));
      } else if (firstRowKeys.some(k => k.includes('TORNEIO') || k.includes('LOCAL') || k.includes('TAXA'))) {
        result.torneios.push(...rows.map((r, idx) => parseTorneioRow(r, result.torneios.length + idx)));
      } else if (firstRowKeys.some(k => k.includes('IDADE') || k.includes('TIPO') && firstRowKeys.some(k => k.includes('RATING')))) {
        result.categorias.push(...rows.map((r, idx) => parseCategoriaRow(r, result.categorias.length + idx)));
      } else {
        // Default fallback to Atletas sheet if generic
        result.atletas.push(...rows.map((r, idx) => parseAtletaRow(r, result.atletas.length + idx)));
      }
    }
  });

  return result;
}

function parseAtletaRow(r: any, idx: number): Atleta {
  const rawId = getVal(r, ['ID', 'CODIGO', 'MATRICULA']);
  const rawWa = getVal(r, ['WHATSAPP', 'WA', 'CELULAR', 'TELEFONE2']);
  const rawTel = getVal(r, ['TELEFONE', 'TEL', 'FONE', 'FIXO']);
  const rawNasc = getVal(r, ['NASCIMENTO', 'DATA_NASCIMENTO', 'NASC', 'DATA']);

  return {
    id: rawId ? cleanStr(rawId) : `ATL_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'NOME_COMPLETO', 'ATLETA', 'JOGADOR', 'NAME'], 'ATLETA SEM NOME').toUpperCase(),
    nasc: formatExcelDate(rawNasc, ''),
    cpf: getVal(r, ['CPF', 'DOC_CPF']),
    rg: getVal(r, ['RG', 'DOC_RG']),
    genero: getVal(r, ['GENERO', 'SEXO'], ''),
    natural: getVal(r, ['NATURALIDADE', 'NATURAL', 'CIDADE_NATAL']),
    end: getVal(r, ['ENDERECO', 'RUA', 'LOGRADOURO']),
    cat: getVal(r, ['CATEGORIA', 'CAT', 'CLASSE']),
    clube: getVal(r, ['CLUBE', 'ENTIDADE', 'EQUIPE', 'ASSOCIACAO']),
    rating: parseNumVal(getVal(r, ['RATING', 'PONTOS', 'PTS']), 1000),
    cbtt: getVal(r, ['CBTT_ID', 'CBTT', 'FEDERACAO']),
    nivel: getVal(r, ['NIVEL', 'CATEGORIA_NIVEL']),
    mao: getVal(r, ['MAO_DOMINANTE', 'MAO', 'CANHOTO_DIESTRO']),
    emp: getVal(r, ['EMPUNHADURA', 'EMP']),
    status: getVal(r, ['STATUS', 'SITUACAO']),
    obs: getVal(r, ['OBSERVACOES', 'OBS', 'NOTAS']),
    email: getVal(r, ['EMAIL', 'E-MAIL', 'CORREIO']),
    wa: normalizePhoneToBrazil(rawWa),
    tel: normalizePhoneToBrazil(rawTel),
    emerg: getVal(r, ['EMERGENCIA', 'TEL_EMERGENCIA']),
    resp: getVal(r, ['RESPONSAVEL', 'PAI_MAE']),
    respCpf: getVal(r, ['RESPONSAVEL_CPF', 'CPF_RESPONSAVEL']),
    foto: getVal(r, ['FOTO', 'IMAGEM']),
    presenca: getVal(r, ['PRESENCA', 'CONFIRMADO']),
    pagamento: getVal(r, ['PAGAMENTO', 'TAXA_PAGA'])
  };
}

function parseArbitroRow(r: any, idx: number): Arbitro {
  const rawId = getVal(r, ['ID', 'CODIGO']);
  const rawWa = getVal(r, ['WHATSAPP', 'WA', 'CELULAR']);
  const rawTel = getVal(r, ['TELEFONE', 'TEL', 'FONE']);
  const rawVal = getVal(r, ['VALOR_HORA', 'VALOR', 'VAL', 'DIARIA']);

  return {
    id: rawId ? cleanStr(rawId) : `ARB_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'ARBITRO', 'NOME_COMPLETO'], 'ÁRBITRO').toUpperCase(),
    nasc: formatExcelDate(getVal(r, ['NASCIMENTO', 'NASC', 'DATA_NASCIMENTO']), ''),
    cpf: getVal(r, ['CPF']),
    nivel: getVal(r, ['NIVEL', 'CATEGORIA_ARBITRAGEM']),
    cbtt: getVal(r, ['CBTT', 'CBTT_ID']),
    email: getVal(r, ['EMAIL', 'E-MAIL']),
    wa: normalizePhoneToBrazil(rawWa),
    tel: normalizePhoneToBrazil(rawTel),
    status: getVal(r, ['STATUS', 'DISPONIBILIDADE']),
    val: parseCurrencyVal(rawVal, '100.00'),
    obs: getVal(r, ['OBSERVACOES', 'OBS']),
    foto: getVal(r, ['FOTO']),
    presenca: getVal(r, ['PRESENCA']),
    pagamento: getVal(r, ['PAGAMENTO'])
  };
}

function parseTreinadorRow(r: any, idx: number): Treinador {
  const rawId = getVal(r, ['ID', 'CODIGO']);
  const rawWa = getVal(r, ['WHATSAPP', 'WA', 'CELULAR']);

  return {
    id: rawId ? cleanStr(rawId) : `TRN_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'TREINADOR', 'TECNICO'], 'TREINADOR').toUpperCase(),
    clube: getVal(r, ['CLUBE', 'ENTIDADE', 'EQUIPE']),
    cref: getVal(r, ['CREF', 'REGISTRO_CREF']),
    wa: normalizePhoneToBrazil(rawWa),
    email: getVal(r, ['EMAIL', 'E-MAIL']),
    foto: getVal(r, ['FOTO']),
    status: getVal(r, ['STATUS'])
  };
}

function parseFuncionarioRow(r: any, idx: number): Funcionario {
  const rawId = getVal(r, ['ID', 'CODIGO']);
  const rawWa = getVal(r, ['WHATSAPP', 'WA', 'CELULAR']);
  const rawTel = getVal(r, ['TELEFONE', 'TEL']);
  const rawSalario = getVal(r, ['SALARIO', 'SALARIO_BASE', 'REMUNERACAO']);

  return {
    id: rawId ? cleanStr(rawId) : `FUNC_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'FUNCIONARIO', 'COLABORADOR'], 'FUNCIONÁRIO').toUpperCase(),
    nasc: formatExcelDate(getVal(r, ['NASCIMENTO', 'NASC']), ''),
    cpf: getVal(r, ['CPF']),
    rg: getVal(r, ['RG']),
    genero: getVal(r, ['GENERO', 'SEXO']),
    ecivil: getVal(r, ['ESTADO_CIVIL', 'ECIVIL']),
    end: getVal(r, ['ENDERECO', 'LOGRADOURO']),
    cargo: getVal(r, ['CARGO', 'FUNCAO']),
    depto: getVal(r, ['DEPARTAMENTO', 'DEPTO', 'SETOR']),
    admissao: formatExcelDate(getVal(r, ['ADMISSAO', 'DATA_ADMISSAO']), ''),
    contrato: getVal(r, ['CONTRATO', 'TIPO_CONTRATO']),
    salario: parseCurrencyVal(rawSalario, '2000.00'),
    ch: getVal(r, ['CARGA_HORARIA', 'CH']),
    ctps: getVal(r, ['CTPS']),
    pis: getVal(r, ['PIS', 'PASEP']),
    status: getVal(r, ['STATUS']),
    demissao: formatExcelDate(getVal(r, ['DEMISSAO', 'DATA_DEMISSAO']), ''),
    obs: getVal(r, ['OBSERVACOES', 'OBS']),
    email: getVal(r, ['EMAIL', 'E-MAIL']),
    wa: normalizePhoneToBrazil(rawWa),
    tel: normalizePhoneToBrazil(rawTel),
    ramal: getVal(r, ['RAMAL']),
    emerg: getVal(r, ['EMERGENCIA']),
    email2: getVal(r, ['EMAIL_ALT', 'EMAIL2']),
    foto: getVal(r, ['FOTO'])
  };
}

function parseTorneioRow(r: any, idx: number): Torneio {
  const rawId = getVal(r, ['ID', 'CODIGO']);
  const rawTaxa = getVal(r, ['TAXA', 'VALOR_INCRICAO', 'PRECO']);

  return {
    id: rawId ? cleanStr(rawId) : `TOR_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'TORNEIO', 'NOME_TORNEIO', 'COMPETICAO'], 'TORNEIO DE TÊNIS DE MESA').toUpperCase(),
    ini: formatExcelDate(getVal(r, ['DATA_INICIO', 'INI', 'INICIO', 'DATA']), ''),
    fim: formatExcelDate(getVal(r, ['DATA_FIM', 'FIM', 'TERMINO']), ''),
    hora: getVal(r, ['HORA', 'HORARIO']),
    status: getVal(r, ['STATUS', 'SITUACAO']),
    local: getVal(r, ['LOCAL', 'GINASIO']),
    cidade: getVal(r, ['CIDADE', 'MUNICIPIO']),
    end: getVal(r, ['ENDERECO']),
    fmt: getVal(r, ['FORMATO', 'FMT', 'SISTEMA']),
    taxa: parseCurrencyVal(rawTaxa, '50.00'),
    lim: String(parseNumVal(getVal(r, ['LIMITE', 'MAX_ATLETAS', 'VAGAS']), 128)),
    org: getVal(r, ['ORGANIZACAO', 'ORG', 'PROMOTOR']),
    cont: getVal(r, ['CONTATO', 'ORGANIZADOR']),
    desc: getVal(r, ['DESCRICAO', 'DESC'])
  };
}

function parseCategoriaRow(r: any, idx: number): Categoria {
  const rawId = getVal(r, ['ID', 'CODIGO']);

  return {
    id: rawId ? cleanStr(rawId) : `CAT_SYNC_${idx + 1}`,
    nome: getVal(r, ['NOME', 'CATEGORIA', 'CLASSE'], 'CATEGORIA').toUpperCase(),
    tipo: getVal(r, ['TIPO', 'MODALIDADE']),
    genero: getVal(r, ['GENERO', 'SEXO']),
    idmin: String(parseNumVal(getVal(r, ['IDADE_MIN', 'IDMIN', 'MIN_IDADE']), 0)),
    idmax: String(parseNumVal(getVal(r, ['IDADE_MAX', 'IDMAX', 'MAX_IDADE']), 99)),
    rmin: String(parseNumVal(getVal(r, ['RATING_MIN', 'RMIN', 'MIN_RATING']), 0)),
    rmax: String(parseNumVal(getVal(r, ['RATING_MAX', 'RMAX', 'MAX_RATING']), 5000)),
    fmt: getVal(r, ['FORMATO', 'FMT']),
    max: String(parseNumVal(getVal(r, ['MAX_ATLETAS', 'VAGAS', 'LIMITE']), 64)),
    desc: getVal(r, ['DESCRICAO', 'DESC'])
  };
}

/**
 * Smart, ultra-faithful field comparison and entity matching engine
 */
export function diffEntities<T extends { id: string; nome?: string; [key: string]: any }>(
  currentList: T[],
  incomingList: T[],
  fieldLabels: Record<string, string>,
  secondaryKeyField?: string
): SectionDiffReport<T> {
  const currentMap = new Map<string, T>();
  const secondaryMap = new Map<string, T>();
  const nameMap = new Map<string, T>();

  // Map current entities by ID, secondary key (CPF/CREF/CBTT), and clean Name
  currentList.forEach(item => {
    if (item.id) currentMap.set(cleanStr(item.id), item);
    if (secondaryKeyField && item[secondaryKeyField]) {
      const secVal = cleanStr(item[secondaryKeyField]);
      if (secVal) secondaryMap.set(secVal, item);
    }
    if (item.nome) {
      const nameVal = cleanStr(item.nome);
      if (nameVal) nameMap.set(nameVal, item);
    }
  });

  const added: T[] = [];
  const updated: T[] = [];
  let unchangedCount = 0;
  const diffs: EntityDiff<T>[] = [];

  incomingList.forEach(incoming => {
    const incId = cleanStr(incoming.id);
    const secKey = secondaryKeyField && incoming[secondaryKeyField] ? cleanStr(incoming[secondaryKeyField]) : '';
    const incName = incoming.nome ? cleanStr(incoming.nome) : '';

    // Find matching existing entity: 1. ID Match, 2. Secondary Key Match (CPF/CREF), 3. Full Name Match
    let existing = currentMap.get(incId);
    if (!existing && secKey) existing = secondaryMap.get(secKey);
    if (!existing && incName) existing = nameMap.get(incName);

    if (!existing) {
      // Clean up defaults for brand new entity if missing
      const cleanNewItem: T = { ...incoming };
      if (!cleanNewItem.id || cleanNewItem.id.startsWith('_SYNC_')) {
        cleanNewItem.id = `ID_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      }

      added.push(cleanNewItem);
      diffs.push({
        id: cleanNewItem.id,
        name: cleanNewItem.nome || cleanNewItem.id,
        status: 'ADDED',
        item: cleanNewItem,
        changes: []
      });
    } else {
      // Compare fields with existing entity
      const changes: Array<{ field: string; label: string; oldVal: any; newVal: any }> = [];
      const updatedFields: Record<string, any> = {};

      Object.keys(incoming).forEach(key => {
        // Skip photo blob comparison or system generated IDs if incoming is synthetic
        if (key === 'foto') return;
        if (key === 'id' && incoming[key] && incoming[key].startsWith('_SYNC_')) return;

        const oldVal = existing![key];
        const newVal = incoming[key];

        // Format string values for comparison
        const oldStr = oldVal !== undefined && oldVal !== null ? String(oldVal).trim() : '';
        const newStr = newVal !== undefined && newVal !== null ? String(newVal).trim() : '';

        // Only register an update if incoming value is provided AND different from old value
        if (newStr !== '' && oldStr !== newStr) {
          changes.push({
            field: key,
            label: fieldLabels[key] || key.toUpperCase(),
            oldVal: oldStr !== '' ? oldVal : '(vazio)',
            newVal: newVal
          });
          updatedFields[key] = newVal;
        }
      });

      if (changes.length > 0) {
        // Create updated object preserving existing ID and un-overwritten properties
        const mergedItem: T = { ...existing, ...updatedFields };
        updated.push(mergedItem);
        diffs.push({
          id: existing.id,
          name: existing.nome || existing.id,
          status: 'UPDATED',
          item: mergedItem,
          changes
        });
      } else {
        // Record is completely unchanged
        unchangedCount++;
        diffs.push({
          id: existing.id,
          name: existing.nome || existing.id,
          status: 'UNCHANGED',
          item: existing,
          changes: []
        });
      }
    }
  });

  return {
    added,
    updated,
    unchangedCount,
    diffs
  };
}

/**
 * Main Comparison Engine: Takes current system state and parsed spreadsheet file,
 * and executes field comparison across all 6 main data domains.
 */
export function executeSmartSystemSync(
  currentState: CurrentSystemState,
  parsedData: Partial<CurrentSystemState>
): SyncDiffReport {
  const startTime = performance.now();

  const atletaLabels: Record<string, string> = {
    nome: 'Nome Completo',
    nasc: 'Data Nascimento',
    cpf: 'CPF',
    rg: 'RG',
    genero: 'Gênero',
    natural: 'Naturalidade',
    end: 'Endereço',
    clube: 'Clube/Entidade',
    rating: 'Rating',
    cat: 'Categoria',
    cbtt: 'CBTT ID',
    nivel: 'Nível',
    mao: 'Mão Dominante',
    emp: 'Empunhadura',
    status: 'Status',
    email: 'E-mail',
    wa: 'WhatsApp',
    tel: 'Telefone',
    resp: 'Responsável',
    respCpf: 'CPF Responsável',
    pagamento: 'Pagamento',
    presenca: 'Presença',
    obs: 'Observações'
  };

  const arbitroLabels: Record<string, string> = {
    nome: 'Nome Completo',
    nasc: 'Data Nascimento',
    cpf: 'CPF',
    nivel: 'Nível Arbitragem',
    cbtt: 'CBTT ID',
    email: 'E-mail',
    wa: 'WhatsApp',
    tel: 'Telefone',
    val: 'Valor Hora (R$)',
    status: 'Status',
    pagamento: 'Pagamento',
    presenca: 'Presença',
    obs: 'Observações'
  };

  const treinadorLabels: Record<string, string> = {
    nome: 'Nome Completo',
    clube: 'Clube/Entidade',
    cref: 'Registro CREF',
    wa: 'WhatsApp',
    email: 'E-mail',
    status: 'Status'
  };

  const funcionarioLabels: Record<string, string> = {
    nome: 'Nome Completo',
    nasc: 'Data Nascimento',
    cpf: 'CPF',
    rg: 'RG',
    cargo: 'Cargo',
    depto: 'Departamento',
    admissao: 'Data Admissão',
    contrato: 'Tipo Contrato',
    salario: 'Salário (R$)',
    status: 'Status',
    email: 'E-mail',
    wa: 'WhatsApp'
  };

  const torneioLabels: Record<string, string> = {
    nome: 'Nome do Torneio',
    ini: 'Data Início',
    fim: 'Data Fim',
    hora: 'Horário',
    local: 'Local / Ginásio',
    cidade: 'Cidade',
    status: 'Status',
    fmt: 'Formato Disputa',
    taxa: 'Taxa Inscrição (R$)',
    lim: 'Limite Atletas',
    org: 'Organização'
  };

  const categoriaLabels: Record<string, string> = {
    nome: 'Nome Categoria',
    tipo: 'Tipo',
    genero: 'Gênero',
    idmin: 'Idade Mínima',
    idmax: 'Idade Máxima',
    rmin: 'Rating Mínimo',
    rmax: 'Rating Máximo',
    fmt: 'Formato Disputa',
    max: 'Vagas Máximas'
  };

  const atletasDiff = diffEntities(
    currentState.atletas || [],
    parsedData.atletas || [],
    atletaLabels,
    'cpf'
  );

  const arbitrosDiff = diffEntities(
    currentState.arbitros || [],
    parsedData.arbitros || [],
    arbitroLabels,
    'cpf'
  );

  const treinadoresDiff = diffEntities(
    currentState.treinadores || [],
    parsedData.treinadores || [],
    treinadorLabels,
    'cref'
  );

  const funcionariosDiff = diffEntities(
    currentState.funcionarios || [],
    parsedData.funcionarios || [],
    funcionarioLabels,
    'cpf'
  );

  const torneiosDiff = diffEntities(
    currentState.torneios || [],
    parsedData.torneios || [],
    torneioLabels
  );

  const categoriasDiff = diffEntities(
    currentState.categorias || [],
    parsedData.categorias || [],
    categoriaLabels
  );

  const endTime = performance.now();
  const executionTimeMs = Math.round(endTime - startTime);

  const totalAdded =
    atletasDiff.added.length +
    arbitrosDiff.added.length +
    treinadoresDiff.added.length +
    funcionariosDiff.added.length +
    torneiosDiff.added.length +
    categoriasDiff.added.length;

  const totalUpdated =
    atletasDiff.updated.length +
    arbitrosDiff.updated.length +
    treinadoresDiff.updated.length +
    funcionariosDiff.updated.length +
    torneiosDiff.updated.length +
    categoriasDiff.updated.length;

  const totalUnchanged =
    atletasDiff.unchangedCount +
    arbitrosDiff.unchangedCount +
    treinadoresDiff.unchangedCount +
    funcionariosDiff.unchangedCount +
    torneiosDiff.unchangedCount +
    categoriasDiff.unchangedCount;

  return {
    atletas: atletasDiff,
    arbitros: arbitrosDiff,
    treinadores: treinadoresDiff,
    funcionarios: funcionariosDiff,
    torneios: torneiosDiff,
    categorias: categoriasDiff,
    summary: {
      totalAdded,
      totalUpdated,
      totalUnchanged,
      executionTimeMs
    }
  };
}

/**
 * Merges diff results into current state while maintaining referential integrity
 */
export function applySyncToState(
  currentState: CurrentSystemState,
  report: SyncDiffReport
): CurrentSystemState {
  const updateCollection = <T extends { id: string }>(
    currentList: T[],
    sectionReport: SectionDiffReport<T>
  ): T[] => {
    if (sectionReport.added.length === 0 && sectionReport.updated.length === 0) {
      return currentList;
    }

    const updatedMap = new Map<string, T>();
    sectionReport.updated.forEach(item => updatedMap.set(cleanStr(item.id), item));

    // Replace updated items while keeping unchanged ones intact
    const newList = currentList.map(item => {
      const updatedItem = updatedMap.get(cleanStr(item.id));
      return updatedItem || item;
    });

    // Append newly added items
    return [...newList, ...sectionReport.added];
  };

  return {
    atletas: updateCollection(currentState.atletas || [], report.atletas),
    arbitros: updateCollection(currentState.arbitros || [], report.arbitros),
    treinadores: updateCollection(currentState.treinadores || [], report.treinadores),
    funcionarios: updateCollection(currentState.funcionarios || [], report.funcionarios),
    torneios: updateCollection(currentState.torneios || [], report.torneios),
    categorias: updateCollection(currentState.categorias || [], report.categorias)
  };
}

/**
 * Generates a fully synchronized official spreadsheet (.xlsx) containing all system entities
 * formatted strictly according to the official column schema.
 */
export function exportSynchronizedSpreadsheet(state: CurrentSystemState): Blob {
  const wb = XLSX.utils.book_new();

  // 1. Atletas Sheet
  const atletasData = (state.atletas || []).map(a => ({
    'ID': a.id,
    'NOME': a.nome,
    'NASCIMENTO': a.nasc,
    'CPF': a.cpf,
    'RG': a.rg,
    'GENERO': a.genero,
    'CLUBE': a.clube,
    'CATEGORIA': a.cat,
    'RATING': a.rating,
    'CBTT_ID': a.cbtt,
    'NIVEL': a.nivel,
    'MAO_DOMINANTE': a.mao,
    'EMPUNHADURA': a.emp,
    'STATUS': a.status,
    'EMAIL': a.email,
    'WHATSAPP': a.wa,
    'TELEFONE': a.tel,
    'RESPONSAVEL': a.resp,
    'RESPONSAVEL_CPF': a.respCpf,
    'PRESENCA': a.presenca || 'CONFIRMADA',
    'PAGAMENTO': a.pagamento || 'PAGO',
    'OBSERVACOES': a.obs || ''
  }));
  const wsAtletas = XLSX.utils.json_to_sheet(atletasData);
  XLSX.utils.book_append_sheet(wb, wsAtletas, 'Atletas');

  // 2. Arbitros Sheet
  const arbitrosData = (state.arbitros || []).map(arb => ({
    'ID': arb.id,
    'NOME': arb.nome,
    'NASCIMENTO': arb.nasc,
    'CPF': arb.cpf,
    'NIVEL': arb.nivel,
    'CBTT': arb.cbtt,
    'EMAIL': arb.email,
    'WHATSAPP': arb.wa,
    'TELEFONE': arb.tel,
    'STATUS': arb.status,
    'VALOR_HORA': arb.val,
    'PRESENCA': arb.presenca || 'CONFIRMADA',
    'PAGAMENTO': arb.pagamento || 'PAGO',
    'OBSERVACOES': arb.obs || ''
  }));
  const wsArbitros = XLSX.utils.json_to_sheet(arbitrosData);
  XLSX.utils.book_append_sheet(wb, wsArbitros, 'Arbitros');

  // 3. Treinadores Sheet
  const treinadoresData = (state.treinadores || []).map(t => ({
    'ID': t.id,
    'NOME': t.nome,
    'CLUBE': t.clube,
    'CREF': t.cref,
    'WHATSAPP': t.wa,
    'EMAIL': t.email,
    'STATUS': t.status
  }));
  const wsTreinadores = XLSX.utils.json_to_sheet(treinadoresData);
  XLSX.utils.book_append_sheet(wb, wsTreinadores, 'Treinadores');

  // 4. Funcionarios Sheet
  const funcionariosData = (state.funcionarios || []).map(f => ({
    'ID': f.id,
    'NOME': f.nome,
    'NASCIMENTO': f.nasc,
    'CPF': f.cpf,
    'CARGO': f.cargo,
    'DEPARTAMENTO': f.depto,
    'ADMISSAO': f.admissao,
    'CONTRATO': f.contrato,
    'SALARIO': f.salario,
    'STATUS': f.status,
    'EMAIL': f.email,
    'WHATSAPP': f.wa
  }));
  const wsFuncionarios = XLSX.utils.json_to_sheet(funcionariosData);
  XLSX.utils.book_append_sheet(wb, wsFuncionarios, 'Funcionarios');

  // 5. Torneios Sheet
  const torneiosData = (state.torneios || []).map(tor => ({
    'ID': tor.id,
    'NOME': tor.nome,
    'DATA_INICIO': tor.ini,
    'DATA_FIM': tor.fim,
    'HORA': tor.hora,
    'LOCAL': tor.local,
    'CIDADE': tor.cidade,
    'STATUS': tor.status,
    'FORMATO': tor.fmt,
    'TAXA': tor.taxa,
    'LIMITE': tor.lim,
    'ORGANIZACAO': tor.org
  }));
  const wsTorneios = XLSX.utils.json_to_sheet(torneiosData);
  XLSX.utils.book_append_sheet(wb, wsTorneios, 'Torneios');

  // 6. Categorias Sheet
  const categoriasData = (state.categorias || []).map(c => ({
    'ID': c.id,
    'NOME': c.nome,
    'TIPO': c.tipo,
    'GENERO': c.genero,
    'IDADE_MIN': c.idmin,
    'IDADE_MAX': c.idmax,
    'RATING_MIN': c.rmin,
    'RATING_MAX': c.rmax,
    'FORMATO': c.fmt
  }));
  const wsCategorias = XLSX.utils.json_to_sheet(categoriasData);
  XLSX.utils.book_append_sheet(wb, wsCategorias, 'Categorias');

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  return new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}
