/**
 * Google Drive Automated Backup Utility for TT Manager Pro
 * Scope: https://www.googleapis.com/auth/drive.file
 */

export interface DriveBackupSettings {
  autoBackupEnabled: boolean;
  intervalHours: number; // default 24
  lastBackupTime: number | null;
  lastBackupStatus: string | null;
  lastFileName: string | null;
  accessToken: string | null;
  tokenExpiresAt: number | null;
}

const STORAGE_KEYS = {
  ENABLED: 'ttmpro_gdrive_autobackup_enabled',
  INTERVAL: 'ttmpro_gdrive_interval_hours',
  LAST_TIME: 'ttmpro_gdrive_last_backup_time',
  LAST_STATUS: 'ttmpro_gdrive_last_backup_status',
  LAST_FILE: 'ttmpro_gdrive_last_file_name',
  TOKEN: 'ttmpro_gdrive_access_token',
  EXPIRES: 'ttmpro_gdrive_token_expires_at',
};

export function getDriveSettings(): DriveBackupSettings {
  return {
    autoBackupEnabled: localStorage.getItem(STORAGE_KEYS.ENABLED) === 'true',
    intervalHours: Number(localStorage.getItem(STORAGE_KEYS.INTERVAL) || '24'),
    lastBackupTime: localStorage.getItem(STORAGE_KEYS.LAST_TIME)
      ? Number(localStorage.getItem(STORAGE_KEYS.LAST_TIME))
      : null,
    lastBackupStatus: localStorage.getItem(STORAGE_KEYS.LAST_STATUS) || null,
    lastFileName: localStorage.getItem(STORAGE_KEYS.LAST_FILE) || null,
    accessToken: localStorage.getItem(STORAGE_KEYS.TOKEN) || null,
    tokenExpiresAt: localStorage.getItem(STORAGE_KEYS.EXPIRES)
      ? Number(localStorage.getItem(STORAGE_KEYS.EXPIRES))
      : null,
  };
}

export function saveDriveSettings(settings: Partial<DriveBackupSettings>) {
  if (settings.autoBackupEnabled !== undefined) {
    localStorage.setItem(STORAGE_KEYS.ENABLED, String(settings.autoBackupEnabled));
  }
  if (settings.intervalHours !== undefined) {
    localStorage.setItem(STORAGE_KEYS.INTERVAL, String(settings.intervalHours));
  }
  if (settings.lastBackupTime !== undefined) {
    localStorage.setItem(STORAGE_KEYS.LAST_TIME, String(settings.lastBackupTime));
  }
  if (settings.lastBackupStatus !== undefined) {
    localStorage.setItem(STORAGE_KEYS.LAST_STATUS, settings.lastBackupStatus || '');
  }
  if (settings.lastFileName !== undefined) {
    localStorage.setItem(STORAGE_KEYS.LAST_FILE, settings.lastFileName || '');
  }
  if (settings.accessToken !== undefined) {
    localStorage.setItem(STORAGE_KEYS.TOKEN, settings.accessToken || '');
  }
  if (settings.tokenExpiresAt !== undefined) {
    localStorage.setItem(STORAGE_KEYS.EXPIRES, String(settings.tokenExpiresAt));
  }
}

/**
 * Uploads JSON payload directly to user's Google Drive via REST API
 */
export async function uploadBackupToDrive(
  payload: any,
  accessToken: string
): Promise<{ id: string; name: string; webViewLink?: string }> {
  const now = new Date();
  const dateStr = now.toISOString().replace(/[:.]/g, '-').slice(0, 16);
  const fileName = `tt_manager_pro_backup_${dateStr}.json`;

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: `TT Manager Pro Automated Backup generated at ${now.toLocaleString('pt-BR')}`,
  };

  const fileContent = JSON.stringify(
    {
      _backupType: 'GOOGLE_DRIVE_PERIODIC_AUTOBACKUP',
      _timestamp: now.getTime(),
      _dateReadable: now.toLocaleString('pt-BR'),
      system: 'TT Manager Pro - Tênis de Mesa',
      version: '3.0.0-PRO',
      data: payload,
    },
    null,
    2
  );

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const body =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    fileContent +
    closeDelimiter;

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: body,
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro no Google Drive API (${response.status}): ${errText}`);
  }

  const result = await response.json();

  // Save successful backup status
  saveDriveSettings({
    lastBackupTime: now.getTime(),
    lastBackupStatus: 'Sucesso',
    lastFileName: fileName,
  });

  return result;
}

/**
 * Prompts Google OAuth Token Client to get an access token with drive.file scope
 */
export function requestDriveAccessToken(): Promise<string> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !(window as any).google?.accounts?.oauth2) {
      return reject(
        new Error(
          'SDK do Google Identity Services não carregado. Verifique sua conexão com a internet.'
        )
      );
    }

    try {
      const tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id:
          '1039293827909-ttmanagerpro.apps.googleusercontent.com', // Generic fallback or Cloud OAuth client
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: (tokenResponse: any) => {
          if (tokenResponse.error) {
            if (tokenResponse.error === 'popup_closed' || tokenResponse.error === 'user_denied') {
              return reject(
                new Error('A janela de autorização do Google Drive foi fechada antes da conclusão do login.')
              );
            }
            return reject(
              new Error(`Autenticação recusada ou com erro: ${tokenResponse.error}`)
            );
          }
          if (tokenResponse.access_token) {
            const token = tokenResponse.access_token;
            const expiresAt = Date.now() + (tokenResponse.expires_in || 3600) * 1000;
            saveDriveSettings({
              accessToken: token,
              tokenExpiresAt: expiresAt,
            });
            resolve(token);
          } else {
            reject(new Error('Nenhum token de acesso retornado do Google Drive.'));
          }
        },
        error_callback: (err: any) => {
          if (err?.type === 'popup_closed' || err?.message?.includes('closed') || err?.message?.includes('Popup')) {
            reject(
              new Error('A janela de autorização do Google Drive foi fechada. Para conectar o Google Drive, permita popups em seu navegador e selecione sua conta Google.')
            );
          } else {
            reject(new Error(`Erro OAuth Google Drive: ${err?.message || 'Falha no login'}`));
          }
        },
      });

      tokenClient.requestAccessToken({ prompt: 'consent' });
    } catch (e: any) {
      reject(new Error(`Falha ao inicializar o Google Drive OAuth: ${e.message}`));
    }
  });
}

/**
 * Checks whether periodic auto-backup should run and executes it if required
 */
export async function processPeriodicDriveAutoBackup(
  getCurrentPayload: () => any,
  onSuccessToast?: (msg: string) => void
) {
  const settings = getDriveSettings();
  if (!settings.autoBackupEnabled) return;

  const now = Date.now();
  const intervalMs = settings.intervalHours * 60 * 60 * 1000;
  const lastTime = settings.lastBackupTime || 0;

  // Check if time interval has elapsed
  if (now - lastTime >= intervalMs) {
    // Check if we have a valid non-expired access token
    if (settings.accessToken && settings.tokenExpiresAt && settings.tokenExpiresAt > now + 60000) {
      try {
        const payload = getCurrentPayload();
        const res = await uploadBackupToDrive(payload, settings.accessToken);
        if (onSuccessToast) {
          onSuccessToast(
            `Backup automático no Google Drive concluído com sucesso! Arquivo: ${res.name}`
          );
        }
      } catch (err: any) {
        console.warn('[Google Drive AutoBackup] Erro no backup automático:', err);
        saveDriveSettings({ lastBackupStatus: `Erro: ${err.message}` });
      }
    } else {
      console.log(
        '[Google Drive AutoBackup] Backup periódico pendente. Token de acesso expirado ou ausente. Solicitando autorização do usuário.'
      );
    }
  }
}
