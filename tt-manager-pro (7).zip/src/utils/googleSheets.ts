/**
 * Google Sheets API Integration Utility for TT Manager Pro
 * Scopes: https://www.googleapis.com/auth/spreadsheets, https://www.googleapis.com/auth/drive.file
 */

import { CurrentSystemState } from './spreadsheetSync';

export interface GoogleSheetsSettings {
  linkedSpreadsheetId: string | null;
  linkedSpreadsheetUrl: string | null;
  linkedSpreadsheetName: string | null;
  lastSyncTime: number | null;
  lastSyncStatus: string | null;
  accessToken: string | null;
  tokenExpiresAt: number | null;
  autoSyncEnabled: boolean;
  totalRecordCount: number | null;
}

const STORAGE_KEYS = {
  SHEET_ID: 'ttmpro_gsheets_sheet_id',
  SHEET_URL: 'ttmpro_gsheets_sheet_url',
  SHEET_NAME: 'ttmpro_gsheets_sheet_name',
  LAST_SYNC: 'ttmpro_gsheets_last_sync_time',
  LAST_STATUS: 'ttmpro_gsheets_last_sync_status',
  TOKEN: 'ttmpro_gsheets_access_token',
  EXPIRES: 'ttmpro_gsheets_token_expires_at',
  AUTO_SYNC: 'ttmpro_gsheets_auto_sync',
  RECORD_COUNT: 'ttmpro_gsheets_record_count',
};

export function getGoogleSheetsSettings(): GoogleSheetsSettings {
  return {
    linkedSpreadsheetId: localStorage.getItem(STORAGE_KEYS.SHEET_ID) || null,
    linkedSpreadsheetUrl: localStorage.getItem(STORAGE_KEYS.SHEET_URL) || null,
    linkedSpreadsheetName: localStorage.getItem(STORAGE_KEYS.SHEET_NAME) || null,
    lastSyncTime: localStorage.getItem(STORAGE_KEYS.LAST_SYNC)
      ? Number(localStorage.getItem(STORAGE_KEYS.LAST_SYNC))
      : null,
    lastSyncStatus: localStorage.getItem(STORAGE_KEYS.LAST_STATUS) || null,
    accessToken: localStorage.getItem(STORAGE_KEYS.TOKEN) || null,
    tokenExpiresAt: localStorage.getItem(STORAGE_KEYS.EXPIRES)
      ? Number(localStorage.getItem(STORAGE_KEYS.EXPIRES))
      : null,
    autoSyncEnabled: localStorage.getItem(STORAGE_KEYS.AUTO_SYNC) === 'true',
    totalRecordCount: localStorage.getItem(STORAGE_KEYS.RECORD_COUNT)
      ? Number(localStorage.getItem(STORAGE_KEYS.RECORD_COUNT))
      : null,
  };
}

export function saveGoogleSheetsSettings(settings: Partial<GoogleSheetsSettings>) {
  if (settings.linkedSpreadsheetId !== undefined) {
    if (settings.linkedSpreadsheetId) {
      localStorage.setItem(STORAGE_KEYS.SHEET_ID, settings.linkedSpreadsheetId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_ID);
    }
  }
  if (settings.linkedSpreadsheetUrl !== undefined) {
    if (settings.linkedSpreadsheetUrl) {
      localStorage.setItem(STORAGE_KEYS.SHEET_URL, settings.linkedSpreadsheetUrl);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_URL);
    }
  }
  if (settings.linkedSpreadsheetName !== undefined) {
    if (settings.linkedSpreadsheetName) {
      localStorage.setItem(STORAGE_KEYS.SHEET_NAME, settings.linkedSpreadsheetName);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_NAME);
    }
  }
  if (settings.lastSyncTime !== undefined) {
    if (settings.lastSyncTime) {
      localStorage.setItem(STORAGE_KEYS.LAST_SYNC, String(settings.lastSyncTime));
    } else {
      localStorage.removeItem(STORAGE_KEYS.LAST_SYNC);
    }
  }
  if (settings.lastSyncStatus !== undefined) {
    if (settings.lastSyncStatus) {
      localStorage.setItem(STORAGE_KEYS.LAST_STATUS, settings.lastSyncStatus);
    } else {
      localStorage.removeItem(STORAGE_KEYS.LAST_STATUS);
    }
  }
  if (settings.accessToken !== undefined) {
    if (settings.accessToken) {
      localStorage.setItem(STORAGE_KEYS.TOKEN, settings.accessToken);
    } else {
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
    }
  }
  if (settings.tokenExpiresAt !== undefined) {
    if (settings.tokenExpiresAt) {
      localStorage.setItem(STORAGE_KEYS.EXPIRES, String(settings.tokenExpiresAt));
    } else {
      localStorage.removeItem(STORAGE_KEYS.EXPIRES);
    }
  }
  if (settings.autoSyncEnabled !== undefined) {
    localStorage.setItem(STORAGE_KEYS.AUTO_SYNC, String(settings.autoSyncEnabled));
  }
  if (settings.totalRecordCount !== undefined) {
    if (settings.totalRecordCount !== null) {
      localStorage.setItem(STORAGE_KEYS.RECORD_COUNT, String(settings.totalRecordCount));
    } else {
      localStorage.removeItem(STORAGE_KEYS.RECORD_COUNT);
    }
  }
}

/**
 * Extract Spreadsheet ID from Google Sheets URL or raw ID string
 */
export function extractSpreadsheetId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (!trimmed.includes('/')) return trimmed; // Raw ID
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  return match ? match[1] : null;
}

/**
 * Request Access Token for Google Sheets via Google Identity Services
 */
export function requestGoogleSheetsAccessToken(): Promise<string> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !(window as any).google?.accounts?.oauth2) {
      return reject(
        new Error('SDK do Google Identity Services não carregado. Verifique sua conexão.')
      );
    }

    try {
      const tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: '998222099112-gpl96g2basetut5o3167blnd1qmb0grv.apps.googleusercontent.com',
        scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file',
        callback: (tokenResponse: any) => {
          if (tokenResponse.error) {
            if (tokenResponse.error === 'popup_closed' || tokenResponse.error === 'user_denied') {
              return reject(
                new Error('A janela de autorização do Google Sheets foi fechada.')
              );
            }
            return reject(new Error(`Erro OAuth: ${tokenResponse.error}`));
          }
          if (tokenResponse.access_token) {
            const token = tokenResponse.access_token;
            const expiresAt = Date.now() + (tokenResponse.expires_in || 3600) * 1000;
            saveGoogleSheetsSettings({
              accessToken: token,
              tokenExpiresAt: expiresAt,
            });
            resolve(token);
          } else {
            reject(new Error('Nenhum token de acesso retornado do Google.'));
          }
        },
        error_callback: (err: any) => {
          reject(new Error(`Falha no login Google: ${err?.message || 'Ação cancelada'}`));
        },
      });

      tokenClient.requestAccessToken({ prompt: 'consent' });
    } catch (e: any) {
      reject(new Error(`Erro ao inicializar OAuth do Google Sheets: ${e.message}`));
    }
  });
}

/**
 * Creates a complete Google Spreadsheet for TT Manager Pro
 */
export async function createGoogleSpreadsheet(
  state: CurrentSystemState,
  accessToken: string,
  customTitle?: string
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const title = customTitle || `TT Manager Pro - Planilha Oficial (${new Date().toLocaleDateString('pt-BR')})`;

  const sheetsPayload = {
    properties: { title },
    sheets: [
      { properties: { title: 'Atletas' } },
      { properties: { title: 'Árbitros' } },
      { properties: { title: 'Treinadores' } },
      { properties: { title: 'Funcionários' } },
      { properties: { title: 'Torneios' } },
      { properties: { title: 'Categorias' } },
    ],
  };

  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(sheetsPayload),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao criar planilha no Google Sheets (${response.status}): ${errText}`);
  }

  const createdData = await response.json();
  const spreadsheetId = createdData.spreadsheetId;
  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // Populate cell values
  await syncDataToGoogleSheet(spreadsheetId, state, accessToken);

  const totalRecordCount = 
    state.atletas.length +
    state.arbitros.length +
    state.treinadores.length +
    state.funcionarios.length +
    state.torneios.length +
    state.categorias.length;

  saveGoogleSheetsSettings({
    linkedSpreadsheetId: spreadsheetId,
    linkedSpreadsheetUrl: spreadsheetUrl,
    linkedSpreadsheetName: title,
    lastSyncTime: Date.now(),
    lastSyncStatus: 'Sucesso',
    totalRecordCount,
  });

  return { spreadsheetId, spreadsheetUrl };
}

/**
 * Syncs/Overwrites values in an existing Google Sheet
 */
export async function syncDataToGoogleSheet(
  spreadsheetId: string,
  state: CurrentSystemState,
  accessToken: string
): Promise<void> {
  const dataToSheets = [
    {
      range: 'Atletas!A1',
      values: [
        ['ID', 'Nome', 'Nascimento', 'CPF', 'RG', 'Gênero', 'Naturalidade', 'Clube', 'Rating', 'ID CBTT', 'Nível', 'Mão', 'Empunhadura', 'Status', 'Email', 'WhatsApp', 'Responsável', 'Presença'],
        ...state.atletas.map(a => [
          a.id, a.nome, a.nasc || '', a.cpf || '', a.rg || '', a.genero, a.natural || '',
          a.clube || '', a.rating, a.cbtt || '', a.nivel || 'Iniciante', a.mao || 'Direita',
          a.emp || 'Classineta', a.status, a.email || '', a.wa || '', a.resp || '', a.presenca || 'CONFIRMADA'
        ])
      ]
    },
    {
      range: 'Árbitros!A1',
      values: [
        ['ID', 'Nome', 'Nível', 'CBTT', 'CPF', 'Email', 'WhatsApp', 'Status', 'Valor Hora'],
        ...state.arbitros.map(a => [
          a.id, a.nome, a.nivel, a.cbtt || '', a.cpf || '', a.email || '', a.wa || '', a.status, a.val || ''
        ])
      ]
    },
    {
      range: 'Treinadores!A1',
      values: [
        ['ID', 'Nome', 'Clube', 'CREF', 'Email', 'WhatsApp', 'Status'],
        ...state.treinadores.map(t => [
          t.id, t.nome, t.clube || '', t.cref || '', t.email || '', t.wa || '', t.status
        ])
      ]
    },
    {
      range: 'Funcionários!A1',
      values: [
        ['ID', 'Nome', 'Cargo', 'CPF', 'RG', 'Telefone', 'Email', 'Status', 'Salário'],
        ...state.funcionarios.map(f => [
          f.id, f.nome, f.cargo, f.cpf || '', f.rg || '', f.tel || '', f.email || '', f.status, f.salario || ''
        ])
      ]
    },
    {
      range: 'Torneios!A1',
      values: [
        ['ID', 'Nome', 'Início', 'Fim', 'Hora', 'Local', 'Cidade', 'Status', 'Formato', 'Limite Inscritos'],
        ...state.torneios.map(t => [
          t.id, t.nome, t.ini, t.fim, t.hora, t.local || '', t.cidade || '', t.status, t.fmt, t.lim || ''
        ])
      ]
    },
    {
      range: 'Categorias!A1',
      values: [
        ['ID', 'Nome', 'Idade Mín', 'Idade Máx', 'Gênero', 'Tipo', 'Formato', 'Limite Máx', 'Descrição'],
        ...state.categorias.map(c => [
          c.id, c.nome, c.idmin || '', c.idmax || '', c.genero || 'Misto', c.tipo || '', c.fmt || '', c.max || '', c.desc || ''
        ])
      ]
    }
  ];

  const body = {
    valueInputOption: 'USER_ENTERED',
    data: dataToSheets
  };

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Falha ao atualizar dados no Google Sheets (${response.status}): ${errText}`);
  }

  const totalRecordCount = 
    state.atletas.length +
    state.arbitros.length +
    state.treinadores.length +
    state.funcionarios.length +
    state.torneios.length +
    state.categorias.length;

  saveGoogleSheetsSettings({
    lastSyncTime: Date.now(),
    lastSyncStatus: 'Sucesso',
    totalRecordCount,
  });
}

/**
 * Fetches sheet data from Google Sheets API and returns a structured object for system sync
 */
export async function fetchGoogleSheetData(
  spreadsheetId: string,
  accessToken: string
): Promise<Record<string, any[]>> {
  const ranges = ['Atletas!A1:Z500', 'Árbitros!A1:Z500', 'Treinadores!A1:Z500', 'Funcionários!A1:Z500', 'Torneios!A1:Z500', 'Categorias!A1:Z500'];
  const rangesQuery = ranges.map(r => `ranges=${encodeURIComponent(r)}`).join('&');

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchGet?${rangesQuery}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao ler dados da planilha do Google Sheets (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const valueRanges = data.valueRanges || [];

  const parsedData: Record<string, any[]> = {
    atletas: [],
    arbitros: [],
    treinadores: [],
    funcionarios: [],
    torneios: [],
    categorias: [],
  };

  const mapRowsToObject = (rows: any[][]) => {
    if (!rows || rows.length <= 1) return [];
    const headers = rows[0].map(h => String(h).trim().toLowerCase());
    
    return rows.slice(1).map(row => {
      const item: any = {};
      headers.forEach((header, idx) => {
        item[header] = row[idx] !== undefined ? row[idx] : '';
      });
      return item;
    });
  };

  valueRanges.forEach((vr: any) => {
    const rangeName = vr.range || '';
    const rows = vr.values || [];

    if (rangeName.startsWith('Atletas')) {
      parsedData.atletas = mapRowsToObject(rows);
    } else if (rangeName.startsWith('Árbitros') || rangeName.startsWith('Arbitros')) {
      parsedData.arbitros = mapRowsToObject(rows);
    } else if (rangeName.startsWith('Treinadores')) {
      parsedData.treinadores = mapRowsToObject(rows);
    } else if (rangeName.startsWith('Funcionários') || rangeName.startsWith('Funcionarios')) {
      parsedData.funcionarios = mapRowsToObject(rows);
    } else if (rangeName.startsWith('Torneios')) {
      parsedData.torneios = mapRowsToObject(rows);
    } else if (rangeName.startsWith('Categorias')) {
      parsedData.categorias = mapRowsToObject(rows);
    }
  });

  return parsedData;
}
