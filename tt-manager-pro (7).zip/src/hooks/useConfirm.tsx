import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Trash2, X, HelpCircle, Info } from 'lucide-react';
import { playAlertSound } from '../utils/soundEffects';

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  type?: 'danger' | 'warning' | 'info';
}

export function useConfirm() {
  const [state, setState] = useState<(ConfirmOptions & { resolve: (val: boolean) => void }) | null>(null);

  const confirm = (options: ConfirmOptions): Promise<boolean> => {
    // Trigger subtle alert sound when confirmation dialog pops up
    playAlertSound();
    return new Promise<boolean>((resolve) => {
      setState({
        ...options,
        resolve,
      });
    });
  };

  const handleClose = (value: boolean) => {
    if (state) {
      state.resolve(value);
    }
    setState(null);
  };

  const ConfirmDialog = () => {
    return (
      <AnimatePresence>
        {state && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => handleClose(false)}
              className="absolute inset-0 bg-slate-950/85 backdrop-blur-xs"
            />

            {/* Modal Dialog Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className="relative w-full max-w-sm overflow-hidden rounded-2xl border border-slate-800/80 bg-slate-900 text-left shadow-2xl z-50"
            >
              {/* Header Indicator of type */}
              <div
                className={`h-1.5 w-full ${
                  state.type === 'danger'
                    ? 'bg-red-500'
                    : state.type === 'info'
                    ? 'bg-cyan-500'
                    : 'bg-yellow-500'
                }`}
              />

              {/* Close Button top-right */}
              <button
                type="button"
                onClick={() => handleClose(false)}
                className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 transition rounded-lg p-1 hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="p-5.5">
                {/* Header Icon + Title */}
                <div className="flex items-start gap-3.5">
                  <div
                    className={`rounded-xl p-2.5 shrink-0 ${
                      state.type === 'danger'
                        ? 'bg-red-500/10 text-red-400'
                        : state.type === 'info'
                        ? 'bg-cyan-500/10 text-cyan-400'
                        : 'bg-yellow-500/10 text-yellow-500'
                    }`}
                  >
                    {state.type === 'danger' ? (
                      <Trash2 className="w-5 h-5" />
                    ) : state.type === 'info' ? (
                      <Info className="w-5 h-5" />
                    ) : (
                      <AlertTriangle className="w-5 h-5" />
                    )}
                  </div>

                  <div className="space-y-1 pr-6">
                    <h3 className="text-sm font-black text-slate-100 uppercase tracking-wide">
                      {state.title}
                    </h3>
                    <p className="text-xs text-slate-400 leading-normal font-medium">
                      {state.message}
                    </p>
                  </div>
                </div>

                {/* Confirm & Cancel Actions */}
                <div className="flex items-center gap-2.5 mt-6 justify-end">
                  <button
                    type="button"
                    onClick={() => handleClose(false)}
                    className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-slate-200 bg-slate-850 hover:bg-slate-800 border border-slate-800 rounded-xl transition cursor-pointer"
                  >
                    {state.cancelText || 'Cancelar'}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleClose(true)}
                    className={`px-4.5 py-2 text-xs font-black rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-lg shadow-black/10 ${
                      state.type === 'danger'
                        ? 'bg-red-600 hover:bg-red-500 text-white'
                        : state.type === 'info'
                        ? 'bg-cyan-600 hover:bg-cyan-500 text-white'
                        : 'bg-yellow-500 hover:bg-yellow-400 text-slate-950'
                    }`}
                  >
                    {state.type === 'danger' && <Trash2 className="w-3.5 h-3.5 shrink-0" />}
                    {state.confirmText || 'Confirmar'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    );
  };

  return { confirm, ConfirmDialog };
}
