import React, { useState, useEffect } from 'react';
import { 
  User, Atleta, Categoria, Torneio, Arbitro, Funcionario, SystemConfig, Resultado, Treinador, Inscricao 
} from './types';
import { 
  INITIAL_ATLETAS, INITIAL_CATEGORIAS, INITIAL_TORNEIOS, INITIAL_ARBITROS, 
  INITIAL_RESULTADOS, INITIAL_FUNCIONARIOS, INITIAL_CONFIG, INITIAL_TREINADORES, INITIAL_INSCRICOES 
} from './utils/seedData';

// Component Views Imports
import DashboardView from './components/DashboardView';
import AtletasView from './components/AtletasView';
import FichaInscricaoView from './components/FichaInscricaoView';
import CategoriasView from './components/CategoriasView';
import TorneiosView from './components/TorneiosView';
import ChaveamentoView from './components/ChaveamentoView';
import ResultadosView from './components/ResultadosView';
import SumulaView from './components/SumulaView';
import ArbitrosView from './components/ArbitrosView';
import FuncionariosView from './components/FuncionariosView';
import ClassificacaoView from './components/ClassificacaoView';
import WhatsAppView from './components/WhatsAppView';
import RelatoriosView from './components/RelatoriosView';
import ConfiguracoesView from './components/ConfiguracoesView';
import PlacarArbitroView from './components/PlacarArbitroView';
import AutoRegistroView from './components/AutoRegistroView';
import SpreadsheetSyncModal from './components/SpreadsheetSyncModal';
import { CurrentSystemState } from './utils/spreadsheetSync';
import { refreshAthleteSnapshotsInStorage } from './utils/bracketGenerator';
import FirebaseSyncModal from './components/FirebaseSyncModal';
import CloudIntegrationsModal from './components/CloudIntegrationsModal';
import AutoDeployModal from './components/AutoDeployModal';
import { uploadStateToFirebase, downloadStateFromFirebase } from './lib/firebase';
import { 
  saveStateToIDB, 
  loadStateFromIDB, 
  enqueueOfflineMutation, 
  syncOfflineQueueToFirebase, 
  getPendingOfflineMutations 
} from './utils/indexedDB';
import { processPeriodicDriveAutoBackup } from './utils/googleDrive';

// Icon Imports
import { 
  Trophy, Users, FileText, Tag, Activity, GitBranch, 
  UserCheck, Briefcase, Award, MessageSquare, FileJson, 
  Settings, LogOut, Sun, Moon, LogIn, UserPlus, Menu, X, CheckSquare,
  CheckCircle, AlertCircle, Info, AlertTriangle, ArrowLeft, FileSpreadsheet, Zap,
  Crown, ShieldCheck, Cloud, Rocket, Volume2, VolumeX, Database, Wifi, WifiOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { toUpperCaseRecursive } from './utils/uppercase';
import { useConfirm } from './hooks/useConfirm';
import { 
  playSuccessSound, playAlertSound, playErrorSound, playClickSound, 
  isSoundEnabled, toggleSound 
} from './utils/soundEffects';

const LOCAL_STORAGE_KEY = 'ttmpro_v2_persisted';

// NAVIGATION MENU GROUPS
const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Trophy, category: 'Principal', shortcut: 'Ctrl+D' },
  { id: 'atletas', label: 'Atletas', icon: Users, category: 'Principal', shortcut: 'Ctrl+A' },
  { id: 'ficha', label: 'Ficha Inscrição', icon: FileText, category: 'Principal', shortcut: 'Ctrl+F' },
  { id: 'categorias', label: 'Categorias', icon: Tag, category: 'Principal', shortcut: 'Ctrl+G' },
  
  { id: 'torneios', label: 'Torneios', icon: Trophy, category: 'Competição', shortcut: 'Ctrl+T' },
  { id: 'chaveamento', label: 'Chaveamento', icon: GitBranch, category: 'Competição', shortcut: 'Ctrl+H' },
  { id: 'resultados', label: 'Resultados', icon: Activity, category: 'Competição', shortcut: 'Ctrl+R' },
  { id: 'placar-arbitro', label: 'Placar Árbitro', icon: Activity, category: 'Competição', shortcut: 'Ctrl+P' },
  { id: 'sumula', label: 'Súmula', icon: CheckSquare, category: 'Competição', shortcut: 'Ctrl+S' },
  
  { id: 'arbitros', label: 'Árbitros', icon: UserCheck, category: 'Administração', shortcut: 'Ctrl+B' },
  { id: 'funcionarios', label: 'Funcionários', icon: Briefcase, category: 'Administração' },
  { id: 'classificacao', label: 'Classificação', icon: Award, category: 'Administração' },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageSquare, category: 'Administração' },
  { id: 'relatorios', label: 'Relatórios', icon: FileJson, category: 'Administração' },
  { id: 'config', label: 'Configurações', icon: Settings, category: 'Administração', shortcut: 'Ctrl+K' }
];

export default function App() {
  // Navigation Section Active state
  const [activeSection, setActiveSection] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [desktopCollapsed, setDesktopCollapsed] = useState(false);
  const [immersiveSumula, setImmersiveSumula] = useState(false);
  const [soundActive, setSoundActive] = useState(() => isSoundEnabled());

  // Auto-reset immersive mode when navigating away from sumula section
  useEffect(() => {
    if (activeSection !== 'sumula') {
      setImmersiveSumula(false);
    }
  }, [activeSection]);

  // Toast notifications state
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'error' | 'info' | 'warning' }[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' | 'warning' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2);
    setToasts(prev => [...prev, { id, message, type }]);

    // Play subtle sound effects based on notification action type
    if (type === 'success') {
      playSuccessSound();
    } else if (type === 'warning') {
      playAlertSound();
    } else if (type === 'error') {
      playErrorSound();
    } else {
      playClickSound();
    }

    // Auto-remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  // Listen to global toast events despatched by subcomponents
  useEffect(() => {
    const handleGlobalToast = (e: Event) => {
      const customEvent = e as CustomEvent<{ message: string; type?: 'success' | 'error' | 'info' | 'warning' }>;
      if (customEvent && customEvent.detail) {
        showToast(customEvent.detail.message, customEvent.detail.type || 'success');
      }
    };
    window.addEventListener('ttm-toast', handleGlobalToast);
    return () => {
      window.removeEventListener('ttm-toast', handleGlobalToast);
    };
  }, []);

  // Authentication State
  const [sessionUser, setSessionUser] = useState<User | null>(null);
  const [isLoginTab, setIsLoginTab] = useState(true); // login vs. register tabs list
  const [isAutoRegistro, setIsAutoRegistro] = useState(false); // public self-registration toggler
  const [registeredUsers, setRegisteredUsers] = useState<User[]>([
    { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' },
    { name: 'Usuário Master (Demonstração)', email: 'comum@tt.com', pass: 'comum123', role: 'master' }
  ]);

  const { confirm, ConfirmDialog } = useConfirm();

  // Auth Inputs
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [regRole, setRegRole] = useState<'comum' | 'admin' | 'master' | 'arbitro' | 'mesario'>('comum');

  // Primary System States
  const [atletas, setAtletas] = useState<Atleta[]>([]);
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [torneios, setTorneios] = useState<Torneio[]>([]);
  const [arbitros, setArbitros] = useState<Arbitro[]>([]);
  const [resultados, setResultados] = useState<Resultado[]>([]);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [config, setConfigState] = useState<SystemConfig>(INITIAL_CONFIG);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.theme) {
          return parsed.theme;
        }
      }
    } catch (e) {
      console.error("Failed to parse theme from localStorage on load:", e);
    }
    return 'light';
  });
  const [refereeQueue, setRefereeQueue] = useState<string[]>([]);
  const [treinadores, setTreinadores] = useState<Treinador[]>([]);
  const [inscricoes, setInscricoes] = useState<Inscricao[]>([]);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [isFirebaseSyncModalOpen, setIsFirebaseSyncModalOpen] = useState(false);
  const [isCloudIntegrationsModalOpen, setIsCloudIntegrationsModalOpen] = useState(false);
  const [isAutoDeployModalOpen, setIsAutoDeployModalOpen] = useState(false);

  // Connection & IndexedDB offline queue state
  const [isOnline, setIsOnline] = useState(() => typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [pendingOfflineCount, setPendingOfflineCount] = useState(0);

  // Listener for internet connection changes and auto-flushing IndexedDB offline mutations
  useEffect(() => {
    const handleOnline = async () => {
      setIsOnline(true);
      showToast("Conexão reestabelecida! Sincronizando filas de árbitros e dados locais com a nuvem...", "info");

      const getCurrentStatePayload = () => ({
        atletas, categorias, torneios, arbitros, resultados,
        funcionarios, treinadores, inscricoes, config, registeredUsers, refereeQueue
      });

      try {
        const res = await syncOfflineQueueToFirebase(uploadStateToFirebase, getCurrentStatePayload);
        if (res.syncedCount > 0) {
          showToast(`Sincronização concluída! ${res.syncedCount} alteração(ões) salvas no IndexedDB enviadas para a nuvem.`, "success");
          setPendingOfflineCount(0);
        }
      } catch (err) {
        console.warn("[IndexedDB AutoSync] Falha ao enviar fila offline:", err);
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      showToast("Modo Offline Ativado (IndexedDB): As filas de espera dos árbitros e placares continuam funcionando e sendo salvas localmente.", "warning");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check for pending mutations in IndexedDB queue
    getPendingOfflineMutations().then(muts => {
      setPendingOfflineCount(muts.length);
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [
    atletas, categorias, torneios, arbitros, resultados, 
    funcionarios, treinadores, inscricoes, config, registeredUsers, refereeQueue
  ]);

  // Periodic Google Drive Auto-Backup check (runs every 5 minutes when online)
  useEffect(() => {
    if (!isOnline) return;

    const getCurrentStatePayload = () => ({
      atletas, categorias, torneios, arbitros, resultados,
      funcionarios, treinadores, inscricoes, config, registeredUsers, refereeQueue
    });

    // Run check immediately on mount/online
    processPeriodicDriveAutoBackup(getCurrentStatePayload, (msg) => showToast(msg, "success"));

    // Set 5-minute interval check
    const interval = setInterval(() => {
      processPeriodicDriveAutoBackup(getCurrentStatePayload, (msg) => showToast(msg, "success"));
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [
    isOnline, atletas, categorias, torneios, arbitros, resultados,
    funcionarios, treinadores, inscricoes, config, registeredUsers, refereeQueue
  ]);

  // Helper for centralized navigation that automatically closes all modals
  const navigateToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    setMobileMenuOpen(false);
    setIsSyncModalOpen(false);
    setIsFirebaseSyncModalOpen(false);
    setIsCloudIntegrationsModalOpen(false);
    setIsAutoDeployModalOpen(false);
  };
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(() => {
    return localStorage.getItem('ttmpro_firebase_autosync') === 'true';
  });

  // Persist auto-sync setting
  useEffect(() => {
    localStorage.setItem('ttmpro_firebase_autosync', String(autoSyncEnabled));
  }, [autoSyncEnabled]);

  // Handle Firebase AutoSync on state/payload changes (only if online)
  useEffect(() => {
    if (!autoSyncEnabled || !isOnline) return;

    const payload = {
      atletas,
      categorias,
      torneios,
      arbitros,
      resultados,
      funcionarios,
      treinadores,
      inscricoes,
      config,
      registeredUsers,
      refereeQueue
    };

    const delayDebounceFn = setTimeout(async () => {
      try {
        await uploadStateToFirebase(payload);
        console.log('[Firebase Auto-Sync] Sincronizado automaticamente com sucesso.');
      } catch (err) {
        console.warn('[Firebase Auto-Sync] Aviso/retentativa na sincronização em segundo plano:', err);
      }
    }, 5000); // 5 seconds debounce

    return () => clearTimeout(delayDebounceFn);
  }, [
    atletas, categorias, torneios, arbitros, resultados,
    funcionarios, treinadores, inscricoes, config, registeredUsers,
    refereeQueue, autoSyncEnabled, isOnline
  ]);

  // Handler to apply entire restored state from Firebase
  const handleApplyFirebaseState = (newState: any) => {
    if (newState.atletas) setAtletas(newState.atletas);
    if (newState.categorias) setCategorias(newState.categorias);
    if (newState.torneios) setTorneios(newState.torneios);
    if (newState.arbitros) setArbitros(newState.arbitros);
    if (newState.resultados) setResultados(newState.resultados);
    if (newState.funcionarios) setFuncionarios(newState.funcionarios);
    if (newState.treinadores) setTreinadores(newState.treinadores);
    if (newState.inscricoes) setInscricoes(newState.inscricoes);
    if (newState.config) setConfigState(newState.config);
    if (newState.registeredUsers) setRegisteredUsers(newState.registeredUsers);
    if (newState.refereeQueue) setRefereeQueue(newState.refereeQueue);
  };

  // Intercept and uppercase config saves
  const setConfig = (newCfg: SystemConfig) => {
    if (sessionUser && !checkAdminPermission()) return;
    setConfigState(toUpperCaseRecursive(newCfg));
  };

  // Load from IndexedDB local storage engine or fallback to localStorage / seed data
  useEffect(() => {
    async function loadData() {
      // Try loading from IndexedDB first for resilient offline restoration
      const idbState = await loadStateFromIDB();
      const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
      let parsed: any = null;

      if (idbState && idbState._lastUpdated) {
        let localTime = 0;
        if (raw) {
          try {
            const parsedLocal = JSON.parse(raw);
            localTime = parsedLocal._lastUpdated || 0;
          } catch (e) {}
        }
        if (idbState._lastUpdated >= localTime) {
          parsed = idbState;
          console.log('[App Startup] Estado restaurado do IndexedDB local com sucesso!');
        } else if (raw) {
          try { parsed = JSON.parse(raw); } catch (e) {}
        }
      } else if (raw) {
        try { parsed = JSON.parse(raw); } catch (e) {}
      }

      if (parsed) {
        try {
          let loadedUsers: User[] = parsed.registeredUsers || [
            { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' },
            { name: 'Usuário Comum (Demonstração)', email: 'comum@tt.com', pass: 'comum123', role: 'comum' }
          ];
          
          const hasAdmin = loadedUsers.some(u => u.email.toLowerCase() === 'schmidtvagner@gmail.com');
          if (!hasAdmin) {
            loadedUsers = [
              { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' },
              ...loadedUsers.filter(u => u.email.toLowerCase() !== 'master@tt.com' && u.email.toLowerCase() !== 'admin@tt.com')
            ];
          }
          
          const correctedUsers = loadedUsers.map(u => ({
            ...u,
            role: (u.role || 'master') as 'master' | 'admin' | 'comum'
          }));
          
          setRegisteredUsers(correctedUsers);
          
          if (parsed.sessionUser) {
            const sUser = parsed.sessionUser;
            setSessionUser({
              ...sUser,
              role: (sUser.role || 'master') as 'master' | 'admin' | 'comum'
            });
          } else {
            // Automatic login as master admin schmidtvagner@gmail.com
            const autoUser = correctedUsers.find(u => u.email.toLowerCase() === 'schmidtvagner@gmail.com') || { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' };
            setSessionUser(autoUser as User);
          }
          setAtletas(parsed.atletas || INITIAL_ATLETAS);
          setCategorias(parsed.categorias || INITIAL_CATEGORIAS);
          setTorneios(parsed.torneios || INITIAL_TORNEIOS);
          setArbitros(parsed.arbitros || INITIAL_ARBITROS);
          setResultados(parsed.resultados || INITIAL_RESULTADOS);
          setFuncionarios(parsed.funcionarios || INITIAL_FUNCIONARIOS);
          setTreinadores(parsed.treinadores || INITIAL_TREINADORES);
          setInscricoes(parsed.inscricoes || INITIAL_INSCRICOES);
          setConfigState(parsed.config || INITIAL_CONFIG);
          setTheme(parsed.theme || 'dark');
          if (parsed.refereeQueue) {
            setRefereeQueue(parsed.refereeQueue);
          } else {
            const initialQueue = (parsed.arbitros || INITIAL_ARBITROS)
              .filter((a: any) => a.status === 'Disponível' || a.status === 'DISPONÍVEL')
              .map((a: any) => a.id);
            setRefereeQueue(initialQueue);
          }
        } catch (err) {
          console.error("Storage loading error, using fallbacks:", err);
          loadFallbacks();
          const defaultUser = { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' };
          setSessionUser(defaultUser as User);
        }
      } else {
        loadFallbacks();
        const defaultUser = { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' };
        setSessionUser(defaultUser as User);
      }
    }

    loadData();
  }, []);

  // Check URL query params for public auto registration link
  useEffect(() => {
    try {
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (
        search.includes('public') || 
        search.includes('inscricao') || 
        search.includes('registro') || 
        hash.includes('public') ||
        hash.includes('auto-registro')
      ) {
        setIsAutoRegistro(true);
      }
    } catch (e) {
      console.error("Error parsing URL params for public mode:", e);
    }
  }, []);

  const loadFallbacks = () => {
    setAtletas(INITIAL_ATLETAS);
    setCategorias(INITIAL_CATEGORIAS);
    setTorneios(INITIAL_TORNEIOS);
    setArbitros(INITIAL_ARBITROS);
    setResultados(INITIAL_RESULTADOS);
    setFuncionarios(INITIAL_FUNCIONARIOS);
    setTreinadores(INITIAL_TREINADORES);
    setInscricoes(INITIAL_INSCRICOES);
    setConfigState(INITIAL_CONFIG);
    setTheme('dark');
    setRefereeQueue(INITIAL_ARBITROS.filter(a => a.status === 'Disponível' || a.status === 'DISPONÍVEL').map(a => a.id));
  };

  // Dual-layer persistence: Sync to IndexedDB and LocalStorage on every state update
  useEffect(() => {
    const timestamp = Date.now();
    const payload = {
      _lastUpdated: timestamp,
      sessionUser,
      registeredUsers,
      atletas,
      categorias,
      torneios,
      arbitros,
      resultados,
      funcionarios,
      treinadores,
      inscricoes,
      config,
      theme,
      refereeQueue
    };

    // 1. LocalStorage
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(payload));

    // 2. IndexedDB (Asynchronous, High-capacity & Offline Resilient)
    saveStateToIDB(payload);

    // 3. Enqueue mutation if offline
    if (!isOnline) {
      enqueueOfflineMutation('UPDATE_REFEREE_QUEUE', { refereeQueue, timestamp }).then(() => {
        getPendingOfflineMutations().then(muts => setPendingOfflineCount(muts.length));
      });
    }
  }, [
    sessionUser, registeredUsers, atletas, categorias, torneios, 
    arbitros, resultados, funcionarios, config, theme, refereeQueue,
    treinadores, inscricoes, isOnline
  ]);

  // Apply dark/light classes to root document
  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
      document.documentElement.setAttribute('data-theme', 'light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  }, [theme]);

  // Automatic theme scheduling check (Auto Dark Mode after 18:00)
  useEffect(() => {
    if (!config.themeAutoSchedule) return;

    const checkAndApplyTheme = () => {
      try {
        const currentHour = new Date().getHours();
        const startHour = config.themeAutoScheduleStartHour ?? 18;
        const endHour = config.themeAutoScheduleEndHour ?? 6;

        let shouldBeDark = false;
        if (startHour > endHour) {
          // Night range spans across midnight (e.g. 18:00 to 06:00)
          shouldBeDark = currentHour >= startHour || currentHour < endHour;
        } else {
          // Night range within the same day (e.g. 18:00 to 22:00)
          shouldBeDark = currentHour >= startHour && currentHour < endHour;
        }

        const targetTheme = shouldBeDark ? 'dark' : 'light';
        setTheme(prev => {
          if (prev !== targetTheme) {
            console.log(`[Auto Theme] Alternando automaticamente para o modo ${targetTheme === 'dark' ? 'escuro' : 'claro'} às ${currentHour}h`);
            return targetTheme;
          }
          return prev;
        });
      } catch (err) {
        console.error("Error evaluating automatic theme schedule:", err);
      }
    };

    // Run immediately on config load
    checkAndApplyTheme();

    // Check every 60 seconds
    const interval = setInterval(checkAndApplyTheme, 60000);
    return () => clearInterval(interval);
  }, [config.themeAutoSchedule, config.themeAutoScheduleStartHour, config.themeAutoScheduleEndHour]);

  // Global Keyboard Shortcuts for rapid navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if not logged in
      if (!sessionUser) return;

      // Ignore shortcuts if the user is typing in forms or text fields
      const active = document.activeElement;
      if (active) {
        const tag = active.tagName.toLowerCase();
        if (tag === 'input' || tag === 'textarea' || active.hasAttribute('contenteditable')) {
          return;
        }
      }

      // Check modifier (Ctrl / Command for macOS)
      const isMod = e.ctrlKey || e.metaKey;
      if (!isMod) return;

      const key = e.key.toLowerCase();
      let targetId = '';

      if (key === 'd') targetId = 'dashboard';
      else if (key === 'a') targetId = 'atletas';
      else if (key === 'f') targetId = 'ficha';
      else if (key === 'g') targetId = 'categorias';
      else if (key === 't') targetId = 'torneios';
      else if (key === 'h') targetId = 'chaveamento';
      else if (key === 'r') targetId = 'resultados';
      else if (key === 'p') targetId = 'placar-arbitro';
      else if (key === 's') targetId = 'sumula';
      else if (key === 'b') targetId = 'arbitros';
      else if (key === 'k') targetId = 'config';

      if (targetId) {
        e.preventDefault();
        navigateToSection(targetId);
        const item = menuItems.find(i => i.id === targetId);
        showToast(`Navegação por atalho: ${item ? item.label : targetId}`, 'info');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [sessionUser]);

  // Authentication Triggers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanMail = loginEmail.trim().toLowerCase();
    const target = registeredUsers.find(u => u.email.toLowerCase() === cleanMail && u.pass === loginPass);
    if (target) {
      setSessionUser(target);
      setLoginEmail('');
      setLoginPass('');
      showToast(`Bem-vindo de volta, ${target.name}!`, 'success');
    } else {
      showToast("Credenciais de acesso incorretas!", 'error');
    }
  };

  const handleDemoLogin = () => {
    const demoMasterUser: User = { name: 'Visitante Master', email: 'visitante@tt.com', pass: 'visitante', role: 'master' };
    setSessionUser(demoMasterUser);
    showToast("Entrou com Controle de Acesso Master (Todas as Prioridades Liberadas)!", 'success');
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim() || !regPass) {
      showToast("Preencha todos os campos obrigatórios!", 'warning');
      return;
    }
    if (regPass.length < 6) {
      showToast("A senha de acesso deve ter pelo menos 6 caracteres!", 'warning');
      return;
    }
    if (regPass !== regConfirm) {
      showToast("A confirmação de senha não coincide!", 'warning');
      return;
    }
    const cleanMail = regEmail.trim().toLowerCase();
    if (registeredUsers.some(u => u.email.toLowerCase() === cleanMail)) {
      showToast("Este endereço de e-mail já está em uso!", 'error');
      return;
    }

    const assignedRole: 'master' = 'master'; // Master access granted to all users
    const newUser: User = { name: regName, email: cleanMail, pass: regPass, role: assignedRole };
    const updatedUsers = [...registeredUsers, newUser];
    setRegisteredUsers(updatedUsers);
    setSessionUser(newUser);
    showToast(`Conta "${newUser.name}" criada com sucesso com Nível Master (Acesso e Prioridade Total)!`, 'success');

    // reset forms
    setRegName('');
    setRegEmail('');
    setRegPass('');
    setRegConfirm('');
    setRegRole('master');
  };

  const handleLogout = () => {
    setSessionUser(null);
    navigateToSection('dashboard');
    showToast("Sessão finalizada com sucesso!", 'info');
  };

  const handleRegisterPublicInvolved = (type: 'atleta' | 'arbitro' | 'treinador' | 'funcionario', data: any) => {
    const rawUpper = toUpperCaseRecursive(data);
    const idValue = `${type}-${Date.now()}`;
    const newRecord = { ...rawUpper, id: idValue };

    if (type === 'atleta') {
      setAtletas(prev => [...prev, newRecord as Atleta]);
    } else if (type === 'arbitro') {
      setArbitros(prev => [...prev, newRecord as Arbitro]);
    } else if (type === 'treinador') {
      setTreinadores(prev => [...prev, newRecord as Treinador]);
    } else if (type === 'funcionario') {
      setFuncionarios(prev => [...prev, newRecord as Funcionario]);
    }
  };

  const checkAdminPermission = (): boolean => {
    // Master Access Control: All users have master permissions and full priorities
    if (!sessionUser) {
      const defaultUser = registeredUsers[0] || { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' };
      setSessionUser(defaultUser);
    }
    return true;
  };

  // State Modifiers passed to child components
  const handleSaveAtleta = (a: Atleta) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(a);
    const idx = atletas.findIndex(x => x.id === rawUpper.id);
    if (idx >= 0) {
      const copy = [...atletas];
      copy[idx] = rawUpper;
      setAtletas(copy);
      showToast(`Atleta "${rawUpper.nome}" updated successfully!`, 'success');
    } else {
      setAtletas([...atletas, rawUpper]);
      showToast(`Atleta "${rawUpper.nome}" registered successfully!`, 'success');
    }
  };

  const handleDeleteAtleta = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = atletas.find(x => x.id === id);
    const ok = await confirm({
      title: 'Excluir Atleta',
      message: `Tem certeza de que deseja remover o atleta "${target?.nome || 'Selecionado'}" do sistema? Essa operação é irreversível e apagará todos os dados associados.`,
      confirmText: 'Excluir Atleta',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setAtletas(atletas.filter(x => x.id !== id));
    showToast(`Atleta "${target?.nome || 'Selecionado'}" removido do sistema!`, 'warning');
  };

  const handleSaveCategoria = (c: Categoria) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(c);
    const idx = categorias.findIndex(x => x.id === rawUpper.id);
    if (idx >= 0) {
      const copy = [...categorias];
      copy[idx] = rawUpper;
      setCategorias(copy);
      showToast(`Categoria "${rawUpper.nome}" atualizada!`, 'success');
    } else {
      setCategorias([...categorias, rawUpper]);
      showToast(`Categoria "${rawUpper.nome}" cadastrada com sucesso!`, 'success');
    }
  };

  const handleSaveCategorias = (cats: Categoria[]) => {
    if (!checkAdminPermission()) return;
    const rawUpper = cats.map(c => toUpperCaseRecursive(c));
    setCategorias(prev => {
      const copy = [...prev];
      rawUpper.forEach(c => {
        const idx = copy.findIndex(x => x.id === c.id);
        if (idx >= 0) {
          copy[idx] = c;
        } else {
          copy.push(c);
        }
      });
      return copy;
    });
    showToast(`${cats.length} Categorias oficiais por idade configuradas!`, 'success');
  };

  const handleDeleteCategoria = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = categorias.find(x => x.id === id);
    const ok = await confirm({
      title: 'Excluir Categoria',
      message: `Tem certeza de que deseja remover a categoria "${target?.nome || 'Selecionada'}"? Isso poderá afetar chaveamentos e agrupamentos existentes.`,
      confirmText: 'Excluir Categoria',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setCategorias(categorias.filter(x => x.id !== id));
    showToast(`Categoria "${target?.nome || 'Selecionada'}" removida do sistema!`, 'warning');
  };

  const handleSaveTorneio = (t: Torneio) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(t);
    const idx = torneios.findIndex(x => x.id === rawUpper.id);
    if (idx >= 0) {
      const copy = [...torneios];
      copy[idx] = rawUpper;
      setTorneios(copy);
      showToast(`Torneio "${rawUpper.nome}" atualizado!`, 'success');
    } else {
      setTorneios([...torneios, rawUpper]);
      showToast(`Torneio "${rawUpper.nome}" cadastrado com sucesso!`, 'success');
    }
  };

  const handleDeleteTorneio = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = torneios.find(x => x.id === id);
    const ok = await confirm({
      title: 'Excluir Torneio',
      message: `CRÍTICO: Tem certeza de que prefere excluir o torneio "${target?.nome || 'Selecionado'}"? Todos os chaveamentos, súmulas e dados de classificação associados serão apagados permanentemente!`,
      confirmText: 'Excluir Torneio',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setTorneios(torneios.filter(x => x.id !== id));
    showToast(`Torneio "${target?.nome || 'Selecionado'}" removido!`, 'warning');
  };

  const handleSaveArbitro = (a: Arbitro) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(a);
    const idx = arbitros.findIndex(x => x.id === rawUpper.id);
    let finalArbitros = [...arbitros];
    if (idx >= 0) {
      finalArbitros[idx] = rawUpper;
      showToast(`Árbitro "${rawUpper.nome}" atualizado!`, 'success');
    } else {
      finalArbitros.push(rawUpper);
      showToast(`Árbitro "${rawUpper.nome}" cadastrado com sucesso!`, 'success');
    }
    setArbitros(finalArbitros);

    // Sync queue with availability
    if (rawUpper.status === 'DISPONÍVEL' || rawUpper.status === 'Disponível') {
      setRefereeQueue(prev => {
        if (!prev.includes(rawUpper.id)) {
          return [...prev, rawUpper.id];
        }
        return prev;
      });
    } else {
      setRefereeQueue(prev => prev.filter(id => id !== rawUpper.id));
    }
  };

  const handleDeleteArbitro = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = arbitros.find(x => x.id === id);
    const ok = await confirm({
      title: 'Excluir Árbitro',
      message: `Deseja realmente remover o árbitro "${target?.nome || 'Selecionado'}" do quadro do torneio?`,
      confirmText: 'Excluir Árbitro',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setArbitros(arbitros.filter(x => x.id !== id));
    setRefereeQueue(prev => prev.filter(qId => qId !== id));
    showToast(`Árbitro "${target?.nome || 'Selecionado'}" removido!`, 'warning');
  };

  const handleSaveResultado = (r: Resultado) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(r);
    setResultados([...resultados, rawUpper]);

    // 1. Ao terminar aquela partida a mesa desocupa
    if (rawUpper.mesa) {
      setConfigState(prev => {
        const nextStatus = (prev.mesasStatus || []).map(m => 
          m.numero === rawUpper.mesa ? { ...m, status: 'livre' as const } : m
        );
        return { ...prev, mesasStatus: nextStatus };
      });
    }

    // 2. Ele retornar para a fila para esperar nova convocação
    const referee = arbitros.find(a => a.nome.toUpperCase() === rawUpper.arb.toUpperCase());
    if (referee) {
      setArbitros(prev => prev.map(a => a.id === referee.id ? { ...a, status: 'Disponível' } : a));
      setRefereeQueue(prev => {
        const filtered = prev.filter(id => id !== referee.id);
        return [...filtered, referee.id];
      });
      showToast(`Mesa ${rawUpper.mesa} desocupada. Árbitro "${referee.nome}" retornou para a Fila de Espera!`, 'info');
    } else {
      if (rawUpper.wo) {
        showToast('W.O. registrado com sucesso!', 'warning');
      } else {
        showToast('Resultado de partida salvo com sucesso!', 'success');
      }
    }
  };

  const handleDeleteResultado = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = resultados.find(x => x.id === id);
    const matchLabel = target ? `${target.p1} vs ${target.p2}` : 'selecionada';
    const ok = await confirm({
      title: 'Excluir Resultado',
      message: `Tem certeza de que deseja apagar o placar registrado da partida "${matchLabel}"? Isso alterará as classificações geradas de forma imediata.`,
      confirmText: 'Excluir Placar',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setResultados(resultados.filter(x => x.id !== id));
    showToast("Resultado de partida removido!", 'warning');
  };

  const handleSaveFuncionario = (f: Funcionario) => {
    if (!checkAdminPermission()) return;
    const rawUpper = toUpperCaseRecursive(f);
    const idx = funcionarios.findIndex(x => x.id === rawUpper.id);
    if (idx >= 0) {
      const copy = [...funcionarios];
      copy[idx] = rawUpper;
      setFuncionarios(copy);
      showToast(`Funcionário "${rawUpper.nome}" atualizado!`, 'success');
    } else {
      setFuncionarios([...funcionarios, rawUpper]);
      showToast(`Funcionário "${rawUpper.nome}" cadastrado com sucesso!`, 'success');
    }
  };

  const handleDeleteFuncionario = async (id: string) => {
    if (!checkAdminPermission()) return;
    const target = funcionarios.find(x => x.id === id);
    const ok = await confirm({
      title: 'Excluir Funcionário',
      message: `Tem certeza de que deseja excluir o cadastro do funcionário/staff "${target?.nome || 'Selecionado'}"?`,
      confirmText: 'Excluir Registro',
      cancelText: 'Cancelar',
      type: 'danger'
    });
    if (!ok) return;
    setFuncionarios(funcionarios.filter(x => x.id !== id));
    showToast(`Registro do funcionário "${target?.nome || 'Selecionado'}" removido!`, 'warning');
  };

  const handleSaveTreinadores = (treins: Treinador[]) => {
    if (!checkAdminPermission()) return;
    setTreinadores(treins);
  };

  const handleSaveInscricoes = (inscs: Inscricao[]) => {
    if (!checkAdminPermission()) return;
    setInscricoes(inscs);
  };

  const handleApplySync = (newState: CurrentSystemState) => {
    if (sessionUser && !checkAdminPermission()) return;
    if (newState.atletas) setAtletas(newState.atletas);
    if (newState.arbitros) setArbitros(newState.arbitros);
    if (newState.treinadores) setTreinadores(newState.treinadores);
    if (newState.funcionarios) setFuncionarios(newState.funcionarios);
    if (newState.torneios) setTorneios(newState.torneios);
    if (newState.categorias) setCategorias(newState.categorias);

    // Chaveamentos e fases de grupos já gerados guardam uma "foto" dos atletas no
    // momento da montagem. Ao atualizar via planilha, propaga os dados novos
    // (nome, rating, clube, etc.) para dentro deles, preservando os placares já lançados.
    if (newState.atletas) {
      const updatedCount = refreshAthleteSnapshotsInStorage(
        newState.torneios || torneios,
        newState.categorias || categorias,
        newState.atletas
      );
      if (updatedCount > 0) {
        showToast(
          `Planilha sincronizada! ${updatedCount} chaveamento(s)/grupo(s) já gerados foram atualizados com os novos dados dos atletas.`,
          'success'
        );
      }
    }
  };

  const handleUpdateRefereeQueue = (queue: string[]) => {
    if (!checkAdminPermission()) return;
    setRefereeQueue(queue);
  };

  // Administration helpers
  const handleResetFactory = () => {
    if (!checkAdminPermission()) return;
    loadFallbacks();
    showToast("Banco de dados do sistema restaurado com as configurações de semente!", 'info');
  };

  const handleClearAll = () => {
    if (!checkAdminPermission()) return;
    setAtletas([]);
    setCategorias([]);
    setTorneios([]);
    setArbitros([]);
    setResultados([]);
    setFuncionarios([]);
    setTreinadores([]);
    setInscricoes([]);
    setConfig({ org: 'TT Manager Pro', cnpj: '', email: '', wa: '', site: '', sets: 'Melhor de 5 sets (11 pontos)', setsMax: 5, setsPoints: 11 });
    showToast("Todos os registros limpos com sucesso!", 'warning');
  };

  const toggleTheme = () => {
    setTheme(prev => {
      const nextTheme = prev === 'dark' ? 'light' : 'dark';
      if (config.themeAutoSchedule) {
        setConfigState(prevCfg => ({
          ...prevCfg,
          themeAutoSchedule: false
        }));
        showToast(`Tema alterado para ${nextTheme === 'dark' ? 'Escuro' : 'Claro'}. O agendamento automático foi desativado.`, 'info');
      } else {
        showToast(`Tema alterado para ${nextTheme === 'dark' ? 'Escuro' : 'Claro'}!`, 'success');
      }
      return nextTheme;
    });
  };

  // Return Gate View
  if (!sessionUser) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 p-4 font-sans selection:bg-yellow-400 selection:text-slate-950 relative">
        
        {/* Toast notifications overlay for login validation feedback */}
        <div className="no-print fixed top-5 left-1/2 -translate-x-1/2 z-[9999] flex flex-col gap-2.5 w-full max-w-sm px-4 pointer-events-none select-none">
          <AnimatePresence>
            {toasts.map(t => {
              let iconColor = 'text-emerald-400';
              let leftBarColor = 'bg-emerald-500';
              let Icon = CheckCircle;

              if (t.type === 'error') {
                iconColor = 'text-red-400';
                leftBarColor = 'bg-red-500';
                Icon = AlertCircle;
              } else if (t.type === 'warning') {
                iconColor = 'text-amber-400';
                leftBarColor = 'bg-amber-500';
                Icon = AlertTriangle;
              } else if (t.type === 'info') {
                iconColor = 'text-sky-450 text-sky-400';
                leftBarColor = 'bg-sky-500';
                Icon = Info;
              }

              return (
                <motion.div
                  key={t.id}
                  initial={{ opacity: 0, y: -25, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -25, scale: 0.95 }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                  className="pointer-events-auto w-full bg-slate-900 border border-slate-800 text-slate-100 flex items-center gap-3.5 pl-4 pr-4 py-3 rounded-xl shadow-2xl relative overflow-hidden backdrop-blur-md"
                >
                  <div className={`absolute top-0 bottom-0 left-0 w-1.25 ${leftBarColor}`} />
                  <div className="shrink-0">
                    <Icon className={`w-5 h-5 ${iconColor}`} />
                  </div>
                  <p className="text-xs font-semibold leading-normal flex-1 pr-2">
                    {t.message}
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setToasts(prev => prev.filter(item => item.id !== t.id));
                    }}
                    className="text-slate-400 hover:text-slate-200 transition p-1 hover:bg-slate-800/50 rounded-lg cursor-pointer shrink-0 animate-none"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {isAutoRegistro ? (
          <AutoRegistroView 
            onRegister={handleRegisterPublicInvolved} 
            onCancel={() => setIsAutoRegistro(false)} 
          />
        ) : (
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800/80 rounded-2xl shadow-2xl p-6 sm:p-8 space-y-6">
          
          {/* Logo Title Row */}
          <div className="text-center space-y-2 select-none">
            <div className="mx-auto w-14 h-14 bg-yellow-405 bg-yellow-400 text-slate-950 rounded-2xl flex items-center justify-center font-black text-2xl shadow-lg shadow-yellow-400/10">
              🏓
            </div>
            <h1 className="text-xl font-black text-slate-100 uppercase tracking-tight">TT Manager Pro</h1>
            <p className="text-xs text-slate-400 font-medium">Gestão Completa de Tênis de Mesa</p>
          </div>

          {isLoginTab ? (
            /* LOGIN CARD */
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-1">
                <input 
                  type="email" 
                  placeholder="Administrador E-mail"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="password" 
                  placeholder="Senha"
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold py-2.5 rounded-lg text-sm transition tracking-wide flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-98"
              >
                <LogIn className="w-4 h-4" />
                Entrar no Sistema
              </button>

              <button
                type="button"
                onClick={() => {
                  const target = registeredUsers.find(u => u.email.toLowerCase() === 'schmidtvagner@gmail.com') || { name: 'Vagner Schmidt', email: 'schmidtvagner@gmail.com', pass: '180820', role: 'master' };
                  setSessionUser(target as User);
                  showToast(`Sessão iniciada como ${target.name}!`, 'success');
                }}
                className="w-full bg-gradient-to-r from-amber-500/10 to-yellow-500/15 hover:from-amber-500/20 hover:to-yellow-500/25 border border-amber-500/40 text-amber-300 font-extrabold py-2.5 rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition cursor-pointer active:scale-95 shadow-sm"
              >
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>Acesso Rápido: Vagner Schmidt</span>
              </button>

              <div className="flex items-center gap-4 text-xs text-slate-500 py-1">
                <div className="h-px bg-slate-800 flex-1"></div>
                <span>ou</span>
                <div className="h-px bg-slate-800 flex-1"></div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setIsAutoRegistro(true)}
                  className="w-full bg-emerald-600/95 hover:bg-emerald-500 text-slate-100 font-extrabold py-2 rounded-lg text-xs transition flex items-center justify-center gap-2 shadow-lg border border-emerald-500/30 cursor-pointer"
                >
                  📝 Auto-Registro / Inscrição de Envolvidos
                </button>
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="w-full bg-slate-950 hover:bg-slate-800/40 text-slate-350 border border-slate-800 hover:border-slate-700/80 font-bold py-2 rounded-lg text-xs transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  Modo Demonstrativo (Demo)
                </button>
                <button
                  type="button"
                  onClick={() => setIsLoginTab(false)}
                  className="w-full bg-transparent text-slate-400 hover:text-slate-200 text-xs font-semibold py-1 text-center block transition cursor-pointer font-sans"
                >
                  Cadastrar nova conta administrador
                </button>
              </div>
            </form>
          ) : (
            /* REGISTER CARD */
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-1">
                <input 
                  type="text" 
                  placeholder="Seu Nome Completo"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="email" 
                  placeholder="Seu Melhor E-mail"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="password" 
                  placeholder="Escolha uma Senha (mín. 6)"
                  value={regPass}
                  onChange={(e) => setRegPass(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>
              <div className="space-y-1">
                <input 
                  type="password" 
                  placeholder="Confirme a Senha"
                  value={regConfirm}
                  onChange={(e) => setRegConfirm(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg px-3.5 py-2.5 text-sm outline-none transition font-medium"
                />
              </div>

              <div className="space-y-1">
                <label className="text-3xs uppercase font-extrabold tracking-wider text-slate-400 block pl-0.5 mb-1">Nível de Permissão</label>
                <select
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-3 py-2 text-xs font-bold outline-none cursor-pointer focus:ring-1 focus:ring-yellow-400/20"
                >
                  <option value="comum">Usuário Comum (Visualizar + Auto-Registro)</option>
                  <option value="arbitro">Árbitro Oficial (Mesa / Súmulas)</option>
                  <option value="mesario">Mesário (Assistente de Mesa / Placar)</option>
                  <option value="admin">Administrador (Gerenciar; Sem Excluir ou Financeiro)</option>
                  <option value="master">Administrador Master (Acesso Total / Supremo)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold py-2.5 rounded-lg text-sm transition tracking-wide flex items-center justify-center gap-2 cursor-pointer shadow-lg font-black"
              >
                <UserPlus className="w-4 h-4" />
                Criar Minha Conta
              </button>

              <button
                type="button"
                onClick={() => setIsLoginTab(true)}
                className="w-full bg-transparent hover:bg-slate-800/40 text-slate-400 hover:text-slate-200 border border-slate-800 font-bold py-2 rounded-lg text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                Voltar ao Login
              </button>
            </form>
          )}

        </div>
      )}
      </div>
    );
  }

  const getSectionTitle = () => {
    return menuItems.find(item => item.id === activeSection)?.label || activeSection;
  };

  return (
    <div className={`min-h-screen flex bg-slate-950 font-sans selection:bg-yellow-400 selection:text-slate-950 transition-colors duration-200 ${
      theme === 'light' ? 'bg-[#f0f2f8]' : 'bg-slate-950'
    }`}>
      
      {/* Toast notifications overlay */}
      <div className="no-print fixed top-5 left-1/2 -translate-x-1/2 z-[9999] flex flex-col gap-2.5 w-full max-w-sm px-4 pointer-events-none select-none">
        <AnimatePresence>
          {toasts.map(t => {
            let iconColor = 'text-emerald-400';
            let leftBarColor = 'bg-emerald-500';
            let Icon = CheckCircle;

            if (t.type === 'error') {
              iconColor = 'text-red-400';
              leftBarColor = 'bg-red-500';
              Icon = AlertCircle;
            } else if (t.type === 'warning') {
              iconColor = 'text-amber-400';
              leftBarColor = 'bg-amber-500';
              Icon = AlertTriangle;
            } else if (t.type === 'info') {
              iconColor = 'text-sky-450 text-sky-400';
              leftBarColor = 'bg-sky-500';
              Icon = Info;
            }

            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: -25, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -25, scale: 0.95 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className={`pointer-events-auto w-full border flex items-center gap-3.5 pl-4 pr-4 py-3 rounded-xl shadow-2xl relative overflow-hidden backdrop-blur-md transition-all duration-150 ${
                  theme === 'light' 
                    ? 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300/40' 
                    : 'bg-slate-900/95 border-slate-800/95 text-slate-100 shadow-slate-950/50'
                }`}
              >
                <div className={`absolute top-0 bottom-0 left-0 w-1.25 ${leftBarColor}`} />
                <div className="shrink-0">
                  <Icon className={`w-5 h-5 ${iconColor}`} />
                </div>
                <p className="text-xs font-semibold leading-normal flex-1 pr-2">
                  {t.message}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setToasts(prev => prev.filter(item => item.id !== t.id));
                  }}
                  className={`transition p-1 rounded-lg cursor-pointer shrink-0 animate-none ${
                    theme === 'light' 
                      ? 'text-slate-400 hover:text-slate-700 hover:bg-slate-100' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
      
      {/* MOBILE BACKDROP OVERLAY */}
      {mobileMenuOpen && !immersiveSumula && (
        <div 
          onClick={() => setMobileMenuOpen(false)}
          className="no-print lg:hidden fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 transition-opacity animate-fadeIn cursor-pointer"
        />
      )}

      {/* MOBILE TRIGGER SIDEBAR HUD BUTTON */}
      {!immersiveSumula && (
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="no-print lg:hidden fixed top-3 left-3 z-[60] bg-yellow-400 hover:bg-yellow-300 text-slate-950 p-2 rounded-lg cursor-pointer transition active:scale-95 shadow-lg shadow-yellow-400/20 flex items-center justify-center"
          title="Alternar Menu Lateral"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      )}

      {/* SIDEBAR NAVIGATION NAVIGATION DRAWER COMPONENT */}
      <aside className={`no-print fixed top-0 bottom-0 left-0 z-50 w-60 border-r bg-slate-900 border-slate-800/80 flex flex-col justify-between shrink-0 transition-transform duration-300 transform overflow-y-auto ${
        immersiveSumula 
          ? '-translate-x-full lg:-translate-x-full' 
          : (desktopCollapsed 
              ? (mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:-translate-x-full')
              : (mobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'))
      }`}>
        <div className="space-y-4">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 bg-yellow-400 text-slate-950 rounded-xl flex items-center justify-center font-black text-lg shrink-0 shadow-sm">
                🏓
              </div>
              <div className="min-w-0">
                <h2 className="font-extrabold text-sm text-slate-100 tracking-tight leading-none truncate">TT Manager Pro</h2>
                <span className="text-[10px] text-yellow-400 font-extrabold tracking-wider uppercase">⚡ Sincronizado</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="lg:hidden p-1.5 text-slate-400 hover:text-slate-100 bg-slate-800/80 hover:bg-slate-800 rounded-lg transition shrink-0"
              title="Fechar Menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <nav className="px-3 pb-8 space-y-6">
            {['Principal', 'Competição', 'Administração'].map(cat => {
              const items = menuItems.filter(item => item.category === cat);
              return (
                <div key={cat} className="space-y-1">
                  <span className="block px-3 text-[10px] font-extrabold uppercase tracking-widest text-slate-500 py-2">
                    {cat}
                  </span>
                  {items.map(item => {
                    const Icon = item.icon;
                    const isActive = activeSection === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => navigateToSection(item.id)}
                        className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-lg tracking-wide select-none cursor-pointer duration-100 ${
                          isActive 
                            ? 'bg-yellow-400/10 text-yellow-400 border-l-2 border-yellow-400/90 pl-2.5' 
                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850/45'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Icon className={`w-4 h-4 shrink-0 duration-100 ${isActive ? 'text-yellow-400' : 'text-slate-500 group-hover:text-slate-200'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        {item.shortcut && (
                          <kbd className="hidden lg:inline-block text-[9px] bg-slate-950/90 text-slate-500 border border-slate-800/80 px-1 py-0.5 rounded font-mono font-semibold uppercase shrink-0">
                            {item.shortcut}
                          </kbd>
                        )}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </nav>
        </div>

        {/* User Footer Profile & Live Role Switcher */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/20 select-none space-y-2.5">
          <div className="flex items-center gap-3">
            <div className="w-8.5 h-9 bg-yellow-400 text-slate-950 font-black rounded-full flex items-center justify-center uppercase shrink-0 text-sm">
              {sessionUser.name[0]}
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-extrabold text-slate-250 truncate text-xs">{sessionUser.name}</div>
              <div className="text-slate-450 truncate text-3xs font-mono">{sessionUser.email}</div>
            </div>
          </div>

          <div className="space-y-1.5 p-2 rounded-lg bg-amber-500/10 border border-amber-500/25">
            <div className="text-[9px] uppercase tracking-wider font-extrabold text-amber-400 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                Controle Master
              </span>
              <span className="text-[8px] bg-emerald-500/20 text-emerald-400 px-1 py-0.5 rounded font-mono font-bold">TODOS LIBERADOS</span>
            </div>
            <select
              value={sessionUser.role || 'master'}
              onChange={(e) => {
                const nextRole = e.target.value as 'comum' | 'admin' | 'master';
                const updated = { ...sessionUser, role: nextRole };
                setSessionUser(updated);
                setRegisteredUsers(prev => prev.map(u => u.email.toLowerCase() === sessionUser.email.toLowerCase() ? { ...u, role: nextRole } : u));
                showToast(`Nível de acesso definido para: ${nextRole === 'master' ? '👑 Master Admin (Prioridade Total)' : nextRole === 'admin' ? '🛡️ Administrador' : '👥 Usuário Comum'}`, 'info');
              }}
              className="w-full bg-slate-950 border border-slate-800 text-[10px] text-amber-400 font-extrabold rounded px-2 py-1 outline-none cursor-pointer"
            >
              <option value="master">👑 MASTER ADMIN (PRIORIDADE TOTAL)</option>
              <option value="admin">🛡️ ADMINISTRADOR</option>
              <option value="comum">👥 USUÁRIO COMUM</option>
            </select>
          </div>
        </div>
      </aside>

      {/* MAIN CONTAINER WINDOWPORT */}
      <main className={`flex-1 flex flex-col min-w-0 relative transition-all duration-300 ${
        immersiveSumula || desktopCollapsed ? 'lg:pl-0' : 'lg:pl-60'
      }`}>
        
        {/* UPPER TITLE & THEME TOPBAR */}
        <header className={`no-print h-14 border-b border-slate-800/50 bg-slate-900 flex items-center justify-between px-4 sm:px-6 shrink-0 relative z-30 transition-all duration-300 ${
          immersiveSumula ? 'pl-4 sm:pl-6' : 'pl-14 lg:pl-6'
        }`}>
          <div className="flex items-center gap-3">
            {!immersiveSumula && (
              <button
                type="button"
                onClick={() => setDesktopCollapsed(!desktopCollapsed)}
                className="hidden lg:flex p-2 rounded-lg bg-slate-800 hover:bg-slate-750 text-yellow-400 border border-slate-700 transition active:scale-95 cursor-pointer items-center justify-center shrink-0 shadow-sm"
                title={desktopCollapsed ? "Expandir Barra Lateral" : "Recolher Barra Lateral"}
              >
                <Menu className="w-4 h-4" />
              </button>
            )}
            {activeSection !== 'dashboard' && (
              <button
                type="button"
                onClick={() => navigateToSection('dashboard')}
                className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 text-slate-350 hover:text-yellow-400 border border-slate-700 rounded-lg px-2.5 py-1.5 text-2xs font-black cursor-pointer transition active:scale-95 uppercase shadow-sm duration-150"
                title="VOLTAR PARA O INÍCIO (DASHBOARD)"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">VOLTAR</span>
              </button>
            )}
            <h2 className="text-sm font-extrabold text-slate-200 uppercase tracking-wider truncate">{getSectionTitle()}</h2>
          </div>
          
          <div className="flex items-center gap-3 select-none">
            <div className="hidden sm:flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-2.5 py-1 rounded-lg text-2xs font-extrabold uppercase tracking-wider shadow-sm">
              <Crown className="w-3.5 h-3.5 fill-current text-amber-400 shrink-0" />
              <span>Acesso Master Liberado</span>
            </div>
            <span className="hidden md:inline text-xs text-slate-400 font-medium font-mono">{config.org}</span>
            <div className="h-4 w-px bg-slate-800 hidden md:block"></div>
            
            {/* IndexedDB Offline Storage & Connection Badge */}
            <div 
              onClick={() => setIsCloudIntegrationsModalOpen(true)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-2xs font-extrabold uppercase transition cursor-pointer border shadow-sm ${
                isOnline
                  ? 'bg-blue-500/15 text-blue-400 border-blue-500/30 hover:bg-blue-500/25'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/50 animate-pulse hover:bg-amber-500/30'
              }`}
              title={
                isOnline
                  ? "IndexedDB Ativo: Todos os dados e filas de árbitros salvos localmente no navegador."
                  : "MODO OFFLINE (IndexedDB): Filas de árbitros e placares funcionando normal localmente!"
              }
            >
              <Database className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              {isOnline ? (
                <span className="hidden xl:inline-flex items-center gap-1 text-emerald-400">
                  <Wifi className="w-3 h-3 text-emerald-400" /> IDB Ativo
                </span>
              ) : (
                <span className="flex items-center gap-1 text-amber-300 font-black">
                  <WifiOff className="w-3 h-3 text-amber-400" /> Offline {pendingOfflineCount > 0 && `(${pendingOfflineCount})`}
                </span>
              )}
            </div>

            {/* Sound Effects Toggle Button */}
            <button
              onClick={() => {
                const active = toggleSound();
                setSoundActive(active);
                if (active) {
                  playSuccessSound();
                }
              }}
              className={`p-1.5 rounded-lg border transition cursor-pointer flex items-center justify-center shrink-0 shadow-sm ${
                soundActive
                  ? 'bg-yellow-400/10 hover:bg-yellow-400/20 text-yellow-400 border-yellow-400/30'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-400 border-slate-700'
              }`}
              title={soundActive ? "Efeitos Sonoros Ativados (Clique para Silenciar)" : "Efeitos Sonoros Desativados (Clique para Ativar)"}
            >
              {soundActive ? <Volume2 className="w-3.5 h-3.5 text-yellow-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
            </button>

            {/* Spreadsheet Sync Quick Button */}
            <button
              onClick={() => setIsSyncModalOpen(true)}
              className="flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 px-2.5 py-1.5 rounded-lg text-2xs font-extrabold uppercase transition cursor-pointer shadow-sm"
              title="Sincronização Inteligente de Planilha em 1 Clique"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Sincronizar Planilha</span>
            </button>

            {/* Firebase Cloud Sync Button */}
            <button
              onClick={() => setIsFirebaseSyncModalOpen(true)}
              className="flex items-center gap-1.5 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/40 px-2.5 py-1.5 rounded-lg text-2xs font-extrabold uppercase transition cursor-pointer shadow-sm relative group"
              title="Banco de Dados Firebase Grátis na Nuvem"
            >
              <Cloud className={`w-3.5 h-3.5 text-yellow-400 ${autoSyncEnabled ? 'animate-pulse' : ''}`} />
              <span className="hidden sm:inline">Firebase Nuvem</span>
              {autoSyncEnabled && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-slate-900 animate-pulse"></span>
              )}
            </button>

            {/* Deploy Automático Button */}
            <button
              onClick={() => setIsAutoDeployModalOpen(true)}
              className="flex items-center gap-1.5 bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-300 hover:to-amber-400 text-slate-950 px-3 py-1.5 rounded-lg text-2xs font-black uppercase transition cursor-pointer shadow-md group"
              title="Executar Deploy Automático de Atualizações"
            >
              <Rocket className="w-3.5 h-3.5 text-slate-950 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              <span>Deploy Automático</span>
            </button>

            {/* Vercel & GitHub Integrations Status Button */}
            <button
              onClick={() => setIsCloudIntegrationsModalOpen(true)}
              className="flex items-center gap-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/40 px-2.5 py-1.5 rounded-lg text-2xs font-extrabold uppercase transition cursor-pointer shadow-sm"
              title="Status da Nuvem (Firebase, Vercel DB & GitHub)"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="hidden md:inline">Status Nuvem & Git</span>
            </button>

            {/* Theme switcher */}
            <button
              onClick={toggleTheme}
              className="p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800/40 transition-colors duration-150 cursor-pointer"
              title="Alternar Tema Clareador / Escurecedor"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-yellow-400" /> : <Moon className="w-4 h-4 text-slate-500" />}
            </button>

            {/* Logout anchor */}
            <button
              onClick={handleLogout}
              className="p-1.5 focus:outline-none flex items-center gap-1 bg-transparent hover:bg-slate-800 text-slate-450 hover:text-red-400 font-extrabold rounded-lg text-3xs transition duration-150 cursor-pointer uppercase tracking-wider"
              title="Sair da Conta Administrador"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Sair</span>
            </button>
          </div>
        </header>

        {/* SECTION WRAPPER INJECTS */}
        <section className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6">
          {(() => {
            const curRole = sessionUser?.role || 'master';
            return (
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeSection}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.18, ease: 'easeOut' }}
                  className="w-full space-y-6"
                >
                  {activeSection === 'dashboard' && (
                    <DashboardView 
                      atletas={atletas} 
                      torneios={torneios} 
                      resultados={resultados} 
                      arbitros={arbitros} 
                      funcionarios={funcionarios} 
                      categorias={categorias}
                      inscricoes={inscricoes}
                      onNavigate={navigateToSection} 
                      config={config}
                    />
                  )}

                  {activeSection === 'atletas' && (
                    <AtletasView 
                      atletas={atletas} 
                      categorias={categorias}
                      torneios={torneios}
                      inscricoes={inscricoes}
                      onSave={handleSaveAtleta} 
                      onDelete={handleDeleteAtleta} 
                      onSaveInscricoes={handleSaveInscricoes}
                      onNavigateToSection={setActiveSection}
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'ficha' && (
                    <FichaInscricaoView 
                      atletas={atletas} 
                      torneios={torneios} 
                      arbitros={arbitros}
                      funcionarios={funcionarios}
                      treinadores={treinadores}
                      inscricoes={inscricoes}
                      config={config}
                      onSaveTreinadores={handleSaveTreinadores}
                      onSaveInscricoes={handleSaveInscricoes}
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'categorias' && (
                    <CategoriasView 
                      categorias={categorias} 
                      onSave={handleSaveCategoria} 
                      onSaveMultiple={handleSaveCategorias}
                      onDelete={handleDeleteCategoria} 
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'torneios' && (
                    <TorneiosView 
                      torneios={torneios} 
                      onSave={handleSaveTorneio} 
                      onDelete={handleDeleteTorneio} 
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'chaveamento' && (
                    <ChaveamentoView 
                      torneios={torneios} 
                      atletas={atletas} 
                      categorias={categorias}
                      inscricoes={inscricoes}
                      arbitros={arbitros}
                      config={config}
                      userRole={curRole}
                      onSaveAtleta={(updated) => setAtletas(prev => prev.map(a => a.id === updated.id ? updated : a))}
                      onSaveAtletasBulk={setAtletas}
                    />
                  )}

                  {activeSection === 'resultados' && (
                    <ResultadosView 
                      torneios={torneios} 
                      categorias={categorias} 
                      atletas={atletas} 
                      arbitros={arbitros} 
                      resultados={resultados} 
                      onSave={handleSaveResultado} 
                      onDelete={handleDeleteResultado} 
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'sumula' && (
                    <SumulaView 
                      torneios={torneios} 
                      atletas={atletas} 
                      arbitros={arbitros}
                      resultados={resultados}
                      immersiveMode={immersiveSumula}
                      onToggleImmersive={() => setImmersiveSumula(!immersiveSumula)}
                      config={config}
                    />
                  )}

                  {activeSection === 'placar-arbitro' && (
                    <PlacarArbitroView 
                      torneios={torneios}
                      categorias={categorias}
                      atletas={atletas}
                      arbitros={arbitros}
                      resultados={resultados}
                      onSaveResultado={handleSaveResultado}
                      onNavigate={navigateToSection}
                      refereeQueue={refereeQueue}
                      onUpdateRefereeQueue={handleUpdateRefereeQueue}
                      config={config}
                      onSaveConfig={setConfig}
                      onUpdateArbitro={handleSaveArbitro}
                      userRole={curRole}
                      sessionUser={sessionUser}
                    />
                  )}

                  {activeSection === 'arbitros' && (
                    <ArbitrosView 
                      arbitros={arbitros} 
                      resultados={resultados} 
                      onSave={handleSaveArbitro} 
                      onDelete={handleDeleteArbitro} 
                      refereeQueue={refereeQueue}
                      onUpdateRefereeQueue={handleUpdateRefereeQueue}
                      onUpdateArbitro={handleSaveArbitro}
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'funcionarios' && (
                    <FuncionariosView 
                      funcionarios={funcionarios} 
                      onSave={handleSaveFuncionario} 
                      onDelete={handleDeleteFuncionario} 
                      userRole={curRole}
                    />
                  )}

                  {activeSection === 'classificacao' && (
                    <ClassificacaoView 
                      atletas={atletas} 
                      resultados={resultados} 
                    />
                  )}

                  {activeSection === 'whatsapp' && (
                    <WhatsAppView 
                      atletas={atletas} 
                      arbitros={arbitros} 
                    />
                  )}

                  {activeSection === 'relatorios' && (
                    <RelatoriosView 
                      atletas={atletas} 
                      torneios={torneios} 
                      resultados={resultados} 
                      arbitros={arbitros} 
                      funcionarios={funcionarios} 
                      stateDump={{ atletas, torneios, categorias, arbitros, resultados, funcionarios, treinadores, inscricoes, registeredUsers, config }} 
                      onOpenSyncModal={() => setIsSyncModalOpen(true)}
                    />
                  )}

                  {activeSection === 'config' && (
                    <ConfiguracoesView 
                      config={config} 
                      onSaveConfig={setConfig} 
                      onResetFactory={handleResetFactory} 
                      onClearAll={handleClearAll} 
                      userRole={curRole}
                      onOpenSyncModal={() => setIsSyncModalOpen(true)}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            );
          })()}
        </section>

      </main>

      <SpreadsheetSyncModal 
        isOpen={isSyncModalOpen} 
        onClose={() => setIsSyncModalOpen(false)} 
        currentState={{ atletas, arbitros, treinadores, funcionarios, torneios, categorias }} 
        onApplySync={handleApplySync} 
      />

      <FirebaseSyncModal
        isOpen={isFirebaseSyncModalOpen}
        onClose={() => setIsFirebaseSyncModalOpen(false)}
        currentState={{
          atletas,
          categorias,
          torneios,
          arbitros,
          resultados,
          funcionarios,
          treinadores,
          inscricoes,
          config,
          registeredUsers,
          refereeQueue
        }}
        onApplySync={handleApplyFirebaseState}
        autoSyncEnabled={autoSyncEnabled}
        onToggleAutoSync={setAutoSyncEnabled}
      />

      <CloudIntegrationsModal
        isOpen={isCloudIntegrationsModalOpen}
        onClose={() => setIsCloudIntegrationsModalOpen(false)}
        autoSyncFirebase={autoSyncEnabled}
        onToggleAutoSyncFirebase={setAutoSyncEnabled}
        onOpenAutoDeploy={() => setIsAutoDeployModalOpen(true)}
        getCurrentPayload={() => ({
          atletas, categorias, torneios, arbitros, resultados,
          funcionarios, treinadores, inscricoes, config, registeredUsers, refereeQueue
        })}
      />

      <AutoDeployModal
        isOpen={isAutoDeployModalOpen}
        onClose={() => setIsAutoDeployModalOpen(false)}
        currentState={{
          atletas,
          categorias,
          torneios,
          arbitros,
          resultados,
          funcionarios,
          treinadores,
          inscricoes,
          config,
          registeredUsers,
          refereeQueue
        }}
      />

      <ConfirmDialog />
    </div>
  );
}
