export default async function handler(req: any, res: any) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const timestamp = new Date().toISOString();
    return res.status(200).json({
      success: true,
      message: 'Vercel Auto-Sync executado com sucesso!',
      timestamp,
      environment: process.env.VERCEL_ENV || 'production',
      syncedAt: timestamp
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: error?.message || 'Erro ao executar o Vercel Auto-Sync'
    });
  }
}
