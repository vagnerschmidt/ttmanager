# 🏓 Guia de Instalação no Computador - TT Manager Pro

Este documento explica como instalar e executar o **TT Manager Pro** no seu computador com **banco de dados 100% local e gratuito (IndexedDB)**, funcionando para sempre mesmo **sem conexão com a internet**.

---

## 🚀 Opção 1: Instalação Nativa com 1-Clique (Recomendada - PWA)

Não precisa instalar nada além do seu navegador (Google Chrome, Microsoft Edge ou Brave):

1. Abra o aplicativo no seu navegador Chrome, Edge ou Brave.
2. Na barra de endereço (lado direito) ou no menu do sistema, clique no botão **"Instalar Aplicativo no Computador"** 💻.
3. Clique em **"Instalar"**.
4. Um ícone do **TT Manager Pro** será criado na sua **Área de Trabalho (Desktop)** e no Menu Iniciar.
5. O sistema rodará em uma janela própria de aplicativo nativo, com **banco de dados local IndexedDB ativado**.

---

## 💻 Opção 2: Executável Local no Computador (`.bat`)

Se você baixou os arquivos do projeto para o seu computador:

1. Certifique-se de ter o **Node.js LTS** instalado (disponível em [nodejs.org](https://nodejs.org)).
2. Dê um duplo clique no arquivo `INSTALAR_TT_MANAGER_PRO.bat`.
3. O script instalará automaticamente todas as dependências e iniciará o sistema localmente em `http://localhost:3000`.

---

## 💾 Banco de Dados Local & Infinito

- O sistema utiliza **HTML5 IndexedDB** de alta capacidade dentro do navegador.
- Todos os atletas, categorias, torneios, chaves, súmulas, placares e configurações são salvos diretamente no seu computador.
- **Backup de Segurança:** Acesse o menu *Relatórios* ou *Instalador PC* para baixar a qualquer momento um arquivo `.json` de cópia de segurança de todo o banco de dados.
