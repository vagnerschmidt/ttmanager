@echo off
title TT Manager Pro - Instalador e Inicializador do Computador
color 0A
cls
echo =======================================================================
echo          INSTALADOR E INICIALIZADOR DO TT MANAGER PRO (PC)
echo =======================================================================
echo.
echo [1/3] Verificando ambiente e dependencias do Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ALERTA] Node.js nao encontrado no seu computador!
    echo Por favor, baixe e instale o Node.js LTS gratuito em: https://nodejs.org
    echo Pressione qualquer tecla para abrir o site do Node.js...
    pause >nul
    start https://nodejs.org
    exit /b
)

echo [2/3] Instalando todas as dependencias locais e banco de dados...
call npm install

echo [3/3] Compilando e iniciando o servidor local do TT Manager Pro...
echo.
echo =======================================================================
echo   SISTEMA PRONTO! O TT Manager Pro abrira automaticamente no seu navegador.
echo   Banco de dados local (IndexedDB) ativado e pronto para uso offline infinito.
echo =======================================================================
echo.

start http://localhost:3000
call npm run dev

pause
