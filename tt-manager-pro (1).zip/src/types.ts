export type UserRole = 'comum' | 'admin' | 'master' | 'arbitro' | 'mesario';

export interface User {
  name: string;
  email: string;
  pass: string;
  role?: UserRole;
}

export interface Atleta {
  id: string;
  nome: string;
  nasc: string; // YYYY-MM-DD
  cpf: string;
  rg: string;
  genero: string;
  natural: string;
  end: string;
  cat: string;
  clube: string;
  rating: number;
  cbtt: string;
  nivel: string; // 'Iniciante' | 'Intermediário' | 'Avançado' | 'Elite'
  mao: string; // 'Direita' | 'Esquerda'
  emp: string; // 'Caneta' | 'Shakehand'
  status: string; // 'Ativo' | 'Inativo' | 'Suspenso'
  obs: string;
  email: string;
  wa: string;
  tel: string;
  emerg: string;
  resp: string;
  respCpf: string;
  foto: string; // Data URL or empty
  presenca?: string; // 'PENDENTE' | 'CONFIRMADA' | 'AUSENTE'
  pagamento?: string; // 'PENDENTE' | 'PAGO' | 'ISENTO'
}

export interface BracketMatch {
  id: string; // 'q1' | 'q2' | 'q3' | 'q4' | 's1' | 's2' | 'f1' | 'r1_1' | 'r1_2' | 'r2_1' | 'r2_2' | 'rf' | 'sf'
  round: 'quartas' | 'semis' | 'final' | 'repescagem_r1' | 'repescagem_r2' | 'repescagem_final' | 'super_final';
  p1: Atleta | null;
  p2: Atleta | null;
  score1: number;
  score2: number;
  isWO?: boolean;
  woLoser?: 'p1' | 'p2';
  bracketType?: 'main' | 'losers';
}

export interface Categoria {
  id: string;
  nome: string;
  tipo: string; // 'Simples' | 'Duplas' | 'Misto'
  genero: string; // 'Masculino' | 'Feminino' | 'Misto' | 'Livre'
  idmin: string;
  idmax: string;
  rmin: string;
  rmax: string;
  fmt: string; // 'Eliminatória Simples' | 'Dupla Eliminação' | 'Round Robin' | 'Grupos + Eliminatória'
  max: string;
  desc: string;
}

export interface Torneio {
  id: string;
  nome: string;
  ini: string; // YYYY-MM-DD
  fim: string; // YYYY-MM-DD
  hora: string;
  status: string; // 'Inscrições Abertas' | 'Em Andamento' | 'Encerrado' | 'Cancelado'
  local: string;
  cidade: string;
  end: string;
  fmt: string;
  taxa: string;
  lim: string;
  org: string;
  cont: string;
  desc: string;
  mesas?: number;
  pixKey?: string;
  setsMax?: number;
  setsPoints?: number;
}

export interface Arbitro {
  id: string;
  nome: string;
  nasc: string;
  cpf: string;
  nivel: string; // 'Nacional' | 'Estadual' | 'Regional' | 'Local'
  cbtt: string;
  email: string;
  wa: string;
  tel: string;
  status: string; // 'Disponível' | 'Em Jogo' | 'Indisponível'
  val: string;
  obs: string;
  foto: string;
  presenca?: string; // 'PENDENTE' | 'CONFIRMADA' | 'AUSENTE'
  pagamento?: string; // 'PENDENTE' | 'PAGO' | 'ISENTO'
}

export interface Funcionario {
  id: string;
  nome: string;
  nasc: string;
  cpf: string;
  rg: string;
  genero: string;
  ecivil: string; // 'Solteiro(a)' | 'Casado(a)' | ...
  end: string;
  cargo: string;
  depto: string; // 'Administração' | 'Técnico' | 'Arbitragem' | ...
  admissao: string;
  contrato: string; // 'CLT' | 'PJ' | ...
  salario: string;
  ch: string;
  ctps: string;
  pis: string;
  status: string; // 'Ativo' | 'Férias' | 'Afastado' | 'Demitido'
  demissao: string;
  obs: string;
  email: string;
  wa: string;
  tel: string;
  ramal: string;
  emerg: string;
  email2: string;
  foto: string;
}

export interface Resultado {
  id: string;
  torId: string;
  catId: string;
  nomeA: string;
  nomeB: string;
  ponA: number; // Sets won by Player A
  ponB: number; // Sets won by Player B
  setsA: number; // Points in current/last set A (or final calculation sets/points)
  setsB: number;
  arb: string;
  mesa: number;
  dt: string; // DateTime ISO
  wo?: 'A' | 'B'; // 'A' or 'B' indicates who lost by W.O.
  obs?: string; // Custom notes or audit remarks (e.g. "Falta do atleta/Cartões aplicados")
  cartoesA?: { amarelo: number; vermelho: number };
  cartoesB?: { amarelo: number; vermelho: number };
}

export interface MesaStatus {
  numero: number;
  status: 'livre' | 'ocupada';
  arbitroNome?: string;
}

export interface SystemConfig {
  org: string;
  cnpj: string;
  email: string;
  wa: string;
  site: string;
  sets: string; // 'Melhor de 5' etc.
  setsMax?: number;
  setsPoints?: number;
  fbkey?: string;
  fbpid?: string;
  fbauth?: string;
  mesasCount?: number;
  mesasStatus?: MesaStatus[];
  pixKey?: string;
  themeAutoSchedule?: boolean;
  themeAutoScheduleStartHour?: number;
  themeAutoScheduleEndHour?: number;
}

export interface Treinador {
  id: string;
  nome: string;
  clube: string;
  cref: string;
  wa: string;
  email: string;
  foto?: string;
  status: string;
}

export interface Inscricao {
  id: string;
  atletaId: string;
  torneioId: string;
  categoria: string;
  valorTaxa: string;
  statusPagamento: 'Pendente' | 'Pago' | 'Isento';
  confirmada: boolean;
  treinadorId?: string;
  identificadorAtleta?: string;
  identificadorPagamento?: string;
  pixPayloadString?: string;
  pixQrCodeUrl?: string;
  pixTransactionUuid?: string;
}
