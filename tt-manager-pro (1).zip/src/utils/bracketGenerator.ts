import { Atleta, Categoria, Inscricao, BracketMatch } from '../types';

export interface PotDistribution {
  pote1: Atleta[]; // Cabeças de Chave
  pote2: Atleta[]; // Segundos Cabeças
  pote3: Atleta[]; // Intermediários
  pote4: Atleta[]; // Qualificantes / Base
}

/**
 * Divides enrolled athletes into 4 seeds/pots by rating (descending).
 */
export function divideAthletesIntoPots(athletes: Atleta[]): PotDistribution {
  const sorted = [...athletes].sort((a, b) => (b.rating || 0) - (a.rating || 0));
  const total = sorted.length;

  if (total <= 4) {
    return {
      pote1: sorted.slice(0, 2),
      pote2: sorted.slice(2, 4),
      pote3: [],
      pote4: []
    };
  } else if (total <= 8) {
    return {
      pote1: sorted.slice(0, 2),
      pote2: sorted.slice(2, 4),
      pote3: sorted.slice(4, 6),
      pote4: sorted.slice(6, 8)
    };
  } else {
    const potSize = Math.ceil(total / 4);
    return {
      pote1: sorted.slice(0, potSize),
      pote2: sorted.slice(potSize, potSize * 2),
      pote3: sorted.slice(potSize * 2, potSize * 3),
      pote4: sorted.slice(potSize * 3)
    };
  }
}

export const createEmptyMatches = (format: 'simples' | 'dupla' = 'simples'): BracketMatch[] => {
  const mainMatches: BracketMatch[] = [
    { id: 'q1', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 'q2', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 'q3', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 'q4', round: 'quartas', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 's1', round: 'semis', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 's2', round: 'semis', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
    { id: 'f1', round: 'final', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'main' },
  ];

  if (format === 'dupla') {
    const losersMatches: BracketMatch[] = [
      { id: 'r1_1', round: 'repescagem_r1', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
      { id: 'r1_2', round: 'repescagem_r1', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
      { id: 'r2_1', round: 'repescagem_r2', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
      { id: 'r2_2', round: 'repescagem_r2', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
      { id: 'rf', round: 'repescagem_final', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
      { id: 'sf', round: 'super_final', p1: null, p2: null, score1: 0, score2: 0, bracketType: 'losers' },
    ];
    return [...mainMatches, ...losersMatches];
  }

  return mainMatches;
};

export function getWinner(m: BracketMatch): Atleta | null {
  if (!m.p1 && !m.p2) return null;
  if (m.p1 && !m.p2) return m.p1;
  if (!m.p1 && m.p2) return m.p2;
  if (m.isWO) {
    if (m.woLoser === 'p1') return m.p2;
    if (m.woLoser === 'p2') return m.p1;
  }
  if (m.score1 > m.score2) return m.p1;
  if (m.score2 > m.score1) return m.p2;
  return m.p1;
}

export function getLoser(m: BracketMatch): Atleta | null {
  if (!m.p1 || !m.p2) return null;
  if (m.isWO) {
    if (m.woLoser === 'p1') return m.p1;
    if (m.woLoser === 'p2') return m.p2;
  }
  if (m.score1 > m.score2) return m.p2;
  if (m.score2 > m.score1) return m.p1;
  return m.p2;
}

export function propagateBracket(
  targetMatches: BracketMatch[],
  format: 'simples' | 'dupla' = 'simples'
): BracketMatch[] {
  const updated = targetMatches.map(m => ({ ...m }));
  const findMatch = (id: string) => updated.find(m => m.id === id);

  const q1 = findMatch('q1');
  const q2 = findMatch('q2');
  const q3 = findMatch('q3');
  const q4 = findMatch('q4');
  const s1 = findMatch('s1');
  const s2 = findMatch('s2');
  const f1 = findMatch('f1');

  if (s1 && q1 && q2) {
    s1.p1 = getWinner(q1);
    s1.p2 = getWinner(q2);
  }
  if (s2 && q3 && q4) {
    s2.p1 = getWinner(q3);
    s2.p2 = getWinner(q4);
  }
  if (f1 && s1 && s2) {
    f1.p1 = getWinner(s1);
    f1.p2 = getWinner(s2);
  }

  const isDupla = format === 'dupla' || updated.some(m => m.id === 'r1_1');

  if (isDupla) {
    const r1_1 = findMatch('r1_1');
    const r1_2 = findMatch('r1_2');
    const r2_1 = findMatch('r2_1');
    const r2_2 = findMatch('r2_2');
    const rf = findMatch('rf');
    const sf = findMatch('sf');

    if (r1_1 && q1 && q2) {
      r1_1.p1 = getLoser(q1);
      r1_1.p2 = getLoser(q2);
    }
    if (r1_2 && q3 && q4) {
      r1_2.p1 = getLoser(q3);
      r1_2.p2 = getLoser(q4);
    }

    if (r2_1 && r1_1 && s1) {
      r2_1.p1 = getWinner(r1_1);
      r2_1.p2 = getLoser(s1);
    }
    if (r2_2 && r1_2 && s2) {
      r2_2.p1 = getWinner(r1_2);
      r2_2.p2 = getLoser(s2);
    }

    if (rf && r2_1 && r2_2) {
      rf.p1 = getWinner(r2_1);
      rf.p2 = getWinner(r2_2);
    }

    if (sf && f1 && rf) {
      sf.p1 = getWinner(f1);
      sf.p2 = getWinner(rf);
    }
  }

  return updated;
}

/**
 * Generates and saves automatic bracket for a category based on Pots and chosen format (Simples / Dupla)
 */
export function generateAutoBracketForCategory(
  torneioId: string,
  catIdOrName: string,
  atletas: Atleta[],
  inscricoes: Inscricao[],
  categorias: Categoria[],
  strategy: 'rating' | 'random' = 'rating',
  format: 'simples' | 'dupla' = 'simples'
): { success: boolean; message: string; count: number; format: string } {
  if (!torneioId || !catIdOrName) {
    return { success: false, message: 'Torneio ou categoria não selecionados', count: 0, format };
  }

  const cat = categorias.find(
    c => c.id === catIdOrName || c.nome.trim().toLowerCase() === catIdOrName.trim().toLowerCase()
  );
  if (!cat) {
    return { success: false, message: `Categoria "${catIdOrName}" não encontrada`, count: 0, format };
  }

  const catName = cat.nome.trim().toLowerCase();

  const matchedInscricoes = inscricoes.filter(
    i => i.torneioId === torneioId && i.categoria.trim().toLowerCase() === catName
  );

  let candidates: Atleta[] = [];
  if (matchedInscricoes.length > 0) {
    candidates = atletas.filter(a => matchedInscricoes.some(ins => ins.atletaId === a.id));
  } else {
    candidates = atletas.filter(a => {
      if (!a.cat) return false;
      return a.cat.split(',').map(s => s.trim().toLowerCase()).includes(catName);
    });
  }

  if (candidates.length < 2) {
    candidates = atletas.filter(a => a.status === 'Ativo');
  }

  if (candidates.length < 2) {
    return {
      success: false,
      message: `São necessários no mínimo 2 atletas cadastrados para gerar o chaveamento da categoria "${cat.nome}"`,
      count: candidates.length,
      format
    };
  }

  if (cat.max) {
    const limit = parseInt(cat.max, 10);
    if (candidates.length > limit) {
      candidates = candidates.slice(0, limit);
    }
  }

  // Sort candidates by strategy
  if (strategy === 'rating') {
    candidates = [...candidates].sort((a, b) => b.rating - a.rating);
  } else {
    candidates = [...candidates].sort(() => Math.random() - 0.5);
  }

  const top8 = candidates.slice(0, 8);
  const pots = divideAthletesIntoPots(top8);

  const matches = createEmptyMatches(format);
  const q1 = matches.find(m => m.id === 'q1')!;
  const q2 = matches.find(m => m.id === 'q2')!;
  const q3 = matches.find(m => m.id === 'q3')!;
  const q4 = matches.find(m => m.id === 'q4')!;

  if (strategy === 'rating') {
    // Seeding with Pots:
    // Pote 1: Seed #1 & Seed #2 (Opposite ends of bracket: Q1 vs Q4)
    q1.p1 = pots.pote1[0] || top8[0] || null;
    q4.p2 = pots.pote1[1] || top8[1] || null;

    // Pote 2: Seed #3 & Seed #4 (Opposite quarters: Q3 vs Q2)
    q3.p1 = pots.pote2[0] || top8[2] || null;
    q2.p1 = pots.pote2[1] || top8[3] || null;

    // Pote 3 & 4: Remaining opponents
    q2.p2 = pots.pote3[0] || top8[4] || null;
    q3.p2 = pots.pote3[1] || top8[5] || null;
    q4.p1 = pots.pote4[0] || top8[6] || null;
    q1.p2 = pots.pote4[1] || top8[7] || null;
  } else {
    q1.p1 = top8[0] || null; q1.p2 = top8[1] || null;
    q2.p1 = top8[2] || null; q2.p2 = top8[3] || null;
    q3.p1 = top8[4] || null; q3.p2 = top8[5] || null;
    q4.p1 = top8[6] || null; q4.p2 = top8[7] || null;
  }

  const propagated = propagateBracket(matches, format);

  const key = `ttmpro_bracket_${torneioId}_${cat.id}`;
  localStorage.setItem(key, JSON.stringify({
    matches: propagated,
    generated: true,
    format: format,
    pots: pots
  }));

  return {
    success: true,
    message: `Chaveamento automático por Potes (${format === 'dupla' ? 'Eliminatória Dupla' : 'Eliminação Simples'}) gerado para ${top8.length} atletas na categoria "${cat.nome}"!`,
    count: top8.length,
    format
  };
}
