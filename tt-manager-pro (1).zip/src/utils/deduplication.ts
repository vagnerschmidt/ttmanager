import { Atleta, Arbitro, Treinador, Funcionario, Torneio, Categoria, Inscricao } from '../types';

export interface DeduplicationSummary {
  atletasRemoved: number;
  atletasMerged: string[];
  inscricoesRemoved: number;
  arbitrosRemoved: number;
  treinadoresRemoved: number;
  funcionariosRemoved: number;
  categoriasRemoved: number;
  torneiosRemoved: number;
  totalRemoved: number;
}

export interface DetailedDuplicatesReport {
  duplicateAtletasGroups: { primary: Atleta; duplicates: Atleta[]; reason: string }[];
  duplicateInscricoes: { primary: Inscricao; duplicate: Inscricao; reason: string }[];
  duplicateArbitros: { primary: Arbitro; duplicates: Arbitro[]; reason: string }[];
  duplicateTreinadores: { primary: Treinador; duplicates: Treinador[]; reason: string }[];
  duplicateFuncionarios: { primary: Funcionario; duplicates: Funcionario[]; reason: string }[];
  duplicateCategorias: { primary: Categoria; duplicates: Categoria[]; reason: string }[];
  duplicateTorneios: { primary: Torneio; duplicates: Torneio[]; reason: string }[];
  hasDuplicates: boolean;
}

const cleanString = (val?: string) => (val || '').trim().toLowerCase();
const cleanCpf = (cpf?: string) => (cpf || '').replace(/\D/g, '');

/**
 * Scans state to find duplicate records without modifying state.
 */
export function analyzeDuplicates(
  atletas: Atleta[],
  inscricoes: Inscricao[],
  arbitros: Arbitro[],
  treinadores: Treinador[],
  funcionarios: Funcionario[],
  categorias: Categoria[],
  torneios: Torneio[]
): DetailedDuplicatesReport {
  const report: DetailedDuplicatesReport = {
    duplicateAtletasGroups: [],
    duplicateInscricoes: [],
    duplicateArbitros: [],
    duplicateTreinadores: [],
    duplicateFuncionarios: [],
    duplicateCategorias: [],
    duplicateTorneios: [],
    hasDuplicates: false,
  };

  // 1. Analyze Atletas
  const processedAtletaIds = new Set<string>();
  for (let i = 0; i < atletas.length; i++) {
    const a1 = atletas[i];
    if (processedAtletaIds.has(a1.id)) continue;

    const cpf1 = cleanCpf(a1.cpf);
    const name1 = cleanString(a1.nome);
    const nasc1 = cleanString(a1.nasc);
    const clube1 = cleanString(a1.clube);

    if (!name1 && !cpf1) continue;

    const duplicates: Atleta[] = [];
    let matchReason = '';

    for (let j = i + 1; j < atletas.length; j++) {
      const a2 = atletas[j];
      if (processedAtletaIds.has(a2.id)) continue;

      const cpf2 = cleanCpf(a2.cpf);
      const name2 = cleanString(a2.nome);
      const nasc2 = cleanString(a2.nasc);
      const clube2 = cleanString(a2.clube);

      let isDup = false;
      if (cpf1 && cpf2 && cpf1 === cpf2) {
        isDup = true;
        matchReason = `CPF idêntico (${a1.cpf})`;
      } else if (name1 && name1 === name2) {
        if (nasc1 && nasc2 && nasc1 === nasc2) {
          isDup = true;
          matchReason = `Nome e data de nascimento idênticos (${a1.nome})`;
        } else if (clube1 && clube2 && clube1 === clube2) {
          isDup = true;
          matchReason = `Nome e clube idênticos (${a1.nome} - ${a1.clube})`;
        } else if (!nasc1 || !nasc2 || nasc1 === nasc2) {
          isDup = true;
          matchReason = `Nome idêntico (${a1.nome})`;
        }
      }

      if (isDup) {
        duplicates.push(a2);
        processedAtletaIds.add(a2.id);
      }
    }

    if (duplicates.length > 0) {
      processedAtletaIds.add(a1.id);
      report.duplicateAtletasGroups.push({
        primary: a1,
        duplicates,
        reason: matchReason,
      });
    }
  }

  // 2. Analyze Inscricoes
  const seenInscKeys = new Map<string, Inscricao>();
  for (const ins of inscricoes) {
    const key = `${ins.atletaId}_${ins.torneioId}_${cleanString(ins.categoria)}`;
    if (seenInscKeys.has(key)) {
      const existing = seenInscKeys.get(key)!;
      report.duplicateInscricoes.push({
        primary: existing.confirmada || existing.statusPagamento === 'Pago' ? existing : ins,
        duplicate: existing.confirmada || existing.statusPagamento === 'Pago' ? ins : existing,
        reason: `Inscrição duplicada na mesma categoria (${ins.categoria})`,
      });
    } else {
      seenInscKeys.set(key, ins);
    }
  }

  // 3. Analyze Arbitros
  const processedArbIds = new Set<string>();
  for (let i = 0; i < arbitros.length; i++) {
    const ar1 = arbitros[i];
    if (processedArbIds.has(ar1.id)) continue;

    const cpf1 = cleanCpf(ar1.cpf);
    const name1 = cleanString(ar1.nome);
    const duplicates: Arbitro[] = [];
    let reason = '';

    for (let j = i + 1; j < arbitros.length; j++) {
      const ar2 = arbitros[j];
      if (processedArbIds.has(ar2.id)) continue;

      const cpf2 = cleanCpf(ar2.cpf);
      const name2 = cleanString(ar2.nome);

      if ((cpf1 && cpf2 && cpf1 === cpf2) || (name1 && name1 === name2)) {
        duplicates.push(ar2);
        processedArbIds.add(ar2.id);
        reason = cpf1 === cpf2 ? `CPF idêntico (${ar1.cpf})` : `Nome idêntico (${ar1.nome})`;
      }
    }

    if (duplicates.length > 0) {
      processedArbIds.add(ar1.id);
      report.duplicateArbitros.push({ primary: ar1, duplicates, reason });
    }
  }

  // 4. Analyze Treinadores
  const processedTrIds = new Set<string>();
  for (let i = 0; i < treinadores.length; i++) {
    const tr1 = treinadores[i];
    if (processedTrIds.has(tr1.id)) continue;

    const cref1 = cleanString(tr1.cref);
    const name1 = cleanString(tr1.nome);
    const duplicates: Treinador[] = [];
    let reason = '';

    for (let j = i + 1; j < treinadores.length; j++) {
      const tr2 = treinadores[j];
      if (processedTrIds.has(tr2.id)) continue;

      const cref2 = cleanString(tr2.cref);
      const name2 = cleanString(tr2.nome);

      if ((cref1 && cref2 && cref1 === cref2) || (name1 && name1 === name2)) {
        duplicates.push(tr2);
        processedTrIds.add(tr2.id);
        reason = cref1 === cref2 ? `CREF idêntico (${tr1.cref})` : `Nome idêntico (${tr1.nome})`;
      }
    }

    if (duplicates.length > 0) {
      processedTrIds.add(tr1.id);
      report.duplicateTreinadores.push({ primary: tr1, duplicates, reason });
    }
  }

  // 5. Analyze Funcionarios
  const processedFuncIds = new Set<string>();
  for (let i = 0; i < funcionarios.length; i++) {
    const f1 = funcionarios[i];
    if (processedFuncIds.has(f1.id)) continue;

    const cpf1 = cleanCpf(f1.cpf);
    const name1 = cleanString(f1.nome);
    const duplicates: Funcionario[] = [];
    let reason = '';

    for (let j = i + 1; j < funcionarios.length; j++) {
      const f2 = funcionarios[j];
      if (processedFuncIds.has(f2.id)) continue;

      const cpf2 = cleanCpf(f2.cpf);
      const name2 = cleanString(f2.nome);

      if ((cpf1 && cpf2 && cpf1 === cpf2) || (name1 && name1 === name2)) {
        duplicates.push(f2);
        processedFuncIds.add(f2.id);
        reason = cpf1 === cpf2 ? `CPF idêntico (${f1.cpf})` : `Nome idêntico (${f1.nome})`;
      }
    }

    if (duplicates.length > 0) {
      processedFuncIds.add(f1.id);
      report.duplicateFuncionarios.push({ primary: f1, duplicates, reason });
    }
  }

  // 6. Analyze Categorias
  const processedCatIds = new Set<string>();
  for (let i = 0; i < categorias.length; i++) {
    const c1 = categorias[i];
    if (processedCatIds.has(c1.id)) continue;

    const name1 = cleanString(c1.nome);
    const duplicates: Categoria[] = [];

    for (let j = i + 1; j < categorias.length; j++) {
      const c2 = categorias[j];
      if (processedCatIds.has(c2.id)) continue;

      if (name1 && name1 === cleanString(c2.nome)) {
        duplicates.push(c2);
        processedCatIds.add(c2.id);
      }
    }

    if (duplicates.length > 0) {
      processedCatIds.add(c1.id);
      report.duplicateCategorias.push({ primary: c1, duplicates, reason: `Nome idêntico (${c1.nome})` });
    }
  }

  // 7. Analyze Torneios
  const processedTorIds = new Set<string>();
  for (let i = 0; i < torneios.length; i++) {
    const t1 = torneios[i];
    if (processedTorIds.has(t1.id)) continue;

    const name1 = cleanString(t1.nome);
    const duplicates: Torneio[] = [];

    for (let j = i + 1; j < torneios.length; j++) {
      const t2 = torneios[j];
      if (processedTorIds.has(t2.id)) continue;

      if (name1 && name1 === cleanString(t2.nome)) {
        duplicates.push(t2);
        processedTorIds.add(t2.id);
      }
    }

    if (duplicates.length > 0) {
      processedTorIds.add(t1.id);
      report.duplicateTorneios.push({ primary: t1, duplicates, reason: `Nome idêntico (${t1.nome})` });
    }
  }

  report.hasDuplicates =
    report.duplicateAtletasGroups.length > 0 ||
    report.duplicateInscricoes.length > 0 ||
    report.duplicateArbitros.length > 0 ||
    report.duplicateTreinadores.length > 0 ||
    report.duplicateFuncionarios.length > 0 ||
    report.duplicateCategorias.length > 0 ||
    report.duplicateTorneios.length > 0;

  return report;
}

/**
 * Removes duplicate entries across all entities, merges record details,
 * and re-wires registration references.
 */
export function removeAndMergeDuplicates(
  atletas: Atleta[],
  inscricoes: Inscricao[],
  arbitros: Arbitro[],
  treinadores: Treinador[],
  funcionarios: Funcionario[],
  categorias: Categoria[],
  torneios: Torneio[]
): {
  cleanAtletas: Atleta[];
  cleanInscricoes: Inscricao[];
  cleanArbitros: Arbitro[];
  cleanTreinadores: Treinador[];
  cleanFuncionarios: Funcionario[];
  cleanCategorias: Categoria[];
  cleanTorneios: Torneio[];
  summary: DeduplicationSummary;
} {
  const summary: DeduplicationSummary = {
    atletasRemoved: 0,
    atletasMerged: [],
    inscricoesRemoved: 0,
    arbitrosRemoved: 0,
    treinadoresRemoved: 0,
    funcionariosRemoved: 0,
    categoriasRemoved: 0,
    torneiosRemoved: 0,
    totalRemoved: 0,
  };

  // Map to redirect merged duplicate athlete IDs to their primary ID
  const athleteIdRedirectMap = new Map<string, string>();

  // --- DEDUPLICATE ATLETAS ---
  const cleanAtletas: Atleta[] = [];
  const processedAtletaIds = new Set<string>();

  for (let i = 0; i < atletas.length; i++) {
    const a1 = atletas[i];
    if (processedAtletaIds.has(a1.id)) continue;

    const cpf1 = cleanCpf(a1.cpf);
    const name1 = cleanString(a1.nome);
    const nasc1 = cleanString(a1.nasc);
    const clube1 = cleanString(a1.clube);

    if (!name1 && !cpf1) continue;

    let primary: Atleta = { ...a1 };
    processedAtletaIds.add(a1.id);

    for (let j = i + 1; j < atletas.length; j++) {
      const a2 = atletas[j];
      if (processedAtletaIds.has(a2.id)) continue;

      const cpf2 = cleanCpf(a2.cpf);
      const name2 = cleanString(a2.nome);
      const nasc2 = cleanString(a2.nasc);
      const clube2 = cleanString(a2.clube);

      let isDup = false;
      if (cpf1 && cpf2 && cpf1 === cpf2) {
        isDup = true;
      } else if (name1 && name1 === name2) {
        if ((nasc1 && nasc2 && nasc1 === nasc2) || (clube1 && clube2 && clube1 === clube2) || !nasc1 || !nasc2) {
          isDup = true;
        }
      }

      if (isDup) {
        // Redirect duplicate ID to primary ID
        athleteIdRedirectMap.set(a2.id, primary.id);
        processedAtletaIds.add(a2.id);

        // Merge fields into primary if primary is missing them
        primary = {
          ...primary,
          cpf: primary.cpf || a2.cpf,
          rg: primary.rg || a2.rg,
          email: primary.email || a2.email,
          wa: primary.wa || a2.wa,
          nasc: primary.nasc || a2.nasc,
          clube: primary.clube && primary.clube !== 'Independente' ? primary.clube : (a2.clube || primary.clube),
          cbtt: primary.cbtt || a2.cbtt,
          rating: Math.max(primary.rating || 0, a2.rating || 0),
          foto: primary.foto || a2.foto,
          obs: primary.obs ? `${primary.obs} | Mesclado: ${a2.id}` : `Mesclado de ${a2.id}`
        };

        summary.atletasRemoved++;
        summary.atletasMerged.push(a2.nome);
      }
    }

    cleanAtletas.push(primary);
  }

  // --- DEDUPLICATE INSCRICOES ---
  const rewiredInscricoes = inscricoes.map(ins => {
    const redirectedId = athleteIdRedirectMap.get(ins.atletaId);
    return redirectedId ? { ...ins, atletaId: redirectedId } : ins;
  });

  const cleanInscricoes: Inscricao[] = [];
  const seenInscKeys = new Set<string>();

  for (const ins of rewiredInscricoes) {
    const key = `${ins.atletaId}_${ins.torneioId}_${cleanString(ins.categoria)}`;
    if (seenInscKeys.has(key)) {
      summary.inscricoesRemoved++;
    } else {
      seenInscKeys.add(key);
      cleanInscricoes.push(ins);
    }
  }

  // --- DEDUPLICATE ARBITROS ---
  const cleanArbitros: Arbitro[] = [];
  const processedArbIds = new Set<string>();

  for (let i = 0; i < arbitros.length; i++) {
    const ar1 = arbitros[i];
    if (processedArbIds.has(ar1.id)) continue;

    const cpf1 = cleanCpf(ar1.cpf);
    const name1 = cleanString(ar1.nome);
    let primary = { ...ar1 };
    processedArbIds.add(ar1.id);

    for (let j = i + 1; j < arbitros.length; j++) {
      const ar2 = arbitros[j];
      if (processedArbIds.has(ar2.id)) continue;

      const cpf2 = cleanCpf(ar2.cpf);
      const name2 = cleanString(ar2.nome);

      if ((cpf1 && cpf2 && cpf1 === cpf2) || (name1 && name1 === name2)) {
        processedArbIds.add(ar2.id);
        primary = {
          ...primary,
          cpf: primary.cpf || ar2.cpf,
          email: primary.email || ar2.email,
          wa: primary.wa || ar2.wa,
          cbtt: primary.cbtt || ar2.cbtt
        };
        summary.arbitrosRemoved++;
      }
    }

    cleanArbitros.push(primary);
  }

  // --- DEDUPLICATE TREINADORES ---
  const cleanTreinadores: Treinador[] = [];
  const processedTrIds = new Set<string>();

  for (let i = 0; i < treinadores.length; i++) {
    const tr1 = treinadores[i];
    if (processedTrIds.has(tr1.id)) continue;

    const cref1 = cleanString(tr1.cref);
    const name1 = cleanString(tr1.nome);
    let primary = { ...tr1 };
    processedTrIds.add(tr1.id);

    for (let j = i + 1; j < treinadores.length; j++) {
      const tr2 = treinadores[j];
      if (processedTrIds.has(tr2.id)) continue;

      const cref2 = cleanString(tr2.cref);
      const name2 = cleanString(tr2.nome);

      if ((cref1 && cref2 && cref1 === cref2) || (name1 && name1 === name2)) {
        processedTrIds.add(tr2.id);
        primary = {
          ...primary,
          cref: primary.cref || tr2.cref,
          email: primary.email || tr2.email,
          wa: primary.wa || tr2.wa
        };
        summary.treinadoresRemoved++;
      }
    }

    cleanTreinadores.push(primary);
  }

  // --- DEDUPLICATE FUNCIONARIOS ---
  const cleanFuncionarios: Funcionario[] = [];
  const processedFuncIds = new Set<string>();

  for (let i = 0; i < funcionarios.length; i++) {
    const f1 = funcionarios[i];
    if (processedFuncIds.has(f1.id)) continue;

    const cpf1 = cleanCpf(f1.cpf);
    const name1 = cleanString(f1.nome);
    let primary = { ...f1 };
    processedFuncIds.add(f1.id);

    for (let j = i + 1; j < funcionarios.length; j++) {
      const f2 = funcionarios[j];
      if (processedFuncIds.has(f2.id)) continue;

      const cpf2 = cleanCpf(f2.cpf);
      const name2 = cleanString(f2.nome);

      if ((cpf1 && cpf2 && cpf1 === cpf2) || (name1 && name1 === name2)) {
        processedFuncIds.add(f2.id);
        primary = {
          ...primary,
          cpf: primary.cpf || f2.cpf,
          email: primary.email || f2.email,
          wa: primary.wa || f2.wa
        };
        summary.funcionariosRemoved++;
      }
    }

    cleanFuncionarios.push(primary);
  }

  // --- DEDUPLICATE CATEGORIAS ---
  const cleanCategorias: Categoria[] = [];
  const seenCatNames = new Set<string>();

  for (const cat of categorias) {
    const name = cleanString(cat.nome);
    if (seenCatNames.has(name)) {
      summary.categoriasRemoved++;
    } else {
      seenCatNames.add(name);
      cleanCategorias.push(cat);
    }
  }

  // --- DEDUPLICATE TORNEIOS ---
  const cleanTorneios: Torneio[] = [];
  const seenTorNames = new Set<string>();

  for (const tor of torneios) {
    const name = cleanString(tor.nome);
    if (seenTorNames.has(name)) {
      summary.torneiosRemoved++;
    } else {
      seenTorNames.add(name);
      cleanTorneios.push(tor);
    }
  }

  summary.totalRemoved =
    summary.atletasRemoved +
    summary.inscricoesRemoved +
    summary.arbitrosRemoved +
    summary.treinadoresRemoved +
    summary.funcionariosRemoved +
    summary.categoriasRemoved +
    summary.torneiosRemoved;

  return {
    cleanAtletas,
    cleanInscricoes,
    cleanArbitros,
    cleanTreinadores,
    cleanFuncionarios,
    cleanCategorias,
    cleanTorneios,
    summary,
  };
}
