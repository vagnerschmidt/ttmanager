import { Atleta } from '../types';
import { jsPDF } from 'jspdf';
import { triggerToast } from './toast';

// Helper to calculate age from birth date
const calculateAge = (born: string) => {
  if (!born) return '—';
  const birthDate = new Date(born);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return `${age} anos`;
};

// Helper to format date cleanly
const formatDate = (dateStr: string) => {
  if (!dateStr) return '—';
  try {
    const [year, month, day] = dateStr.split('-');
    if (year && month && day) {
      return `${day}/${month}/${year}`;
    }
    return dateStr;
  } catch (e) {
    return dateStr;
  }
};

// Utility to truncate string based on pixel calculation approximations to prevent PDF overflow
const fitText = (text: string, maxWidthMm: number, fontSize: number): string => {
  if (!text) return '';
  const cleanStr = String(text).trim().replace(/[\r\n]+/g, ' ');
  // Average width estimate for Helvetica - 1 Helvetica character is roughly 0.14mm wide per point of font size
  const charWidthMm = fontSize * 0.145;
  const maxChars = Math.floor(maxWidthMm / charWidthMm);
  if (cleanStr.length > maxChars) {
    return cleanStr.substring(0, Math.max(3, maxChars - 3)) + '...';
  }
  return cleanStr;
};

interface ExportOptions {
  filterDescription?: string;
}

export function exportAtletasToPDF(atletas: Atleta[], options: ExportOptions = {}) {
  const { filterDescription = 'Todos os Registros' } = options;

  if (!atletas || atletas.length === 0) {
    triggerToast('Não há atletas na lista para exportar!', 'warning');
    return;
  }

  try {
    // A4 dimensions: 210mm x 297mm
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const totalAtletas = atletas.length;
    const ativosCount = atletas.filter(a => a.status === 'Ativo').length;
    const inativosCount = atletas.filter(a => a.status !== 'Ativo').length;

    let pageCount = 1;

    // Helper to draw the header on each page
    const drawPageHeader = (p: number) => {
      // Header brand line
      doc.setDrawColor(30, 41, 59); // slate-800
      doc.setLineWidth(1.2);
      doc.line(15, 12, 195, 12);

      // System Title
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(30, 41, 59); // slate-800
      doc.text('TT MANAGER PRO', 15, 19);

      // Report Tag
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105); // slate-600
      doc.text('Sistema de Gestão de Tênis de Mesa | Relatório Oficial', 15, 23);

      // Date / Page Indicators
      const now = new Date();
      const dateStr = now.toLocaleDateString('pt-BR');
      const timeStr = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
      
      doc.setFontSize(8);
      doc.text(`Gerado em: ${dateStr} às ${timeStr}`, 195, 19, { align: 'right' });
      doc.text(`Filtro: ${fitText(filterDescription, 50, 8)}`, 195, 23, { align: 'right' });

      // Secondary fine line
      doc.setDrawColor(203, 213, 225); // slate-300
      doc.setLineWidth(0.2);
      doc.line(15, 26, 195, 26);
    };

    // Helper to draw Footer on each page
    const drawPageFooter = (p: number) => {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(7.5);
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text('Documento oficial autogerado para consultas e impressão - Confederação Vinculada', 15, 287);
      doc.text(`Página ${p}`, 195, 287, { align: 'right' });
    };

    // Draw First Page Header and Summary Card
    drawPageHeader(pageCount);

    // Summary Card Box (First Page Only)
    doc.setFillColor(248, 250, 252); // slate-50
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setLineWidth(0.2);
    doc.rect(15, 30, 180, 18, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text('QUADRO DE ESTATÍSTICAS IMPRESSAS', 18, 34);

    // Stats Grid
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42); // slate-900
    doc.text(`Total de Atletas: ${totalAtletas}`, 18, 41);
    
    // Colored active/inactive elements
    doc.text(`Atletas Ativos: ${ativosCount}`, 75, 41);
    doc.text(`Atletas Inativos/Outros: ${inativosCount}`, 130, 41);

    // Table settings
    const tableHeaderY = 56;
    let currentY = tableHeaderY + 7.5; // Row start Y offset

    // Draw Column Headers
    const drawTableColumns = (yPos: number) => {
      // Light background header bar
      doc.setFillColor(241, 245, 249); // slate-100
      doc.rect(15, yPos - 5, 180, 7.5, 'F');
      
      // Fine border for header row
      doc.setDrawColor(203, 213, 225); // slate-300
      doc.setLineWidth(0.4);
      doc.line(15, yPos - 5, 195, yPos - 5);
      doc.line(15, yPos + 2.5, 195, yPos + 2.5);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(15, 23, 42); // slate-900
      
      doc.text('#', 17, yPos);
      doc.text('Nome do Atleta', 24, yPos);
      doc.text('Idade', 84, yPos);
      doc.text('Clube', 100, yPos);
      doc.text('Rating', 133, yPos);
      doc.text('Categorias de Atividade', 147, yPos);
      doc.text('Status', 185, yPos);
    };

    // Draw first table header
    drawTableColumns(tableHeaderY);

    // Print rows
    atletas.forEach((a, index) => {
      // Check for page overflow. Printable border is ~275mm before footer.
      if (currentY > 270) {
        drawPageFooter(pageCount);
        
        doc.addPage();
        pageCount++;
        
        drawPageHeader(pageCount);
        
        // Repeating table columns header on next page starting slightly lower
        const nextTableHeaderY = 35;
        drawTableColumns(nextTableHeaderY);
        currentY = nextTableHeaderY + 7.5;
      }

      // Draw standard row background on alternating entries to increase scan speed
      if (index % 2 === 1) {
        doc.setFillColor(250, 250, 250); // slight gray shift
        doc.rect(15, currentY - 4.5, 180, 6.5, 'F');
      }

      // Thin horizontal dividing line
      doc.setDrawColor(241, 245, 249); // very light slate-100 line
      doc.setLineWidth(0.1);
      doc.line(15, currentY + 2, 195, currentY + 2);

      // Font parameters for body rows
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(30, 41, 59); // slate-800

      // # column
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text(String(index + 1), 17, currentY);

      // Name column
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text(fitText(a.nome, 58, 8), 24, currentY);

      // Age / Birth Date column
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(51, 65, 85);
      const ageStr = calculateAge(a.nasc);
      doc.text(ageStr, 84, currentY);

      // Clube column
      const clubStr = a.clube || '—';
      doc.text(fitText(clubStr, 31, 8), 100, currentY);

      // Rating column
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(161, 98, 7); // deep yellow-800 rating highlight
      doc.text(String(a.rating), 133, currentY);

      // Categories column
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(51, 65, 85);
      const categoriesStr = a.cat || '—';
      doc.text(fitText(categoriesStr, 36, 8), 147, currentY);

      // Status column
      doc.setFont('helvetica', 'bold');
      if (a.status === 'Ativo') {
        doc.setTextColor(5, 150, 105); // emerald-600
        doc.text('ATIVO', 185, currentY);
      } else if (a.status === 'Inativo') {
        doc.setTextColor(217, 119, 6); // amber-600
        doc.text('INAT', 185, currentY);
      } else {
        doc.setTextColor(220, 38, 38); // red-600
        doc.text('SUSP', 185, currentY);
      }

      currentY += 6.5; // increment line spacing
    });

    // Draw final page footer
    drawPageFooter(pageCount);

    // Save and download pdf file
    const safeFilterDesc = filterDescription.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    const filename = `atletas_categorias_${safeFilterDesc || 'geral'}.pdf`;
    doc.save(filename);
    
    triggerToast('Arquivo PDF exportado com sucesso!', 'success');
  } catch (err) {
    console.error('Fatal Error during PDF export creation:', err);
    triggerToast('Não foi possível gerar o arquivo PDF.', 'error');
  }
}
