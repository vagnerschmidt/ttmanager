/**
 * Google Sheets API Integration Utility for TT Manager Pro
 * Scopes: https://www.googleapis.com/auth/spreadsheets, https://www.googleapis.com/auth/drive.file
 */

import { CurrentSystemState } from './spreadsheetSync';
import { Atleta, Inscricao, Torneio, Categoria } from '../types';

export interface GoogleSheetsSettings {
  linkedSpreadsheetId: string | null;
  linkedSpreadsheetUrl: string | null;
  linkedSpreadsheetName: string | null;
  lastSyncTime: number | null;
  lastSyncStatus: string | null;
  accessToken: string | null;
  tokenExpiresAt: number | null;
  autoSyncEnabled: boolean;
  totalRecordCount: number | null;
}

const STORAGE_KEYS = {
  SHEET_ID: 'ttmpro_gsheets_sheet_id',
  SHEET_URL: 'ttmpro_gsheets_sheet_url',
  SHEET_NAME: 'ttmpro_gsheets_sheet_name',
  LAST_SYNC: 'ttmpro_gsheets_last_sync_time',
  LAST_STATUS: 'ttmpro_gsheets_last_sync_status',
  TOKEN: 'ttmpro_gsheets_access_token',
  EXPIRES: 'ttmpro_gsheets_token_expires_at',
  AUTO_SYNC: 'ttmpro_gsheets_auto_sync',
  RECORD_COUNT: 'ttmpro_gsheets_record_count',
};

export function getGoogleSheetsSettings(): GoogleSheetsSettings {
  return {
    linkedSpreadsheetId: localStorage.getItem(STORAGE_KEYS.SHEET_ID) || null,
    linkedSpreadsheetUrl: localStorage.getItem(STORAGE_KEYS.SHEET_URL) || null,
    linkedSpreadsheetName: localStorage.getItem(STORAGE_KEYS.SHEET_NAME) || null,
    lastSyncTime: localStorage.getItem(STORAGE_KEYS.LAST_SYNC)
      ? Number(localStorage.getItem(STORAGE_KEYS.LAST_SYNC))
      : null,
    lastSyncStatus: localStorage.getItem(STORAGE_KEYS.LAST_STATUS) || null,
    accessToken: localStorage.getItem(STORAGE_KEYS.TOKEN) || null,
    tokenExpiresAt: localStorage.getItem(STORAGE_KEYS.EXPIRES)
      ? Number(localStorage.getItem(STORAGE_KEYS.EXPIRES))
      : null,
    autoSyncEnabled: localStorage.getItem(STORAGE_KEYS.AUTO_SYNC) === 'true',
    totalRecordCount: localStorage.getItem(STORAGE_KEYS.RECORD_COUNT)
      ? Number(localStorage.getItem(STORAGE_KEYS.RECORD_COUNT))
      : null,
  };
}

export function saveGoogleSheetsSettings(settings: Partial<GoogleSheetsSettings>) {
  if (settings.linkedSpreadsheetId !== undefined) {
    if (settings.linkedSpreadsheetId) {
      localStorage.setItem(STORAGE_KEYS.SHEET_ID, settings.linkedSpreadsheetId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_ID);
    }
  }
  if (settings.linkedSpreadsheetUrl !== undefined) {
    if (settings.linkedSpreadsheetUrl) {
      localStorage.setItem(STORAGE_KEYS.SHEET_URL, settings.linkedSpreadsheetUrl);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_URL);
    }
  }
  if (settings.linkedSpreadsheetName !== undefined) {
    if (settings.linkedSpreadsheetName) {
      localStorage.setItem(STORAGE_KEYS.SHEET_NAME, settings.linkedSpreadsheetName);
    } else {
      localStorage.removeItem(STORAGE_KEYS.SHEET_NAME);
    }
  }
  if (settings.lastSyncTime !== undefined) {
    if (settings.lastSyncTime) {
      localStorage.setItem(STORAGE_KEYS.LAST_SYNC, String(settings.lastSyncTime));
    } else {
      localStorage.removeItem(STORAGE_KEYS.LAST_SYNC);
    }
  }
  if (settings.lastSyncStatus !== undefined) {
    if (settings.lastSyncStatus) {
      localStorage.setItem(STORAGE_KEYS.LAST_STATUS, settings.lastSyncStatus);
    } else {
      localStorage.removeItem(STORAGE_KEYS.LAST_STATUS);
    }
  }
  if (settings.accessToken !== undefined) {
    if (settings.accessToken) {
      localStorage.setItem(STORAGE_KEYS.TOKEN, settings.accessToken);
    } else {
      localStorage.removeItem(STORAGE_KEYS.TOKEN);
    }
  }
  if (settings.tokenExpiresAt !== undefined) {
    if (settings.tokenExpiresAt) {
      localStorage.setItem(STORAGE_KEYS.EXPIRES, String(settings.tokenExpiresAt));
    } else {
      localStorage.removeItem(STORAGE_KEYS.EXPIRES);
    }
  }
  if (settings.autoSyncEnabled !== undefined) {
    localStorage.setItem(STORAGE_KEYS.AUTO_SYNC, String(settings.autoSyncEnabled));
  }
  if (settings.totalRecordCount !== undefined) {
    if (settings.totalRecordCount !== null) {
      localStorage.setItem(STORAGE_KEYS.RECORD_COUNT, String(settings.totalRecordCount));
    } else {
      localStorage.removeItem(STORAGE_KEYS.RECORD_COUNT);
    }
  }
}

/**
 * Extract Spreadsheet ID from Google Sheets URL or raw ID string
 */
export function extractSpreadsheetId(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (!trimmed.includes('/')) return trimmed; // Raw ID
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  return match ? match[1] : null;
}

/**
 * Request Access Token for Google Sheets via Google Identity Services
 */
export function requestGoogleSheetsAccessToken(): Promise<string> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !(window as any).google?.accounts?.oauth2) {
      return reject(
        new Error('SDK do Google Identity Services não carregado. Verifique sua conexão.')
      );
    }

    try {
      const tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: '998222099112-gpl96g2basetut5o3167blnd1qmb0grv.apps.googleusercontent.com',
        scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file',
        callback: (tokenResponse: any) => {
          if (tokenResponse.error) {
            if (tokenResponse.error === 'popup_closed' || tokenResponse.error === 'user_denied') {
              return reject(
                new Error('A janela de autorização do Google Sheets foi fechada.')
              );
            }
            return reject(new Error(`Erro OAuth: ${tokenResponse.error}`));
          }
          if (tokenResponse.access_token) {
            const token = tokenResponse.access_token;
            const expiresAt = Date.now() + (tokenResponse.expires_in || 3600) * 1000;
            saveGoogleSheetsSettings({
              accessToken: token,
              tokenExpiresAt: expiresAt,
            });
            resolve(token);
          } else {
            reject(new Error('Nenhum token de acesso retornado do Google.'));
          }
        },
        error_callback: (err: any) => {
          reject(new Error(`Falha no login Google: ${err?.message || 'Ação cancelada'}`));
        },
      });

      tokenClient.requestAccessToken({ prompt: 'consent' });
    } catch (e: any) {
      reject(new Error(`Erro ao inicializar OAuth do Google Sheets: ${e.message}`));
    }
  });
}

/**
 * Creates a complete Google Spreadsheet for TT Manager Pro
 */
export async function createGoogleSpreadsheet(
  state: CurrentSystemState,
  accessToken: string,
  customTitle?: string
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const title = customTitle || `TT Manager Pro - Planilha Oficial (${new Date().toLocaleDateString('pt-BR')})`;

  const sheetsPayload = {
    properties: { title },
    sheets: [
      { properties: { title: 'Atletas' } },
      { properties: { title: 'Árbitros' } },
      { properties: { title: 'Treinadores' } },
      { properties: { title: 'Funcionários' } },
      { properties: { title: 'Torneios' } },
      { properties: { title: 'Categorias' } },
      { properties: { title: 'Inscrições' } },
    ],
  };

  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(sheetsPayload),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao criar planilha no Google Sheets (${response.status}): ${errText}`);
  }

  const createdData = await response.json();
  const spreadsheetId = createdData.spreadsheetId;
  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // Populate cell values
  await syncDataToGoogleSheet(spreadsheetId, state, accessToken);

  const totalRecordCount = 
    state.atletas.length +
    state.arbitros.length +
    state.treinadores.length +
    state.funcionarios.length +
    state.torneios.length +
    state.categorias.length;

  saveGoogleSheetsSettings({
    linkedSpreadsheetId: spreadsheetId,
    linkedSpreadsheetUrl: spreadsheetUrl,
    linkedSpreadsheetName: title,
    lastSyncTime: Date.now(),
    lastSyncStatus: 'Sucesso',
    totalRecordCount,
  });

  return { spreadsheetId, spreadsheetUrl };
}

/**
 * Ensures required tabs exist in the Google Spreadsheet before sending values:batchUpdate.
 * Creates missing tabs via batchUpdate if necessary.
 */
export async function ensureSheetTabsExist(
  spreadsheetId: string,
  requiredTabs: string[],
  accessToken: string
): Promise<void> {
  try {
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (!metaRes.ok) return;

    const meta = await metaRes.json();
    const existingTitles = new Set<string>(
      (meta.sheets || []).map((s: any) => s.properties?.title || '')
    );

    const missingTabs = requiredTabs.filter(t => !existingTitles.has(t));
    if (missingTabs.length === 0) return;

    const requests = missingTabs.map(title => ({
      addSheet: {
        properties: { title }
      }
    }));

    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ requests }),
    });
  } catch (err) {
    console.warn('Non-blocking: could not auto-create missing sheet tabs:', err);
  }
}

/**
 * Syncs/Overwrites values in an existing Google Sheet
 */
export async function syncDataToGoogleSheet(
  spreadsheetId: string,
  state: CurrentSystemState,
  accessToken: string
): Promise<void> {
  const requiredTabs = ['Atletas', 'Árbitros', 'Treinadores', 'Funcionários', 'Torneios', 'Categorias', 'Inscrições'];
  await ensureSheetTabsExist(spreadsheetId, requiredTabs, accessToken);

  const dataToSheets = [
    {
      range: "'Atletas'!A1",
      values: [
        ['ID', 'Nome', 'Nascimento', 'CPF', 'RG', 'Gênero', 'Naturalidade', 'Clube', 'Rating', 'ID CBTT', 'Nível', 'Mão', 'Empunhadura', 'Status', 'Email', 'WhatsApp', 'Responsável', 'Presença'],
        ...state.atletas.map(a => [
          a.id, a.nome, a.nasc || '', a.cpf || '', a.rg || '', a.genero, a.natural || '',
          a.clube || '', a.rating, a.cbtt || '', a.nivel || 'Iniciante', a.mao || 'Direita',
          a.emp || 'Classineta', a.status, a.email || '', a.wa || '', a.resp || '', a.presenca || 'CONFIRMADA'
        ])
      ]
    },
    {
      range: "'Árbitros'!A1",
      values: [
        ['ID', 'Nome', 'Nível', 'CBTT', 'CPF', 'Email', 'WhatsApp', 'Status', 'Valor Hora'],
        ...state.arbitros.map(a => [
          a.id, a.nome, a.nivel, a.cbtt || '', a.cpf || '', a.email || '', a.wa || '', a.status, a.val || ''
        ])
      ]
    },
    {
      range: "'Treinadores'!A1",
      values: [
        ['ID', 'Nome', 'Clube', 'CREF', 'Email', 'WhatsApp', 'Status'],
        ...state.treinadores.map(t => [
          t.id, t.nome, t.clube || '', t.cref || '', t.email || '', t.wa || '', t.status
        ])
      ]
    },
    {
      range: "'Funcionários'!A1",
      values: [
        ['ID', 'Nome', 'Cargo', 'CPF', 'RG', 'Telefone', 'Email', 'Status', 'Salário'],
        ...state.funcionarios.map(f => [
          f.id, f.nome, f.cargo, f.cpf || '', f.rg || '', f.tel || '', f.email || '', f.status, f.salario || ''
        ])
      ]
    },
    {
      range: "'Torneios'!A1",
      values: [
        ['ID', 'Nome', 'Início', 'Fim', 'Hora', 'Local', 'Cidade', 'Status', 'Formato', 'Limite Inscritos'],
        ...state.torneios.map(t => [
          t.id, t.nome, t.ini, t.fim, t.hora, t.local || '', t.cidade || '', t.status, t.fmt, t.lim || ''
        ])
      ]
    },
    {
      range: "'Categorias'!A1",
      values: [
        ['ID', 'Nome', 'Idade Mín', 'Idade Máx', 'Gênero', 'Tipo', 'Formato', 'Limite Máx', 'Descrição'],
        ...state.categorias.map(c => [
          c.id, c.nome, c.idmin || '', c.idmax || '', c.genero || 'Misto', c.tipo || '', c.fmt || '', c.max || '', c.desc || ''
        ])
      ]
    },
    {
      range: "'Inscrições'!A1",
      values: [
        ['ID', 'ID Atleta', 'Nome Atleta', 'ID Torneio', 'Categoria', 'Taxa', 'Status Pagamento', 'Confirmada'],
        ...(state.inscricoes || []).map(i => {
          const atl = state.atletas.find(a => a.id === i.atletaId);
          return [
            i.id,
            i.atletaId,
            atl?.nome || '',
            i.torneioId,
            i.categoria,
            i.valorTaxa || '0',
            i.statusPagamento || 'Pago',
            i.confirmada ? 'SIM' : 'NÃO'
          ];
        })
      ]
    }
  ];

  const body = {
    valueInputOption: 'USER_ENTERED',
    data: dataToSheets
  };

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchUpdate`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Falha ao atualizar dados no Google Sheets (${response.status}): ${errText}`);
  }

  const totalRecordCount = 
    state.atletas.length +
    state.arbitros.length +
    state.treinadores.length +
    state.funcionarios.length +
    state.torneios.length +
    state.categorias.length +
    (state.inscricoes ? state.inscricoes.length : 0);

  saveGoogleSheetsSettings({
    lastSyncTime: Date.now(),
    lastSyncStatus: 'Sucesso',
    totalRecordCount,
  });
}

/**
 * Fetches sheet data from Google Sheets API and returns a structured object for system sync
 */
export async function fetchGoogleSheetData(
  spreadsheetId: string,
  accessToken: string
): Promise<Record<string, any[]>> {
  let existingTitles: string[] = [];
  try {
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (metaRes.ok) {
      const meta = await metaRes.json();
      existingTitles = (meta.sheets || []).map((s: any) => s.properties?.title).filter(Boolean);
    }
  } catch (e) {
    console.warn('Não foi possível ler metadados das abas da planilha:', e);
  }

  const rangesToQuery = existingTitles.length > 0
    ? existingTitles.map(t => `'${t}'!A1:Z500`)
    : [
        "'Atletas'!A1:Z500",
        "'Árbitros'!A1:Z500",
        "'Treinadores'!A1:Z500",
        "'Funcionários'!A1:Z500",
        "'Torneios'!A1:Z500",
        "'Categorias'!A1:Z500",
        "'Inscrições'!A1:Z500",
        "'Inscritos'!A1:Z500",
        "'Participantes'!A1:Z500"
      ];

  const rangesQuery = rangesToQuery.map(r => `ranges=${encodeURIComponent(r)}`).join('&');

  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values:batchGet?${rangesQuery}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erro ao ler dados da planilha do Google Sheets (${response.status}): ${errText}`);
  }

  const data = await response.json();
  const valueRanges = data.valueRanges || [];

  const parsedData: Record<string, any[]> = {
    atletas: [],
    arbitros: [],
    treinadores: [],
    funcionarios: [],
    torneios: [],
    categorias: [],
    inscricoes: [],
  };

  const mapRowsToObject = (rows: any[][]) => {
    if (!rows || rows.length <= 1) return [];
    const headers = rows[0].map(h => String(h).trim().toLowerCase());
    
    return rows.slice(1).map(row => {
      const item: any = {};
      headers.forEach((header, idx) => {
        item[header] = row[idx] !== undefined ? row[idx] : '';
      });
      return item;
    });
  };

  valueRanges.forEach((vr: any) => {
    const rangeName = vr.range || '';
    const rows = vr.values || [];

    if (rangeName.includes('Atletas')) {
      parsedData.atletas = mapRowsToObject(rows);
    } else if (rangeName.includes('Árbitros') || rangeName.includes('Arbitros')) {
      parsedData.arbitros = mapRowsToObject(rows);
    } else if (rangeName.includes('Treinadores')) {
      parsedData.treinadores = mapRowsToObject(rows);
    } else if (rangeName.includes('Funcionários') || rangeName.includes('Funcionarios')) {
      parsedData.funcionarios = mapRowsToObject(rows);
    } else if (rangeName.includes('Torneios')) {
      parsedData.torneios = mapRowsToObject(rows);
    } else if (rangeName.includes('Categorias')) {
      parsedData.categorias = mapRowsToObject(rows);
    } else if (
      rangeName.includes('Inscrições') ||
      rangeName.includes('Inscricoes') ||
      rangeName.includes('Inscritos') ||
      rangeName.includes('Participantes')
    ) {
      if (!parsedData.inscricoes) parsedData.inscricoes = [];
      parsedData.inscricoes.push(...mapRowsToObject(rows));
    }
  });

  return parsedData;
}

/**
 * Automatically registers participating athletes from Google Sheets data into tournament registrations (Inscricoes)
 */
export function syncInscricoesFromGoogleSheetsData(
  parsedData: Record<string, any[]>,
  currentAtletas: Atleta[],
  currentInscricoes: Inscricao[],
  currentTorneios: Torneio[],
  currentCategorias: Categoria[],
  activeTorneioId?: string
): {
  updatedAtletas: Atleta[];
  updatedInscricoes: Inscricao[];
  summary: {
    atletasImportados: number;
    inscricoesImportadas: number;
    categoriasProcessadas: string[];
  };
} {
  let updatedAtletas = [...currentAtletas];
  let updatedInscricoes = [...currentInscricoes];

  let newAtletasCount = 0;
  let newInscricoesCount = 0;
  const processedCatNames = new Set<string>();

  const targetTorneioId = activeTorneioId || (currentTorneios.length > 0 ? currentTorneios[0].id : 'torneio_1');

  const rawInscRows = parsedData.inscricoes || [];

  const processEntry = (row: Record<string, any>) => {
    const rowAthleteId = String(row.id_atleta || row['id atleta'] || row.atleta_id || row.atletaId || row.id || '').trim();
    const rowAthleteName = String(row.nome_atleta || row['nome atleta'] || row.atleta || row.nome || '').trim();
    const rowCpf = String(row.cpf || '').replace(/\D/g, '');
    
    const rowCat = String(row.categoria || row.cat || '').trim();
    const rowTorneio = String(row.id_torneio || row['id torneio'] || row.torneio || row.torneioId || '').trim();

    if (!rowAthleteName && !rowAthleteId && !rowCpf) return;

    // Match or create athlete
    let athlete = updatedAtletas.find(a => 
      (rowAthleteId && a.id === rowAthleteId) ||
      (rowCpf && a.cpf.replace(/\D/g, '') === rowCpf) ||
      (rowAthleteName && a.nome.toLowerCase() === rowAthleteName.toLowerCase())
    );

    if (!athlete) {
      const newId = rowAthleteId || `atl_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      athlete = {
        id: newId,
        nome: rowAthleteName || `Atleta ${newId}`,
        nasc: String(
          row.data_de_nascimento || 
          row['data de nascimento'] || 
          row.data_nascimento || 
          row['data nascimento'] || 
          row.dt_nascimento || 
          row['dt nascimento'] || 
          row.nascimento || 
          row.nasc || 
          row.data || 
          '2000-01-01'
        ).trim(),
        cpf: rowCpf || '',
        rg: '',
        genero: row.genero || row.gênero || 'Masculino',
        natural: '',
        end: '',
        cat: rowCat || 'Livre',
        clube: row.clube || 'Independente',
        rating: Number(row.rating) || 1000,
        cbtt: row.cbtt || '',
        nivel: row.nivel || 'Intermediário',
        mao: 'Direita',
        emp: 'Classineta',
        status: 'Ativo',
        obs: 'Importado via Google Sheets',
        email: row.email || '',
        wa: row.whatsapp || row.wa || '',
        tel: '',
        emerg: '',
        resp: '',
        respCpf: '',
        foto: ''
      };
      updatedAtletas.push(athlete);
      newAtletasCount++;
    }

    let torneioId = targetTorneioId;
    if (rowTorneio) {
      const matchedTor = currentTorneios.find(t => t.id === rowTorneio || t.nome.toLowerCase() === rowTorneio.toLowerCase());
      if (matchedTor) torneioId = matchedTor.id;
    }

    const catList = rowCat ? rowCat.split(/[,;/]+/).map(s => s.trim()).filter(Boolean) : ['Livre'];

    catList.forEach(cName => {
      const catObj = currentCategorias.find(c => c.id === cName || c.nome.toLowerCase() === cName.toLowerCase());
      const finalCatName = catObj ? catObj.nome : cName;

      processedCatNames.add(finalCatName);

      const exists = updatedInscricoes.some(i => 
        i.atletaId === athlete!.id && 
        i.torneioId === torneioId && 
        i.categoria.toLowerCase() === finalCatName.toLowerCase()
      );

      if (!exists) {
        const newInsc: Inscricao = {
          id: `ins_${athlete!.id}_${torneioId}_${finalCatName.replace(/\s+/g, '_')}`,
          atletaId: athlete!.id,
          torneioId: torneioId,
          categoria: finalCatName,
          valorTaxa: row.taxa || row.valor || '50,00',
          statusPagamento: String(row.status || row.pagamento || '').toLowerCase().includes('pago') ? 'Pago' : (String(row.status).toLowerCase().includes('isento') ? 'Isento' : 'Pendente'),
          confirmada: true
        };
        updatedInscricoes.push(newInsc);
        newInscricoesCount++;
      }
    });
  };

  rawInscRows.forEach(processEntry);

  if (parsedData.atletas && parsedData.atletas.length > 0) {
    parsedData.atletas.forEach(row => {
      if (row.categoria || row.cat || row.torneio) {
        processEntry(row);
      }
    });
  }

  return {
    updatedAtletas,
    updatedInscricoes,
    summary: {
      atletasImportados: newAtletasCount,
      inscricoesImportadas: newInscricoesCount,
      categoriasProcessadas: Array.from(processedCatNames)
    }
  };
}
