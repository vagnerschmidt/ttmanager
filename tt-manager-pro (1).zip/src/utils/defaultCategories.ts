import { Categoria } from '../types';

export function getDefaultOfficialCategories(): Categoria[] {
  return [
    // Sub-9
    { id: 'cat_sub9_m', nome: 'Sub-9 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '0', idmax: '9', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas masculinos com até 9 anos completos.' },
    { id: 'cat_sub9_f', nome: 'Sub-9 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '0', idmax: '9', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas femininas com até 9 anos completos.' },
    { id: 'cat_sub9_g', nome: 'Sub-9 Geral', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '9', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas em geral com até 9 anos completos.' },

    // Sub-11
    { id: 'cat_sub11_m', nome: 'Sub-11 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '10', idmax: '11', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas masculinos entre 10 e 11 anos.' },
    { id: 'cat_sub11_f', nome: 'Sub-11 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '10', idmax: '11', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas femininas entre 10 e 11 anos.' },
    { id: 'cat_sub11_g', nome: 'Sub-11 Geral', tipo: 'Simples', genero: 'Livre', idmin: '10', idmax: '11', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas em geral entre 10 e 11 anos.' },

    // Sub-13
    { id: 'cat_sub13_m', nome: 'Sub-13 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '12', idmax: '13', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas masculinos entre 12 e 13 anos.' },
    { id: 'cat_sub13_f', nome: 'Sub-13 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '12', idmax: '13', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas femininas entre 12 e 13 anos.' },
    { id: 'cat_sub13_g', nome: 'Sub-13 Geral', tipo: 'Simples', genero: 'Livre', idmin: '12', idmax: '13', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas em geral entre 12 e 13 anos.' },

    // Sub-15
    { id: 'cat_sub15_m', nome: 'Sub-15 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '14', idmax: '15', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas masculinos entre 14 e 15 anos.' },
    { id: 'cat_sub15_f', nome: 'Sub-15 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '14', idmax: '15', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas femininas entre 14 e 15 anos.' },
    { id: 'cat_sub15_g', nome: 'Sub-15 Geral', tipo: 'Simples', genero: 'Livre', idmin: '14', idmax: '15', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas em geral entre 14 e 15 anos.' },

    // Sub-17
    { id: 'cat_sub17_m', nome: 'Sub-17 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '16', idmax: '17', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas masculinos entre 16 e 17 anos.' },
    { id: 'cat_sub17_f', nome: 'Sub-17 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '16', idmax: '17', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas femininas entre 16 e 17 anos.' },
    { id: 'cat_sub17_g', nome: 'Sub-17 Geral', tipo: 'Simples', genero: 'Livre', idmin: '16', idmax: '17', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas em geral entre 16 e 17 anos.' },

    // Sub-19
    { id: 'cat_sub19_m', nome: 'Sub-19 Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '18', idmax: '19', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas masculinos entre 18 e 19 anos.' },
    { id: 'cat_sub19_f', nome: 'Sub-19 Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '18', idmax: '19', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas femininas entre 18 e 19 anos.' },
    { id: 'cat_sub19_g', nome: 'Sub-19 Geral', tipo: 'Simples', genero: 'Livre', idmin: '18', idmax: '19', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas em geral entre 18 e 19 anos.' },

    // Sub-21 & Adulto
    { id: 'cat_sub21_g', nome: 'Sub-21 Geral', tipo: 'Simples', genero: 'Livre', idmin: '20', idmax: '21', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas de 20 a 21 anos.' },
    { id: 'cat_adulto_m', nome: 'Adulto Masculino', tipo: 'Simples', genero: 'Masculino', idmin: '18', idmax: '39', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas adultos masculinos de 18 a 39 anos.' },
    { id: 'cat_adulto_f', nome: 'Adulto Feminino', tipo: 'Simples', genero: 'Feminino', idmin: '18', idmax: '39', rmin: '0', rmax: '9999', fmt: 'Round Robin', max: '', desc: 'Atletas adultas femininas de 18 a 39 anos.' },
    { id: 'cat_adulto_g', nome: 'Adulto Geral', tipo: 'Simples', genero: 'Livre', idmin: '18', idmax: '39', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas adultos de 18 a 39 anos.' },

    // Veteranos
    { id: 'cat_vet40', nome: 'Veterano +40', tipo: 'Simples', genero: 'Livre', idmin: '40', idmax: '49', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas veteranos entre 40 e 49 anos.' },
    { id: 'cat_vet50', nome: 'Veterano +50', tipo: 'Simples', genero: 'Livre', idmin: '50', idmax: '59', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas veteranos entre 50 e 59 anos.' },
    { id: 'cat_vet60', nome: 'Veterano +60', tipo: 'Simples', genero: 'Livre', idmin: '60', idmax: '69', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas veteranos entre 60 e 69 anos.' },
    { id: 'cat_vet70', nome: 'Veterano +70', tipo: 'Simples', genero: 'Livre', idmin: '70', idmax: '99', rmin: '0', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas veteranos com 70 anos ou mais.' },

    // Rating / Nível
    { id: 'cat_rat_a', nome: 'Rating A', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '1800', rmax: '9999', fmt: 'Eliminatória Simples', max: '', desc: 'Atletas com rating igual ou superior a 1800 pts.' },
    { id: 'cat_rat_b', nome: 'Rating B', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '1500', rmax: '1799', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas com rating entre 1500 e 1799 pts.' },
    { id: 'cat_rat_c', nome: 'Rating C', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '1200', rmax: '1499', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas com rating entre 1200 e 1499 pts.' },
    { id: 'cat_rat_d', nome: 'Rating D', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '900', rmax: '1199', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas com rating entre 900 e 1199 pts.' },
    { id: 'cat_rat_e', nome: 'Rating E', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '0', rmax: '899', fmt: 'Grupos + Eliminatória', max: '', desc: 'Atletas iniciantes com rating até 899 pts.' },
    { id: 'cat_open', nome: 'Open Geral', tipo: 'Simples', genero: 'Livre', idmin: '0', idmax: '99', rmin: '0', rmax: '9999', fmt: 'Grupos + Eliminatória', max: '', desc: 'Categoria aberta para qualquer idade ou rating.' },
  ];
}
