import React, { useState, useMemo, useEffect } from 'react';
import { Atleta, Torneio, Resultado, Arbitro, Funcionario, SystemConfig, Categoria, Inscricao } from '../types';
import { 
  Users, Trophy, Activity, UserCheck, Briefcase, Medal, RefreshCw, Star, 
  PlaySquare, UserPlus, GitBranch, FileText, Zap, ArrowRight, PlusCircle, 
  Filter, Tag, ChevronDown, X, Layers, Globe, FileSpreadsheet, ExternalLink,
  Clock, CheckCircle2, AlertTriangle, Database, Timer, Shield, ChevronRight 
} from 'lucide-react';
import { getGoogleSheetsSettings } from '../utils/googleSheets';

interface DashboardViewProps {
  atletas: Atleta[];
  torneios: Torneio[];
  resultados: Resultado[];
  arbitros: Arbitro[];
  funcionarios: Funcionario[];
  categorias?: Categoria[];
  inscricoes?: Inscricao[];
  onNavigate: (section: string) => void;
  config?: SystemConfig;
}

export default function DashboardView({
  atletas,
  torneios,
  resultados,
  arbitros,
  funcionarios,
  categorias = [],
  inscricoes = [],
  onNavigate,
  config
}: DashboardViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('todas');
  const [mesaFilter, setMesaFilter] = useState<'todas' | 'livres' | 'ocupadas'>('todas');
  const [gsSettings, setGsSettings] = useState(() => getGoogleSheetsSettings());

  const [nowTimestamp, setNowTimestamp] = useState<number>(Date.now());

  useEffect(() => {
    setGsSettings(getGoogleSheetsSettings());

    // Live 1-second ticker for match elapsed time
    const timer = setInterval(() => {
      setNowTimestamp(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Compute list of available unique category names
  const availableCategories = useMemo(() => {
    const catSet = new Set<string>();
    if (categorias && categorias.length > 0) {
      categorias.forEach(c => {
        if (c.nome && c.nome.trim()) catSet.add(c.nome.trim());
      });
    }
    atletas.forEach(a => {
      if (a.cat) {
        a.cat.split(',').forEach(c => {
          const trimmed = c.trim();
          if (trimmed) catSet.add(trimmed);
        });
      }
    });
    if (inscricoes) {
      inscricoes.forEach(i => {
        if (i.categoria && i.categoria.trim()) catSet.add(i.categoria.trim());
      });
    }
    return Array.from(catSet).sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }, [categorias, atletas, inscricoes]);

  // Filter Atletas according to selected category
  const filteredAtletas = useMemo(() => {
    if (selectedCategory === 'todas') return atletas;
    const catLower = selectedCategory.toLowerCase();
    const athleteIdsInCat = new Set(
      (inscricoes || [])
        .filter(i => i.categoria && i.categoria.trim().toLowerCase() === catLower)
        .map(i => i.atletaId)
    );
    return atletas.filter(a => {
      const matchCatString = a.cat && a.cat.toLowerCase().includes(catLower);
      const matchInscricao = athleteIdsInCat.has(a.id);
      return matchCatString || matchInscricao;
    });
  }, [atletas, selectedCategory, inscricoes]);

  // Filter Resultados according to selected category
  const filteredResultados = useMemo(() => {
    if (selectedCategory === 'todas') return resultados;
    const catObj = (categorias || []).find(c => c.nome.toLowerCase() === selectedCategory.toLowerCase() || c.id === selectedCategory);
    const catId = catObj ? catObj.id : selectedCategory;
    const catLower = selectedCategory.toLowerCase();

    return resultados.filter(r => {
      if (r.catId && (r.catId === catId || r.catId.toLowerCase() === catLower)) return true;
      const athleteNames = new Set(filteredAtletas.map(a => a.nome.toLowerCase()));
      return athleteNames.has((r.nomeA || '').toLowerCase()) || athleteNames.has((r.nomeB || '').toLowerCase());
    });
  }, [resultados, selectedCategory, categorias, filteredAtletas]);

  // Filter Torneios according to selected category
  const filteredTorneios = useMemo(() => {
    if (selectedCategory === 'todas') return torneios;
    const catLower = selectedCategory.toLowerCase();
    const tournamentIds = new Set<string>();

    (inscricoes || []).forEach(i => {
      if (i.categoria && i.categoria.trim().toLowerCase() === catLower && i.torneioId) {
        tournamentIds.add(i.torneioId);
      }
    });

    const catObj = (categorias || []).find(c => c.nome.toLowerCase() === catLower || c.id === selectedCategory);
    const catId = catObj ? catObj.id : selectedCategory;

    resultados.forEach(r => {
      if ((r.catId === catId || r.catId.toLowerCase() === catLower) && r.torId) {
        tournamentIds.add(r.torId);
      }
    });

    if (tournamentIds.size > 0) {
      return torneios.filter(t => tournamentIds.has(t.id));
    }
    return torneios;
  }, [torneios, selectedCategory, inscricoes, resultados, categorias]);

  // Top athletes by rating in filtered list
  const topAtletas = [...filteredAtletas].sort((a, b) => b.rating - a.rating).slice(0, 5);
  
  // Latest 5 match results in filtered list
  const latestResultados = [...filteredResultados].slice(-5).reverse();

  // Active tournaments in filtered list
  const activeTorneios = filteredTorneios.filter(t => t.status === 'Em Andamento' || t.status === 'Inscrições Abertas');

  // Active scheduled games mapped by table number
  const activeGamesByMesa = useMemo(() => {
    const map: Record<number, any> = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('ttmpro_escala_')) {
          const item = localStorage.getItem(key);
          if (item) {
            const games = JSON.parse(item);
            if (Array.isArray(games)) {
              games.forEach((g: any) => {
                if (g.status === 'Em Jogo' && g.mesa) {
                  const mNum = Number(g.mesa);
                  if (!map[mNum]) {
                    map[mNum] = g;
                  }
                }
              });
            }
          }
        }
      }
    } catch (e) {
      console.error('Erro ao ler escala de jogos ativas:', e);
    }
    return map;
  }, [nowTimestamp, config?.mesasStatus]);

  // Build table metrics for monitor block with real-time elapsed timers
  const totalMesasCount = config?.mesasCount || 8;
  const tablesList = Array.from({ length: totalMesasCount }, (_, i) => {
    const tableNum = i + 1;
    const configuredMesa = (config?.mesasStatus || []).find((m: any) => m.numero === tableNum);
    const mStatus = configuredMesa ? configuredMesa.status : 'livre';
    const activeGame = activeGamesByMesa[tableNum];

    const occupied = (mStatus as string) === 'ocupada' || (mStatus as string) === 'ocupado' || Boolean(activeGame);
    const mArbNome = activeGame?.arbitroNome || configuredMesa?.arbitroNome || undefined;

    // Real-time timer calculation
    let elapsedText = '--:--';
    if (occupied) {
      let startMs: number | null = null;
      if (activeGame && (activeGame.startedAt || activeGame.startTimeMs)) {
        startMs = activeGame.startedAt || activeGame.startTimeMs;
      } else {
        const stored = localStorage.getItem(`ttmpro_mesa_start_${tableNum}`);
        if (stored) {
          startMs = Number(stored);
        } else {
          // Initialize start time for occupied table so timer counts up live
          const fallback = Date.now() - (6 * 60 * 1000 + (tableNum * 43 * 1000) % (15 * 60 * 1000));
          localStorage.setItem(`ttmpro_mesa_start_${tableNum}`, String(fallback));
          startMs = fallback;
        }
      }
      if (startMs) {
        const diffSec = Math.max(0, Math.floor((nowTimestamp - startMs) / 1000));
        const mins = Math.floor(diffSec / 60);
        const secs = diffSec % 60;
        elapsedText = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
      }
    } else {
      localStorage.removeItem(`ttmpro_mesa_start_${tableNum}`);
    }

    return {
      tableNum,
      configuredMesa,
      mStatus,
      mArbNome,
      occupied,
      activeGame,
      elapsedText
    };
  });

  const freeTablesCount = tablesList.filter(t => !t.occupied).length;
  const occupiedTablesCount = tablesList.filter(t => t.occupied).length;
  const occupancyRate = totalMesasCount > 0 ? Math.round((occupiedTablesCount / totalMesasCount) * 100) : 0;

  const filteredTables = tablesList.filter(table => {
    if (mesaFilter === 'livres') return !table.occupied;
    if (mesaFilter === 'ocupadas') return table.occupied;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Global Category Filter Control Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 shadow-lg relative overflow-hidden">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-yellow-400/10 border border-yellow-400/20 text-yellow-400 rounded-xl shrink-0">
            <Filter className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs sm:text-sm font-black text-slate-100 uppercase tracking-wide">
                Filtro Global por Categoria
              </h3>
              {selectedCategory !== 'todas' ? (
                <span className="bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 text-3xs font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-yellow-400"></span>
                  Filtrado
                </span>
              ) : (
                <span className="bg-slate-800 text-slate-400 text-3xs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider hidden sm:inline-block">
                  Visão Geral
                </span>
              )}
            </div>
            <p className="text-3xs text-slate-400 font-medium mt-0.5">
              Filtre estatísticas, atletas, torneios e resultados por uma modalidade ou faixa etária específica.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto self-stretch md:self-auto shrink-0">
          <div className="relative flex-1 md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-yellow-400">
              <Tag className="w-4 h-4" />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-slate-950 text-slate-100 text-xs font-bold pl-9 pr-8 py-2.5 rounded-xl border border-slate-700 hover:border-yellow-400/50 focus:border-yellow-400 focus:outline-none transition appearance-none cursor-pointer shadow-inner"
            >
              <option value="todas">Todas as Categorias ({availableCategories.length})</option>
              {availableCategories.map((catName) => (
                <option key={catName} value={catName}>
                  Categoria: {catName}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>

          {selectedCategory !== 'todas' && (
            <button
              type="button"
              onClick={() => setSelectedCategory('todas')}
              className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-slate-700 shrink-0"
              title="Restaurar visualização de todas as categorias"
            >
              <X className="w-3.5 h-3.5 text-yellow-400" />
              <span className="text-3xs uppercase tracking-wider font-extrabold">Limpar</span>
            </button>
          )}
        </div>
      </div>

      {/* Category Quick Pill Selectors if categories exist */}
      {availableCategories.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-2xs font-bold">
          <span className="text-3xs uppercase tracking-wider text-slate-500 font-extrabold shrink-0 mr-1 flex items-center gap-1">
            <Layers className="w-3 h-3" />
            Atalhos:
          </span>
          <button
            type="button"
            onClick={() => setSelectedCategory('todas')}
            className={`px-3 py-1.5 rounded-lg border transition whitespace-nowrap cursor-pointer shrink-0 ${
              selectedCategory === 'todas'
                ? 'bg-yellow-400 text-slate-950 font-black border-yellow-400 shadow-sm'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
            }`}
          >
            Todas ({availableCategories.length})
          </button>
          {availableCategories.slice(0, 7).map(catName => (
            <button
              key={catName}
              type="button"
              onClick={() => setSelectedCategory(catName)}
              className={`px-3 py-1.5 rounded-lg border transition whitespace-nowrap cursor-pointer shrink-0 ${
                selectedCategory === catName
                  ? 'bg-yellow-400 text-slate-950 font-black border-yellow-400 shadow-sm'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              {catName}
            </button>
          ))}
          {availableCategories.length > 7 && (
            <span className="text-3xs text-slate-500 shrink-0 pl-1 font-semibold">
              +{availableCategories.length - 7} mais
            </span>
          )}
        </div>
      )}

      {/* Google Sheets Live Status Widget */}
      <div id="gsheets-status-widget" className="bg-slate-900 border border-slate-800 rounded-xl p-4 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 shadow-md">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg shrink-0">
              <Globe className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs sm:text-sm font-black text-slate-100 uppercase tracking-wide">
                  Sincronização com Planilhas Google
                </h3>
                {gsSettings.linkedSpreadsheetId ? (
                  <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                    Vinculado
                  </span>
                ) : (
                  <span className="bg-slate-800 text-slate-400 border border-slate-700 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Não Vinculado
                  </span>
                )}
              </div>
              <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                Status da integração direta do banco de dados com a API do Google Sheets.
              </p>
            </div>
          </div>

          <button
            id="dashboard-gsheets-setup-btn"
            type="button"
            onClick={() => onNavigate('config')}
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold rounded-lg transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-400 animate-spin-slow" />
            Gerenciar Integração
          </button>
        </div>

        {/* Status Metrics Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3.5 pt-3.5 border-t border-slate-800/60">
          {/* Linked Spreadsheet details */}
          <div id="widget-sheet-info" className="bg-slate-950/40 border border-slate-800/40 rounded-xl p-3 flex items-start gap-2.5">
            <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <div className="text-[9px] text-slate-500 uppercase font-black tracking-wider">Planilha Oficial</div>
              <div className="text-xs font-bold text-slate-200 truncate mt-0.5" title={gsSettings.linkedSpreadsheetName || undefined}>
                {gsSettings.linkedSpreadsheetName || 'Nenhuma planilha associada'}
              </div>
              {gsSettings.linkedSpreadsheetUrl ? (
                <a
                  id="widget-open-sheet-link"
                  href={gsSettings.linkedSpreadsheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[9.5px] text-emerald-400 hover:underline inline-flex items-center gap-1 font-semibold mt-1"
                >
                  Abrir no Google Sheets <ExternalLink className="w-2.5 h-2.5" />
                </a>
              ) : (
                <div className="text-[9.5px] text-slate-500 mt-1">Vincule nas configurações do sistema</div>
              )}
            </div>
          </div>

          {/* Sync Status and Time */}
          <div id="widget-sync-time" className="bg-slate-950/40 border border-slate-800/40 rounded-xl p-3 flex items-start gap-2.5">
            <Clock className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-[9px] text-slate-500 uppercase font-black tracking-wider">Último Sync</div>
              <div className="text-xs font-bold text-slate-200 mt-0.5">
                {gsSettings.lastSyncTime ? new Date(gsSettings.lastSyncTime).toLocaleString('pt-BR') : 'Nunca sincronizado'}
              </div>
              <div className="text-[9.5px] flex items-center gap-1 mt-1">
                {gsSettings.linkedSpreadsheetId ? (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span className="text-slate-300 font-medium">Status: </span>
                    <span className="text-emerald-400 font-bold">{gsSettings.lastSyncStatus || 'Sucesso'}</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-3 h-3 text-yellow-500 shrink-0" />
                    <span className="text-yellow-500 font-bold">Aguardando Vinculação</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Records count */}
          <div id="widget-record-count" className="bg-slate-950/40 border border-slate-800/40 rounded-xl p-3.5 flex items-start gap-3">
            <Database className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-3xs text-slate-500 uppercase font-black tracking-wider">Registros Sincronizados</div>
              <div className="text-xs font-black text-slate-200 mt-0.5">
                {gsSettings.linkedSpreadsheetId 
                  ? `${gsSettings.totalRecordCount !== null ? gsSettings.totalRecordCount : '---'} registros` 
                  : 'Nenhum dado conectado'}
              </div>
              <div className="text-3xs text-slate-400 mt-1 leading-snug">
                {gsSettings.linkedSpreadsheetId 
                  ? 'Sincronizado de Atletas, Árbitros, Treinadores, Torneios e Categorias' 
                  : 'Vincule um documento para visualizar os registros'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div 
          onClick={() => onNavigate('atletas')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 transition rounded-xl p-4 cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            {selectedCategory !== 'todas' && (
              <span className="text-3xs bg-blue-500/10 text-blue-400 font-bold px-1.5 py-0.5 rounded border border-blue-500/20">
                Filtrado
              </span>
            )}
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-100">{filteredAtletas.length}</div>
            <div className="text-xs text-slate-400 mt-1">
              {selectedCategory !== 'todas' ? (
                <span>Atletas ({selectedCategory})</span>
              ) : (
                <span>Atletas Totais</span>
              )}
            </div>
            {selectedCategory !== 'todas' && (
              <div className="text-[10px] text-slate-500 mt-0.5 font-medium">
                de {atletas.length} atletas cadastrados
              </div>
            )}
          </div>
        </div>

        <div 
          onClick={() => onNavigate('torneios')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 transition rounded-xl p-4 cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-xl">
              <Trophy className="w-5 h-5" />
            </div>
            {selectedCategory !== 'todas' && (
              <span className="text-3xs bg-yellow-500/10 text-yellow-400 font-bold px-1.5 py-0.5 rounded border border-yellow-500/20">
                Filtrado
              </span>
            )}
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-100">{filteredTorneios.length}</div>
            <div className="text-xs text-slate-400 mt-1">
              {selectedCategory !== 'todas' ? (
                <span>Torneios ({selectedCategory})</span>
              ) : (
                <span>Torneios Totais</span>
              )}
            </div>
            {selectedCategory !== 'todas' && (
              <div className="text-[10px] text-slate-500 mt-0.5 font-medium">
                de {torneios.length} torneios gerais
              </div>
            )}
          </div>
        </div>

        <div 
          onClick={() => onNavigate('resultados')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 transition rounded-xl p-4 cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 bg-green-500/10 text-green-400 rounded-xl">
              <Activity className="w-5 h-5" />
            </div>
            {selectedCategory !== 'todas' && (
              <span className="text-3xs bg-green-500/10 text-green-400 font-bold px-1.5 py-0.5 rounded border border-green-500/20">
                Filtrado
              </span>
            )}
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-100">{filteredResultados.length}</div>
            <div className="text-xs text-slate-400 mt-1">
              {selectedCategory !== 'todas' ? (
                <span>Resultados ({selectedCategory})</span>
              ) : (
                <span>Resultados Totais</span>
              )}
            </div>
            {selectedCategory !== 'todas' && (
              <div className="text-[10px] text-slate-500 mt-0.5 font-medium">
                de {resultados.length} resultados no geral
              </div>
            )}
          </div>
        </div>

        <div 
          onClick={() => onNavigate('arbitros')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 transition rounded-xl p-4 cursor-pointer flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 bg-yellow-400/10 text-yellow-400 rounded-xl">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-100">{arbitros.length}</div>
            <div className="text-xs text-slate-400 mt-1">Árbitros</div>
          </div>
        </div>

        <div 
          onClick={() => onNavigate('funcionarios')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/80 transition rounded-xl p-4 cursor-pointer col-span-2 lg:col-span-1 flex flex-col justify-between"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="p-2.5 bg-orange-500/10 text-orange-400 rounded-xl">
              <Briefcase className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-3xl font-extrabold text-slate-100">{funcionarios.length}</div>
            <div className="text-xs text-slate-400 mt-1">Funcionários</div>
          </div>
        </div>
      </div>

      {/* Quick Access Shortcuts Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-yellow-400/10 border border-yellow-400/30 flex items-center justify-center text-yellow-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-100 uppercase tracking-wide">Acesso Rápido</h3>
              <p className="text-3xs text-slate-400 font-medium">Atalhos para as principais funções do sistema</p>
            </div>
          </div>
          <span className="text-3xs font-extrabold uppercase tracking-widest bg-slate-950 text-slate-400 px-2.5 py-1 rounded-md border border-slate-800 hidden sm:inline-block">
            Atalhos Diretos
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* Card 1: Cadastrar Atleta */}
          <div 
            onClick={() => onNavigate('atletas')}
            className="group bg-slate-950/70 border border-slate-800 hover:border-blue-500/50 hover:bg-slate-900/90 transition-all duration-200 rounded-xl p-4 cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden active:scale-[0.98] shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl group-hover:scale-105 transition-transform">
                <UserPlus className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-100 group-hover:text-blue-400 transition-colors uppercase tracking-wider">
                Cadastrar Novo Atleta
              </h4>
              <p className="text-3xs text-slate-400 mt-1 leading-snug">
                Adicione atletas com foto, clube, ranking e inscrição direta.
              </p>
            </div>
          </div>

          {/* Card 2: Iniciar Torneio */}
          <div 
            onClick={() => onNavigate('torneios')}
            className="group bg-slate-950/70 border border-slate-800 hover:border-yellow-500/50 hover:bg-slate-900/90 transition-all duration-200 rounded-xl p-4 cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden active:scale-[0.98] shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 rounded-xl group-hover:scale-105 transition-transform">
                <PlusCircle className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-yellow-400 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-100 group-hover:text-yellow-400 transition-colors uppercase tracking-wider">
                Iniciar Torneio
              </h4>
              <p className="text-3xs text-slate-400 mt-1 leading-snug">
                Crie campeonatos, defina datas, locais e modalidades ativas.
              </p>
            </div>
          </div>

          {/* Card 3: Consultar Chaveamento */}
          <div 
            onClick={() => onNavigate('chaveamento')}
            className="group bg-slate-950/70 border border-slate-800 hover:border-purple-500/50 hover:bg-slate-900/90 transition-all duration-200 rounded-xl p-4 cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden active:scale-[0.98] shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-purple-500/10 border border-purple-500/20 text-purple-400 rounded-xl group-hover:scale-105 transition-transform">
                <GitBranch className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-purple-400 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-100 group-hover:text-purple-400 transition-colors uppercase tracking-wider">
                Consultar Chaveamento
              </h4>
              <p className="text-3xs text-slate-400 mt-1 leading-snug">
                Gere e acompanhe os confrontos e chaves por categoria.
              </p>
            </div>
          </div>

          {/* Card 4: Ficha de Inscrição */}
          <div 
            onClick={() => onNavigate('ficha')}
            className="group bg-slate-950/70 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900/90 transition-all duration-200 rounded-xl p-4 cursor-pointer flex flex-col justify-between space-y-3 relative overflow-hidden active:scale-[0.98] shadow-sm"
          >
            <div className="flex items-center justify-between">
              <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 text-teal-400 rounded-xl group-hover:scale-105 transition-transform">
                <FileText className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-teal-400 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-100 group-hover:text-teal-400 transition-colors uppercase tracking-wider">
                Ficha de Inscrição
              </h4>
              <p className="text-3xs text-slate-400 mt-1 leading-snug">
                Gerencie pagamentos, crachás e comprovantes de inscritos.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Live Table Monitor Component — Status das Mesas em Tempo Real */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        {/* Header Title & Navigation */}
        <div className="px-5 py-4 border-b border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950">
          <div className="text-left space-y-0.5">
            <h4 className="font-black text-slate-100 flex items-center gap-2 text-sm uppercase tracking-wide">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              Status das Mesas em Tempo Real
            </h4>
            <p className="text-xs text-slate-400 font-medium">
              Monitoramento ao vivo de partidas ativas, tempo decorrido de jogo e disponibilidade de mesas oficiais.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto shrink-0">
            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-bold shrink-0 shadow-inner flex-1 md:flex-initial">
              <button
                type="button"
                onClick={() => setMesaFilter('todas')}
                className={`px-3 py-1.5 rounded-md transition cursor-pointer text-center flex-1 ${
                  mesaFilter === 'todas'
                    ? 'bg-yellow-400 text-slate-950 font-black shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Todas ({tablesList.length})
              </button>
              <button
                type="button"
                onClick={() => setMesaFilter('livres')}
                className={`px-3 py-1.5 rounded-md transition cursor-pointer text-center flex-1 ${
                  mesaFilter === 'livres'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-black'
                    : 'text-slate-400 hover:text-emerald-400'
                }`}
              >
                Livres ({freeTablesCount})
              </button>
              <button
                type="button"
                onClick={() => setMesaFilter('ocupadas')}
                className={`px-3 py-1.5 rounded-md transition cursor-pointer text-center flex-1 ${
                  mesaFilter === 'ocupadas'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 font-black'
                    : 'text-slate-400 hover:text-amber-400'
                }`}
              >
                Em Jogo ({occupiedTablesCount})
              </button>
            </div>

            <button 
              type="button"
              onClick={() => onNavigate('placar-arbitro')}
              className="bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black px-3.5 py-2 rounded-lg text-xs cursor-pointer transition flex items-center justify-center gap-1.5 uppercase tracking-wide shrink-0 shadow-md active:scale-95"
            >
              <PlaySquare className="w-4 h-4" />
              <span className="hidden sm:inline">Placar Árbitro</span>
            </button>
          </div>
        </div>

        {/* Real-time Summary Bar */}
        <div className="bg-slate-950/60 px-5 py-3 border-b border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-bold">
          <div className="flex items-center gap-2 text-slate-300">
            <span className="p-1.5 bg-slate-800 rounded text-slate-400">🏓</span>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Total de Mesas</div>
              <div className="text-sm font-black text-slate-100">{totalMesasCount} Oficial(is)</div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-emerald-400">
            <span className="p-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400">🟢</span>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Mesas Livres</div>
              <div className="text-sm font-black text-emerald-400">{freeTablesCount} Disponível(is)</div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-amber-400">
            <span className="p-1.5 bg-amber-500/10 border border-amber-500/20 rounded text-amber-400">🟡</span>
            <div>
              <div className="text-[10px] text-slate-500 uppercase">Partidas em Andamento</div>
              <div className="text-sm font-black text-amber-400">{occupiedTablesCount} Em Jogo</div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-cyan-400">
            <span className="p-1.5 bg-cyan-500/10 border border-cyan-500/20 rounded text-cyan-400">📊</span>
            <div className="w-full min-w-0">
              <div className="text-[10px] text-slate-500 uppercase">Taxa de Ocupação</div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-cyan-300">{occupancyRate}%</span>
                <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-cyan-400 transition-all duration-300" 
                    style={{ width: `${occupancyRate}%` }} 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Tables Grid */}
        <div className="p-5">
          {filteredTables.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredTables.map(({ tableNum, mArbNome, occupied, activeGame, elapsedText }) => {
                const refObj = mArbNome 
                  ? arbitros.find(a => a.nome.toUpperCase() === mArbNome.toUpperCase())
                  : undefined;

                return (
                  <div 
                    key={tableNum}
                    className={`border rounded-xl p-4 transition-all duration-200 flex flex-col justify-between relative overflow-hidden shadow-sm ${
                      occupied 
                        ? 'bg-zinc-950/90 border-amber-500/40 hover:border-amber-500/70' 
                        : 'bg-zinc-950/40 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {/* Top Decorative Strip */}
                    <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${
                      occupied ? 'from-amber-400 via-orange-500 to-rose-500 animate-pulse' : 'from-emerald-500 to-teal-500'
                    }`} />

                    {/* Table Header: Number, Status & Live Elapsed Time */}
                    <div className="flex items-center justify-between pb-3 border-b border-zinc-850 gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs uppercase tracking-wider font-extrabold text-zinc-400 font-mono">
                          MESA
                        </span>
                        <span className="text-xl font-black text-zinc-100 font-mono tracking-tight bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-md">
                          #{String(tableNum).padStart(2, '0')}
                        </span>
                      </div>

                      {occupied ? (
                        <div className="flex flex-col items-end">
                          <span className="inline-flex items-center gap-1 text-[10px] bg-amber-400/10 text-amber-400 border border-amber-400/30 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                            <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping"></span>
                            Em Jogo
                          </span>
                          <span className="text-[11px] font-mono font-bold text-amber-300 mt-1 flex items-center gap-1 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/20">
                            <Clock className="w-3 h-3 text-amber-400 animate-spin-slow" />
                            <span>{elapsedText}</span>
                          </span>
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-400/10 text-emerald-400 border border-emerald-400/30 px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                          Livre
                        </span>
                      )}
                    </div>

                    {/* Match & Players Information */}
                    <div className="py-3 my-1 space-y-2">
                      {occupied ? (
                        <div>
                          {activeGame ? (
                            <div className="space-y-1.5">
                              <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                                <span className="truncate max-w-[150px]">{activeGame.categoriaNome || 'Confronto Oficial'}</span>
                                {activeGame.fase && (
                                  <span className="text-amber-400 text-3xs font-black">{activeGame.fase}</span>
                                )}
                              </div>
                              <div className="bg-zinc-900/90 border border-zinc-800 rounded-lg p-2 flex items-center justify-between gap-2">
                                <span className="text-xs font-black text-emerald-400 truncate flex-1 text-left">
                                  {activeGame.p1?.nome || 'Atleta A'}
                                </span>
                                <span className="text-3xs font-black bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded border border-amber-500/30 shrink-0">
                                  VS
                                </span>
                                <span className="text-xs font-black text-rose-400 truncate flex-1 text-right">
                                  {activeGame.p2?.nome || 'Atleta B'}
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="bg-zinc-900/80 border border-zinc-850 p-2.5 rounded-lg text-center space-y-1">
                              <span className="text-xs font-bold text-amber-300 block">Partida em Andamento</span>
                              <span className="text-3xs text-zinc-400 font-mono">Lançamento ativo no placar do árbitro</span>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="py-2 text-center space-y-1">
                          <span className="text-xs font-bold text-emerald-400/90 block">Mesa Desocupada</span>
                          <span className="text-3xs text-zinc-500">Pronta para a próxima rodada do torneio</span>
                        </div>
                      )}
                    </div>

                    {/* Referee & Action Footer */}
                    <div className="pt-2 border-t border-zinc-850 flex items-center justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        {occupied ? (
                          <div className="flex items-center gap-1.5 text-2xs text-zinc-300 font-semibold truncate">
                            <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span className="truncate">{mArbNome || 'Árbitro de Mesa'}</span>
                          </div>
                        ) : (
                          <div className="text-3xs text-zinc-500 uppercase tracking-wider font-extrabold">
                            Aguardando Jogadores
                          </div>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => onNavigate('placar-arbitro')}
                        className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 shrink-0 cursor-pointer ${
                          occupied 
                            ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30' 
                            : 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20'
                        }`}
                        title="Ir para o Placar do Árbitro"
                      >
                        <span className="text-2xs uppercase font-extrabold">{occupied ? 'Placar' : 'Escalar'}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 px-4 border border-dashed border-slate-800 rounded-xl bg-slate-950/20">
              <p className="text-sm text-slate-400">
                Nenhuma mesa encontrada com o filtro selecionado (<strong>{mesaFilter === 'livres' ? 'Disponível / Livre' : 'Ativa / Em Jogo'}</strong>).
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Grid of details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Top Athletes */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
            <h4 className="font-bold text-slate-200 flex items-center gap-2">
              <Medal className="w-4 h-4 text-yellow-400" />
              Melhores Atletas (Ranking)
            </h4>
            <span className="text-2xs font-bold uppercase tracking-wider text-yellow-400 bg-yellow-400/10 px-2 py-0.5 rounded-full">
              Rating Oficial
            </span>
          </div>
          <div className="p-5 divide-y divide-slate-800">
            {topAtletas.length > 0 ? (
              topAtletas.map((a, index) => (
                <div key={a.id} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="w-8 flex items-center justify-center font-bold text-lg text-slate-500">
                    {index === 0 ? (
                      <span className="text-yellow-400">❶</span>
                    ) : index === 1 ? (
                      <span className="text-slate-300">❷</span>
                    ) : index === 2 ? (
                      <span className="text-amber-600">❸</span>
                    ) : (
                      index + 1
                    )}
                  </div>
                  
                  {a.foto ? (
                    <img src={a.foto} className="w-9 h-9 rounded-full object-cover border border-slate-700" alt={a.nome} />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-sm text-slate-300">
                      {a.nome[0].toUpperCase()}
                    </div>
                  )}

                  <div className="flex-1">
                    <div className="text-sm font-semibold text-slate-200">{a.nome}</div>
                    <div className="text-xs text-slate-400">{a.clube || 'Nenhum Clube'} · {a.cat}</div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-bold text-yellow-400">{a.rating}</span>
                    <span className="block text-2xs text-slate-400">pts</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6 text-slate-500 text-sm">
                Nenhum atleta cadastrado.
              </div>
            )}
          </div>
        </div>

        {/* Recent Results */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
            <h4 className="font-bold text-slate-200 flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-400" />
              Últimos Resultados
            </h4>
            <button 
              type="button"
              onClick={() => onNavigate('resultados')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium"
            >
              Ver todos
            </button>
          </div>
          <div className="p-5 overflow-x-auto">
            {latestResultados.length > 0 ? (
              <table className="w-full text-slate-200 text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-2xs uppercase tracking-wider text-left">
                    <th className="pb-3 pr-2">Atleta A</th>
                    <th className="pb-3 text-center px-2">Placar</th>
                    <th className="pb-3 pl-2">Atleta B</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {latestResultados.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-800/30 transition">
                      <td className="py-2.5 font-semibold text-slate-200 truncate max-w-[140px] pr-2">{r.nomeA}</td>
                      <td className="py-2.5 text-center px-2">
                        <span className="inline-block bg-yellow-400/10 text-yellow-400 font-bold px-2 py-0.5 rounded text-xs">
                          {r.ponA} × {r.ponB}
                        </span>
                      </td>
                      <td className="py-2.5 font-semibold text-slate-200 truncate max-w-[140px] pl-2">{r.nomeB}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center py-8 text-slate-500 text-sm">
                Nenhum resultado registrado ainda.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Active tournaments list */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden mt-6">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h4 className="font-bold text-slate-200 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-400" />
            Torneios Ativos
          </h4>
        </div>
        <div className="p-5">
          {activeTorneios.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeTorneios.map(t => (
                <div 
                  key={t.id} 
                  className="bg-slate-950 border border-slate-800 hover:border-slate-700/80 transition rounded-xl p-4 flex items-start gap-4"
                >
                  <div className="p-3 bg-yellow-400/5 text-yellow-400 rounded-xl shrink-0 mt-0.5">
                    <Trophy className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-slate-100 truncate text-sm">{t.nome}</div>
                    <div className="text-slate-400 text-xs mt-1 truncate">
                      {t.local}, {t.cidade}
                    </div>
                    <div className="text-slate-500 text-3xs mt-2 uppercase font-semibold">
                      Início: {new Date(t.ini + 'T12:00').toLocaleDateString('pt-BR')}
                    </div>
                  </div>
                  <span className={`text-3xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                    t.status === 'Em Andamento' 
                      ? 'bg-emerald-400/10 text-emerald-400' 
                      : 'bg-blue-400/10 text-blue-400'
                  }`}>
                    {t.status === 'Em Andamento' ? 'Ao Vivo' : 'Inscrições'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-slate-500 text-sm">
              Não há torneios ativos no momento.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
