import React, { useState, useEffect } from 'react';
import { 
  Laptop, 
  Download, 
  CheckCircle2, 
  Database, 
  X, 
  HardDrive, 
  Sparkles, 
  ShieldCheck, 
  Globe, 
  FileCode, 
  Terminal, 
  Upload, 
  HelpCircle,
  Cpu,
  Zap,
  FolderDown
} from 'lucide-react';
import { triggerToast } from '../utils/toast';

interface DesktopInstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt: any;
  onInstallPWA: () => void;
  isPWAInstalled: boolean;
  onExportDatabaseJSON: () => void;
  onImportDatabaseJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function DesktopInstallerModal({
  isOpen,
  onClose,
  deferredPrompt,
  onInstallPWA,
  isPWAInstalled,
  onExportDatabaseJSON,
  onImportDatabaseJSON
}: DesktopInstallerModalProps) {

  // Escape key listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleDownloadBatchScript = () => {
    const batContent = `@echo off
title TT Manager Pro - Instalador do Computador
color 0A
cls
echo =======================================================================
echo          INSTALADOR E INICIALIZADOR DO TT MANAGER PRO (PC)
echo =======================================================================
echo.
echo [1/3] Verificando Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ALERTA] Node.js nao encontrado no seu computador!
    echo Por favor, baixe e instale o Node.js LTS em: https://nodejs.org
    pause >nul
    start https://nodejs.org
    exit /b
)

echo [2/3] Instalando todas as dependencias locais...
call npm install

echo [3/3] Iniciando o servidor local do TT Manager Pro...
start http://localhost:3000
call npm run dev
pause
`;

    const blob = new Blob([batContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'INSTALAR_TT_MANAGER_PRO.bat';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    triggerToast('Download do script de instalação no PC (INSTALAR_TT_MANAGER_PRO.bat) iniciado!', 'success');
  };

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col my-auto">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-r from-emerald-500/10 via-cyan-500/10 to-blue-500/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-9 h-9 sm:w-10 sm:h-10 bg-emerald-400/10 rounded-xl flex items-center justify-center border border-emerald-400/20 text-emerald-400 shrink-0">
              <Laptop className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-slate-100 text-sm sm:text-base tracking-wide">
                  Gerar Instalador no Computador 💻
                </h3>
                <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-1.5 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> OFFLINE & INFINITO
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium">
                Instale o aplicativo direto no seu PC com todas as dependências e banco de dados local
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 p-1.5 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto max-h-[75vh]">

          {/* Option 1: PWA Native Desktop App Installation */}
          <div className="bg-slate-950/80 border-2 border-emerald-500/40 hover:border-emerald-400/60 rounded-xl p-4 sm:p-5 space-y-3.5 transition shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-center shrink-0">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                    1. Instalação Nativa no PC (1-Clique)
                  </h4>
                  <p className="text-3xs text-slate-300">
                    Cria um ícone na sua Área de Trabalho e abre em janela própria de app sem navegador.
                  </p>
                </div>
              </div>

              {isPWAInstalled ? (
                <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 text-xs font-black uppercase px-3 py-1.5 rounded-lg flex items-center gap-1.5 shrink-0">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> App Já Instalado
                </span>
              ) : deferredPrompt ? (
                <button
                  type="button"
                  onClick={onInstallPWA}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase px-4 py-2 rounded-lg flex items-center gap-2 transition cursor-pointer shadow-md active:scale-95 shrink-0"
                >
                  <Download className="w-4 h-4" />
                  Instalar no PC Agora
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onInstallPWA}
                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-black text-xs uppercase px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition cursor-pointer shrink-0"
                >
                  <Laptop className="w-4 h-4 text-emerald-400" />
                  Instalar via Navegador
                </button>
              )}
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-lg text-3xs text-slate-300 space-y-1.5 leading-relaxed font-medium">
              <span className="font-extrabold text-emerald-400 block uppercase">💡 Como instalar manualmente no seu navegador:</span>
              <ul className="list-disc list-inside space-y-1 text-slate-300">
                <li><strong>Google Chrome / Edge:</strong> Clique no ícone de computador/instalar <Laptop className="w-3 h-3 inline text-emerald-400" /> no canto direito da barra de endereço e confirme em "Instalar".</li>
                <li><strong>Outros navegadores:</strong> Acesse o menu (3 pontos no topo direito) &gt; <em>"Mais ferramentas"</em> &gt; <em>"Instalar aplicativo TT Manager Pro"</em> ou <em>"Criar Atalho..."</em>.</li>
              </ul>
            </div>
          </div>

          {/* Option 2: Script / Executable Batch Installer File */}
          <div className="bg-slate-950/60 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-4 sm:p-5 space-y-3 transition">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center shrink-0">
                  <Terminal className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                    2. Script Executável Local (INSTALAR_TT_MANAGER_PRO.bat)
                  </h4>
                  <p className="text-3xs text-slate-400 font-mono">
                    Pacote com inicializador automatizado para Windows (Node.js + Servidor Local)
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleDownloadBatchScript}
                className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 font-extrabold text-xs uppercase px-3.5 py-2 rounded-lg flex items-center gap-2 transition cursor-pointer shrink-0"
              >
                <FolderDown className="w-4 h-4 text-cyan-400" />
                Baixar Script .BAT
              </button>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed font-medium">
              O arquivo <code className="text-cyan-300 bg-slate-900 px-1.5 py-0.5 rounded font-mono">INSTALAR_TT_MANAGER_PRO.bat</code> permite rodar o sistema diretamente na sua máquina Windows. Ele verifica as dependências do Node.js, compila o código e abre a aplicação localmente sem requerer conexão com a internet.
            </p>
          </div>

          {/* Option 3: Embedded Database (IndexedDB) */}
          <div className="bg-slate-950/60 border border-yellow-500/30 hover:border-yellow-400/50 rounded-xl p-4 sm:p-5 space-y-3.5 transition">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                    3. Banco de Dados Local Integrado (IndexedDB) 💾
                  </h4>
                  <p className="text-3xs text-slate-400 font-mono">
                    Engine: HTML5 IndexedDB | Capacidade ilimitada offline
                  </p>
                </div>
              </div>

              <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-400/30 text-4xs font-black uppercase px-2.5 py-1 rounded-lg flex items-center gap-1 shrink-0">
                <ShieldCheck className="w-3.5 h-3.5 text-yellow-400" /> 100% Persistente
              </span>
            </div>

            <p className="text-3xs text-slate-300 leading-relaxed font-medium">
              Seus atletas, categorias, chaves, súmulas, árbitros e configurações ficam salvos permanentemente no banco de dados local do seu computador (<code className="text-yellow-300 bg-slate-900 px-1 py-0.5 rounded font-mono">IndexedDB</code>).
            </p>

            {/* Export & Import JSON Backup Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onExportDatabaseJSON}
                className="bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-extrabold text-xs px-3 py-2 rounded-lg flex items-center justify-center gap-2 transition cursor-pointer shadow-sm active:scale-95"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                Exportar Cópia do Banco (.JSON)
              </button>

              <label className="bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-extrabold text-xs px-3 py-2 rounded-lg flex items-center justify-center gap-2 transition cursor-pointer shadow-sm active:scale-95">
                <Upload className="w-4 h-4 text-cyan-400" />
                Restaurar Banco de Dados (.JSON)
                <input 
                  type="file" 
                  accept=".json" 
                  onChange={onImportDatabaseJSON} 
                  className="hidden" 
                />
              </label>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800/80 flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="text-3xs text-slate-400 flex items-center gap-1.5 font-mono">
            <Cpu className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>TT Manager Pro • Versão com suporte total a execução local offline e PWA Desktop</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase px-5 py-2 rounded-lg transition cursor-pointer"
          >
            Fechar Janela
          </button>
        </div>

      </div>
    </div>
  );
}
