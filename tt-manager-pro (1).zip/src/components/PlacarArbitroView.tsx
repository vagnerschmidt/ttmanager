import React, { useState, useEffect } from 'react';
import { Torneio, Categoria, Atleta, Arbitro, Resultado } from '../types';
import { 
  Play, Pause, RotateCcw, Plus, Minus, Send, MessageSquare, 
  Clock, Users, Trophy, Radio, Shield, Star, RefreshCw,
  Lock, Unlock, CheckCircle, AlertTriangle, Volume2, Megaphone,
  ChevronLeft, ChevronRight, ArrowRight, ExternalLink, Zap
} from 'lucide-react';
import { triggerToast } from '../utils/toast';
import { normalizePhoneToBrazil } from '../utils/phone';

interface PlacarArbitroViewProps {
  torneios: Torneio[];
  categorias: Categoria[];
  atletas: Atleta[];
  arbitros: Arbitro[];
  resultados: Resultado[];
  onSaveResultado: (result: Resultado) => void;
  onNavigate?: (section: string) => void;
  refereeQueue?: string[];
  onUpdateRefereeQueue?: (queue: string[]) => void;
  config?: any;
  onSaveConfig?: (config: any) => void;
  onUpdateArbitro?: (arbitro: Arbitro) => void;
  userRole?: string;
  sessionUser?: any;
}

export default function PlacarArbitroView({
  torneios,
  categorias,
  atletas,
  arbitros,
  resultados,
  onSaveResultado,
  onNavigate,
  refereeQueue = [],
  onUpdateRefereeQueue,
  config,
  onSaveConfig,
  onUpdateArbitro,
  userRole,
  sessionUser
}: PlacarArbitroViewProps) {
  // Main Selection States
  const [selectedTorneioId, setSelectedTorneioId] = useState('');
  const [selectedCatId, setSelectedCatId] = useState('');
  const [selectedArbId, setSelectedArbId] = useState('');
  
  // Game Setup
  const [athleteAId, setAthleteAId] = useState('');
  const [athleteBId, setAthleteBId] = useState('');
  const [selectedMesa, setSelectedMesa] = useState(1);
  const [maxSets, setMaxSets] = useState(() => config?.setsMax || 5); // Best of 5 by default
  const [pointsPerSet, setPointsPerSet] = useState(() => config?.setsPoints || 11); // Standard 11 points

  React.useEffect(() => {
    if (selectedTorneioId) {
      const currentT = torneios.find(t => t.id === selectedTorneioId);
      if (currentT) {
        if (currentT.setsMax) {
          setMaxSets(currentT.setsMax);
        } else if (config?.setsMax) {
          setMaxSets(config.setsMax);
        }
        if (currentT.setsPoints) {
          setPointsPerSet(currentT.setsPoints);
        } else if (config?.setsPoints) {
          setPointsPerSet(config.setsPoints);
        }
        return;
      }
    }
    if (config?.setsMax) setMaxSets(config.setsMax);
    if (config?.setsPoints) setPointsPerSet(config.setsPoints);
  }, [selectedTorneioId, torneios, config?.setsMax, config?.setsPoints]);

  // Auto-assign available referee if none selected
  useEffect(() => {
    if (!selectedArbId && arbitros.length > 0) {
      const avail = arbitros.find(a => a.status === 'Disponível') || arbitros[0];
      if (avail) {
        setSelectedArbId(avail.id);
      }
    }
  }, [arbitros, selectedArbId]);

  // Master Scheduled Games state for Visual Bracket Alerts
  const [scheduledGamesList, setScheduledGamesList] = useState<any[]>([]);
  const [selectedAlertIndex, setSelectedAlertIndex] = useState(0);

  // Load schedule whenever tournament or category changes
  const refreshScheduleList = () => {
    let tId = selectedTorneioId;
    if (!tId && torneios.length > 0) {
      tId = torneios[0].id;
    }
    if (tId) {
      const storageKey = `ttmpro_escala_${tId}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            setScheduledGamesList(parsed);
            return;
          }
        } catch (e) {
          console.error('Error parsing scheduled games:', e);
        }
      }
    }
    setScheduledGamesList([]);
  };

  useEffect(() => {
    refreshScheduleList();
    setSelectedAlertIndex(0);
  }, [selectedTorneioId, selectedCatId, torneios]);

  // Filter pending games (optionally filtered by category)
  const pendingScheduledGames = scheduledGamesList.filter(g => {
    if (g.status === 'Concluído') return false;
    if (selectedCatId && g.categoriaId !== selectedCatId) return false;
    return true;
  });

  const activeAlertMatch = pendingScheduledGames[selectedAlertIndex] || pendingScheduledGames[0] || null;

  // Handler to load selected bracket match directly into the scoreboard controls
  const handleLoadAlertMatchToPlacar = (match: any) => {
    if (!match) return;

    const targetMesaNum = Number(match.mesa) || 1;

    // Check if the table currently has a match 'Em Jogo' that is not this match
    const busyMatchInSchedule = scheduledGamesList.find(
      (g: any) => Number(g.mesa) === targetMesaNum && g.status === 'Em Jogo' && g.id !== match.id && g.matchId !== match.matchId
    );

    if (busyMatchInSchedule) {
      triggerToast(
        `⚠️ A Mesa #${targetMesaNum} ainda possui uma partida EM JOGO (${busyMatchInSchedule.p1?.nome || 'Atleta A'} vs ${busyMatchInSchedule.p2?.nome || 'Atleta B'})! A nova partida só será aberta nesta mesa quando a convocada anteriormente for concluída.`,
        'error'
      );
      return;
    }

    if (match.torneioId && match.torneioId !== selectedTorneioId) {
      setSelectedTorneioId(match.torneioId);
    }
    if (match.categoriaId) {
      setSelectedCatId(match.categoriaId);
    }
    if (match.mesa) {
      setSelectedMesa(Number(match.mesa));
    }

    // Match Athlete A
    if (match.p1?.id) {
      setAthleteAId(match.p1.id);
    } else if (match.p1?.nome) {
      const foundA = atletas.find(a => a.nome.toLowerCase().trim() === match.p1.nome.toLowerCase().trim());
      if (foundA) setAthleteAId(foundA.id);
    }

    // Match Athlete B
    if (match.p2?.id) {
      setAthleteBId(match.p2.id);
    } else if (match.p2?.nome) {
      const foundB = atletas.find(b => b.nome.toLowerCase().trim() === match.p2.nome.toLowerCase().trim());
      if (foundB) setAthleteBId(foundB.id);
    }

    // Match Referee
    if (match.arbitroNome) {
      const foundArb = arbitros.find(a => a.nome.toLowerCase().trim() === match.arbitroNome.toLowerCase().trim());
      if (foundArb) setSelectedArbId(foundArb.id);
    }

    // Reset current score
    setScoreA(0);
    setScoreB(0);
    setSetsWonA(0);
    setSetsWonB(0);
    setSetHistory([]);
    setGameOver(false);
    setWinner(null);

    triggerToast(`🏓 Escalação da Mesa #${match.mesa} (${match.p1?.nome || 'Atleta A'} vs ${match.p2?.nome || 'Atleta B'}) carregada com sucesso no placar!`, 'success');
  };

  const handleAnnounceAlertMatch = (match: any) => {
    if (!match) return;
    const p1Name = match.p1?.nome || 'Atleta 1';
    const p2Name = match.p2?.nome || 'Atleta 2';
    const mesaNum = match.mesa || 1;
    const catName = match.categoriaNome || 'Categoria';
    const arbText = match.arbitroNome ? `, sob arbitragem de ${match.arbitroNome}` : '';

    const msg = `Atenção, convocação de mesa por chaveamento! Atleta ${p1Name} e Atleta ${p2Name}, da categoria ${catName}. Favor se dirigir imediatamente à Mesa de número ${mesaNum}${arbText}. Repito: Mesa ${mesaNum} para ${p1Name} e ${p2Name}.`;

    playAlertSoundAndVoice(msg);
    triggerToast(`📢 Convocação por voz emitida para Mesa #${mesaNum}: ${p1Name} vs ${p2Name}`, 'info');
  };

  // Scoreboard Live States
  const [scoreA, setScoreA] = useState(0);
  const [scoreB, setScoreB] = useState(0);
  const [setsWonA, setSetsWonA] = useState(0);
  const [setsWonB, setSetsWonB] = useState(0);
  const [service, setService] = useState<'A' | 'B'>('A'); // server indicator
  const [firstServer, setFirstServer] = useState<'A' | 'B'>('A'); // who served first in this set
  
  // Match history of sets
  const [setHistory, setSetHistory] = useState<{ setNum: number; scoreA: number; scoreB: number }[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState<'A' | 'B' | null>(null);

  // Timer States
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [timerActive, setTimerActive] = useState(false);

  // Card Penalties State
  const [yellowCardsA, setYellowCardsA] = useState(0);
  const [redCardsA, setRedCardsA] = useState(0);
  const [yellowCardsB, setYellowCardsB] = useState(0);
  const [redCardsB, setRedCardsB] = useState(0);

  // W.O. Walkover Status State
  const [woStatus, setWoStatus] = useState<'A' | 'B' | null>(null);
  const [obsNotes, setObsNotes] = useState('');

  // Voice alerts capability & state
  const [autoVoiceAlert, setAutoVoiceAlert] = useState(true);

  // Helper to play beeps followed by voice announcement
  const playAlertSoundAndVoice = (text: string) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const audioCtx = new AudioCtx();
        const playTone = (freq: number, start: number, duration: number) => {
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, start);
          
          gain.gain.setValueAtTime(0.18, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + duration - 0.05);
          
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          
          osc.start(start);
          osc.stop(start + duration);
        };

        // Beautiful tri-note chime
        playTone(523.25, audioCtx.currentTime, 0.15); // C5
        playTone(659.25, audioCtx.currentTime + 0.12, 0.18); // E5
        playTone(783.99, audioCtx.currentTime + 0.24, 0.25); // G5
      }
    } catch (e) {
      console.warn("AudioContext blocked or not supported:", e);
    }

    setTimeout(() => {
      try {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const speech = new SpeechSynthesisUtterance(text);
          speech.lang = 'pt-BR';
          speech.rate = 0.95;
          speech.pitch = 1.0;
          
          const voices = window.speechSynthesis.getVoices();
          const ptVoice = voices.find(v => v.lang === 'pt-BR') || voices.find(v => v.lang.startsWith('pt'));
          if (ptVoice) {
            speech.voice = ptVoice;
          }
          window.speechSynthesis.speak(speech);
        }
      } catch (err) {
        console.warn("SpeechSynthesis error:", err);
      }
    }, 450);
  };

  // Active object references
  const currentTorneio = torneios.find(t => t.id === selectedTorneioId);
  const currentCat = categorias.find(c => c.id === selectedCatId);
  const currentArb = arbitros.find(a => a.id === selectedArbId);
  const athleteA = atletas.find(a => a.id === athleteAId);
  const athleteB = atletas.find(a => a.id === athleteBId);

  // Operator identification & check to comply with restriction:
  // "Gerar o placar apenas o arbrito escalado para aquela mesa e os mesários poderão mexer neles. Placar só pode ser alterado pelo juiz e pelo usuário master"
  const [operatorBypass, setOperatorBypass] = useState<'none' | 'arbitro' | 'mesario' | 'master'>(
    userRole === 'master' || userRole === 'admin' ? 'master' : (userRole === 'mesario' ? 'mesario' : 'none')
  );

  useEffect(() => {
    if (userRole === 'master' || userRole === 'admin') {
      setOperatorBypass('master');
    } else if (userRole === 'mesario') {
      setOperatorBypass('mesario');
    } else {
      setOperatorBypass('none');
    }
  }, [userRole]);

  const isMasterOrAdmin = userRole === 'master' || userRole === 'admin';
  const isMesario = userRole === 'mesario';
  const isAssignedReferee = !!currentArb && !!sessionUser && (
    sessionUser.role === 'arbitro' && 
    (sessionUser.name || '').toLowerCase().trim() === (currentArb.nome || '').toLowerCase().trim()
  );

  const hasEditPermission = isMasterOrAdmin || isMesario || isAssignedReferee || operatorBypass !== 'none';

  const guardAction = (fn: () => void, errorMsg: string = "Apenas o árbitro escalado (juiz), mesários autorizados ou o usuário master podem alterar o placar!") => {
    if (!hasEditPermission) {
      triggerToast(errorMsg, "error");
      return;
    }
    fn();
  };

  // Dynamic mesas options list from tournament
  const numMesas = currentTorneio?.mesas || 4;
  const mesasArray = Array.from({ length: numMesas }, (_, i) => i + 1);

  // Match Duration Timer Effect
  useEffect(() => {
    let interval: any = null;
    if (timerActive) {
      interval = setInterval(() => {
        setTimerSeconds(s => s + 1);
      }, 1000);
    } else {
      if (interval) clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [timerActive]);

  // Format Elapsed Time MM:SS
  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Rule engine for servicing/saque toggles and set completion
  useEffect(() => {
    if (gameOver) return;

    const totalPoints = scoreA + scoreB;
    const isDeuce = scoreA >= (pointsPerSet - 1) && scoreB >= (pointsPerSet - 1);

    // In deuce, server changes every point. Otherwise, changes every 2 points.
    const serviceInterval = isDeuce ? 1 : 2;
    const relativePoints = totalPoints;
    
    const shouldSwitch = Math.floor(relativePoints / serviceInterval) % 2 === 0;
    // Align with initial server of the set
    if (shouldSwitch) {
      setService(firstServer);
    } else {
      setService(firstServer === 'A' ? 'B' : 'A');
    }

    // Check if Set is completed
    const winningThreshold = pointsPerSet;
    const diff = Math.abs(scoreA - scoreB);

    if ((scoreA >= winningThreshold || scoreB >= winningThreshold) && diff >= 2) {
      // Set Finished!
      const isSetWinnerA = scoreA > scoreB;
      const nextSetsA = isSetWinnerA ? setsWonA + 1 : setsWonA;
      const nextSetsB = !isSetWinnerA ? setsWonB + 1 : setsWonB;

      const newHistory = [...setHistory, {
        setNum: setHistory.length + 1,
        scoreA,
        scoreB
      }];
      setSetHistory(newHistory);

      // Reset live point scoreboard
      setScoreA(0);
      setScoreB(0);

      // Toggle first server for the next set
      const nextFirstServer = firstServer === 'A' ? 'B' : 'A';
      setFirstServer(nextFirstServer);
      setService(nextFirstServer);

      // Check Match Finish (e.g., best of 5, first to 3 sets wins)
      const setsNeededToWin = Math.ceil(maxSets / 2);
      if (nextSetsA >= setsNeededToWin) {
        setSetsWonA(nextSetsA);
        setSetsWonB(nextSetsB);
        setGameOver(true);
        setWinner('A');
        setTimerActive(false);
      } else if (nextSetsB >= setsNeededToWin) {
        setSetsWonA(nextSetsA);
        setSetsWonB(nextSetsB);
        setGameOver(true);
        setWinner('B');
        setTimerActive(false);
      } else {
        setSetsWonA(nextSetsA);
        setSetsWonB(nextSetsB);
      }
    }
  }, [scoreA, scoreB]);

  // Handle Score Adjustments manually
  const adjustScore = (player: 'A' | 'B', action: 'add' | 'sub') => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro escalado (juiz), mesários autorizados ou o usuário master podem alterar o placar!", "error");
      return;
    }
    if (gameOver) return;
    // Auto-active timer on first score interaction If not playing
    if (!timerActive && timerSeconds === 0) {
      setTimerActive(true);
    }

    if (player === 'A') {
      if (action === 'add') setScoreA(p => p + 1);
      else setScoreA(p => Math.max(0, p - 1));
    } else {
      if (action === 'add') setScoreB(p => p + 1);
      else setScoreB(p => Math.max(0, p - 1));
    }
  };

  // Switch server manually (in case of mistakes)
  const toggleServerManually = () => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro escalado (juiz), mesários autorizados ou o usuário master podem alterar o saque!", "error");
      return;
    }
    setService(prev => prev === 'A' ? 'B' : 'A');
  };

  // Reset current scorecard fully
  const handleFullReset = () => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro/juiz ou o usuário master podem resetar o placar!", "error");
      return;
    }
    if (confirm("Resetar toda a partida atual e zerar o placar?")) {
      setScoreA(0);
      setScoreB(0);
      setSetsWonA(0);
      setSetsWonB(0);
      setSetHistory([]);
      setGameOver(false);
      setWinner(null);
      setTimerSeconds(0);
      setTimerActive(false);
      setYellowCardsA(0);
      setRedCardsA(0);
      setYellowCardsB(0);
      setRedCardsB(0);
      setWoStatus(null);
      setObsNotes('');
    }
  };

  // Declare W.O. function
  const handleDeclareWO = (missingPlayer: 'A' | 'B') => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro escalado (juiz), mesários autorizados ou o usuário master podem aplicar W.O.!", "error");
      return;
    }
    if (!athleteAId || !athleteBId) {
      triggerToast("Selecione os dois atletas antes de aplicar o W.O.!", "warning");
      return;
    }
    const missingName = missingPlayer === 'A' ? (athleteA?.nome || 'Atleta A') : (athleteB?.nome || 'Atleta B');
    const winnerName = missingPlayer === 'A' ? (athleteB?.nome || 'Atleta B') : (athleteA?.nome || 'Atleta A');
    
    if (confirm(`Confirmar vitória por W.O. para ${winnerName} devido ao não comparecimento (falta) de ${missingName}?`)) {
      setWoStatus(missingPlayer);
      const setsNeededToWin = Math.ceil(maxSets / 2);
      
      if (missingPlayer === 'A') {
        setSetsWonA(0);
        setSetsWonB(setsNeededToWin);
        setScoreA(0);
        setScoreB(11);
        setWinner('B');
      } else {
        setSetsWonB(0);
        setSetsWonA(setsNeededToWin);
        setScoreB(0);
        setScoreA(11);
        setWinner('A');
      }
      
      const mockHistory = Array.from({ length: setsNeededToWin }, (_, i) => ({
        setNum: i + 1,
        scoreA: missingPlayer === 'A' ? 0 : 11,
        scoreB: missingPlayer === 'A' ? 11 : 0
      }));
      setSetHistory(mockHistory);
      
      setGameOver(true);
      setTimerActive(false);
      setObsNotes(`Vitória por W.O. devido à falta cometida/ausência do atleta ${missingName}.`);
    }
  };

  // Summon/call next referee from queue and alert via WhatsApp
  const handleSummonNext = () => {
    if (!refereeQueue || refereeQueue.length === 0) {
      triggerToast("Nenhum árbitro na fila de espera!", "error");
      return;
    }
    // Find first referee in queue
    const nextArbId = refereeQueue[0];
    const refObj = arbitros.find(a => a.id === nextArbId);
    if (!refObj) {
      triggerToast("Árbitro da fila não encontrado nos cadastros!", "error");
      return;
    }

    // Assign as current selected referee
    setSelectedArbId(refObj.id);

    // Update their status to 'Convocado' to pulse in active view
    if (onUpdateArbitro) {
      onUpdateArbitro({
        ...refObj,
        status: 'Convocado'
      });
    }

    triggerToast(`Árbitro ${refObj.nome} convocado! Gerando alerta automático WhatsApp...`, "success");

    if (autoVoiceAlert) {
      playAlertSoundAndVoice(`Atenção! Árbitro ${refObj.nome}, favor comparecer à mesa número ${selectedMesa} para arbitrar a partida.`);
    }

    // Open WhatsApp in separate window pointing to their number
    setTimeout(() => {
      const cleanPhone = (refObj.wa || refObj.tel || '').replace(/\D/g, '');
      const tNome = currentTorneio?.nome || 'Campeonato';
      const aNomeA = athleteA?.nome || 'Atleta A';
      const aNomeB = athleteB?.nome || 'Atleta B';
      const message = `🏓 *TT Manager Pro — Escalação de Mesa*\n\nOlá, Árbitro *${refObj.nome}*!\n\nVocê acaba de ser *CONVOCADO* da fila para mediar a partida:\n👤 *${aNomeA}* 🆚 *${aNomeB}*\n📍 *Mesa ${selectedMesa}*\n🏆 Torneio: *${tNome}*\n\nFavor comparecer imediatamente à mesa e confirmar sua presença no sistema!\n\n_Organização TT Manager_`;
      const encodedText = encodeURIComponent(message);
      const openUrl = cleanPhone 
        ? `https://wa.me/${cleanPhone}?text=${encodedText}` 
        : `https://wa.me/?text=${encodedText}`;
      window.open(openUrl, '_blank');
    }, 200);
  };

  // Confirm appearance, free a table if busy, update status to Em Jogo
  const handleConfirmPresence = () => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro/juiz escalado para aquela mesa, mesários autorizados ou o usuário master podem confirmar a presença!", "error");
      return;
    }
    if (!currentArb) return;

    const currentMesasStatus = Array.isArray(config?.mesasStatus) ? config.mesasStatus : [];
    
    // Helper to check if a table is currently busy/occupied
    const isMesaBusy = (num: number) => {
      const match = currentMesasStatus.find((m: any) => m.numero === num);
      return match ? (match.status === 'ocupada' || match.status === 'ocupado') : false;
    };

    let targetMesa = selectedMesa;

    // Check if selected table is busy, if yes, auto re-assign to next free table
    if (isMesaBusy(selectedMesa)) {
      let foundFree = false;
      for (const mNum of mesasArray) {
        if (!isMesaBusy(mNum)) {
          targetMesa = mNum;
          foundFree = true;
          break;
        }
      }
      if (foundFree) {
        setSelectedMesa(targetMesa);
        triggerToast(`Mesa ${selectedMesa} ocupada! Direcionando automaticamente para a Mesa desocupada Nº ${targetMesa}.`, "success");
      }
    }

    // Set referee playing status
    if (onUpdateArbitro) {
      onUpdateArbitro({
        ...currentArb,
        status: 'Em Jogo'
      });
    }

    // Mark that table as busy inside global configs
    if (onSaveConfig && config) {
      const updatedConfig = { ...config };
      const currentStatus = Array.isArray(updatedConfig.mesasStatus) ? updatedConfig.mesasStatus : [];
      
      let found = false;
      let nextStatus = currentStatus.map((m: any) => {
        if (m.numero === targetMesa) {
          found = true;
          return { ...m, status: 'ocupada' as const, arbitroNome: currentArb.nome };
        }
        return m;
      });
      
      if (!found) {
        nextStatus.push({ numero: targetMesa, status: 'ocupada' as const, arbitroNome: currentArb.nome });
      }
      
      updatedConfig.mesasStatus = nextStatus;
      onSaveConfig(updatedConfig);
    }

    // Pull from waitlist queue
    if (onUpdateRefereeQueue) {
      onUpdateRefereeQueue(refereeQueue.filter(id => id !== currentArb.id));
    }

    triggerToast(`Árbitro ${currentArb.nome} confirmado! Mesa ${targetMesa} desocupada aberta para início do jogo.`, "success");
  };

  // Save/Submit finalized match resultado to history
  const handleSaveResult = () => {
    if (!hasEditPermission) {
      triggerToast("Apenas o árbitro/juiz escalado para aquela mesa, mesários autorizados ou o usuário master podem salvar o resultado!", "error");
      return;
    }
    if (!athleteAId || !athleteBId || athleteAId === athleteBId) {
      triggerToast("Por favor, selecione atletas válidos e distintos!", "warning");
      return;
    }

    const tRef = torneios.find(t => t.id === selectedTorneioId);
    const cRef = categorias.find(c => c.id === selectedCatId);

    const match: Resultado = {
      id: 'res_arb_' + Date.now().toString(36),
      torId: selectedTorneioId,
      catId: selectedCatId,
      nomeA: athleteA?.nome || 'Atleta A',
      nomeB: athleteB?.nome || 'Atleta B',
      ponA: scoreA,
      ponB: scoreB,
      setsA: setsWonA,
      setsB: setsWonB,
      arb: currentArb?.nome || 'Árbitro Oficial',
      mesa: Number(selectedMesa) || 1,
      dt: new Date().toISOString(),
      wo: woStatus || undefined,
      obs: obsNotes || undefined,
      cartoesA: (yellowCardsA > 0 || redCardsA > 0) ? { amarelo: yellowCardsA, vermelho: redCardsA } : undefined,
      cartoesB: (yellowCardsB > 0 || redCardsB > 0) ? { amarelo: yellowCardsB, vermelho: redCardsB } : undefined
    };

    onSaveResultado(match);

    // 1. Release Mesa in config.mesasStatus
    const freedMesaNum = Number(selectedMesa) || 1;
    if (onSaveConfig && config) {
      const updatedConfig = { ...config };
      const currentStatus = Array.isArray(updatedConfig.mesasStatus) ? updatedConfig.mesasStatus : [];
      const nextStatus = currentStatus.map((m: any) => {
        if (m.numero === freedMesaNum) {
          return { ...m, status: 'disponivel' as const, arbitroNome: '' };
        }
        return m;
      });
      updatedConfig.mesasStatus = nextStatus;
      onSaveConfig(updatedConfig);
    }

    // 2. Release Referee to 'Disponível'
    const freedArbName = currentArb?.nome || 'Árbitro de Mesa';
    if (currentArb && onUpdateArbitro) {
      onUpdateArbitro({
        ...currentArb,
        status: 'Disponível'
      });
    }
    if (currentArb && onUpdateRefereeQueue) {
      if (!refereeQueue.includes(currentArb.id)) {
        onUpdateRefereeQueue([...refereeQueue, currentArb.id]);
      }
    }

    // 3. Update Master Game Schedule in localStorage and auto-assign freed table and referee to next game
    if (selectedTorneioId) {
      const storageKey = `ttmpro_escala_${selectedTorneioId}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        try {
          const games = JSON.parse(saved);
          if (Array.isArray(games)) {
            let updated = games.map((g: any) => {
              if (
                g.mesa === freedMesaNum && 
                (g.status === 'Em Jogo' || (g.p1?.nome === athleteA?.nome && g.p2?.nome === athleteB?.nome))
              ) {
                return { ...g, status: 'Concluído', score1: setsWonA, score2: setsWonB };
              }
              return g;
            });

            // Automatically open freed table for the next waiting match on that table (or next in line)
            const nextWaiting = updated.find((g: any) => g.status === 'Aguardando' && Number(g.mesa) === freedMesaNum) ||
                                updated.find((g: any) => g.status === 'Aguardando');
            if (nextWaiting) {
              updated = updated.map((g: any) => {
                if (g.id === nextWaiting.id) {
                  return { ...g, mesa: freedMesaNum, arbitroNome: freedArbName, status: 'Em Jogo' };
                }
                return g;
              });
              triggerToast(`🏓 PARTIDA NA MESA #${freedMesaNum} CONCLUÍDA! Mesa liberada para os novos convocados: ${nextWaiting.p1?.nome || 'Atleta A'} vs ${nextWaiting.p2?.nome || 'Atleta B'} (${nextWaiting.categoriaNome})`, 'success');
            } else {
              triggerToast(`✓ Partida concluída com sucesso! Mesa #${freedMesaNum} e Árbitro ${freedArbName} agora estão totalmente livres.`, 'success');
            }
            localStorage.setItem(storageKey, JSON.stringify(updated));
            refreshScheduleList();
          }
        } catch (e) {
          console.error('Erro ao atualizar escala em handleSaveResult:', e);
        }
      } else {
        triggerToast(`✓ Partida salva! Mesa #${freedMesaNum} e Árbitro ${freedArbName} estão livres.`, 'success');
      }
    }

    // Clear and prompt next match
    setScoreA(0);
    setScoreB(0);
    setSetsWonA(0);
    setSetsWonB(0);
    setSetHistory([]);
    setGameOver(false);
    setWinner(null);
    setTimerSeconds(0);
    setTimerActive(false);
    setYellowCardsA(0);
    setRedCardsA(0);
    setYellowCardsB(0);
    setRedCardsB(0);
    setWoStatus(null);
    setObsNotes('');
  };

  // WhatsApp alerts helper
  const sendWhatsAppNotification = (dest: 'arbitro' | 'atletaA' | 'atletaB') => {
    if (!selectedTorneioId) {
      triggerToast("Selecione o torneio primeiro!", "warning");
      return;
    }
    if (!athleteAId || !athleteBId) {
      triggerToast("Selecione os atletas para saber quem disputará o jogo!", "warning");
      return;
    }

    const tNome = currentTorneio?.nome || 'Campeonato';
    const aNomeA = athleteA?.nome || 'Atleta A';
    const aNomeB = athleteB?.nome || 'Atleta B';
    const arbNome = currentArb?.nome || 'Árbitro de Mesa';
    
    let targetPhone = '';
    let message = '';

    if (dest === 'arbitro') {
      if (!currentArb) {
        triggerToast("Nenhum árbitro selecionado para a escala!", "warning");
        return;
      }
      targetPhone = currentArb.wa || currentArb.tel || '';
      message = `🏓 *TT Manager Pro — Escalação de Mesa*\n\nOlá, Árbitro *${arbNome}*!\n\nVocê foi escalado para mediar a próxima rodada:\n👤 *${aNomeA}* 🆚 *${aNomeB}*\n📍 *Mesa ${selectedMesa}*\n🏆 Torneio: *${tNome}*\n\nFavor comparecer imediatamente à mesa com a súmula oficial!\n\n_Organização TT Manager_`;
    } else if (dest === 'atletaA') {
      if (!athleteA) return;
      targetPhone = athleteA.wa || athleteA.tel || '';
      message = `🏓 *TT Manager Pro — Convocação de Mesa*\n\nOlá, Atleta *${aNomeA}*!\n\nSua próxima partida foi escalada:\n🆚 Oponente: *${aNomeB}*\n📍 *Mesa ${selectedMesa}*\n👤 Árbitro: *${arbNome}*\n🏆 Campeonato: *${tNome}*\n\nFavor dirigir-se com raquete em mãos à mesa designada.\n\n_Organização TT Manager_`;
    } else if (dest === 'atletaB') {
      if (!athleteB) return;
      targetPhone = athleteB.wa || athleteB.tel || '';
      message = `🏓 *TT Manager Pro — Convocação de Mesa*\n\nOlá, Atleta *${aNomeB}*!\n\nSua próxima partida foi escalada:\n🆚 Oponente: *${aNomeA}*\n📍 *Mesa ${selectedMesa}*\n👤 Árbitro: *${arbNome}*\n🏆 Campeonato: *${tNome}*\n\nFavor dirigir-se com raquete em mãos à mesa designada.\n\n_Organização TT Manager_`;
    }

    const normalizedPhone = normalizePhoneToBrazil(targetPhone);
    const cleanPhone = normalizedPhone.replace(/\D/g, '');
    const encodedText = encodeURIComponent(message);
    const openUrl = cleanPhone 
      ? `https://wa.me/${cleanPhone}?text=${encodedText}` 
      : `https://wa.me/?text=${encodedText}`;

    window.open(openUrl, '_blank');

    // Also trigger local device sound/voice alert
    if (autoVoiceAlert) {
      if (dest === 'arbitro') {
        playAlertSoundAndVoice(`Atenção! Convocamos o árbitro ${arbNome}, para atuar na Mesa de número ${selectedMesa}.`);
      } else if (dest === 'atletaA' && athleteA) {
        playAlertSoundAndVoice(`Atenção, atleta ${aNomeA}. Favor comparecer à mesa de número ${selectedMesa}. Repito: atleta ${aNomeA}, favor dirigir-se à mesa ${selectedMesa}.`);
      } else if (dest === 'atletaB' && athleteB) {
        playAlertSoundAndVoice(`Atenção, atleta ${aNomeB}. Favor comparecer à mesa de número ${selectedMesa}. Repito: atleta ${aNomeB}, favor dirigir-se à mesa ${selectedMesa}.`);
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* VISUAL ALERT BANNER - CHAVEAMENTO & PROXIMA MESA */}
      <div className="bg-zinc-900 border-2 border-emerald-500/50 rounded-xl p-4 sm:p-4 shadow-lg relative overflow-hidden transition-all">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/30 animate-pulse">
              <Megaphone className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-zinc-100 text-xs sm:text-sm tracking-wide flex items-center gap-2 uppercase">
                Alerta Visual de Convocação — Mesa Destinada
              </h3>
              <p className="text-2xs text-zinc-400 font-medium">
                Indicação automática dos próximos atletas e mesa escalados pela categoria
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            {pendingScheduledGames.length > 0 && (
              <div className="flex items-center gap-1 bg-zinc-950 px-2.5 py-1 rounded-lg border border-zinc-800 text-2xs text-zinc-300 font-mono font-bold">
                <span>Partida {selectedAlertIndex + 1} de {pendingScheduledGames.length} pendentes</span>
              </div>
            )}

            {pendingScheduledGames.length > 1 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setSelectedAlertIndex(prev => Math.max(0, prev - 1))}
                  disabled={selectedAlertIndex === 0}
                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-zinc-200 rounded cursor-pointer transition"
                  title="Anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedAlertIndex(prev => Math.min(pendingScheduledGames.length - 1, prev + 1))}
                  disabled={selectedAlertIndex >= pendingScheduledGames.length - 1}
                  className="p-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-zinc-200 rounded cursor-pointer transition"
                  title="Próxima"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {activeAlertMatch ? (
          <div className="mt-3 grid grid-cols-1 md:grid-cols-12 gap-3 items-center bg-zinc-950 p-3 rounded-xl border border-zinc-800 shadow-inner">
            
            {/* Mesa Badge Box */}
            <div className="md:col-span-3 flex flex-col items-center sm:items-start justify-center border-b md:border-b-0 md:border-r border-zinc-800 pb-3 md:pb-0 pr-0 md:pr-3">
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                Mesa Designada
              </span>
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-zinc-950 px-3 py-1.5 rounded-lg text-sm sm:text-base font-black tracking-tight shadow flex items-center gap-1.5">
                <span>MESA #{activeAlertMatch.mesa}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-1 text-[10px]">
                <span className="bg-zinc-800 text-zinc-300 font-bold px-2 py-0.5 rounded border border-zinc-700">
                  {activeAlertMatch.categoriaNome || 'Categoria'}
                </span>
                {activeAlertMatch.fase && (
                  <span className="bg-amber-400/20 text-amber-400 font-bold px-2 py-0.5 rounded border border-amber-400/30">
                    {activeAlertMatch.fase}
                  </span>
                )}
                {activeAlertMatch.horario && (
                  <span className="bg-zinc-800 text-zinc-400 font-mono px-2 py-0.5 rounded">
                    ⏰ {activeAlertMatch.horario}
                  </span>
                )}
              </div>
            </div>

            {/* Athletes Pair Box */}
            <div className="md:col-span-6 space-y-1.5 text-center sm:text-left">
              <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-400 block">
                Atletas Convocados para a Mesa #{activeAlertMatch.mesa}:
              </span>
              
              <div className="flex flex-col sm:flex-row items-center justify-between gap-2 bg-zinc-900/90 p-2.5 rounded-lg border border-zinc-850">
                <div className="flex-1 text-center sm:text-left min-w-0">
                  <div className="font-bold text-emerald-400 text-xs sm:text-sm truncate">
                    {activeAlertMatch.p1?.nome || 'Atleta A'}
                  </div>
                  {activeAlertMatch.p1?.clube && (
                    <div className="text-[10px] text-zinc-400 truncate">
                      🏛️ {activeAlertMatch.p1.clube}
                    </div>
                  )}
                </div>

                <div className="px-2.5 py-0.5 bg-amber-500/20 text-amber-400 font-bold text-[10px] rounded-full border border-amber-500/30 shrink-0">
                  VS
                </div>

                <div className="flex-1 text-center sm:text-right min-w-0">
                  <div className="font-bold text-rose-400 text-xs sm:text-sm truncate">
                    {activeAlertMatch.p2?.nome || 'Atleta B'}
                  </div>
                  {activeAlertMatch.p2?.clube && (
                    <div className="text-[10px] text-zinc-400 truncate">
                      🏛️ {activeAlertMatch.p2.clube}
                    </div>
                  )}
                </div>
              </div>

              {activeAlertMatch.arbitroNome && (
                <div className="text-2xs text-zinc-400 font-medium flex items-center gap-1 justify-center sm:justify-start">
                  <Shield className="w-3.5 h-3.5 text-amber-400" />
                  <span>Árbitro Escalado: <strong className="text-zinc-200">{activeAlertMatch.arbitroNome}</strong></span>
                </div>
              )}
            </div>

            {/* Action Buttons Box */}
            <div className="md:col-span-3 flex flex-col gap-1.5 pt-2 md:pt-0 border-t md:border-t-0 md:border-l border-zinc-800 pl-0 md:pl-3">
              <button
                type="button"
                onClick={() => handleLoadAlertMatchToPlacar(activeAlertMatch)}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-1.5 px-3 rounded-lg text-xs uppercase tracking-wide cursor-pointer transition flex items-center justify-center gap-1.5 shadow active:scale-95"
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                <span>Escalar no Placar</span>
              </button>

              <button
                type="button"
                onClick={() => handleAnnounceAlertMatch(activeAlertMatch)}
                className="w-full bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold py-1.5 px-3 rounded-lg text-xs uppercase cursor-pointer transition flex items-center justify-center gap-1.5 shadow active:scale-95"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Chamada de Voz</span>
              </button>
            </div>

          </div>
        ) : (
          <div className="mt-3 bg-zinc-950 p-3 rounded-xl border border-zinc-800 text-center space-y-1.5">
            <p className="text-xs text-zinc-400 font-medium">
              {selectedCatId ? 'Nenhuma partida pendente para esta categoria no chaveamento.' : 'Selecione um torneio/categoria ou gere a escala de jogos no Chaveamento.'}
            </p>
            {onNavigate && (
              <button
                type="button"
                onClick={() => onNavigate('chaveamento')}
                className="inline-flex items-center gap-1 text-xs text-emerald-400 hover:text-emerald-300 font-bold hover:underline cursor-pointer"
              >
                <span>Ver Chaveamento & Gerar Escala de Mesas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* SELECTION HUD / SETUP BAR */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-850 pb-2.5">
          <h3 className="font-bold text-slate-100 text-xs sm:text-sm flex items-center gap-2 uppercase tracking-wide">
            <Radio className="w-4 h-4 text-yellow-400 animate-pulse" />
            Configuração da Mesa de Arbitragem
          </h3>
          <div className="text-slate-400 text-2xs font-mono">
            {currentTorneio ? `Mesas Alocadas: ${numMesas}` : 'Selecione um Torneio'}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Tournament selection */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Torneio Ativo</label>
            <select
              value={selectedTorneioId}
              onChange={(e) => {
                setSelectedTorneioId(e.target.value);
                setSelectedMesa(1); // Reset selected table to table 1
              }}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-medium"
            >
              <option value="">Selecione o Torneio...</option>
              {torneios.map(t => (
                <option key={t.id} value={t.id}>{t.nome}</option>
              ))}
            </select>
          </div>

          {/* Categoria selection */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Categoria</label>
            <select
              value={selectedCatId}
              onChange={(e) => setSelectedCatId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-medium"
            >
              <option value="">Selecione a Categoria...</option>
              {categorias.map(c => (
                <option key={c.id} value={c.id}>{c.nome}</option>
              ))}
            </select>
          </div>

          {/* Table index selection */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Mesa da Partida</label>
            <select
              value={selectedMesa}
              onChange={(e) => setSelectedMesa(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-mono font-bold"
            >
              {mesasArray.map(mNum => (
                <option key={mNum} value={mNum}>Mesa nº {mNum}</option>
              ))}
            </select>
          </div>

          {/* Referee scale */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Árbitro de Partida</label>
            <select
              value={selectedArbId}
              onChange={(e) => setSelectedArbId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-medium"
            >
              <option value="">Delegar Árbitro...</option>
              {arbitros.map(a => (
                <option key={a.id} value={a.id}>{a.nome} ({a.nivel}) — {a.status}</option>
              ))}
            </select>
            {refereeQueue.length > 0 && !selectedArbId && (
              <button
                type="button"
                onClick={handleSummonNext}
                className="mt-1.5 w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-2 py-1.5 rounded text-[10px] uppercase cursor-pointer flex items-center justify-center gap-1 leading-none shadow transition"
              >
                📢 CONVOCAR PRÓXIMO DA FILA: {arbitros.find(x => x.id === refereeQueue[0])?.nome}
              </button>
            )}
          </div>

        </div>

        {/* Players / Format Selection Panel */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          
          {/* Athlete A */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Atleta A (Esquerda)</label>
            <select
              value={athleteAId}
              onChange={(e) => {
                setAthleteAId(e.target.value);
                setScoreA(0);
                setSetsWonA(0);
              }}
              className="w-full bg-slate-950 border border-emerald-950 hover:border-emerald-500 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition font-medium"
            >
              <option value="">Selecione Jogador A...</option>
              {atletas.map(a => (
                <option key={a.id} value={a.id}>{a.nome} ({a.rating} pts)</option>
              ))}
            </select>
          </div>

          {/* Athlete B */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold block">Atleta B (Direita)</label>
            <select
              value={athleteBId}
              onChange={(e) => {
                setAthleteBId(e.target.value);
                setScoreB(0);
                setSetsWonB(0);
              }}
              className="w-full bg-slate-950 border border-red-950 hover:border-red-500 text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition font-medium"
            >
              <option value="">Selecione Jogador B...</option>
              {atletas.map(a => (
                <option key={a.id} value={a.id}>{a.nome} ({a.rating} pts)</option>
              ))}
            </select>
          </div>

          {/* Sets Format Selection */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold flex items-center justify-between gap-1">
              <span>Melhor de quantos Sets?</span>
              {currentTorneio?.setsMax ? (
                <span className="text-[9px] bg-yellow-400/10 text-yellow-400 px-1.5 py-0.5 rounded font-black tracking-normal uppercase">🏆 Oficial</span>
              ) : null}
            </label>
            <select
              value={maxSets}
              onChange={(e) => setMaxSets(Number(e.target.value))}
              className={`w-full bg-slate-950 border text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-mono ${
                currentTorneio?.setsMax ? 'border-yellow-400/30 text-yellow-100' : 'border-slate-800'
              }`}
            >
              <option value={3}>Melhor de 3 Sets (Vence quem fizer 2)</option>
              <option value={5}>Melhor de 5 Sets (Vence quem fizer 3)</option>
              <option value={7}>Melhor de 7 Sets (Vence quem fizer 4)</option>
              {![3, 5, 7].includes(maxSets) && (
                <option value={maxSets}>Melhor de {maxSets} Sets</option>
              )}
            </select>
          </div>

          {/* Points Per Set */}
          <div className="space-y-1">
            <label className="text-2xs uppercase tracking-wider text-slate-400 font-extrabold flex items-center justify-between gap-1">
              <span>Pontos por Set</span>
              {currentTorneio?.setsPoints ? (
                <span className="text-[9px] bg-yellow-400/10 text-yellow-400 px-1.5 py-0.5 rounded font-black tracking-normal uppercase">🏆 Oficial</span>
              ) : null}
            </label>
            <select
              value={pointsPerSet}
              onChange={(e) => setPointsPerSet(Number(e.target.value))}
              className={`w-full bg-slate-950 border text-slate-200 rounded-lg px-3 py-2 text-xs outline-none transition focus:border-yellow-400 font-mono ${
                currentTorneio?.setsPoints ? 'border-yellow-400/30 text-yellow-100' : 'border-slate-800'
              }`}
            >
              <option value={11}>11 pontos padrão</option>
              <option value={21}>21 pontos antigo</option>
              {![11, 21].includes(pointsPerSet) && (
                <option value={pointsPerSet}>{pointsPerSet} pontos</option>
              )}
            </select>
          </div>

        </div>

        {currentArb && (currentArb.status === 'Convocado' || currentArb.status === 'CONVOCADO') && (
          <div className="bg-amber-400/5 border border-amber-400/30 p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-pulse">
            <div className="text-left space-y-1">
              <span className="text-[10px] bg-amber-400 text-slate-950 font-extrabold px-2 py-0.5 rounded uppercase font-mono tracking-wider inline-block">
                🔔 Árbitro Convocado e Escalado
              </span>
              <h4 className="text-sm font-black text-slate-100 uppercase">
                AGUARDANDO CONFIRMAÇÃO DO ÁRBITRO: {currentArb.nome}
              </h4>
              <p className="text-xs text-slate-400">
                O profissional foi escalado para a Mesa <span className="font-bold text-yellow-500 font-mono">#{selectedMesa}</span>. Caso esteja em uso, outra mesa desocupada será sugerida ao confirmar.
              </p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto shrink-0 font-bold">
              <button
                type="button"
                onClick={() => sendWhatsAppNotification('arbitro')}
                className="flex-1 sm:flex-initial px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs rounded-lg transition text-center cursor-pointer"
              >
                Reenviar Alerta WA
              </button>
              <button
                type="button"
                onClick={handleConfirmPresence}
                className="flex-1 sm:flex-initial px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black text-xs rounded-lg transition text-center cursor-pointer shadow-lg"
              >
                CONFIRMAR PRESENÇA E LIBERAR MESA
              </button>
            </div>
          </div>
        )}

        {/* COMUNICAÇÃO DE MESA & ALTO-FALANTE */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* WhatsApp Notification Center */}
          <div className="bg-slate-950/40 p-4 border border-slate-850 rounded-xl space-y-3 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-extrabold text-cyan-400 uppercase tracking-widest flex items-center gap-1.5 leading-none">
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                Avisos para Celular (WhatsApp)
              </h4>
              <p className="text-[11px] text-slate-400 leading-normal mt-1.5">
                Para o funcionamento em rede ou internet, avise os envolvidos sobre a numeração da mesa. Abre o App do WhatsApp com textos de convocação automáticos e pré-formatados!
              </p>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              <button
                type="button"
                onClick={() => sendWhatsAppNotification('arbitro')}
                disabled={!selectedArbId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  selectedArbId 
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                Chamar Árbitro ⚖️
              </button>
              <button
                type="button"
                onClick={() => sendWhatsAppNotification('atletaA')}
                disabled={!athleteAId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  athleteAId 
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                Notificar Atleta A 🏓
              </button>
              <button
                type="button"
                onClick={() => sendWhatsAppNotification('atletaB')}
                disabled={!athleteBId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  athleteBId 
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                Notificar Atleta B 🏓
              </button>
            </div>
          </div>

          {/* Local Megaphone & Sound Warning Center */}
          <div className="bg-slate-950/40 p-4 border border-slate-850 rounded-xl space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-xs font-extrabold text-yellow-400 uppercase tracking-widest flex items-center gap-1.5 leading-none">
                  <Megaphone className="w-4 h-4 text-yellow-400 animate-pulse animate-duration-1000" />
                  Mesa-fone por Voz & Gongo 🔊
                </h4>
                
                {/* Auto voice switch */}
                <button
                  type="button"
                  onClick={() => setAutoVoiceAlert(!autoVoiceAlert)}
                  className={`text-[10px] font-extrabold px-2.5 py-1 rounded flex items-center gap-1 transition shrink-0 ${
                    autoVoiceAlert 
                      ? 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-400' 
                      : 'bg-slate-900 border border-slate-850 text-slate-400'
                  }`}
                >
                  {autoVoiceAlert ? '🔊 Voz: ATIVA' : '🔇 Silenciada'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal mt-1.5">
                Utilize o alto-falante do celular/tablet ou conecte a saída de som a uma caixa acústica para o robô fazer anúncios de voz automáticos e organizar o andamento!
              </p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <button
                type="button"
                onClick={() => playAlertSoundAndVoice('Atenção!')}
                className="text-2xs font-extrabold py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg flex items-center gap-1.5 transition cursor-pointer"
              >
                🔔 Tocar Gongo
              </button>
              
              <button
                type="button"
                onClick={() => {
                  if (!currentArb) {
                    triggerToast("Selecione um árbitro primeiro!", "warning");
                    return;
                  }
                  playAlertSoundAndVoice(`Atenção! Árbitro, ${currentArb.nome}, favor comparecer imediatamente para dirigir a partida na Mesa de número ${selectedMesa}.`);
                }}
                disabled={!selectedArbId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  selectedArbId 
                    ? 'bg-yellow-500 hover:bg-yellow-400 text-slate-950 cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                ⚖️ Voz: Árbitro
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!athleteA && !athleteB) {
                    triggerToast("Selecione os atletas primeiro!", "warning");
                    return;
                  }
                  const nameA = athleteA?.nome || 'Atleta A';
                  const nameB = athleteB?.nome || 'Atleta B';
                  playAlertSoundAndVoice(`Atenção atletas! Atleta ${nameA} e atleta ${nameB}, favor comparecer imediatamente para jogar na Mesa número ${selectedMesa}.`);
                }}
                disabled={!athleteAId && !athleteBId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  athleteAId || athleteBId 
                    ? 'bg-yellow-500 hover:bg-yellow-400 text-slate-950 cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                🏓 Voz: Atletas
              </button>

              <button
                type="button"
                onClick={() => {
                  const nameA = athleteA?.nome || 'Atleta A';
                  const nameB = athleteB?.nome || 'Atleta B';
                  const arbName = currentArb?.nome || 'árbitro de mesa';
                  playAlertSoundAndVoice(`Chamada geral de partida da Mesa número ${selectedMesa}. Atleta ${nameA} versus atleta ${nameB}. Sob arbitragem de ${arbName}. Partida oficial.`);
                }}
                disabled={!athleteAId && !athleteBId}
                className={`text-2xs font-extrabold py-2 px-3 rounded-lg flex items-center gap-1.5 transition ${
                  athleteAId || athleteBId 
                    ? 'bg-cyan-600 hover:bg-cyan-500 text-white cursor-pointer' 
                    : 'bg-slate-850 text-slate-500 cursor-not-allowed'
                }`}
              >
                📢 Chamada Completa
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* FULL-SCREEN INTUITIVE DYNAMIC REFEREE SCOREBOARD */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch select-none">
        
        {/* BIG LIVE SCORING PANEL (COL SPAN 8) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col justify-between overflow-hidden relative shadow-lg min-h-[480px]">
          
          {/* Header display matches information */}
          <div className="bg-slate-950 p-4 border-b border-slate-800 flex justify-between items-center px-6">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse"></span>
              <span className="text-3xs tracking-widest font-extrabold text-slate-400 uppercase">
                {currentTorneio?.nome || 'MESA DE ARBITRAGEM LIVRE'} — MESA {selectedMesa}
              </span>
            </div>
            
            {/* Match Duration Timer panel */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 rounded-md font-mono text-xs font-bold text-slate-350">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>{formatTime(timerSeconds)}</span>
              </div>
              <button
                onClick={() => setTimerActive(prev => !prev)}
                className={`p-1.5 rounded-md duration-150 transition cursor-pointer ${
                  timerActive 
                    ? 'bg-red-500/10 hover:bg-red-500/20 text-red-400' 
                    : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400'
                }`}
                title={timerActive ? 'Pausar Timer' : 'Retomar Timer'}
              >
                {timerActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* OPERATOR ACCESS CONTROL BAR */}
          <div className={`p-3 text-2xs font-bold border-b transition flex flex-col sm:flex-row items-center justify-between gap-2.5 ${
            hasEditPermission 
              ? 'bg-emerald-950/25 border-emerald-900/50 text-emerald-400' 
              : 'bg-red-950/25 border-red-950/50 text-red-400 font-medium'
          }`}>
            <div className="flex items-center gap-2">
              {hasEditPermission ? (
                <>
                  <Unlock className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    Placar Desbloqueado para Edição como:{' '}
                    <strong className="uppercase text-[11px] text-emerald-305">
                      {isMasterOrAdmin ? 'Usuário Master / Admin' : isMesario ? 'Mesário' : isAssignedReferee ? `Árbitro Escalado (${sessionUser?.name})` : `Auto-Declarado (${operatorBypass === 'arbitro' ? 'Árbitro' : operatorBypass === 'mesario' ? 'Mesário' : 'Master'})`}
                    </strong>
                  </span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4 text-red-400 shrink-0 animate-pulse" />
                  <span>
                    Modo Leitura — Apenas o Árbitro escalado, Mesários ou o Master podem alterar este placar.
                  </span>
                </>
              )}
            </div>

            {/* Simulating capabilities in UI for seamless demonstration */}
            <div className="flex items-center gap-1.5 shrink-0 select-none">
              <span className="text-slate-400 text-[10px]">Identificar-se como:</span>
              <select
                value={operatorBypass}
                onChange={(e) => {
                  const val = e.target.value as any;
                  setOperatorBypass(val);
                  if (val !== 'none') {
                    triggerToast(`Modo simulado: Operando como ${val === 'master' ? 'Master' : val === 'arbitro' ? 'Árbitro Escalado' : 'Mesário'}!`, "success");
                  } else {
                    triggerToast("Modo leitura restrito ativado.", "info");
                  }
                }}
                className="bg-slate-950/95 border border-slate-800 text-slate-250 text-xs rounded px-2.2 py-1 font-bold outline-none cursor-pointer hover:border-slate-700 transition"
              >
                <option value="none">Espectador (Apenas Leitura)</option>
                <option value="arbitro">Árbitro Escalado (Mesa)</option>
                <option value="mesario">Mesário de Mesa</option>
                <option value="master">Administrador Master</option>
              </select>
            </div>
          </div>

          {/* DUAL SCORING COLUMNS */}
          <div className="flex-1 grid grid-cols-2 relative min-h-[300px]">
            
            {/* Net / Separator in the middle */}
            <div className="absolute inset-y-0 left-1/2 -translate-x-px w-0.5 bg-slate-800/80 z-20 flex flex-col justify-center items-center pointer-events-none">
              <div className="bg-slate-950 text-slate-400 text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded border border-slate-800 shadow">
                REDE
              </div>
            </div>

            {/* PLAYER A SCORING BLOCK */}
            <div className={`p-6 flex flex-col justify-between items-center transition relative group ${
              service === 'A' ? 'bg-emerald-950/10' : 'bg-transparent'
            }`}>
              
              {/* Service Indicator Badge */}
              <div className="h-8 flex justify-center items-center">
                {service === 'A' ? (
                  <div className="text-emerald-400 text-3xs font-extrabold uppercase px-2.5 py-1 bg-emerald-500/15 rounded-full border border-emerald-500/30 tracking-widest flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping font-mono"></span>
                    SAQUE PRO / SERVING
                  </div>
                ) : (
                  <button 
                    onClick={toggleServerManually}
                    className="text-slate-600 hover:text-slate-400 text-4xs uppercase tracking-widest font-black transition cursor-pointer"
                  >
                    Alternar Saque
                  </button>
                )}
              </div>

              {/* Player card name and club details */}
              <div className="text-center space-y-1 z-10 max-w-[90%]">
                <div className="flex items-center justify-center gap-1.5 min-h-[16px]">
                  <span className="text-[10px] uppercase font-bold text-emerald-500">Jogador A</span>
                  {Array.from({ length: yellowCardsA }).map((_, i) => (
                    <span key={`y-a-${i}`} className="w-2.5 h-3.5 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0 animate-bounce" title="Cartão Amarelo" />
                  ))}
                  {Array.from({ length: redCardsA }).map((_, i) => (
                    <span key={`r-a-${i}`} className="w-2.5 h-3.5 bg-red-650 rounded-sm border border-red-750 block shrink-0 animate-bounce" title="Cartão Vermelho" />
                  ))}
                </div>
                <h4 className="font-black text-slate-100 text-base leading-tight truncate">
                  {athleteA?.nome || 'Selecione Jogador A'}
                </h4>
                <p className="text-3xs text-slate-400 truncate max-w-[150px]">
                  {athleteA?.clube || 'Nenhum Clube Cadastrado'}
                </p>
              </div>

              {/* HUGE DIGIT PRESSURE SENSITIVE INCREMENT CARD */}
              <div 
                onClick={() => adjustScore('A', 'add')}
                className="my-5 flex flex-col items-center justify-center cursor-pointer select-none active:scale-95 duration-100 hover:text-yellow-300 w-full max-w-[200px]"
              >
                <span className="text-7xl sm:text-8xl md:text-9xl font-black text-slate-100 font-mono tracking-tighter leading-none hover:scale-105 duration-150 transition drop-shadow-md">
                   {scoreA}
                </span>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Toque para somar</span>
              </div>

              {/* MANUAL PLUS MINUS HUD */}
              <div className="flex flex-col items-center gap-3 w-full z-10">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => adjustScore('A', 'sub')}
                    className="w-10 h-10 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-red-400 hover:bg-slate-750 duration-100 rounded-full border border-slate-700/80 active:scale-90"
                    title="Subtrair Ponto"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="text-slate-300 font-black text-xs font-mono select-none px-3 py-1 bg-slate-950/60 rounded border border-slate-800 shadow">
                    SET WON A: <span className="text-yellow-400 font-extrabold">{setsWonA}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => adjustScore('A', 'add')}
                    className="w-10 h-10 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-emerald-400 hover:bg-slate-755 duration-100 rounded-full border border-slate-700/80 active:scale-90 animate-pulse"
                    title="Somar Ponto"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Punishment Cards Control Panel */}
                <div className="flex flex-col items-center gap-2 bg-slate-950/50 p-2 rounded-xl border border-slate-850 w-full max-w-[190px]">
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-455">Punições (A):</span>
                    <div className="flex gap-2">
                      {/* Yellow Card adjustments */}
                      <div className="flex items-center bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 gap-1" title="Cartão Amarelo">
                        <span className="w-2.5 h-3.5 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0" />
                        <span className="text-2xs font-mono text-slate-200 font-bold">{yellowCardsA}</span>
                        <div className="flex flex-col font-mono text-[8px] leading-3 ml-1">
                          <button onClick={() => guardAction(() => setYellowCardsA(c => c + 1), "Apenas o árbitro/juiz ou o master podem aplicar punições!")} className="text-emerald-400 hover:text-emerald-300 font-bold text-center">+</button>
                          <button onClick={() => guardAction(() => setYellowCardsA(c => Math.max(0, c - 1)), "Apenas o árbitro/juiz ou o master podem remover punições!")} className="text-red-400 hover:text-red-300 font-bold text-center">-</button>
                        </div>
                      </div>

                      {/* Red Card adjustments */}
                      <div className="flex items-center bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 gap-1" title="Cartão Vermelho">
                        <span className="w-2.5 h-3.5 bg-red-650 rounded-sm border border-red-750 block shrink-0" />
                        <span className="text-2xs font-mono text-slate-200 font-bold">{redCardsA}</span>
                        <div className="flex flex-col font-mono text-[8px] leading-3 ml-1">
                          <button 
                            onClick={() => {
                              guardAction(() => {
                                setRedCardsA(c => c + 1);
                                if (confirm("Cartão Vermelho: Deseja creditar automaticamente +1 ponto de penalidade para o adversário (Jogador B)?")) {
                                  setScoreB(p => p + 1);
                                }
                              }, "Apenas o árbitro/juiz ou o master podem aplicar punições!");
                            }} 
                            className="text-emerald-400 hover:text-emerald-350 font-bold text-center"
                          >
                            +
                          </button>
                          <button onClick={() => guardAction(() => setRedCardsA(c => Math.max(0, c - 1)), "Apenas o árbitro/juiz ou o master podem remover punições!")} className="text-red-400 hover:text-red-350 font-bold text-center">-</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Walkover Button */}
                  {!gameOver && athleteAId && (
                    <button
                      type="button"
                      onClick={() => handleDeclareWO('A')}
                      className="w-full text-[9px] uppercase tracking-wider font-extrabold py-1 px-2 border border-red-500/25 hover:border-red-500 bg-red-500/5 hover:bg-red-500/10 text-red-400 rounded transition cursor-pointer text-center font-mono leading-none"
                    >
                      Aplicar Falta (W.O.)
                    </button>
                  )}
                </div>
              </div>

            </div>

            {/* PLAYER B SCORING BLOCK */}
            <div className={`p-6 flex flex-col justify-between items-center transition relative group ${
              service === 'B' ? 'bg-emerald-950/10' : 'bg-transparent'
            }`}>
              
              {/* Service Indicator Badge */}
              <div className="h-8 flex justify-center items-center">
                {service === 'B' ? (
                  <div className="text-emerald-400 text-3xs font-extrabold uppercase px-2.5 py-1 bg-emerald-500/15 rounded-full border border-emerald-500/30 tracking-widest flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-405 animate-ping"></span>
                    SAQUE PRO / SERVING
                  </div>
                ) : (
                  <button 
                    onClick={toggleServerManually}
                    className="text-slate-600 hover:text-slate-400 text-4xs uppercase tracking-widest font-black transition cursor-pointer"
                  >
                    Alternar Saque
                  </button>
                )}
              </div>

              {/* Player card name and club details */}
              <div className="text-center space-y-1 z-10 max-w-[90%]">
                <div className="flex items-center justify-center gap-1.5 min-h-[16px]">
                  <span className="text-[10px] uppercase font-bold text-emerald-500">Jogador B</span>
                  {Array.from({ length: yellowCardsB }).map((_, i) => (
                    <span key={`y-b-${i}`} className="w-2.5 h-3.5 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0 animate-bounce" title="Cartão Amarelo" />
                  ))}
                  {Array.from({ length: redCardsB }).map((_, i) => (
                    <span key={`r-b-${i}`} className="w-2.5 h-3.5 bg-red-650 rounded-sm border border-red-750 block shrink-0 animate-bounce" title="Cartão Vermelho" />
                  ))}
                </div>
                <h4 className="font-black text-slate-100 text-base leading-tight truncate">
                  {athleteB?.nome || 'Selecione Jogador B'}
                </h4>
                <p className="text-3xs text-slate-400 truncate max-w-[150px]">
                  {athleteB?.clube || 'Nenhum Clube Cadastrado'}
                </p>
              </div>

              {/* HUGE DIGIT PRESSURE SENSITIVE INCREMENT CARD */}
              <div 
                onClick={() => adjustScore('B', 'add')}
                className="my-5 flex flex-col items-center justify-center cursor-pointer select-none active:scale-95 duration-100 hover:text-yellow-300 w-full max-w-[200px]"
              >
                <span className="text-7xl sm:text-8xl md:text-9xl font-black text-slate-100 font-mono tracking-tighter leading-none hover:scale-105 duration-150 transition drop-shadow-md">
                  {scoreB}
                </span>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Toque para somar</span>
              </div>

              {/* MANUAL PLUS MINUS HUD */}
              <div className="flex flex-col items-center gap-3 w-full z-10">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => adjustScore('B', 'sub')}
                    className="w-10 h-10 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-red-400 hover:bg-slate-755 duration-100 rounded-full border border-slate-700/80 active:scale-90"
                    title="Subtrair Ponto"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <div className="text-slate-300 font-black text-xs font-mono select-none px-3 py-1 bg-slate-950/60 rounded border border-slate-800 shadow">
                    SET WON B: <span className="text-yellow-400 font-extrabold">{setsWonB}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => adjustScore('B', 'add')}
                    className="w-10 h-10 flex items-center justify-center font-bold bg-slate-800 text-slate-400 hover:text-emerald-400 hover:bg-slate-755 duration-100 rounded-full border border-slate-700/80 active:scale-90 animate-pulse"
                    title="Somar Ponto"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Punishment Cards Control Panel */}
                <div className="flex flex-col items-center gap-2 bg-slate-950/50 p-2 rounded-xl border border-slate-850 w-full max-w-[190px]">
                  <div className="flex items-center justify-between w-full">
                    <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-450">Punições (B):</span>
                    <div className="flex gap-2">
                      {/* Yellow Card adjustments */}
                      <div className="flex items-center bg-slate-900 border border-slate-800 rounded px-1.5 py-0.5 gap-1" title="Cartão Amarelo">
                        <span className="w-2.5 h-3.5 bg-yellow-400 rounded-sm border border-yellow-500 block shrink-0" />
                        <span className="text-2xs font-mono text-slate-200 font-bold">{yellowCardsB}</span>
                        <div className="flex flex-col font-mono text-[8px] leading-3 ml-1">
                          <button onClick={() => guardAction(() => setYellowCardsB(c => c + 1), "Apenas o árbitro/juiz ou o master podem aplicar punições!")} className="text-emerald-400 hover:text-emerald-300 font-bold text-center">+</button>
                          <button onClick={() => guardAction(() => setYellowCardsB(c => Math.max(0, c - 1)), "Apenas o árbitro/juiz ou o master podem remover punições!")} className="text-red-400 hover:text-red-300 font-bold text-center">-</button>
                        </div>
                      </div>

                      {/* Red Card adjustments */}
                      <div className="flex items-center bg-slate-905 border border-slate-800 rounded px-1.5 py-0.5 gap-1" title="Cartão Vermelho">
                        <span className="w-2.5 h-3.5 bg-red-650 rounded-sm border border-red-750 block shrink-0" />
                        <span className="text-2xs font-mono text-slate-200 font-bold">{redCardsB}</span>
                        <div className="flex flex-col font-mono text-[8px] leading-3 ml-1">
                          <button 
                            onClick={() => {
                              guardAction(() => {
                                setRedCardsB(c => c + 1);
                                if (confirm("Cartão Vermelho: Deseja creditar automaticamente +1 ponto de penalidade para o adversário (Jogador A)?")) {
                                  setScoreA(p => p + 1);
                                }
                              }, "Apenas o árbitro/juiz ou o master podem aplicar punições!");
                            }} 
                            className="text-emerald-400 hover:text-emerald-305 font-bold text-center"
                          >
                            +
                          </button>
                          <button onClick={() => guardAction(() => setRedCardsB(c => Math.max(0, c - 1)), "Apenas o árbitro/juiz ou o master podem remover punições!")} className="text-red-400 hover:text-red-305 font-bold text-center">-</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Walkover Button */}
                  {!gameOver && athleteBId && (
                    <button
                      type="button"
                      onClick={() => handleDeclareWO('B')}
                      className="w-full text-[9px] uppercase tracking-wider font-extrabold py-1 px-2 border border-red-500/25 hover:border-red-500 bg-red-500/5 hover:bg-red-500/10 text-red-400 rounded transition cursor-pointer text-center font-mono leading-none"
                    >
                      Aplicar Falta (W.O.)
                    </button>
                  )}
                </div>
              </div>

            </div>

          </div>

          {/* FOOTER ACTIONS AREA */}
          <div className="bg-slate-950 p-4 border-t border-slate-800 flex justify-between items-center px-6">
            <button
              onClick={handleFullReset}
              className="text-slate-400 hover:text-red-400 duration-150 transition text-2xs font-extrabold uppercase flex items-center gap-2 cursor-pointer bg-transparent border border-slate-805 hover:border-red-500/40 px-3 py-2 rounded-lg"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Resetar Placar
            </button>

            {gameOver && (
              <div className="text-yellow-400 text-2xs uppercase tracking-widest font-black animate-bounce">
                🎉 JOGO FINALIZADO! Vencedor: {winner === 'A' ? (athleteA?.nome || 'Jogador A') : (athleteB?.nome || 'Jogador B')}
              </div>
            )}

            <button
              onClick={handleSaveResult}
              disabled={!gameOver && (setsWonA === 0 && setsWonB === 0)}
              className={`text-2xs font-extrabold py-2 px-4 rounded-lg flex items-center gap-1.5 transition ${
                gameOver || (setsWonA > 0 || setsWonB > 0)
                  ? 'bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black cursor-pointer shadow-lg shadow-yellow-400/15'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              Lançar e Concluir Partida
            </button>
          </div>

        </div>

        {/* SIDEBAR DETAILED RECAP STATS (COL SPAN 4) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-5 shadow-sm">
          
          <div className="space-y-4 flex-1">
            <h4 className="text-xs font-black text-slate-100 uppercase tracking-widest flex items-center gap-2 pb-3 border-b border-slate-800 leading-none">
              <Trophy className="w-4 h-4 text-slate-500" />
              Súmula Digital
            </h4>

            {/* Current Match Parameters */}
            <div className="space-y-2 background-slate-950 bg-slate-950/40 p-3 rounded-lg border border-slate-850">
              <div className="flex justify-between text-2xs font-semibold">
                <span className="text-slate-400">Torneio:</span>
                <span className="text-slate-200 truncate max-w-[200px]" title={currentTorneio?.nome || 'Livre'}>
                  {currentTorneio?.nome || 'Livre'}
                </span>
              </div>
              <div className="flex justify-between text-2xs font-semibold">
                <span className="text-slate-400">Categoria:</span>
                <span className="text-slate-200 truncate font-mono">
                  {currentCat?.nome || 'Não definida'}
                </span>
              </div>
              <div className="flex justify-between text-2xs font-semibold">
                <span className="text-slate-400">Árbitro Oficial:</span>
                <span className="text-slate-200 font-bold">
                  {currentArb?.nome || 'Delegar Árbitro'}
                </span>
              </div>
              <div className="flex justify-between text-2xs font-semibold">
                <span className="text-slate-400">Modelo:</span>
                <span className="text-slate-200 font-mono">
                  Melhor de {maxSets} Sets ({pointsPerSet} pts)
                </span>
              </div>
            </div>

            {/* Set History Progression */}
            <div className="space-y-2.5">
              <label className="text-3xs uppercase tracking-widest text-slate-500 font-extrabold block">
                Histórico de Sets da Partida
              </label>

              {setHistory.length > 0 ? (
                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {setHistory.map((sh) => {
                    const isWinnerA = sh.scoreA > sh.scoreB;
                    return (
                      <div 
                        key={sh.setNum}
                        className="flex items-center justify-between bg-slate-950/60 border border-slate-805 rounded-xl px-4 py-2.5 font-mono"
                      >
                        <span className="text-slate-400 text-xs font-bold uppercase">
                          Set {sh.setNum}
                        </span>
                        
                        <div className="flex items-center gap-2 text-sm font-black">
                          <span className={isWinnerA ? 'text-yellow-400 font-black scale-105' : 'text-slate-400'}>
                            {sh.scoreA}
                          </span>
                          <span className="text-slate-600 font-medium">×</span>
                          <span className={!isWinnerA ? 'text-yellow-400 font-black scale-105' : 'text-slate-400'}>
                            {sh.scoreB}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-8 bg-slate-950/20 text-center text-slate-500 italic text-2xs border border-dashed border-slate-800 rounded-xl">
                  Nenhum set finalizado neste jogo.
                </div>
              )}
            </div>

            {/* Quick Rules reminder block */}
            <div className="bg-yellow-400/5 p-3.5 border border-yellow-400/10 rounded-lg text-3xs text-slate-400 leading-normal">
              <span className="font-extrabold uppercase text-yellow-400 block mb-1">Dica de Arbitragem:</span>
              O saque alterna automaticamente a cada 2 pontos totais. Se a partida empatar por 10×10, a regra de deuce é ativada, alternando o saque a cada ponto até que um competidor abra 2 pontos de vantagem.
            </div>

          </div>

          <div className="border-t border-slate-800 pt-3.5 mt-2 flex flex-col justify-end gap-2.5">
            {onNavigate && (
              <button
                onClick={() => onNavigate('resultados')}
                className="w-full bg-slate-950 hover:bg-slate-850 text-slate-300 font-bold py-2.5 rounded-lg text-2xs transition flex items-center justify-center gap-1.5 cursor-pointer border border-slate-800"
              >
                Voltar à Grade de Resultados
              </button>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
