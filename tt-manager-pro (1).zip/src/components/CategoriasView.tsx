import React, { useState } from 'react';
import { Categoria, Atleta } from '../types';
import { getDefaultOfficialCategories } from '../utils/defaultCategories';
import { Search, Plus, Edit, Trash2, Tag, Save, X, Zap, Users, Sparkles, CheckCircle2 } from 'lucide-react';

interface CategoriasViewProps {
  categorias: Categoria[];
  atletas?: Atleta[];
  onSave: (categoria: Categoria) => void;
  onSaveMultiple?: (categorias: Categoria[]) => void;
  onDelete: (id: string) => void;
  userRole?: 'comum' | 'admin' | 'master';
}

export default function CategoriasView({ categorias, atletas = [], onSave, onSaveMultiple, onDelete, userRole = 'comum' }: CategoriasViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const activeAthletes = atletas.filter(a => a.status === 'Ativo' || !a.status);

  // Auto Generate Categories directly from Athlete Registration List
  const handleGenerateFromAthletes = () => {
    if (!onSaveMultiple) {
      alert("Operação em lote não suportada pelo componente pai.");
      return;
    }
    if (!atletas || atletas.length === 0) {
      alert("Nenhum atleta cadastrado no sistema para gerar categorias automaticamente.");
      return;
    }

    if (activeAthletes.length === 0) {
      alert("Nenhum atleta ativo encontrado no cadastro.");
      return;
    }

    const currentYear = new Date().getFullYear();
    const generatedCategoriesMap = new Map<string, Categoria>();

    // 1. Process explicit categories declared on athlete profiles (a.cat)
    activeAthletes.forEach(ath => {
      if (ath.cat && ath.cat.trim() && ath.cat.trim().toLowerCase() !== 'geral') {
        const catName = ath.cat.trim();
        if (!generatedCategoriesMap.has(catName.toLowerCase())) {
          let idmin = '0';
          let idmax = '99';
          const lowerName = catName.toLowerCase();
          
          if (lowerName.includes('sub-9') || lowerName.includes('sub 9')) { idmin = '0'; idmax = '9'; }
          else if (lowerName.includes('sub-11') || lowerName.includes('sub 11')) { idmin = '0'; idmax = '11'; }
          else if (lowerName.includes('sub-13') || lowerName.includes('sub 13')) { idmin = '0'; idmax = '13'; }
          else if (lowerName.includes('sub-15') || lowerName.includes('sub 15')) { idmin = '0'; idmax = '15'; }
          else if (lowerName.includes('sub-19') || lowerName.includes('sub 19')) { idmin = '0'; idmax = '19'; }
          else if (lowerName.includes('sub-21') || lowerName.includes('sub 21')) { idmin = '0'; idmax = '21'; }
          else if (lowerName.includes('adulto') || lowerName.includes('absoluto')) { idmin = '19'; idmax = '39'; }
          else if (lowerName.includes('veterano') || lowerName.includes('sênior') || lowerName.includes('senior')) { idmin = '40'; idmax = '99'; }

          let genero = 'Misto';
          if (lowerName.includes('fem') || ath.genero?.toLowerCase() === 'feminino') { genero = 'Feminino'; }
          else if (lowerName.includes('masc') || ath.genero?.toLowerCase() === 'masculino') { genero = 'Masculino'; }

          generatedCategoriesMap.set(catName.toLowerCase(), {
            id: `cat_ath_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            nome: catName,
            tipo: 'Simples',
            genero,
            idmin,
            idmax,
            rmin: '0',
            rmax: '9999',
            fmt: 'Eliminatória Simples',
            max: '',
            desc: `Categoria gerada automaticamente pelo perfil dos atletas.`
          });
        }
      }
    });

    // 2. Process Athlete Birth Dates / Ages & Genders
    const ageBrackets = [
      { name: 'Sub-9', idmin: '0', idmax: '9' },
      { name: 'Sub-11', idmin: '10', idmax: '11' },
      { name: 'Sub-13', idmin: '12', idmax: '13' },
      { name: 'Sub-15', idmin: '14', idmax: '15' },
      { name: 'Sub-19', idmin: '16', idmax: '19' },
      { name: 'Adulto', idmin: '20', idmax: '39' },
      { name: 'Veterano (40+)', idmin: '40', idmax: '99' },
    ];

    ageBrackets.forEach(bracket => {
      const minAge = parseInt(bracket.idmin);
      const maxAge = parseInt(bracket.idmax);

      const matchingAthletes = activeAthletes.filter(ath => {
        if (!ath.nasc) return false;
        const bYear = new Date(ath.nasc).getFullYear();
        if (isNaN(bYear)) return false;
        const age = currentYear - bYear;
        return age >= minAge && age <= maxAge;
      });

      if (matchingAthletes.length > 0) {
        const hasMale = matchingAthletes.some(a => a.genero?.toLowerCase() === 'masculino');
        const hasFemale = matchingAthletes.some(a => a.genero?.toLowerCase() === 'feminino');

        if (hasMale) {
          const catName = `${bracket.name} Masculino`;
          if (!generatedCategoriesMap.has(catName.toLowerCase())) {
            generatedCategoriesMap.set(catName.toLowerCase(), {
              id: `cat_age_m_${bracket.name.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
              nome: catName,
              tipo: 'Simples',
              genero: 'Masculino',
              idmin: bracket.idmin,
              idmax: bracket.idmax,
              rmin: '0',
              rmax: '9999',
              fmt: 'Eliminatória Simples',
              max: '',
              desc: `Gerada para atletas masculinos desta faixa etária.`
            });
          }
        }

        if (hasFemale) {
          const catName = `${bracket.name} Feminino`;
          if (!generatedCategoriesMap.has(catName.toLowerCase())) {
            generatedCategoriesMap.set(catName.toLowerCase(), {
              id: `cat_age_f_${bracket.name.toLowerCase().replace(/[^a-z0-9]/g, '')}`,
              nome: catName,
              tipo: 'Simples',
              genero: 'Feminino',
              idmin: bracket.idmin,
              idmax: bracket.idmax,
              rmin: '0',
              rmax: '9999',
              fmt: 'Eliminatória Simples',
              max: '',
              desc: `Gerada para atletas femininas desta faixa etária.`
            });
          }
        }
      }
    });

    // 3. Process Levels ('Iniciante', 'Intermediário', 'Avançado', 'Elite')
    const levels = Array.from(new Set(activeAthletes.map(a => a.nivel).filter(Boolean)));
    levels.forEach(lvl => {
      const catName = `Nível ${lvl}`;
      if (!generatedCategoriesMap.has(catName.toLowerCase())) {
        generatedCategoriesMap.set(catName.toLowerCase(), {
          id: `cat_lvl_${lvl.toLowerCase()}`,
          nome: catName,
          tipo: 'Simples',
          genero: 'Livre',
          idmin: '0',
          idmax: '99',
          rmin: '0',
          rmax: '9999',
          fmt: 'Eliminatória Simples',
          max: '',
          desc: `Gerada automaticamente para atletas do nível ${lvl}.`
        });
      }
    });

    // Merge with existing categories
    const existingMap = new Map(categorias.map(c => [c.nome.toLowerCase(), c]));
    let createdCount = 0;
    generatedCategoriesMap.forEach((newCat, key) => {
      if (!existingMap.has(key)) {
        existingMap.set(key, newCat);
        createdCount++;
      }
    });

    const finalCategoryList = Array.from(existingMap.values());
    onSaveMultiple(finalCategoryList);

    alert(`🎉 Categorias Geradas com Sucesso!\n\nAnalisados ${activeAthletes.length} atletas cadastrados. ${createdCount} novas categorias foram adicionadas (Total: ${finalCategoryList.length}).`);
  };

  const handleAutoGenerateAgeCategories = () => {
    if (!onSaveMultiple) {
      alert("Operação em lote não suportada pelo componente pai.");
      return;
    }
    const confirmGen = confirm(
      "Deseja gerar automaticamente TODAS as categorias oficiais de jogo (Sub-9 a Veteranos e Ratings A a E) para chaveamento automático? Categorias existentes com o mesmo nome serão preservadas."
    );
    if (!confirmGen) return;

    const defaultList = getDefaultOfficialCategories();

    const toSave: Categoria[] = defaultList.map((preset, idx) => {
      const existing = categorias.find(c => c.nome.toLowerCase() === preset.nome.toLowerCase());
      return {
        ...preset,
        id: existing?.id || preset.id || `cat_auto_${idx}_` + Date.now().toString(36),
      };
    });

    onSaveMultiple(toSave);
    alert(`🎉 ${toSave.length} Categorias oficiais geradas e preparadas com sucesso para o chaveamento automático!`);
  };

  // Form State
  const [formId, setFormId] = useState('');
  const [formNome, setFormNome] = useState('');
  const [formTipo, setFormTipo] = useState('Simples');
  const [formGenero, setFormGenero] = useState('Masculino');
  const [formIdMin, setFormIdMin] = useState('0');
  const [formIdMax, setFormIdMax] = useState('99');
  const [formRMin, setFormRMin] = useState('0');
  const [formRMax, setFormRMax] = useState('9999');
  const [formFmt, setFormFmt] = useState('Eliminatória Simples');
  const [formMax, setFormMax] = useState('');
  const [formDesc, setFormDesc] = useState('');

  const handleOpenModal = (c?: Categoria) => {
    if (c) {
      setFormId(c.id);
      setFormNome(c.nome);
      setFormTipo(c.tipo);
      setFormGenero(c.genero);
      setFormIdMin(c.idmin || '0');
      setFormIdMax(c.idmax || '99');
      setFormRMin(c.rmin || '0');
      setFormRMax(c.rmax || '9999');
      setFormFmt(c.fmt);
      setFormMax(c.max || '');
      setFormDesc(c.desc || '');
    } else {
      setFormId('');
      setFormNome('');
      setFormTipo('Simples');
      setFormGenero('Masculino');
      setFormIdMin('0');
      setFormIdMax('99');
      setFormRMin('0');
      setFormRMax('9999');
      setFormFmt('Eliminatória Simples');
      setFormMax('');
      setFormDesc('');
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formNome.trim()) {
      alert("Nome de categoria é obrigatório!");
      return;
    }
    const targetId = formId || 'cat_' + Date.now().toString(36);
    onSave({
      id: targetId,
      nome: formNome,
      tipo: formTipo,
      genero: formGenero,
      idmin: formIdMin,
      idmax: formIdMax,
      rmin: formRMin,
      rmax: formRMax,
      fmt: formFmt,
      max: formMax,
      desc: formDesc
    });
    setIsModalOpen(false);
  };

  const filteredCategories = categorias.filter(c =>
    c.nome.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Auto-Generation Hero Banner based on Athlete List */}
      <div className="bg-slate-900 border border-emerald-500/30 rounded-xl p-3.5 sm:p-4 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-3.5 relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-black px-2 py-0.5 rounded-md flex items-center gap-1 uppercase tracking-wide">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              Sincronização Automática
            </span>
            <span className="bg-slate-800 text-slate-300 text-[10px] font-bold px-2.5 py-0.5 rounded-md border border-slate-700/80 flex items-center gap-1">
              <Users className="w-3 h-3 text-emerald-400" />
              {activeAthletes.length} Atletas Cadastrados
            </span>
          </div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">
            Gerar Categorias Automaticamente pelos Atletas
          </h2>
          <p className="text-[11px] text-slate-400 max-w-2xl leading-normal">
            Analisa a lista de atletas (idades, gêneros, níveis e categorias) e cria instantaneamente todas as categorias necessárias.
          </p>
        </div>

        {userRole !== 'comum' && (
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto shrink-0 relative z-10">
            <button
              type="button"
              onClick={handleGenerateFromAthletes}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black px-3.5 py-2 rounded-lg text-xs flex items-center justify-center gap-2 shadow transition active:scale-95 cursor-pointer uppercase tracking-wider"
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
              <span>Gerar Categorias pelos Atletas</span>
            </button>

            <button
              type="button"
              onClick={handleAutoGenerateAgeCategories}
              className="bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold px-3 py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer uppercase tracking-wider"
            >
              <Tag className="w-3.5 h-3.5 text-emerald-400" />
              <span>Padrão Oficial (Sub-9 a Vet)</span>
            </button>
          </div>
        )}
      </div>

      {/* Parameter filtering search bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar categoria por título..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-10 pr-4 py-2 text-sm outline-none transition"
          />
        </div>

        {userRole !== 'comum' && (
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto shrink-0">
            <button
              onClick={() => handleOpenModal()}
              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-4 py-2 rounded-lg text-sm flex items-center justify-center gap-2 cursor-pointer transition shadow-lg"
            >
              <Plus className="w-4 h-4" />
              Nova Categoria
            </button>
          </div>
        )}
      </div>

      {/* Main List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm text-slate-200">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/20 text-slate-400 text-2xs uppercase tracking-wider font-semibold">
                <th className="py-3 px-4 w-12 text-center">#</th>
                <th className="py-3 px-4">Nome Categoria</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Gênero</th>
                <th className="py-3 px-4">Faixa de Idade</th>
                <th className="py-3 px-4 text-center">Faixa de Rating</th>
                <th className="py-3 px-4 text-center">Formato Chaveamento</th>
                <th className="py-3 px-4 text-center w-28">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredCategories.length > 0 ? (
                filteredCategories.map((c, i) => (
                  <tr key={c.id} className="hover:bg-slate-950/20 transition-colors">
                    <td className="py-3.5 px-4 text-center text-slate-500 font-mono text-xs">{i+1}</td>
                    <td className="py-3.5 px-4 font-bold text-slate-100">{c.nome}</td>
                    <td className="py-3.5 px-4 text-xs whitespace-nowrap">
                      <span className="bg-blue-400/10 text-blue-400 border border-blue-400/20 px-2 py-0.5 rounded font-bold">
                        {c.tipo}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 text-xs">{c.genero}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-400 text-xs">
                      {c.idmin === '0' && c.idmax === '99' ? 'Livre' : `${c.idmin || 0} a ${c.idmax || 99} anos`}
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono text-slate-400 text-xs">
                      {c.rmin || '0'} – {c.rmax || '9999'}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="text-2xs font-extrabold uppercase bg-slate-800 text-slate-300 px-2 py-0.5 border border-slate-700/80 rounded">
                        {c.fmt}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        {userRole !== 'comum' && (
                          <button
                            onClick={() => handleOpenModal(c)}
                            className="p-1.5 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded-md transition"
                            title="Editar"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        {userRole === 'master' && (
                          <button
                            onClick={() => {
                              if (confirm(`Deseja mesmo remover a categoria "${c.nome}"?`)) {
                                onDelete(c.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-md transition-colors"
                            title="Excluir"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    Nenhuma categoria registrada ainda.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CATEGORY FORM MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg overflow-hidden flex flex-col shadow-2xl">
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 flex items-center gap-2">
                <Tag className="w-4 h-4 text-yellow-400" />
                {formId ? 'Editar Categoria' : 'Nova Categoria'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form body */}
            <div className="p-6 overflow-y-auto space-y-4 max-h-[80vh]">
              <div className="bg-slate-950/45 p-3.5 rounded-lg border border-slate-800/60 space-y-1.5 shadow-inner">
                <label className="text-[10px] uppercase tracking-wider text-yellow-400 font-black block">Preencher com Faixa Etária Padrão</label>
                <select
                  onChange={(e) => {
                    const val = e.target.value;
                    if (!val) return;
                    const selected = JSON.parse(val);
                    setFormNome(selected.nome);
                    setFormIdMin(selected.idmin);
                    setFormIdMax(selected.idmax);
                    setFormDesc(selected.desc);
                    setFormGenero('Livre');
                  }}
                  className="w-full bg-slate-950 border border-slate-850 focus:border-yellow-400 rounded-md px-2.5 py-1.5 text-xs text-slate-200 outline-none"
                >
                  <option value="">-- Selecione uma classe de idade padrão --</option>
                  <option value={JSON.stringify({ nome: 'Sub-9 Geral', idmin: '0', idmax: '9', desc: 'Atletas com idade de até 9 anos completos.' })}>Sub-9 Geral (Até 9 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-11 Geral', idmin: '10', idmax: '11', desc: 'Atletas com idade entre 10 e 11 anos completos.' })}>Sub-11 Geral (10 a 11 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-13 Geral', idmin: '12', idmax: '13', desc: 'Atletas com idade entre 12 e 13 anos completos.' })}>Sub-13 Geral (12 a 13 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-15 Geral', idmin: '14', idmax: '15', desc: 'Atletas com idade entre 14 e 15 anos completos.' })}>Sub-15 Geral (14 a 15 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-17 Geral', idmin: '16', idmax: '17', desc: 'Atletas com idade entre 16 e 17 anos completos.' })}>Sub-17 Geral (16 a 17 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-19 Geral', idmin: '18', idmax: '19', desc: 'Atletas com idade entre 18 e 19 anos completos.' })}>Sub-19 Geral (18 a 19 anos)</option>
                  <option value={JSON.stringify({ nome: 'Sub-21 Geral', idmin: '20', idmax: '21', desc: 'Atletas com idade entre 20 e 21 anos completos.' })}>Sub-21 Geral (20 a 21 anos)</option>
                  <option value={JSON.stringify({ nome: 'Adulto Geral', idmin: '22', idmax: '39', desc: 'Atletas na categoria adulta de 22 a 39 anos.' })}>Adulto Geral (22 a 39 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +40', idmin: '40', idmax: '49', desc: 'Atletas veteranos com idade de 40 a 49 anos.' })}>Veterano +40 (40 a 49 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +50', idmin: '50', idmax: '59', desc: 'Atletas veteranos com idade de 50 e 59 anos.' })}>Veterano +50 (50 e 59 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +60', idmin: '60', idmax: '69', desc: 'Atletas veteranos com idade de 60 e 69 anos.' })}>Veterano +60 (60 e 69 anos)</option>
                  <option value={JSON.stringify({ nome: 'Veterano +70', idmin: '70', idmax: '99', desc: 'Atletas veteranos com idade de 70 anos em diante.' })}>Veterano +70 (70 a 99 anos)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Nome de Categoria *</label>
                <input
                  type="text"
                  placeholder="Ex: Sub-17 Masculino"
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 cursor-text rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Tipo</label>
                  <select
                    value={formTipo}
                    onChange={(e) => setFormTipo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Simples">Simples</option>
                    <option value="Duplas">Duplas</option>
                    <option value="Misto">Misto</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Gênero</label>
                  <select
                    value={formGenero}
                    onChange={(e) => setFormGenero(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Masculino">Masculino</option>
                    <option value="Feminino">Feminino</option>
                    <option value="Misto">Misto</option>
                    <option value="Livre">Livre</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Idade Mínima</label>
                  <input
                    type="number"
                    value={formIdMin}
                    onChange={(e) => setFormIdMin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Idade Máxima</label>
                  <input
                    type="number"
                    value={formIdMax}
                    onChange={(e) => setFormIdMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Rating Mínimo</label>
                  <input
                    type="number"
                    value={formRMin}
                    onChange={(e) => setFormRMin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Rating Máximo</label>
                  <input
                    type="number"
                    value={formRMax}
                    onChange={(e) => setFormRMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Formato Chaveamento</label>
                  <select
                    value={formFmt}
                    onChange={(e) => setFormFmt(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Eliminatória Simples">Eliminatória Simples</option>
                    <option value="Dupla Eliminação">Dupla Eliminação</option>
                    <option value="Round Robin">Round Robin</option>
                    <option value="Grupos + Eliminatória">Grupos + Eliminatória</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Max Participantes</label>
                  <input
                    type="number"
                    placeholder="Sem limite"
                    value={formMax}
                    onChange={(e) => setFormMax(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-2xs uppercase tracking-wider text-slate-400 font-bold block">Descrição / Notas Específicas</label>
                <textarea
                  rows={2}
                  placeholder="Restrições, regras ou especificações do chaveamento..."
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-100 focus:border-yellow-400 outline-none resize-none"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950/25">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-755 text-xs font-bold rounded-lg transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black rounded-lg transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Categoria
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
