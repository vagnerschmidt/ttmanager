import React, { useEffect } from 'react';
import { 
  Database, 
  CheckCircle2, 
  X, 
  Sparkles,
  ShieldCheck,
  Globe,
  Rocket
} from 'lucide-react';
import firebaseConfig from '../../firebase-applet-config.json';

interface CloudIntegrationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  autoSyncFirebase: boolean;
  onToggleAutoSyncFirebase: (enabled: boolean) => void;
  onOpenAutoDeploy?: () => void;
  getCurrentPayload?: () => any;
}

export default function CloudIntegrationsModal({
  isOpen,
  onClose,
  autoSyncFirebase,
  onToggleAutoSyncFirebase,
  onOpenAutoDeploy
}: CloudIntegrationsModalProps) {
  // Escape key handler to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!isOpen) return null;

  return (
    <div 
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-4"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-gradient-to-r from-teal-500/10 via-yellow-500/10 to-blue-500/10 flex justify-between items-center">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-9 sm:h-9 bg-teal-400/10 rounded-xl flex items-center justify-center border border-teal-400/20 text-teal-400 shrink-0">
              <Globe className="w-4 h-4 sm:w-4.5 sm:h-4.5 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-slate-100 text-xs sm:text-sm uppercase tracking-wider">
                  Sincronização Netlify & Banco de Dados Gratuito ⚡
                </h3>
                <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 px-1.5 py-0.5 rounded text-4xs font-black uppercase tracking-widest flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> ONLINE
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">
                Hospedagem e sincronização contínua via Netlify + Banco de dados gratuito em nuvem (Firebase Firestore)
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-100 rounded-lg transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 flex-1 overflow-y-auto">
          
          {/* Card 1: Netlify Free Hosting & Continuous Deployment */}
          <div className="bg-slate-950/70 border-2 border-teal-500/40 hover:border-teal-400/60 rounded-xl p-4 space-y-3 transition shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 flex items-center justify-center shrink-0">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2">
                    Netlify (Sincronização & Hospedagem Gratuita) 🌐
                  </h4>
                  <span className="text-3xs text-slate-300 font-mono">
                    Build: npm run build | Pasta: dist | Redirects: netlify.toml (200 OK)
                  </span>
                </div>
              </div>
              <a
                href="https://app.netlify.com/start"
                target="_blank"
                rel="noreferrer"
                className="bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs uppercase px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer shadow-md"
              >
                <Rocket className="w-3.5 h-3.5" />
                Conectar / Deploy no Netlify
              </a>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              O projeto conta com arquivo de configuração <code className="text-teal-300 bg-slate-900 px-1.5 py-0.5 rounded font-mono border border-teal-500/30">netlify.toml</code> pré-configurado e rotas SPA tratadas para publicação direta, rápida e 100% gratuita.
            </p>

            <div className="grid grid-cols-2 gap-3 text-3xs pt-1 border-t border-slate-850">
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Arquivo de Configuração:</span>
                <span className="text-teal-300 font-mono font-bold">netlify.toml (Configurado)</span>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Modo de Publicação:</span>
                <span className="text-emerald-400 font-bold">⚡ Gratuito & Ilimitado</span>
              </div>
            </div>
          </div>

          {/* Card 2: Firebase Cloud Firestore (Free Database) */}
          <div className="bg-slate-950/60 border border-yellow-500/30 hover:border-yellow-400/50 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 flex items-center justify-center shrink-0">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Banco de Dados Gratuito em Nuvem (Firebase Cloud Firestore)
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    ID: {firebaseConfig.projectId}
                  </span>
                </div>
              </div>
              <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-400/30 text-4xs font-black uppercase px-2 py-1 rounded flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-yellow-400" /> Banco Gratuito
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-3xs pt-1 border-t border-slate-850">
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Plano do Banco:</span>
                <span className="text-emerald-400 font-mono font-bold">Spark (100% Gratuito)</span>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-500 font-bold block uppercase">Sincronização Auto-Save:</span>
                <span className={autoSyncFirebase ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                  {autoSyncFirebase ? "⚡ Ativado (Em Tempo Real)" : "⏸️ Manual"}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-850">
              <span className="text-3xs text-slate-300 font-medium">Ativar sincronização automática do banco de dados em tempo real:</span>
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input 
                  type="checkbox" 
                  checked={autoSyncFirebase} 
                  onChange={(e) => onToggleAutoSyncFirebase(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-yellow-400 peer-checked:after:bg-slate-950"></div>
              </label>
            </div>
          </div>

          {/* Card 3: IndexedDB Local Offline Persistence */}
          <div className="bg-slate-950/50 border border-slate-800 hover:border-blue-400/30 rounded-xl p-4 space-y-3 transition">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
                    Banco de Dados Local Gratuito (IndexedDB Offline) 💾
                  </h4>
                  <span className="text-3xs text-slate-400 font-mono">
                    Engine: HTML5 IndexedDB | Armazenamento no Navegador
                  </span>
                </div>
              </div>
              <span className="bg-blue-500/10 text-blue-400 border border-blue-500/30 text-4xs font-black uppercase px-2.5 py-1 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-blue-400" /> Ativo & Local
              </span>
            </div>

            <p className="text-3xs text-slate-400 leading-relaxed">
              Armazena todos os registros do torneio, placares e atletas diretamente no navegador sem nenhum custo. Quando reconectado, sincroniza com o banco de dados gratuito Firebase.
            </p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-3 text-3xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Ícones inteligentes ativos • Dados seguros e autenticados</span>
          </div>
          <div className="flex items-center gap-2">
            {onOpenAutoDeploy && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAutoDeploy();
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-lg text-xs tracking-wider uppercase transition cursor-pointer flex items-center gap-1.5 shadow"
              >
                <Rocket className="w-3.5 h-3.5" />
                Deploy Automático 🚀
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-black rounded-lg text-xs tracking-wider uppercase transition cursor-pointer flex items-center gap-1.5 shadow"
            >
              Concluir & Voltar ao Menu Principal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
