import React, { useState, useEffect } from 'react';
import { X, Trash2, AlertTriangle, CheckCircle, RefreshCw, Users, Shield, UserCheck, Layers, Award, FileSpreadsheet } from 'lucide-react';
import { Atleta, Arbitro, Treinador, Funcionario, Torneio, Categoria, Inscricao } from '../types';
import { analyzeDuplicates, removeAndMergeDuplicates, DetailedDuplicatesReport } from '../utils/deduplication';
import { triggerToast } from '../utils/toast';

interface DeduplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  atletas: Atleta[];
  inscricoes: Inscricao[];
  arbitros: Arbitro[];
  treinadores: Treinador[];
  funcionarios: Funcionario[];
  categorias: Categoria[];
  torneios: Torneio[];
  onSaveAtletasBulk?: (clean: Atleta[]) => void;
  onSaveInscricoes?: (clean: Inscricao[]) => void;
  onSaveArbitrosBulk?: (clean: Arbitro[]) => void;
  onSaveTreinadoresBulk?: (clean: Treinador[]) => void;
  onSaveFuncionariosBulk?: (clean: Funcionario[]) => void;
  onSaveCategoriasBulk?: (clean: Categoria[]) => void;
  onSaveTorneiosBulk?: (clean: Torneio[]) => void;
}

export default function DeduplicationModal({
  isOpen,
  onClose,
  atletas,
  inscricoes,
  arbitros,
  treinadores,
  funcionarios,
  categorias,
  torneios,
  onSaveAtletasBulk,
  onSaveInscricoes,
  onSaveArbitrosBulk,
  onSaveTreinadoresBulk,
  onSaveFuncionariosBulk,
  onSaveCategoriasBulk,
  onSaveTorneiosBulk,
}: DeduplicationModalProps) {
  const [report, setReport] = useState<DetailedDuplicatesReport | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const rep = analyzeDuplicates(atletas, inscricoes, arbitros, treinadores, funcionarios, categorias, torneios);
      setReport(rep);
    }
  }, [isOpen, atletas, inscricoes, arbitros, treinadores, funcionarios, categorias, torneios]);

  if (!isOpen) return null;

  const handleRefresh = () => {
    const rep = analyzeDuplicates(atletas, inscricoes, arbitros, treinadores, funcionarios, categorias, torneios);
    setReport(rep);
    triggerToast('Varredura de duplicados atualizada!', 'info');
  };

  const handleExecuteCleanup = () => {
    if (!report || !report.hasDuplicates) {
      triggerToast('Nenhum registro duplicado foi encontrado para exclusão.', 'info');
      return;
    }

    if (!confirm('Deseja realmente deletar e mesclar todos os registros duplicados detectados no sistema? Essa ação atualizará as inscrições e manterá os dados mais recentes.')) {
      return;
    }

    setIsProcessing(true);

    try {
      const res = removeAndMergeDuplicates(
        atletas,
        inscricoes,
        arbitros,
        treinadores,
        funcionarios,
        categorias,
        torneios
      );

      if (onSaveAtletasBulk) onSaveAtletasBulk(res.cleanAtletas);
      if (onSaveInscricoes) onSaveInscricoes(res.cleanInscricoes);
      if (onSaveArbitrosBulk) onSaveArbitrosBulk(res.cleanArbitros);
      if (onSaveTreinadoresBulk) onSaveTreinadoresBulk(res.cleanTreinadores);
      if (onSaveFuncionariosBulk) onSaveFuncionariosBulk(res.cleanFuncionarios);
      if (onSaveCategoriasBulk) onSaveCategoriasBulk(res.cleanCategorias);
      if (onSaveTorneiosBulk) onSaveTorneiosBulk(res.cleanTorneios);

      triggerToast(`🎉 Limpeza concluída! ${res.summary.totalRemoved} registro(s) duplicado(s) deletado(s) e mesclado(s) com sucesso.`, 'success');

      setIsProcessing(false);
      onClose();
    } catch (err: any) {
      console.error(err);
      triggerToast(`Erro ao deletar registros duplicados: ${err.message || 'Erro inesperado'}`, 'error');
      setIsProcessing(false);
    }
  };

  const totalDuplicatesCount =
    (report?.duplicateAtletasGroups.reduce((acc, g) => acc + g.duplicates.length, 0) || 0) +
    (report?.duplicateInscricoes.length || 0) +
    (report?.duplicateArbitros.reduce((acc, g) => acc + g.duplicates.length, 0) || 0) +
    (report?.duplicateTreinadores.reduce((acc, g) => acc + g.duplicates.length, 0) || 0) +
    (report?.duplicateFuncionarios.reduce((acc, g) => acc + g.duplicates.length, 0) || 0) +
    (report?.duplicateCategorias.reduce((acc, g) => acc + g.duplicates.length, 0) || 0) +
    (report?.duplicateTorneios.reduce((acc, g) => acc + g.duplicates.length, 0) || 0);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-100 flex items-center gap-2">
                Verificação e Exclusão de Registros Duplicados
              </h3>
              <p className="text-xs text-slate-400">
                Detecta e mescla atletas, inscrições, árbitros e tabelas duplicadas no banco de dados.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-700/50 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300">
          {/* Summary Status Box */}
          {report?.hasDuplicates ? (
            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-bold text-amber-200">
                  Foram encontrados {totalDuplicatesCount} registro(s) duplicado(s)!
                </h4>
                <p className="text-xs text-amber-300/80 mt-1">
                  Ao confirmar a limpeza, o sistema mesclará os cadastros (mantendo telefones, e-mails e CPF) e reescreverá as inscrições para o cadastro principal.
                </p>
              </div>
              <button
                type="button"
                onClick={handleRefresh}
                className="p-2 text-slate-300 hover:text-white bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 transition"
                title="Refazer Varredura"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <h4 className="font-bold text-emerald-200">Nenhum registro duplicado detectado!</h4>
                <p className="text-xs text-emerald-300/80">
                  Todos os atletas, inscrições, árbitros e categorias do sistema estão limpos e sem duplicidades.
                </p>
              </div>
            </div>
          )}

          {/* Breakdown Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-center">
              <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 mb-1">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                Atletas Duplicados
              </div>
              <span className={`text-xl font-black ${report?.duplicateAtletasGroups.length ? 'text-rose-400' : 'text-emerald-400'}`}>
                {report?.duplicateAtletasGroups.reduce((acc, g) => acc + g.duplicates.length, 0) || 0}
              </span>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-center">
              <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 mb-1">
                <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                Inscrições Duplicadas
              </div>
              <span className={`text-xl font-black ${report?.duplicateInscricoes.length ? 'text-rose-400' : 'text-emerald-400'}`}>
                {report?.duplicateInscricoes.length || 0}
              </span>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-center">
              <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 mb-1">
                <Shield className="w-3.5 h-3.5 text-sky-400" />
                Árbitros Duplicados
              </div>
              <span className={`text-xl font-black ${report?.duplicateArbitros.length ? 'text-rose-400' : 'text-emerald-400'}`}>
                {report?.duplicateArbitros.reduce((acc, g) => acc + g.duplicates.length, 0) || 0}
              </span>
            </div>

            <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl text-center">
              <div className="flex items-center justify-center gap-1.5 text-xs text-slate-400 mb-1">
                <Layers className="w-3.5 h-3.5 text-purple-400" />
                Categorias / Outros
              </div>
              <span className={`text-xl font-black ${(report?.duplicateCategorias.length || 0) + (report?.duplicateTorneios.length || 0) ? 'text-rose-400' : 'text-emerald-400'}`}>
                {(report?.duplicateCategorias.length || 0) + (report?.duplicateTorneios.length || 0)}
              </span>
            </div>
          </div>

          {/* Details List */}
          {report?.hasDuplicates && (
            <div className="space-y-4 pt-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
                Lista de Registros Duplicados Encontrados:
              </h4>

              {/* Atletas List */}
              {report.duplicateAtletasGroups.length > 0 && (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2">
                  <div className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                    <Users className="w-4 h-4" />
                    Atletas Duplicados ({report.duplicateAtletasGroups.length} grupo(s))
                  </div>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {report.duplicateAtletasGroups.map((group, idx) => (
                      <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs">
                        <div className="flex items-center justify-between font-bold text-slate-200">
                          <span>Principal: {group.primary.nome} ({group.primary.clube || 'Sem clube'})</span>
                          <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded border border-amber-500/20">
                            {group.reason}
                          </span>
                        </div>
                        <div className="mt-1.5 text-slate-400 text-[11px] space-y-0.5 border-t border-slate-800/80 pt-1.5">
                          {group.duplicates.map(d => (
                            <div key={d.id} className="flex items-center justify-between text-rose-300/80">
                              <span>• Duplicado: {d.nome} [ID: {d.id}] - {d.clube}</span>
                              <span className="text-[10px] text-rose-400">Será mesclado/removido</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Inscricoes List */}
              {report.duplicateInscricoes.length > 0 && (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4" />
                    Inscrições Duplicadas ({report.duplicateInscricoes.length})
                  </div>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {report.duplicateInscricoes.map((ins, idx) => {
                      const atl = atletas.find(a => a.id === ins.duplicate.atletaId);
                      return (
                        <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs flex items-center justify-between text-slate-300">
                          <span>Inscrição em {ins.duplicate.categoria} para <strong>{atl?.nome || ins.duplicate.atletaId}</strong></span>
                          <span className="text-rose-400 font-bold text-[10px]">Será removida</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Arbitros List */}
              {report.duplicateArbitros.length > 0 && (
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2">
                  <div className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" />
                    Árbitros Duplicados ({report.duplicateArbitros.length})
                  </div>
                  <div className="space-y-1.5 max-h-32 overflow-y-auto">
                    {report.duplicateArbitros.map((g, idx) => (
                      <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs flex items-center justify-between">
                        <span>{g.primary.nome} ({g.reason})</span>
                        <span className="text-rose-400 text-[10px]">Será mesclado</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-800/80 border-t border-slate-700/80 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            Fechar
          </button>

          <button
            type="button"
            onClick={handleExecuteCleanup}
            disabled={!report?.hasDuplicates || isProcessing}
            className="px-5 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:hover:bg-rose-600 text-white text-xs font-black rounded-xl transition flex items-center gap-2 shadow-lg shadow-rose-900/20 cursor-pointer"
          >
            <Trash2 className={`w-4 h-4 ${isProcessing ? 'animate-bounce' : ''}`} />
            {isProcessing ? 'Processando Exclusão...' : 'Deletar & Mesclar Registros Duplicados'}
          </button>
        </div>
      </div>
    </div>
  );
}
