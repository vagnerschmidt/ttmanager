import React, { useState } from 'react';
import { Arbitro, Resultado } from '../types';
import { 
  Search, Plus, Edit, Trash2, UserCheck, Save, X, Camera, Upload,
  ArrowUp, ArrowDown, Clock, ArrowRight, Copy, Send, Share2, Printer, Shield, Check, AlertTriangle
} from 'lucide-react';
import PhotoCaptureModal from './PhotoCaptureModal';
import DateInput from './DateInput';
import { triggerToast } from '../utils/toast';
import { normalizePhoneToBrazil } from '../utils/phone';

interface ArbitrosViewProps {
  arbitros: Arbitro[];
  resultados: Resultado[];
  onSave: (arbitro: Arbitro) => void;
  onDelete: (id: string) => void;
  refereeQueue?: string[];
  onUpdateRefereeQueue?: (queue: string[]) => void;
  onUpdateArbitro?: (arbitro: Arbitro) => void;
  userRole?: string;
}

export default function ArbitrosView({ 
  arbitros, 
  resultados, 
  onSave, 
  onDelete,
  refereeQueue = [],
  onUpdateRefereeQueue,
  onUpdateArbitro
}: ArbitrosViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLevel, setFilterLevel] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCamOpen, setIsCamOpen] = useState(false);
  const [selectedQueueInsertId, setSelectedQueueInsertId] = useState('');

  // Queue helper handlers
  const moveQueue = (index: number, direction: 'up' | 'down') => {
    if (!onUpdateRefereeQueue) return;
    const newQueue = [...refereeQueue];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= newQueue.length) return;
    
    // Swap element nodes
    const temp = newQueue[index];
    newQueue[index] = newQueue[targetIdx];
    newQueue[targetIdx] = temp;
    onUpdateRefereeQueue(newQueue);
  };

  const removeFromQueueInternal = (id: string) => {
    if (!onUpdateRefereeQueue) return;
    onUpdateRefereeQueue(refereeQueue.filter(qId => qId !== id));
  };

  const addToQueueInternal = (id: string) => {
    if (!onUpdateRefereeQueue || !id) return;
    if (!refereeQueue.includes(id)) {
      onUpdateRefereeQueue([...refereeQueue, id]);
    }
  };

  // Form states
  const [formId, setFormId] = useState('');
  const [formNome, setFormNome] = useState('');
  const [formNasc, setFormNasc] = useState('');
  const [formCpf, setFormCpf] = useState('');
  const [formNivel, setFormNivel] = useState('Nacional');
  const [formCbtt, setFormCbtt] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formWa, setFormWa] = useState('');
  const [formTel, setFormTel] = useState('');
  const [formStatus, setFormStatus] = useState('Disponível');
  const [formVal, setFormVal] = useState('0');
  const [formObs, setFormObs] = useState('');
  const [formFoto, setFormFoto] = useState('');
  const [formPresenca, setFormPresenca] = useState('CONFIRMADA');
  const [formPagamento, setFormPagamento] = useState('PAGO');
  const [filterPresenca, setFilterPresenca] = useState('');
  const [filterPagamento, setFilterPagamento] = useState('');

  const handleOpenModal = (a?: Arbitro) => {
    if (a) {
      setFormId(a.id);
      setFormNome(a.nome);
      setFormNasc(a.nasc || '');
      setFormCpf(a.cpf || '');
      setFormNivel(a.nivel || 'Nacional');
      setFormCbtt(a.cbtt || '');
      setFormEmail(a.email || '');
      setFormWa(a.wa || '');
      setFormTel(a.tel || '');
      setFormStatus(a.status || 'Disponível');
      setFormVal(a.val || '0');
      setFormObs(a.obs || '');
      setFormFoto(a.foto || '');
      setFormPresenca(a.presenca || 'CONFIRMADA');
      setFormPagamento(a.pagamento || 'PAGO');
    } else {
      setFormId('');
      setFormNome('');
      setFormNasc('');
      setFormCpf('');
      setFormNivel('Nacional');
      setFormCbtt('');
      setFormEmail('');
      setFormWa('');
      setFormTel('');
      setFormStatus('Disponível');
      setFormVal('0');
      setFormObs('');
      setFormFoto('');
      setFormPresenca('CONFIRMADA');
      setFormPagamento('PAGO');
    }
    setIsModalOpen(true);
  };

  const maskCpf = (val: string) => {
    let clean = val.replace(/\D/g, '').slice(0, 11);
    clean = clean.replace(/(\d{3})(\d)/, '$1.$2')
                 .replace(/(\d{3})(\d)/, '$1.$2')
                 .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    return clean;
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (upEv) => {
        if (upEv.target?.result) {
          setFormFoto(upEv.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!formNome.trim()) {
      alert("Nome do árbitro é obrigatório!");
      return;
    }
    const targetId = formId || 'arb_' + Date.now().toString(36);
    onSave({
      id: targetId,
      nome: formNome,
      nasc: formNasc,
      cpf: formCpf,
      nivel: formNivel,
      cbtt: formCbtt,
      email: formEmail,
      wa: normalizePhoneToBrazil(formWa),
      tel: normalizePhoneToBrazil(formTel),
      status: formStatus,
      val: formVal,
      obs: formObs,
      foto: formFoto,
      presenca: formPresenca,
      pagamento: formPagamento
    });
    setIsModalOpen(false);
  };

  const filteredArbitros = arbitros.filter(a => {
    const matchesSearch = a.nome.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (a.email && a.email.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (a.cbtt && a.cbtt.includes(searchQuery));
    const matchesLevel = !filterLevel || a.nivel === filterLevel;
    const matchesStatus = !filterStatus || a.status === filterStatus;
    
    const itemPresenca = a.presenca || 'CONFIRMADA';
    const itemPagamento = a.pagamento || 'PAGO';
    const matchesPresenca = !filterPresenca || itemPresenca === filterPresenca;
    const matchesPagamento = !filterPagamento || itemPagamento === filterPagamento;

    return matchesSearch && matchesLevel && matchesStatus && matchesPresenca && matchesPagamento;
  });

  return (
    <div className="space-y-6">
      {/* CARD: ENVIAR CONVITE AUTO-REGISTRO ÁRBITROS */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between shadow-md relative overflow-hidden select-none">
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/5 rounded-full blur-2xl -z-10 pointer-events-none" />
        <div className="flex items-center gap-3 text-left">
          <div className="w-8 h-8 bg-yellow-400/10 text-yellow-400 rounded-lg flex items-center justify-center border border-yellow-500/20 shrink-0">
            <Shield className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="space-y-0.5 ml-0.5">
            <h3 className="text-xs font-bold text-slate-100 uppercase tracking-tight">Convide Árbitros para Auto-Cadastro</h3>
            <p className="text-2xs text-slate-400 leading-relaxed max-w-md font-medium">
              Envie o link oficial para que os árbitros se cadastrem diretamente no sistema. Eles entrarão como pendentes de chamada física e homologação.
            </p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
          <button
            type="button"
            onClick={() => {
              const url = `${window.location.origin}${window.location.pathname}?autoReg=true&role=arbitro`;
              navigator.clipboard.writeText(url)
                .then(() => triggerToast('Link de cadastro de árbitros copiado!', 'success'))
                .catch(() => triggerToast('Falha ao copiar link!', 'error'));
            }}
            className="flex items-center justify-center gap-1.5 bg-slate-950 border border-slate-800 hover:bg-slate-850 text-slate-300 hover:text-white rounded-lg px-3 py-1.5 text-xs font-bold transition cursor-pointer"
            title="Copiar Link de Formulário de Árbitros"
          >
            <Copy className="w-3.5 h-3.5 text-yellow-400" />
            <span>COPIAR LINK</span>
          </button>

          <button
            type="button"
            onClick={() => {
              const url = `${window.location.origin}${window.location.pathname}?autoReg=true&role=arbitro`;
              const msg = `Olá! 🏓 Faça agora mesmo o seu Auto-Cadastro oficial de Árbitro no sistema para trabalhar na mesa coordenadora e marcar partidas do nosso torneio!

Acesse o link abaixo para preencher os seus dados profissionais:
🔗 ${url}

*IMPORTANTE:* Após enviar o formulário, o cadastro ficará como *PENDENTE* no painel central da comissão, liberado imediatamente após a sua *CONFIRMAÇÃO DE PRESENÇA* física no dia de jogos e a *COMPROVAÇÃO DE PAGAMENTO DA TAXA* (se aplicável) junto ao conselho de arbitragem.`;
              window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
            }}
            className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg px-3 py-1.5 text-xs transition cursor-pointer tracking-wider"
            title="Enviar convite para árbitros no WhatsApp"
          >
            <Send className="w-3.5 h-3.5 text-white" />
            <span>ENVIAR NO WHATSAPP</span>
          </button>
        </div>
      </div>

      {/* Configuration Header Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5 justify-between items-center bg-slate-900 p-3 border border-slate-800 rounded-xl">
        <div className="flex flex-wrap sm:flex-nowrap gap-2 w-full sm:flex-1">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar árbitro por nome, e-mail, CBTT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-100 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none transition"
            />
          </div>

          <select
            value={filterLevel}
            onChange={(e) => setFilterLevel(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none transition"
          >
            <option value="">Todos níveis</option>
            <option value="Nacional">Nacional</option>
            <option value="Estadual">Estadual</option>
            <option value="Regional">Regional</option>
            <option value="Local">Local</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none transition"
          >
            <option value="">Todos os status</option>
            <option value="Disponível">Disponível</option>
            <option value="Em Jogo">Em Jogo</option>
            <option value="Indisponível">Indisponível</option>
          </select>

          {/* Presença filter */}
          <select
            value={filterPresenca}
            onChange={(e) => setFilterPresenca(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none transition"
          >
            <option value="">Todas Presenças</option>
            <option value="CONFIRMADA">✓ Confirmada</option>
            <option value="PENDENTE">⚠ Pendente</option>
            <option value="AUSENTE">✗ Ausente</option>
          </select>

          {/* Pagamento filter */}
          <select
            value={filterPagamento}
            onChange={(e) => setFilterPagamento(e.target.value)}
            className="bg-slate-950 border border-slate-800 focus:border-yellow-400 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none transition"
          >
            <option value="">Todos Pagamentos</option>
            <option value="PAGO">✓ Pago</option>
            <option value="PENDENTE">⚠ Pendente</option>
            <option value="ISENTO">✦ Isento</option>
          </select>
        </div>

        <button
          onClick={() => handleOpenModal()}
          className="w-full sm:w-auto bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center justify-center gap-1.5 cursor-pointer transition shadow shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          Novo Árbitro
        </button>
      </div>

      {/* Grid Layout separating Main List vs Referee Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Left Column: Registered Referees Table */}
        <div className="lg:col-span-2 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs text-slate-200">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/40 text-slate-400 text-[10px] uppercase tracking-wider font-semibold">
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">Árbitro</th>
                    <th className="py-2.5 px-3">Nível</th>
                    <th className="py-2.5 px-3">CBTT</th>
                    <th className="py-2.5 px-3">E-mail</th>
                    <th className="py-2.5 px-3">Telefone / WA</th>
                    <th className="py-2.5 px-3 text-center">Jogos</th>
                    <th className="py-2.5 px-3 text-center">Tarifa/h</th>
                    <th className="py-2.5 px-3 text-center">Validação (Presença / Taxa)</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-center w-24">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredArbitros.length > 0 ? (
                    filteredArbitros.map((a, i) => {
                      const matchCount = resultados.filter(r => r.arb === a.nome).length;
                      const isInQueue = refereeQueue.includes(a.id);
                      const queueIndex = refereeQueue.indexOf(a.id);
                      return (
                        <tr key={a.id} className="hover:bg-slate-950/20 transition-colors">
                          <td className="py-2 px-3 text-center text-slate-500 font-mono text-[11px]">{i+1}</td>
                          <td className="py-2 px-3 font-bold text-slate-100 flex items-center gap-2">
                            {a.foto ? (
                              <img src={a.foto} className="w-7 h-7 rounded-full object-cover border border-slate-700 shrink-0" alt={a.nome} />
                            ) : (
                              <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-[10px] text-slate-300 shrink-0">
                                {a.nome[0].toUpperCase()}
                              </div>
                            )}
                            <div className="flex flex-col min-w-0">
                              <span className="truncate max-w-[150px]">{a.nome}</span>
                              {isInQueue && (
                                <span className="text-[9px] text-yellow-400 font-bold font-mono mt-0.5">
                                  {queueIndex + 1}º NA FILA
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-2 px-3 text-[11px] whitespace-nowrap">
                            <span className="bg-yellow-400/10 text-yellow-400 border border-yellow-400/20 px-1.5 py-0.5 rounded text-[10px] font-bold">
                              {a.nivel}
                            </span>
                          </td>
                          <td className="py-2 px-3 font-mono text-slate-400 text-[11px]">{a.cbtt || '—'}</td>
                          <td className="py-2 px-3 text-slate-300 text-[11px] truncate max-w-[120px]">{a.email || '—'}</td>
                          <td className="py-2 px-3 text-slate-400 font-mono text-[11px] whitespace-nowrap">{a.wa || a.tel || '—'}</td>
                          <td className="py-2 px-3 text-center font-bold text-slate-300 font-mono text-[11px]">{matchCount}</td>
                          <td className="py-2 px-3 text-center font-mono text-slate-300 text-[11px]">
                            R$ {Number(a.val || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                           </td>
                           <td className="py-2 px-3 text-center whitespace-nowrap">
                             <div className="flex flex-col items-center gap-0.5 select-none">
                               <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-1 cursor-pointer transition ${
                                 (a.presenca || 'CONFIRMADA') === 'CONFIRMADA'
                                   ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-400/25'
                                   : (a.presenca || 'CONFIRMADA') === 'AUSENTE'
                                   ? 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-550/25'
                                   : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 hover:bg-yellow-500/25'
                               }`}
                               onClick={() => {
                                 const current = a.presenca || 'CONFIRMADA';
                                 const next = current === 'CONFIRMADA' ? 'PENDENTE' : current === 'PENDENTE' ? 'AUSENTE' : 'CONFIRMADA';
                                 onUpdateArbitro ? onUpdateArbitro({ ...a, presenca: next }) : onSave({ ...a, presenca: next });
                                 triggerToast(`Presença de ${a.nome} alterada para ${next}`, 'success');
                               }}
                               title="Alternar Presença Física"
                               >
                                 {(a.presenca || 'CONFIRMADA') === 'CONFIRMADA' ? '✓ PRESENTE' : (a.presenca || 'CONFIRMADA') === 'AUSENTE' ? '✗ AUSENTE' : '⚠ PENDENTE'}
                               </span>
                               
                               <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded flex items-center gap-1 cursor-pointer transition ${
                                 (a.pagamento || 'PAGO') === 'PAGO'
                                   ? 'bg-green-500/10 text-green-300 border border-green-500/20 hover:bg-green-500/25'
                                   : (a.pagamento || 'PAGO') === 'ISENTO'
                                   ? 'bg-indigo-505/10 text-indigo-400 border border-indigo-500/20 hover:bg-indigo-500/25'
                                   : 'bg-red-500/15 text-red-400 border border-red-500/20 animate-pulse hover:bg-red-500/25'
                               }`}
                               onClick={() => {
                                 const current = a.pagamento || 'PAGO';
                                 const next = current === 'PAGO' ? 'PENDENTE' : current === 'PENDENTE' ? 'ISENTO' : 'PAGO';
                                 onUpdateArbitro ? onUpdateArbitro({ ...a, pagamento: next }) : onSave({ ...a, pagamento: next });
                                 triggerToast(`Pagamento de ${a.nome} alterado para ${next}`, 'success');
                               }}
                               title="Alternar Status de Pagamento"
                               >
                                 {(a.pagamento || 'PAGO') === 'PAGO' ? '✓ TAXA PAGA' : (a.pagamento || 'PAGO') === 'ISENTO' ? '✦ ISENTO' : '⚠ PENDENTE'}
                               </span>
                             </div>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-full ${
                              a.status === 'Disponível' || a.status === 'DISPONÍVEL'
                                ? 'bg-emerald-400/10 text-emerald-400' 
                                : a.status === 'Em Jogo' || a.status === 'EM JOGO'
                                ? 'bg-blue-400/10 text-blue-400'
                                : a.status === 'Convocado' || a.status === 'CONVOCADO'
                                ? 'bg-amber-400/10 text-amber-400 animate-pulse'
                                : 'bg-red-500/10 text-red-500'
                            }`}>
                              {a.status}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              {/* Add to queue action */}
                              {!isInQueue && (a.status === 'Disponível' || a.status === 'DISPONÍVEL') && (
                                <button
                                  onClick={() => addToQueueInternal(a.id)}
                                  className="p-1 px-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold rounded text-[9px] uppercase cursor-pointer"
                                  title="Posicionar na Fila"
                                >
                                  + FILA
                                </button>
                              )}
                              <button
                                onClick={() => handleOpenModal(a)}
                                className="p-1 text-slate-400 hover:text-yellow-400 hover:bg-slate-800 rounded transition"
                                title="Editar"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`Deseja mesmo remover o árbitro "${a.nome}"?`)) {
                                    onDelete(a.id);
                                  }
                                }}
                                className="p-1 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition-colors"
                                title="Excluir"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-slate-500 text-xs">
                        Nenhum árbitro encontrado.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Referee Waitlist Priority Queue Panel */}
        <div className="space-y-3">
          <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl space-y-3 shadow-sm flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <h3 className="font-bold text-slate-100 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <Clock className="w-3.5 h-3.5 text-yellow-400" />
                Fila de Espera de Árbitros
              </h3>
              <span className="bg-slate-950 border border-slate-850 px-2 py-0.5 text-[9px] font-mono font-bold text-yellow-400 rounded-full">
                {refereeQueue.length} EM ESPERA
              </span>
            </div>

            {/* Waiting item cards container */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {refereeQueue.length > 0 ? (
                refereeQueue.map((qId, idx) => {
                  const refObj = arbitros.find(ab => ab.id === qId);
                  if (!refObj) return null;
                  return (
                    <div 
                      key={qId} 
                      className={`flex items-center gap-2.5 bg-slate-950 p-2 rounded-lg border relative transition-all ${
                        refObj.status === 'Convocado' || refObj.status === 'CONVOCADO'
                          ? 'border-amber-400/50 bg-amber-400/5'
                          : 'border-slate-850 hover:border-slate-750'
                      }`}
                    >
                      {/* Priority queue identifier badge */}
                      <div className="h-5 w-5 font-mono text-[10px] rounded-full flex items-center justify-center bg-yellow-400 text-slate-950 font-extrabold shrink-0">
                        {idx + 1}º
                      </div>

                      {/* Photo or letters */}
                      {refObj.foto ? (
                        <img src={refObj.foto} className="w-7 h-7 rounded-full object-cover border border-slate-750 shrink-0" alt={refObj.nome} />
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-[10px] text-slate-400 shrink-0">
                          {refObj.nome[0].toUpperCase()}
                        </div>
                      )}

                      {/* Referee layout */}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-xs text-slate-200 truncate leading-tight uppercase pr-2">
                          {refObj.nome}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[9px] bg-slate-900 text-slate-400 border border-slate-800/80 px-1 py-0.2 rounded font-bold">
                            {refObj.nivel}
                          </span>
                          <span className={`h-1.5 w-1.5 rounded-full ${
                            refObj.status === 'Convocado' || refObj.status === 'CONVOCADO'
                              ? 'bg-amber-400 animate-ping'
                              : 'bg-emerald-400'
                          }`} />
                        </div>
                      </div>

                      {/* Interactive order action tray buttons */}
                      <div className="flex items-center gap-0.5 shrink-0">
                        {idx > 0 && (
                          <button
                            onClick={() => moveQueue(idx, 'up')}
                            className="p-1 text-slate-400 hover:text-yellow-400 hover:bg-slate-900 rounded cursor-pointer transition"
                            title="Subir de Posição (Priorizar)"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {idx < refereeQueue.length - 1 && (
                          <button
                            onClick={() => moveQueue(idx, 'down')}
                            className="p-1 text-slate-400 hover:text-yellow-400 hover:bg-slate-900 rounded cursor-pointer transition"
                            title="Descer de Posição"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => removeFromQueueInternal(qId)}
                          className="p-1 text-slate-500 hover:text-red-400 hover:bg-slate-900 rounded cursor-pointer transition"
                          title="Remover da Fila"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-6 bg-slate-950 rounded-lg border border-slate-850">
                  <span className="text-[11px] text-slate-500 font-medium block px-2 leading-relaxed">
                    Nenhum árbitro posicionado na fila de espera.
                  </span>
                </div>
              )}
            </div>

            {/* Ingress addition widget select box dropdown */}
            <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-850 space-y-1.5 mt-1">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                Convidar Árbitro para Fila
              </label>
              <div className="flex gap-1.5">
                <select
                  value={selectedQueueInsertId}
                  onChange={(e) => setSelectedQueueInsertId(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2 py-1 text-xs outline-none focus:border-yellow-400 font-medium"
                >
                  <option value="">Selecione Árbitro...</option>
                  {arbitros
                    .filter(ar => !refereeQueue.includes(ar.id) && (ar.status === 'Disponível' || ar.status === 'DISPONÍVEL'))
                    .map(ar => (
                      <option key={ar.id} value={ar.id}>
                        {ar.nome} ({ar.nivel})
                      </option>
                    ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    if (selectedQueueInsertId) {
                      addToQueueInternal(selectedQueueInsertId);
                      setSelectedQueueInsertId('');
                    }
                  }}
                  disabled={!selectedQueueInsertId}
                  className="bg-yellow-400 hover:bg-yellow-300 disabled:opacity-40 disabled:hover:bg-yellow-400 text-slate-950 font-bold px-2.5 py-1 rounded-lg text-xs cursor-pointer transition flex items-center gap-1 shrink-0"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  Alocar
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* REFEREE FORM MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-xl w-full max-w-lg overflow-hidden flex flex-col shadow-2xl">
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/25">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-yellow-400" />
                {formId ? 'Editar Árbitro' : 'Novo Árbitro'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-100 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form body */}
            <div className="p-4 overflow-y-auto space-y-3 max-h-[80vh]">
              
              {/* Photo component inside referee form */}
              <div className="flex gap-3 items-center bg-slate-950/30 p-2.5 border border-slate-800/80 rounded-xl">
                <div className="relative w-16 h-20 border border-dashed border-slate-700 hover:border-yellow-400/80 rounded flex flex-col items-center justify-center bg-slate-950 overflow-hidden shrink-0 group">
                  {formFoto ? (
                    <>
                      <img src={formFoto} alt="Cap" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex flex-col items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => setIsCamOpen(true)}
                          className="px-1.5 py-0.5 bg-yellow-400 text-slate-950 text-4xs font-bold rounded"
                        >
                          Tirar
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormFoto('')}
                          className="px-1.5 py-0.5 bg-red-600 text-white text-4xs font-bold rounded"
                        >
                          Limpar
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="text-slate-400 text-center flex flex-col items-center pointer-events-none">
                      <Camera className="w-4 h-4 mb-1" />
                      <span className="text-[9px] uppercase tracking-wider font-bold">Foto</span>
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Mídia de Perfil</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCamOpen(true)}
                      className="px-2.5 py-1 bg-slate-800 font-bold text-slate-200 border border-slate-700 rounded-md text-xs hover:bg-slate-700 transition flex items-center gap-1.5"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      Tirar foto
                    </button>
                    <label className="px-2.5 py-1 bg-slate-800 font-bold text-slate-200 border border-slate-700 rounded-md text-xs hover:bg-slate-700 transition flex items-center gap-1.5 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      Upload
                      <input type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
                    </label>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Nome Completo *</label>
                <input
                  type="text"
                  placeholder="NOME DO ÁRBITRO OFICIAL"
                  value={formNome}
                  onChange={(e) => setFormNome(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <DateInput
                  label="Data de Nascimento"
                  value={formNasc}
                  onChange={(val) => setFormNasc(val)}
                />
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">CPF</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="000.000.000-00"
                    value={formCpf}
                    onChange={(e) => setFormCpf(maskCpf(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Nível CBTT</label>
                  <select
                    value={formNivel}
                    onChange={(e) => setFormNivel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Nacional">Nacional</option>
                    <option value="Estadual">Estadual</option>
                    <option value="Regional">Regional</option>
                    <option value="Local">Local</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Código CBTT</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="Nº REGISTRO"
                    value={formCbtt}
                    onChange={(e) => setFormCbtt(e.target.value.toUpperCase())}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">E-mail</label>
                  <input
                    type="email"
                    placeholder="NOME@ARBITRO.COM"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value.toUpperCase())}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder:text-slate-600 focus:border-yellow-400 outline-none uppercase"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">WhatsApp</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="+55 11 99999-9999"
                    value={formWa}
                    onChange={(e) => setFormWa(e.target.value.toUpperCase())}
                    onBlur={() => setFormWa(prev => normalizePhoneToBrazil(prev))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none uppercase font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Telefone Comercial</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    placeholder="(11) 3333-4444"
                    value={formTel}
                    onChange={(e) => setFormTel(e.target.value.toUpperCase())}
                    onBlur={() => setFormTel(prev => normalizePhoneToBrazil(prev))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none uppercase font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Tarifa por Hora (R$)</label>
                  <input
                    type="number"
                    inputMode="decimal"
                    step="0.01"
                    placeholder="0.00"
                    value={formVal}
                    onChange={(e) => setFormVal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-100"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Status em Torneio</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="Disponível">Disponível</option>
                    <option value="Em Jogo">Em Jogo</option>
                    <option value="Indisponível">Indisponível</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Presença Física (Credenciamento)</label>
                  <select 
                    value={formPresenca}
                    onChange={(e) => setFormPresenca(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="CONFIRMADA">✓ CONFIRMADA / PRESENTE</option>
                    <option value="PENDENTE">⚠ PENDENTE</option>
                    <option value="AUSENTE">✗ AUSENTE</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block font-sans">Homologação de Taxa</label>
                  <select 
                    value={formPagamento}
                    onChange={(e) => setFormPagamento(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none"
                  >
                    <option value="PAGO">✓ PAGO</option>
                    <option value="PENDENTE">⚠ PENDENTE</option>
                    <option value="ISENTO">✦ ISENTO</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Notas / Horários de Trabalho</label>
                <textarea
                  rows={2}
                  placeholder="SELECIONE HORÁRIOS DE VISTORIAS PREFERENCIAIS OU NOTAS DO SUPERVISOR CHEFE..."
                  value={formObs}
                  onChange={(e) => setFormObs(e.target.value.toUpperCase())}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 focus:border-yellow-400 outline-none resize-none"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-800 flex justify-end gap-3 bg-slate-950/25">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-755 text-xs font-bold rounded-lg transition"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-slate-950 text-xs font-black rounded-lg transition flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Árbitro
              </button>
            </div>
          </div>
        </div>
      )}

      {/* WEB CAMERA COMPONENT */}
      {isCamOpen && (
        <PhotoCaptureModal 
          onCapture={(snapUrl) => setFormFoto(snapUrl)}
          onClose={() => setIsCamOpen(false)}
        />
      )}
    </div>
  );
}
