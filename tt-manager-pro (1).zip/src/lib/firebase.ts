import { initializeApp } from 'firebase/app';
import { 
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs, 
  writeBatch 
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase using values from configuration file
const app = initializeApp(firebaseConfig);

const isIframe = typeof window !== 'undefined' && (window.self !== window.top || (window.location && (window.location.ancestorOrigins?.length || 0) > 0));

const firestoreOptions: any = {};

if ((firebaseConfig as any).firestoreDatabaseId) {
  firestoreOptions.databaseId = (firebaseConfig as any).firestoreDatabaseId;
}

if (!isIframe) {
  try {
    firestoreOptions.localCache = persistentLocalCache({
      tabManager: persistentMultipleTabManager()
    });
  } catch (cacheErr) {
    console.warn('[Firebase] Não foi possível ativar o cache local persistente:', cacheErr);
  }
} else {
  console.log('[Firebase] Executando em ambiente iframe/sandbox. Cache local persistente desativado para máxima performance e evitar bloqueios de tab-sync.');
}

let db: any;
try {
  db = initializeFirestore(app, firestoreOptions);
} catch (initErr) {
  console.warn('[Firebase] Falha ao inicializar o Firestore com as opções especificadas. Tentando inicialização padrão simples...', initErr);
  db = initializeFirestore(app, {
    databaseId: (firebaseConfig as any).firestoreDatabaseId
  } as any);
}

export { db };

// Interface of entire system state for sync
export interface FullSystemState {
  atletas: any[];
  categorias: any[];
  torneios: any[];
  arbitros: any[];
  resultados: any[];
  funcionarios: any[];
  treinadores: any[];
  inscricoes: any[];
  config: any;
  registeredUsers: any[];
  refereeQueue: string[];
}

/**
 * Helper to recursively remove undefined properties from objects
 * so Firestore setDoc / writeBatch does not throw errors.
 */
function cleanFirestoreData(data: any): any {
  if (data === undefined) return null;
  if (data === null || typeof data !== 'object') return data;
  if (Array.isArray(data)) {
    return data.map(cleanFirestoreData);
  }
  const cleanObj: Record<string, any> = {};
  for (const [key, val] of Object.entries(data)) {
    if (val !== undefined) {
      cleanObj[key] = cleanFirestoreData(val);
    }
  }
  return cleanObj;
}

/**
 * Timeout helper to prevent infinite loading
 */
function withTimeout<T>(promise: Promise<T>, ms: number = 35000): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Conexão com o Firestore temporariamente lenta (timeout de 35s). Seus dados continuam salvos com segurança localmente no IndexedDB e serão sincronizados automaticamente.'));
    }, ms);

    promise
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

/**
 * Uploads all local system data to Firestore in a structured format
 */
export async function uploadStateToFirebase(state: FullSystemState): Promise<void> {
  const cleanState = cleanFirestoreData(state);

  // 1. Unified full state document (single write, guarantees exact restore)
  const unifiedDataRef = doc(db, 'system_data', 'main_database');
  const uploadUnifiedPromise = setDoc(unifiedDataRef, {
    atletas: cleanState.atletas || [],
    categorias: cleanState.categorias || [],
    torneios: cleanState.torneios || [],
    arbitros: cleanState.arbitros || [],
    resultados: cleanState.resultados || [],
    funcionarios: cleanState.funcionarios || [],
    treinadores: cleanState.treinadores || [],
    inscricoes: cleanState.inscricoes || [],
    config: cleanState.config || {},
    registeredUsers: cleanState.registeredUsers || [],
    refereeQueue: cleanState.refereeQueue || [],
    syncedAt: new Date().toISOString()
  });

  await withTimeout(uploadUnifiedPromise, 35000);

  // 2. Metadata snapshot
  const snapshotRef = doc(db, 'system_metadata', 'snapshot');
  setDoc(snapshotRef, {
    lastUpdated: new Date().toISOString(),
    theme: cleanState.config?.theme || 'dark',
    refereeQueue: cleanState.refereeQueue || []
  }).catch((e) => console.warn('Snapshot write notice:', e));

  // 3. Write individual collection documents in chunks to avoid Firestore 500 batch limit
  // Executed asynchronously in the background to avoid blocking the main fast upload
  (async () => {
    try {
      const collectionsToSync = [
        { name: 'atletas', items: cleanState.atletas || [] },
        { name: 'categorias', items: cleanState.categorias || [] },
        { name: 'torneios', items: cleanState.torneios || [] },
        { name: 'arbitros', items: cleanState.arbitros || [] },
        { name: 'resultados', items: cleanState.resultados || [] },
        { name: 'funcionarios', items: cleanState.funcionarios || [] },
        { name: 'treinadores', items: cleanState.treinadores || [] },
        { name: 'inscricoes', items: cleanState.inscricoes || [] },
        { name: 'registeredUsers', items: cleanState.registeredUsers || [] }
      ];

      let currentBatch = writeBatch(db);
      let opCount = 0;

      for (const col of collectionsToSync) {
        for (const item of col.items) {
          if (item && item.id) {
            const docRef = doc(db, col.name, String(item.id));
            currentBatch.set(docRef, {
              ...item,
              updatedAt: new Date().toISOString()
            });
            opCount++;

            if (opCount >= 400) {
              await withTimeout(currentBatch.commit(), 15000);
              currentBatch = writeBatch(db);
              opCount = 0;
            }
          }
        }
      }

      if (opCount > 0) {
        await withTimeout(currentBatch.commit(), 15000);
      }
      console.log('[Firebase Sync] Sincronização em segundo plano de itens individuais concluída.');
    } catch (secError) {
      console.warn('[Firebase Sync] Nota sobre sincronização em segundo plano de itens individuais:', secError);
    }
  })();
}

/**
 * Fetches the consolidated state snapshot from Firebase Firestore
 */
export async function downloadStateFromFirebase(): Promise<FullSystemState | null> {
  const docRef = doc(db, 'system_data', 'main_database');
  const docSnap = await withTimeout(getDoc(docRef), 35000);

  if (docSnap.exists()) {
    return docSnap.data() as FullSystemState;
  }
  return null;
}
